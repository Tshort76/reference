(ns soda-jerk-ws.jaeger.cusip-linking.logic
  (:require [soda-jerk-ws.jaeger.service-interop :as svc]
            [clojure.pprint :as pprint]
            [clojure.string :as st]
            [soda-jerk-ws.common.html-utils :as html]))

(def prospectus-keys [:maturity-date :coupon-rate :first-coupon-date :dated-date
                    :coupon-frequency :rate-type :offering-amount :offering-amount-code :where-traded])
(def equity-keys [:currency-code :issuer-name :ticker-symbol :figi-data #_:new-indicator :where-traded])
(def all-keys (distinct (concat prospectus-keys equity-keys)))
(def control-set->fields {:edgar-multi-1000-full    prospectus-keys
                          :edgar-multi-1000         prospectus-keys
                          :edgar-multi-600          prospectus-keys
                          :edgar-cusipless-fun      prospectus-keys
                          :edgar-single-equity-10ks equity-keys
                          :edgar-easy-equities-800  equity-keys
                          :edgar-equity-multi-300   equity-keys})
(def status-order
  [:hidden :alternates :valid :partial :diff :no-soda :no-lm :other-jaeger :no-data])

(defn map-vals [f m]
  (zipmap (keys m)
          (map f (vals m))))

(defn memoized-get-all-jaeger-docs [state soda-api?]
  (when (not (:jaeger-docs @state))
    (swap! state assoc :jaeger-docs [])
    (svc/async-cusip-linking
      (:control-set @state)
      #(swap! state assoc :jaeger-docs %))))

(defn init-state [state]
  (when-not (:sort-type @state)
    (swap! state assoc :sort-type :md5 :sort-order identity))
  (when-not (:page @state)
    (swap! state assoc :page 0 :page-size 50))
  (when-not (:md5-filter @state)
    (swap! state assoc :md5-filter ""))
  (when-not (:important-fields @state)
    (swap! state assoc :important-fields
           (get control-set->fields (keyword (:control-set @state)) all-keys)))
  (when-not (:all-control-sets @state)
    (swap! state assoc :all-control-sets [])
    (svc/async-jaeger-control-sets
      nil #(swap! state assoc :all-control-sets %))))
