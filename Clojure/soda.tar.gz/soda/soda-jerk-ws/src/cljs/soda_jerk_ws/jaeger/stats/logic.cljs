(ns soda-jerk-ws.jaeger.stats.logic
  (:require [soda-jerk-ws.jaeger.service-interop :as svc]
            [clojure.pprint :as pprint]
            [clojure.string :as str]
            [soda-jerk-ws.common.html-utils :as html])
  (:require-macros [soda.core :as soda]))

(def status-order
  [:hidden :alternates :valid :partial :diff :no-soda :no-lm :other-jaeger :no-data])

(defn add-doc-stats [doc field-count]
  (->> doc
       :jaeger-doc
       vals
       (mapcat (comp (partial keep keyword)
                     (juxt :result
                           #(when (:override %) :hidden)
                           #(when (:alternates %) :alternates))))
       frequencies
       ((fn [freqs]
          (assoc freqs :no-data
                 (- field-count
                    (reduce + (vals (dissoc freqs :hidden :alternates)))))))
       (assoc-in doc [:meta :stats])))

(defn update-notary-fields [cusip field value jaeger-doc]
  (if (-> jaeger-doc :meta :cusip (= cusip))
    (-> jaeger-doc
        (assoc-in [:jaeger-doc field :lm] value)
        (assoc-in [:jaeger-doc field :result] (if value "valid" "no-data")))
    jaeger-doc))

(defn calc-agg-stats [docs]
  (->> docs
       (map (comp :stats :meta))
       (reduce (partial merge-with +))))

(defn map-vals [f m]
  (zipmap (keys m)
          (map f (vals m))))

(defn calc-field-stats [docs]
  (let [doc-count (count docs)]
    (->> docs
         (mapcat (comp #(concat % (keep (fn [[k v]]
                                          (cond
                                            (:override v) [k {:result :hidden}]
                                            (:alternates v) [k {:result :alternates}]
                                            :else nil)) %))
                       seq
                       :jaeger-doc))
         (map #(update % 1 (comp keyword :result)))
         (group-by (comp second))
         ((fn [m] (dissoc m nil)))
         (map-vals (comp
                    (partial map-vals count)
                    (partial group-by first)))
         ((fn [result-map]
            (assoc result-map :no-data
                   (->> result-map
                        vals
                        (apply merge-with +)
                        (map-vals (partial - doc-count)))))))))

(defn recalc-all-stats [state docs merge-map]
  (let [field-count (->> docs
                         (mapcat (comp keys :jaeger-doc))
                         distinct
                         count)
        filtered-docs (map #(add-doc-stats % field-count) docs)]
    (merge
     (assoc state
            :jaeger-docs filtered-docs
            :agg-stats (calc-agg-stats filtered-docs)
            :field-stats (calc-field-stats filtered-docs))
     merge-map)))

(defn update-notary-fn [{docs :orig-docs :as state} cusip field value]
  (let [o-docs (map (partial update-notary-fields cusip field value) docs)]
    (recalc-all-stats state o-docs {:orig-docs o-docs})))

(defn update-notary-value [state cusip field soda-val]
  (svc/async-jaeger-notarize
   {:cusip cusip, :field (name field), :value soda-val}
   (fn []
     (swap! state update-notary-fn cusip field soda-val))))

(defn field-filter-fn [[field type-order]]
  (if field
    (comp #{(first type-order)}
          #(or % :no-data)
          keyword
          :result
          field
          :jaeger-doc)
    identity))

(defn filter-docs [jaeger-docs field-sort]
  (filter (field-filter-fn field-sort) jaeger-docs))

(defn change-field-sort [[field-sort order] field status-types]
  [field (if (= field field-sort)
           (-> order rest vec (conj (first order)))
           status-types)])

(defn update-field-sort [state field status-types]
  (-> state
      (update :field-sort change-field-sort field status-types)))

(defn filter-by-cusip [cusip]
  (let [cusip-pattern (some-> cusip
                              (str/replace #"\*" "\\*")
                              re-pattern)]
    (if cusip-pattern
      (fn [doc]
        (->> doc
             :meta
             :cusip
             (re-find cusip-pattern)))
      (constantly true))))

(defn filter-by-ticker [ticker]
  (let [ticker-pattern (some-> ticker
                              (str/replace #"\*" "\\*")
                              re-pattern)]
    (if ticker-pattern
      (fn [doc]
        (->> doc
             :meta
             :ticker
             (re-find ticker-pattern)))
      (constantly true))))

(defn update-jaeger-field [jaeger field]
  (or (some #(when (= jaeger (:jaeger %)) %)
            (cons field
                  (let [core-field (dissoc field :alternates)]
                    (map #(assoc % :override core-field)
                         (:alternates field)))))
      (if (= nil (:jaeger field) (:soda field))
        field
        (assoc field :result "other-jaeger"))))

(defn pre-filter-by-jaeger [docs jaeger]
  (if jaeger
    (let [jaeger-docs (map #(update % :jaeger-doc
                                    (partial map-vals
                                             (partial update-jaeger-field jaeger)))
                           docs)
          field-set (->> jaeger-docs
                         (map (comp
                               (partial map first)
                               (partial filter
                                        (comp
                                         (partial = jaeger)
                                         :jaeger
                                         second))
                               :jaeger-doc))
                         (reduce into #{}))]
      (map (fn [doc]
             (update doc :jaeger-doc select-keys field-set))
           jaeger-docs))
    docs))

(defn update-jaeger-filter [{docs :orig-docs :as state} jaeger]
  (recalc-all-stats state (pre-filter-by-jaeger docs jaeger) {:current-jaeger jaeger}))

(defn field-value-filter [field doc]
  (cond->> doc
           field
           (filter (soda/comp-> second (get field) some?))))

(defn pre-filter-value-fields [docs {:keys [only-soda-fields? only-lm-fields? only-soda-data? only-lm-data?]}]
  (if (or only-soda-fields? only-lm-fields? only-soda-data? only-lm-data?)
    (let [field-set (->> docs
                         (map (soda/comp->>
                               :jaeger-doc
                               (field-value-filter (when only-soda-fields? :soda))
                               (field-value-filter (when only-lm-fields? :lm))
                               (map first)
                               set))
                         (reduce into #{}))]
      (->> (cond->> docs
                    only-soda-data? (filter (fn [{j :jaeger-doc}]
                                              (some (soda/comp-> second :soda some?) j)))
                    only-lm-data? (filter (fn [{j :jaeger-doc}]
                                            (some (soda/comp-> second :lm some?) j))))
           (map (fn [doc]
                  (update doc :jaeger-doc select-keys field-set)))))
    docs))

(defn update-soda-lm-field-filter [{docs :orig-docs :as state} changes]
  (let [state (merge state changes)]
    (recalc-all-stats state
                      (pre-filter-value-fields docs state)
                      {})))

(defn add-all-jaegers [docs]
  (->> docs
       (mapcat (comp
                (partial remove nil?)
                (partial mapcat #(cons (:jaeger %) (map :jaeger (:alternates %))))
                vals
                :jaeger-doc))
       distinct))

(defn memoized-get-all-jaeger-docs [state soda-api?]
  (when (not (:jaeger-docs @state))
    (swap! state assoc :jaeger-docs [])
    (let [jaeger-docs-fn (if soda-api? svc/async-soda-api-stats svc/async-jaeger-stats)]
      (jaeger-docs-fn
        (:control-set @state)
        #(let [clean-docs (filter (comp :cusip :meta) %)
               tickers? (boolean (some (comp :ticker :meta) %))]
           (do (swap! state recalc-all-stats clean-docs
                      {:orig-docs   clean-docs
                       :all-jaegers (add-all-jaegers clean-docs)})
               (swap! state assoc :tickers? tickers?)))))))

(defn init-state [state]
  (when-not (:sort-order @state)
    (swap! state assoc :sort-order
           (mapv
            (fn [s] [:- s])
            status-order)))
  (when-not (:page @state)
    (swap! state assoc :page 0 :page-size 20))
  (when-not (:all-jaegers @state)
    (swap! state assoc :all-jaegers []))
  (when-not (:all-control-sets @state)
    (swap! state assoc :all-control-sets [])
    (svc/async-jaeger-control-sets
     nil #(swap! state assoc :all-control-sets %))))
