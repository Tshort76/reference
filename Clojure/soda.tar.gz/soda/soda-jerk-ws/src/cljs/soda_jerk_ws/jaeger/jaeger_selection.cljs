(ns soda-jerk-ws.jaeger.jaeger-selection
  (:require [soda-jerk-ws.jaeger.service-interop :as svc]
            [soda-jerk-ws.common.html-utils :as html]))

(defn render-vocab-selector [state collection all-collections]
  (html/pretty-wrap
   "Choose a Jaeger Collection"
   [:div.dropdown
    [:button.btn.btn-default.dropdown-toggle
     {:type "button"
      :data-toggle "dropdown"
      :aria-haspopup "true"
      :aria-expanded "true"
      :style {:width "100%" :textAlign "left"}}
     (or collection "No Selection") " " [:span.caret]]
    [:ul.dropdown-menu.scrollable-menu {:style {:width "100%"}}
     (for [coll all-collections]
       [:li {:key coll}
        [:a {:href (str "#jaeger/" coll)} coll]])
     [:li>a {:key nil
             :href "#jaeger/"
             :on-click #(swap! state dissoc :collection)}
      (name "Deselect")]]]))

(defn render-entries [state docs]
  [:table.table.table-condensed.table-hover
   [:thead>tr
    [:th "Filename"]
    [:th "Vocabulary"]
    [:th "Username"]
    [:th "Entry Time"]]
   [:tbody
    (for [{{:keys [filename vocabulary md5 username]} :meta
           id :_id
           :as doc} docs
          :let [ts (some-> id
                           (subs 0 8)
                           (js/parseInt 16)
                           (* 1000)
                           js/Date.)]]
      [:tr {:key id
            :on-click #(set! (.-location js/window)
                         (str "#jaeger/" (:collection @state) "/" md5))
            :title "View this Jaeger Data"
            :style {:cursor "pointer"}}
       [:td (or filename "-")]
       [:td vocabulary]
       [:td username]
       [:td (str ts)]])]])

(defn memoized-get-all-jaeger-colls [state]
  (when-not (:all-collections @state)
    (swap! state assoc :all-collections [])
    (svc/async-jaeger-collections
     nil #(->> %
               sort
               (swap! state assoc :all-collections)))))

(def memoized-get-all-jaeger-docs
  (let [last-coll (atom nil)]
    (fn [state collection]
      (when (not= collection last-coll)
        (if collection
          (when (not (:jaeger-docs @state))
            (reset! last-coll collection )
            (swap! state assoc :jaeger-docs [])
            (svc/async-jaeger-filenames
             collection
             (partial swap! state assoc :jaeger-docs)))
          (when (:jaeger-docs @state)
            (reset! last-coll nil)
            (swap! state dissoc :jaeger-docs)))))))

(defn render [state]
  (memoized-get-all-jaeger-colls state)
  (memoized-get-all-jaeger-docs state (:collection @state))
  [:div.container
   [:h3 "Jaeger Data Selection"]
   [render-vocab-selector state (:collection @state) (:all-collections @state)]
   [render-entries state (:jaeger-docs @state)]
   [html/render-message (:message @state)]
   [html/toggle-debug state]
   [html/debug-view @state]])
