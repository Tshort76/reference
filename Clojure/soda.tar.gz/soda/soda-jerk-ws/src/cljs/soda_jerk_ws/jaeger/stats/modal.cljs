(ns soda-jerk-ws.jaeger.stats.modal
  (:require [soda-jerk-ws.jaeger.stats.controls :as controls]
            [soda-jerk-ws.jaeger.stats.icons :as icons]
            [soda-jerk-ws.jaeger.stats.logic :as logic]))

(defn modal-button [state {:keys [result override alternates field soda-value] :as modal-data}]
  [:span
   {:data-toggle "modal"
    :data-target "#omni-modal"
    :style {:cursor "pointer"}
    ; :title (str (name field) " : " (prn-str soda-value))
    :on-click #(swap! state assoc :modal-data
                      (assoc modal-data
                        :no-update (= (keyword result) :valid)))}
   (icons/icon result)
   (when-let [alt-icon (cond
                         override :hidden
                         alternates :alternates
                         :else nil)]
     (icons/icon alt-icon))])

(defn validate-modal [state {:keys [cusip link no-update field md5 soda-value
                                    lm-value soda-fmt override alternates jaeger]}]
  [:div.modal.fade
   {:id "omni-modal"
    :tabIndex "-1"
    :role "dialog"}
   [:div.modal-dialog.modal-lg
    {:role "document"}
    [:div.modal-content
     [:div.modal-header
      [:button.close
       {:type "button"
        :data-dismiss "modal"
        :aria-label "Close"}
       [:span.fa.fa-times]]
      [:h4.modal-title>a {:href link} cusip  ", " field]]
     [:div.modal-body
      [:div.row
       [:div.col-md-4 "Soda Value: "
        [:p (when jaeger (str "(" jaeger ") ")) (prn-str soda-value)]]
       (cond
         override [:div.col-md-4 "Overriding Value: "
                   [:p "(" (:jaeger override) ") " (-> override :soda prn-str)]]
         alternates [:div.col-md-4 "Alternate Values: "
                     (for [{:keys [soda jaeger]} alternates]
                       [:p {:key jaeger} "(" jaeger ") " (prn-str soda)])]
         :else [:div.col-md-4])
       [:div.col-md-4 "Validation Value: " [:p (prn-str lm-value)]]]
      (if (and md5 cusip field)
        [:div.row>iframe
         {:src (str js/context "/overmind/food/html?md5=" md5
                    "&limit-context=true&cusip=" cusip
                    "&field-name=" (name field))
          :width "100%"
          :height "300px"}]
        [:div.row>h4.padded "No Viewable Document"])]
     [:div.modal-footer
      [controls/button {:data-dismiss "modal"} "Never mind"]
      [:button.btn.btn-primary
       {:disabled no-update
        :type "button"
        :on-click #(logic/update-notary-value state cusip field soda-fmt)
        :data-dismiss "modal"}
       "Use this Soda value as the Ultimate Source of Truth"]]]]])
