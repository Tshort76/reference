(ns soda-jerk-ws.jaeger.stats.icons
  (:require [soda-jerk-ws.jaeger.stats.logic :as logic]
            [soda-jerk-ws.jaeger.stats.util :as util]))

(defn render-icon [icon-data tooltip?]
  (let [icon-html [:span.fa.fa-fw.icon
                   {:style {:background-color (:color icon-data)}
                    :class (:icon icon-data)}]]
    (if tooltip?
      (util/tooltip icon-html (into [:span] (:content icon-data)))
      icon-html)))

(def icons
  (let [simple-icons
        {:valid        {:content ["SoDa data is valid"]
                        :icon :fa-check
                        :color "#8f8"}
         :partial      {:content ["SoDa partially matches"]
                        :icon :fa-moon-o
                        :color "#4ef"}
         :diff         {:content ["SoDa data does not match"]
                        :icon :fa-times
                        :color "#f88"}
         :no-soda      {:content ["No SoDa data"]
                        :icon :fa-minus
                        :color "#fb4"}
         :no-lm        {:content ["No validation data"]
                        :icon :fa-question
                        :color "#ee0"}
         :no-data      {:content ["No SoDa or validation data"]
                        :icon :fa-circle-thin
                        :color "#ddd"}
         :other-jaeger {:content ["Soda value supplied by another Jaeger"]
                        :icon :fa-user-circle
                        :color "#4ef"}}
        {:keys [valid partial diff no-soda other-jaeger]}
        (logic/map-vals #(render-icon % false) simple-icons)]
    (merge
     simple-icons
     {:precision  {:content ["SoDa precision: " valid " / (" valid " + " partial " + " diff + ")"]
                   :icon :fa-crosshairs}
      :recall     {:content ["SoDa recall: " valid " / (" valid " + " no-soda " + " other-jaeger ")"]
                   :icon :fa-search}
      :hidden     {:content ["Soda value overwritten by another Jaeger"
                             [:br] "Note: this " [:b>em "does"]
                             " include values counted by other metrics (e.g. " diff " and " valid ")"]
                   :icon :fa-eye-slash}
      :alternates {:content ["Multiple provided Soda values"
                             [:br] "Note: this " [:b>em "does"]
                             " include values counted by other metrics (e.g. " diff " and " valid ")"]
                   :icon :fa-eye}})))

(defn icon [icon-name & [tooltip?]]
  (render-icon (or (icons (keyword icon-name))
                   (icons :no-data)) tooltip?))
