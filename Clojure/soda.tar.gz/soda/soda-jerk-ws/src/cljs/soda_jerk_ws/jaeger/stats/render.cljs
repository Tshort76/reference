(ns soda-jerk-ws.jaeger.stats.render
  (:require [clojure.pprint :as pprint]
            [soda-jerk-ws.jaeger.stats.controls :as controls]
            [soda-jerk-ws.jaeger.stats.icons :as icons]
            [soda-jerk-ws.jaeger.stats.logic :as logic]
            [soda-jerk-ws.jaeger.stats.modal :as modal]
            [soda-jerk-ws.jaeger.stats.util :as util]))

(defn percent [num denom]
  (cond
    (= num 0) "---",
    (= num denom) "100%",
    (and num denom (pos? num) (pos? denom))
    (pprint/cl-format nil "~,1f%" (/ num denom .01)),
    :else "---"))

(defn sort-field-button [state [field-sort [type]] field status-types]
  (util/tooltip
   [:th.btn-default
    {:key field
     :style {:text-align "center"
             :cursor "pointer"}
     :type "button"
     :on-click #(swap! state logic/update-field-sort field status-types)}
    (if (= field field-sort)
      [:span [:span.fa.fa-filter]
       (icons/icon type)]
      [:span.fa.fa-filter])]
   (str "Filter by the " (name field) " field")))

(defn header-cell [label attrs]
  [:th.rotate attrs
   [:div {:style {:float "right"}}
    [:span label]]])

(defn header-row [fields tickers?]
  [:thead>tr
   [:th.borderless]
   (when tickers? [:th])
   (header-cell "Total" {})
   (for [field fields]
     (header-cell field {:key field}))
   [:th {:style {:width "100%"}}]])

(defn alt-percent [num den]
  (if (and (= 0 num)
           (pos? den))
    "0.0%"
    (percent num den)))

(defn percent-cell [tag {:keys [key col-span]} num total percent-fn]
  (util/tooltip
   [tag
    (cond-> {:style {:text-align "right"}}
            key (assoc :key key)
            col-span (assoc :colSpan col-span))
    (percent-fn num total)]
   (str num " / " total)))

(defn alt-total-stat [agg-stats types]
  (percent-cell
   :th {}
   (:valid agg-stats)
   (apply + ((apply juxt types) agg-stats))
   alt-percent))

(defn alt-field-stats [fields field-stats types]
  (for [field fields]
    (percent-cell
     :th {:key field}
     (-> field-stats
         :valid
         (field 0))
     (->> field-stats
          ((apply juxt types))
          (keep field)
          (apply +))
     alt-percent)))

(defn normal-total-stat [agg-stats max-field type]
  (percent-cell :td {} (type agg-stats) max-field percent))

(defn normal-field-stats [field-stats fields total-docs type]
  (for [field fields]
    (percent-cell
     :td {:key [type field]}
     (field (type field-stats) 0)
     total-docs percent)))

(defn normal-header-row [type fields field-stats agg-stats max-field total-docs tickers?]
  [:tr {:key type}
   (when tickers? [:td ""])
   [:td {:style {:text-align "right"}}
    (icons/icon type true)]
   (normal-total-stat agg-stats max-field type)
   (normal-field-stats field-stats fields total-docs type)])

(defn stats-rows [fields status-types field-stats agg-stats total-docs tickers?]
  (let [max-field (* (count fields) total-docs)]
    [:thead
     (for [[status-icon types] {:precision [:valid :diff :partial]
                                :recall [:valid :no-soda :other-jaeger]}]
       [:tr {:key status-icon}
        (when tickers? [:td ""])
        [:td {:style {:text-align "right"}}
         (icons/icon status-icon true)]
        (alt-total-stat agg-stats types)
        (alt-field-stats fields field-stats types)])
     (doall
       (for [type status-types]
         (normal-header-row type fields field-stats agg-stats max-field total-docs tickers?)))]))

(defn sort-row [state fields field-sort soda-api? field->status-types tickers?]
  [:thead>tr
   (if-not soda-api?
     [:th "Filename"]
     [:th])
   [:th "CUSIP"]
   (when tickers? [:th "TICKER"])
   (for [field fields]
     (sort-field-button state field-sort field (field->status-types field)))])

(defn render-entries [state soda-api?]
  (let [{:keys [jaeger-docs page page-size field-sort
                field-stats agg-stats cusip-filter ticker-filter tickers?]} @state
        fields (->> jaeger-docs
                    (map :jaeger-doc)
                    (apply merge)
                    keys
                    sort)
        total-docs (count jaeger-docs)
        status-types (remove (fn [type]
                               (= 0 (type agg-stats 0)))
                             logic/status-order)
        field->status-types (reduce (fn [r field]
                                      (assoc r field
                                               (remove
                                                 (fn [type]
                                                   (-> field-stats
                                                       type
                                                       (field 0)
                                                       (= 0)))
                                                 status-types)))
                                    {} fields)]
    [:table.table.table-condensed.table-striped
     [header-row fields tickers?]
     [stats-rows fields status-types field-stats agg-stats total-docs tickers?]
     [sort-row state fields field-sort soda-api? field->status-types tickers?]
     [:tbody ;.xmastable
      (for [{{:keys [filename md5 stats cusip ticker]} :meta
             j-doc :jaeger-doc} (->> jaeger-docs
                                     (filter (logic/filter-by-cusip cusip-filter))
                                     (filter (logic/filter-by-ticker ticker-filter))
                                     ((fn [xs] (logic/filter-docs xs field-sort)))
                                     (drop (* page-size page))
                                     (take page-size))
            :let [link (when-not soda-api? (str "#jaeger/duct-tape/" md5 (when cusip "/") cusip))]]
        [:tr {:key cusip}
         (if-not soda-api?
           [:td.junk {:style {; :max-width "200px"
                              :white-space :nowrap}}
            [:a {:href (str js/context "/overmind/food/html?md5=" md5 "&filename=" filename)} "(doc)"]
            " " [:a {:href (when-not soda-api? (str "#jaeger/duct-tape/" md5))} filename]]
           [:td])
         [:td {:style {:text-align "right"}} cusip]
         (when tickers? [:td {:style {:text-align "right"}} ticker])
         (for [field fields
               :let [{:keys [result override alternates formatted soda lm jaeger]} (some-> j-doc field)]]
           (util/tooltip
            [:td {:key field
                  :style {:text-align "center"}}
             [modal/modal-button
              state {:cusip cusip
                     :link link
                     :result result
                     :override override
                     :alternates alternates
                     :field field
                     :soda-value soda
                     :lm-value lm
                     :jaeger jaeger
                     :md5 md5
                     :soda-fmt formatted}]]
            (str (name field) " : " (prn-str soda))))])]]))

(defn header [state soda-api?]
  [:div {:style {:white-space :no-wrap :padding "8px"}}
   [:img {:width 125 :height 125 :style {:display :inline}
          :src "https://media0.giphy.com/media/R7AW255ijTdV6/giphy.gif"}]
   [:h1 {:style {:display :inline :white-space :no-wrap :position :absolute}} "The Christmas Tree"]
   (controls/all-controls state soda-api?)])

(defn render [state soda-api?]
  (logic/init-state state)
  (logic/memoized-get-all-jaeger-docs state soda-api?)
  [:div.container-fluid
   (header state soda-api?)
   [modal/validate-modal state (:modal-data @state)]
   (render-entries state soda-api?)])
