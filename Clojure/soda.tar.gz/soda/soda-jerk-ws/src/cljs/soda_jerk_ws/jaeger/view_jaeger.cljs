(ns soda-jerk-ws.jaeger.view-jaeger
  (:require [clojure.pprint :refer [pprint]]
            [hipo.core :as hipo]
            [hipo.attribute :as hipo-attr]
            [soda-jerk-ws.common.highlighter :as hl]
            [soda-jerk-ws.common.html-utils :refer [toggle-debug debug-view]]
            [soda-jerk-ws.jaeger.service-interop :as svc]))

(defn map-vals [f m]
  (zipmap (keys m)
          (map f (vals m))))

(defn set-jaeger-docs! [state docs]
  (swap! state #(-> %
                    (assoc :meta (apply merge (map :meta docs)))
                    (assoc :jaeger-docs docs)))
  (svc/async-jaeger-lm-values
    (map (comp :value :cusip-9 :jaeger-doc) docs)
    (fn [x]
      (->> x
           (group-by (comp :cusip :data))
           (map-vals #(->> %
                           (sort-by (juxt (comp #{"notary"} :source) :_id))
                           (map :data)
                           (apply merge)))
           (swap! state assoc :lm-values)))))

(defn memoized-get-jaeger-docs [state docs md5 cusip]
  (when (and (not docs) md5)
    (swap! state assoc :jaeger-docs [])
    (svc/async-jaeger-documents
      (if cusip
        {:md5 md5 :cusip cusip}
        {:md5 md5})
      (partial set-jaeger-docs! state))))

(defn assoc-in-all [m paths v]
  (if (empty? paths)
    m
    (recur (assoc-in m (first paths) v) (rest paths) v)))

;easily viewable colors, start with easiest to differentiate, then adding varying shades
(def colors ["#ff0000" "#0000ff" "#339933" "#9900ff" "#003366" "#ff9900" "#3399ff" "#99ff66" "#ff99cc" "#ffff00" "#ff6600"
             "#66ffff" "#cc99ff" "#cc3399" "#000066" "#003300" "#663300" "#800000" "#660066" "#ff66ff" "#999966"])

(defn pretty-value [value]
  [:p {:style {:margin "0px"}}
   (->> value pprint with-out-str)])

(defn get-fields [jaeger-docs]
  (->> jaeger-docs (map :jaeger-doc) (apply merge) keys sort))

(defn toggle-all-checkbox [state jaeger-docs show-type]
  (let [show (or (show-type @state) {})
        fields (get-fields jaeger-docs)
        distinct-shown (vec (distinct (map show fields)))
        indeterminate (and distinct-shown (= 2 (count distinct-shown)))
        checked (and distinct-shown (not indeterminate) (first distinct-shown))]
    [:input {:type      "checkbox"
             :checked   checked
             :ref       #(when % (aset % "indeterminate" indeterminate))
             :on-change #(swap! state
                                assoc-in-all
                                (for [field fields] [show-type field])
                                (not (or checked indeterminate)))}]))

(defn form-content [state jaeger-docs lm-values]
  (let [show-candidates (:show-candidates @state)
        show-links (:show-links @state)
        collection (:collection @state)
        md5 (-> @state :meta :md5)]
    [:table.table.table-condensed.table-striped
     [:thead>tr
      [:th.rotate [:div>span (toggle-all-checkbox state jaeger-docs :show-candidates) " Candidates"]]
      [:th.rotate [:div>span (toggle-all-checkbox state jaeger-docs :show-links) " Links"]]
      [:th "Field"]
      [:th "Values"]]
     [:tbody
      (for [field (get-fields jaeger-docs)]
        [:tr {:key (name field)}
         [:td [:input {:type      "checkbox"
                       :title     "See candidates for this field"
                       :checked   (field show-candidates)
                       :on-change #(swap! state update-in [:show-candidates field] not)}]]
         [:td [:input {:type      "checkbox"
                       :title     "See linking for this field"
                       :checked   (field show-links)
                       :on-change #(swap! state update-in [:show-links field] not)}]]
         [:td (name field)]
         (let [table-id (str (name field) "-data-table")]
           [:td
            [:a {:data-toggle "collapse" :data-target (str "#" table-id)} "Show/Hide"]
            [:table.collapse.table.table-condensed.table-striped {:id table-id :style {:margin-bottom 0}}
             [:thead>tr [:th "Doc"] [:th "Soda"] [:th "LM"]]
             [:tbody
              (for [doc-index (range (count jaeger-docs))]
                (let [cusip (-> jaeger-docs (nth doc-index) :jaeger-doc :cusip-9 :value)]
                  [:tr {:key doc-index}
                   [:td
                    [:a {:href (str "#jaeger/" collection "/" md5 "/" cusip)}
                     [:div {:style {:width "100%" :height "100%" :color (nth (cycle colors) doc-index)}}
                      (subs cusip 6)]]]
                   [:td (pretty-value (get-in jaeger-docs [doc-index :jaeger-doc field :value]))]
                   [:td (pretty-value (some-> cusip lm-values field))]]))]]])])]]))

(defn render [state]
  (let [{{md5 :md5} :meta :keys [jaeger-docs lm-values cusip]} @state]
    (memoized-get-jaeger-docs state jaeger-docs md5 cusip)
    (if-not (:lm-values @state)
      [:div.alert.alert-info "Loading..."]
      (if (-> @state :jaeger-docs empty?)
        [:div.alert.alert-danger "No results found"]
        [:div.form-pane.padded
         [:h3 "Jaeger Document View"]
         [:p
          [:input {:type      "checkbox"
                   :checked   (:draw-lines @state)
                   :on-change #(swap! state update :draw-lines not)}]
          " Draw Lines "]
         [:hr]
         [form-content state jaeger-docs (or lm-values {})]
         [:hr]
         [:div {:style {:textAlign "center"}}
          [:a {:href (str "#jaeger/" (:jaeger-name @state))}
           "View a different Jaeger Document"]]
         [toggle-debug state]
         [debug-view @state]]))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; All below here occurs after the DOM has been generated and rendered, and the document is shown ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn get-element [id]
  (let [edgar-iframe (.getElementById js/document "doc-view")]
    (when edgar-iframe
      (.getElementById (.-document (.-contentWindow edgar-iframe)) id))))

(defn get-x-scroll []
  (.-scrollLeft (.-body (.-document (.-contentWindow (.getElementById js/document "doc-view"))))))

(defn get-y-scroll []
  (.-scrollTop (.-body (.-document (.-contentWindow (.getElementById js/document "doc-view"))))))

(defn element->coords [element]
  (let [x-scroll (get-x-scroll)
        y-scroll (get-y-scroll)
        box (.getBoundingClientRect element)]
    [(+ (.-left box) x-scroll) (+ (.-top box) y-scroll)
     (+ (.-right box) x-scroll) (+ (.-bottom box) y-scroll)]))

(defn elements->coords [elements]
  (let [coll (if (coll? elements) elements [elements])
        coords (for [element coll] (element->coords element))
        x1 (apply min (map #(nth % 0) coords))
        y1 (apply min (map #(nth % 1) coords))
        x2 (apply max (map #(nth % 2) coords))
        y2 (apply max (map #(nth % 3) coords))]
    (let [ret [x1 y1 x2 y2]]
      (if (some nil? ret)
        (throw (js/Error. "Could not find element"))
        ret))))

(defn clear-old-svg []
  (let [doc-view (.getElementById js/document "doc-view")
        iframe-doc (when doc-view (.-document (.-contentWindow doc-view)))
        svg (when iframe-doc (.getElementById iframe-doc "linking-svg"))]
    (when svg (.removeChild (.-parentElement svg) svg))))

(defn outline [elements color]
  (try
    (let [[x1 y1 x2 y2] (elements->coords elements)
          stroke-w 3]
      (when (some js/isNaN [x1 y1 x2 y2]) (throw (js/Error. "NaN")))
      [:svg/rect {:x     (- x1 stroke-w) :y (- y1 stroke-w)
                  :width (+ (- x2 x1) (* stroke-w 2)) :height (+ (- y2 y1) (* stroke-w 2))
                  :rx    5 :ry 5 :style {:stroke color :stroke-width 2 :fill-opacity 0.0 :stroke-opacity 0.8}}])
    (catch js/Error e nil)))                                ;do not outline if coordinates cannot be calculated for the element)

(defn highlight [elements color]
  (try
    (let [[x1 y1 x2 y2] (elements->coords elements)]
      (when (some js/isNaN [x1 y1 x2 y2]) (throw (js/Error. "NaN")))
      [:svg/rect {:x     x1 :y y1 :width (- x2 x1) :height (- y2 y1)
                  :style {:fill color :fill-opacity 0.3}}])
    (catch js/Error e nil)))                                ;do not highlight if coordinates cannot be calculated for the element

(defn line [element-a element-b color]
  (try
    (let [[ax1 ay1 ax2 ay2] (elements->coords element-a)
          [bx1 by1 bx2 by2] (elements->coords element-b)
          ;find nearest coordinates
          [x-a x-b] (subvec (vec (sort [ax1 ax2 bx1 bx2])) 1 3)
          [y-a y-b] (subvec (vec (sort [ay1 ay2 by1 by2])) 1 3)
          ;ensure coordinates are used in a way that lands on element corners
          corners #{[ax1 ay1] [ax1 ay2] [ax2 ay1] [ax2 ay2] [bx1 by1] [bx1 by2] [bx2 by1] [bx2 by2]}
          [x1 y1 x2 y2] (if (corners [x-a y-a]) [x-a y-a x-b y-b] [x-a y-b x-b y-a])]
      [:svg/line {:x1    x1 :y1 y1 :x2 x2 :y2 y2
                  :style {:stroke color :stroke-width 2 :stroke-opacity 0.5}}])
    (catch js/Error e nil)))                                ;do not draw line if coordinates cannot be calculated for an element

(defn linking-svg [state]
  (let [fields-to-show-links (reduce (fn [coll [k v]] (if v (conj coll k) coll)) [] (:show-links @state))
        fields-to-show-candidates (reduce (fn [coll [k v]] (if v (conj coll k) coll)) [] (:show-candidates @state))
        candidates (-> @state :meta :candidates)
        docs (:jaeger-docs @state)
        doc-colors (zipmap docs colors)
        body (.-body (.-document (.-contentWindow (.getElementById js/document "doc-view"))))
        [bodyx1 bodyy1 bodyx2 bodyy2] (elements->coords body)]
    [:svg/svg {:id    "linking-svg"
               :style {:position "absolute" :display "table-cell"
                       :left     0 :top 0
                       :width    "100%" :height bodyy2
                       :z-index  -1}}
     (if candidates
       (for [field fields-to-show-candidates]
         (for [candidate (candidates field)]
           (for [ids (-> candidate :ids)]
             (outline (map get-element ids) "red"))))
       (prn "Warning: Candidate data not provided in cusip-doc - cannot display candidates."))
     (list                                                  ;hipo doesn't accept sets
       (set                                                 ;ensure uniqueness
         (apply concat                                      ;flatten for result by one layer
                (for [[doc color] doc-colors]
                  (apply concat                             ;flatten for result by one layer
                         (for [field fields-to-show-links]
                           (let [link (-> doc :jaeger-doc field)
                                 identifier-id (or (:identifier-id link) (-> doc :jaeger-doc :cusip-9 :ids first first))
                                 ids (first (:ids link))
                                 identifier-element (get-element identifier-id)
                                 linked-elements (map get-element ids)]
                             [(highlight identifier-element color)
                              (highlight linked-elements color)
                              (when (:draw-lines @state)
                                (line identifier-element linked-elements color))])))))))]))

(defn highlight-candidates [state]
  (let [candidates (-> @state :meta :candidates)
        fields-to-show-candidates (reduce (fn [coll [k v]] (if v (conj coll k) coll)) [] (:show-candidates @state))]
    (doseq [text (array-seq (.getElementsByTagName js/document "text"))] (.setAttribute text "fill" nil))
    (when candidates
      (doseq [field fields-to-show-candidates]
        (doseq [candidate (candidates field)]
          (doseq [ids (-> candidate :ids)]
            (mapv #(.setAttribute % "fill" "red") (flatten (map #(.getElementById js/document %) ids)))))))))

(defn on-doc-load [state & args]
  (clear-old-svg)
  (if-let [doc-view-body (some-> (.getElementById js/document "doc-view")
                                 .-contentWindow
                                 .-document
                                 .-body)]
    (.appendChild doc-view-body (hipo/create (linking-svg state) {:attribute-handlers [hipo-attr/style-handler]}))
    (highlight-candidates state)))