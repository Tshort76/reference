(ns soda-jerk-ws.jaeger.core
  (:require [reagent.core :as r]
            [soda-jerk-ws.jaeger.view-jaeger :as jaeger]
            [soda-jerk-ws.jaeger.jaeger-selection :as selection]
            [soda-jerk-ws.jaeger.stats.render :as stats]
            [soda-jerk-ws.jaeger.cusip-linking.render :as cusip-linking]
            [soda-jerk-ws.pages.layout :refer [side-by-side]]))

(defn main-page
  ([]
   (let [state (r/atom {})]
     (r/create-class
       {:reagent-render (fn [] (selection/render state))})))
  ([collection]
   (let [state (r/atom {:collection collection})]
     (r/create-class
       {:reagent-render (fn [] (selection/render state))})))
  ([collection md5]
   (let [state (r/atom {:collection collection
                        :meta {:md5 md5}})
         doc-load-fn (partial jaeger/on-doc-load state)]
     (r/create-class
       {:component-did-mount doc-load-fn
        :component-did-update doc-load-fn
        :reagent-render (fn [] (side-by-side state jaeger/render doc-load-fn))})))
  ([collection md5 cusip]
   (let [state (r/atom {:collection collection
                        :meta {:md5 md5}
                        :cusip cusip})
         doc-load-fn (partial jaeger/on-doc-load state)]
     (r/create-class
       {:component-did-mount doc-load-fn
        :component-did-update doc-load-fn
        :reagent-render (fn [] (side-by-side state jaeger/render doc-load-fn))}))))

(defn stats-page [control-set & {:keys [soda-api?]}]
  (let [state (r/atom {:control-set control-set})]
    (r/create-class
      {:reagent-render (fn [] (stats/render state soda-api?))})))

(defn cusip-linking-page [control-set & {}]
  (let [state (r/atom {:control-set control-set})]
    (r/create-class
      {:reagent-render (fn [] (cusip-linking/render state))})))
