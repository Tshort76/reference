(ns soda-jerk-ws.jaeger.cusip-linking.icons
  (:require [soda-jerk-ws.jaeger.stats.logic :as logic]))

(defn render-icon [icon-data tooltip?]
  (let [icon-html [:span.fa.fa-fw.icon
                   {:style {:background-color (:color icon-data)}
                    :class (:icon icon-data)}]]
    (if tooltip?
      [:div.custom_tooltip
       {:style {:display :inline-block
                :cursor "help"}}
       icon-html
       (into [:span.custom_tooltiptext]
             (:content icon-data))]
      icon-html)))

(def icons
  (let [simple-icons
        {:correct-doc         {:content ["Document's expected and found cusip's perfectly matched"]
                               :icon    :fa-heart
                               :color   "#8f8"}
         :partial-correct-doc {:content ["No cusips incorrect linking"]
                               :icon    :fa-minus
                               :color   "#ff4"}
         :incorrect-doc       {:content ["Some cusips were incorrectly linked"]
                               :icon    :fa-times
                               :color   "#f00"}

         :correct-noise       {:content ["Linked the correct number of securities"]
                               :icon    :fa-heart
                               :color   "#8f8"}
         :less-noise          {:content ["Linked less securities than expected"]
                               :icon    :fa-minus
                               :color   "#ff4"}
         :more-noise          {:content ["Linked more securities than expected"]
                               :icon    :fa-plus
                               :color   "#f00"}

         :correct-j-noise     {:content ["Jaegers found the correct number of securities"]
                               :icon    :fa-heart
                               :color   "#8f8"}
         :less-j-noise        {:content ["Jaegers found less securities than expected"]
                               :icon    :fa-minus
                               :color   "#ff4"}
         :more-j-noise        {:content ["Jaegers found more securities than expected"]
                               :icon    :fa-plus
                               :color   "#f00"}

         :default             {:content ["defaulted"]
                               :icon    :fa-circle-thin
                               :color   "#ddd"}

         :valid               {:content ["Correct Cusip linked"]
                               :icon    :fa-heart
                               :color   "#8f8"}
         :incorrect           {:content ["Incorrect Cusip linked"]
                               :icon    :fa-times
                               :color   "#f00"}
         :no-link             {:content ["No Cusip linked"]
                               :icon    :fa-minus
                               :color   "#ff4"}
         :missing             {:content ["Expected cusip not found"]
                               :icon    :fa-circle-thin
                               :color   "#ddd"}


         :matched             {:content ["Matched on"]
                               :icon    :fa-heart
                               :color   "#8f8"}
         :not-matched         {:content ["Did not match on"]
                               :icon    :fa-times
                               :color   "#f00"}
         :cusip-only          {:content ["no cusip-db entry found"]
                               :icon    :fa-hard-of-hearing
                               :color   "#ff4"}
         :jaeger-only         {:content ["no jaeger value found"]
                               :icon    :fa-low-vision
                               :color   "#ff4"}
         :nothing            {:content ["no data found"]
                              :icon    :fa-circle-thin
                              :color   "#ddd"}
         :present            {:content ["Matched on"]
                              :icon    :fa-heart
                              :color   "#8f8"}
         :not-present        {:content ["Did not match on"]
                              :icon    :fa-times
                              :color   "#f00"}

         :red-herring         {:content ["'where-traded' was N/A"]
                               :icon    :fa-times
                               :color   "#f00"}

         :no-cik-found        {:content ["No ciks found"]
                               :icon    :fa-times
                               :color   "#f00"}}
        {:keys [correct-doc partial-correct-doc incorrect-doc correct-noise extra-noise partial diff no-soda other-jaeger]}
        (logic/map-vals #(render-icon % false) simple-icons)]
    (merge
     simple-icons
     {:precision {:content ["Correct:" correct-doc " / (" correct-doc " + " incorrect-doc ")"]
                  :icon    :fa-crosshairs}
      :recall    {:content ["Correct:" correct-doc " / (" correct-doc " + " partial-correct-doc ")"]
                  :icon    :fa-search}
      :green     {:content ["Correct:" correct-doc " / TOTAL(" correct-doc " + " partial-correct-doc " + " incorrect-doc ")"]
                  :icon    :fa-heart
                  :color   "#8f8"}
      :yellow    {:content ["Partial-correct/less-linked: "partial-correct-doc " / TOTAL(" correct-doc " + " partial-correct-doc " + " incorrect-doc ")"]
                  :icon    :fa-minus
                  :color   "#ff4"}
      :red       {:content ["Incorrect/more-linked: "incorrect-doc " / TOTAL(" correct-doc " + " partial-correct-doc " + " incorrect-doc ")"]
                  :icon    :fa-times
                  :color   "#f00"}
      :acceptable{:content ["acceptable: (" correct-doc " + " partial-correct-doc ") / TOTAL(" correct-doc " + " partial-correct-doc " + " incorrect-doc ")"]
                  :icon    :fa-thumbs-up}})))

(defn icon [icon-name & [tooltip?]]
  (render-icon (or (icons (keyword icon-name))
                   (icons :no-data)) tooltip?))
