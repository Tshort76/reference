(ns soda-jerk-ws.jaeger.cusip-linking.controls
  (:require [clojure.string :as str]
            [soda-jerk-ws.jaeger.cusip-linking.logic :as logic]))

(def dropdown-attrs
  {:type "button"
   :class "dropdown-toggle"
   :data-toggle "dropdown"
   :aria-haspopup true
   :aria-expanded false})

(defn button [attrs & content]
  (into [:button.btn.btn-default
         (merge {:type "button"} attrs)]
        content))

(defn page-controls [state page page-size doc-num]
  (let [max-page (Math/floor (/ doc-num page-size))
        btn-style {:style {:line-height "2rem"}}]
    [:div.input-group {:style {:width "6em"}}
     [:span.input-group-btn
      (button {:on-click (fn [] (swap! state assoc :page 0))}
              [:span.fa.fa-fast-backward btn-style])
      (button {:on-click (fn [] (swap! state update :page #(max 0 (dec %))))}
              [:span.fa.fa-chevron-left btn-style])]
     [:span.input-group-addon "Page: " (inc page) " / " (inc max-page)]
     [:span.input-group-btn
      (button {:on-click (fn [] (swap! state update :page #(min max-page (inc %))))}
              [:span.fa.fa-chevron-right btn-style])
      (button {:on-click (fn [] (swap! state assoc :page max-page))}
              [:span.fa.fa-fast-forward btn-style])]]))

(defn md5-filter [state]
  [:div.input-group {:style {:width "20em"}}
   [:span.input-group-addon "md5 Filter"]
   [:input.form-control
    {:type      "text"
     :value     (:md5-filter @state)
     :on-change #(swap! state assoc :md5-filter
                        (some-> % .-target .-value
                                str/upper-case
                                (str/replace #"[^0-9A-Z#@*]" "")
                                not-empty))}]])

(defn control-set-selector [state current-control-set all-control-sets soda-api?]
  [:div.btn-group
   [:div.btn-group
    [button dropdown-attrs
     "Control Set: " (or current-control-set "???") " " [:span.fa.fa-sort-desc]]
    [:ul.dropdown-menu
     (for [control-set (sort all-control-sets)]
       [:li {:key control-set}
        [:a {:href (str "#cusip-linking/" control-set)}
         control-set]])]]
   [:span.input-group-btn
    (button dropdown-attrs
            "Page Size: " (:page-size @state) " " [:span.fa.fa-sort-desc])
    [:ul.dropdown-menu
     (for [size [10 20 30 40 50 100]]
       [:li {:key (str "ps" size)}
        [:a {:on-click #(swap! state assoc :page-size size :page 0)}
         "Page Size: " size]])]]])




(defn all-controls [state soda-api?]
  [:div.controlbox {:style {:display :inline-block :float :left}}
   [control-set-selector state (:control-set @state) (:all-control-sets @state) soda-api?]
   [md5-filter state]
   [page-controls state
    (:page @state) (:page-size @state)
    (-> @state :jaeger-docs count)]])
