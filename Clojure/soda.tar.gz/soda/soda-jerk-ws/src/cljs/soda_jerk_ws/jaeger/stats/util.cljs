(ns soda-jerk-ws.jaeger.stats.util)

(defn tooltip [main-form tooltip-forms]
  (if (vector? main-form)
    (if (map? (second main-form))
      (-> main-form
          (update-in [1 :class] (fn [x] (if x
                                          (str (name x) " custom_tooltip")
                                          "custom_tooltip")))
          (conj [:span.custom_tooltiptext
                 tooltip-forms]))
      (conj (into [(first main-form)
                   {:class  "custom_tooltip"}]
                  (rest main-form))
            [:span.custom_tooltiptext
                   tooltip-forms]))
    [:div.custom_tooltip
     main-form
     [:span.custom_tooltiptext
      tooltip-forms]]))
