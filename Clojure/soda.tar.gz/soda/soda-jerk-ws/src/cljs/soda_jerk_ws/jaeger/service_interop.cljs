(ns soda-jerk-ws.jaeger.service-interop "All Jaeger interop with services go here."
  ; (:require-macros [cljs.core.async.macros :refer [go]])
  (:require [soda-jerk-ws.common.service-interop-functions :as sif]
            [ajax.core :refer [GET POST]]
            ; [cljs.core.async :refer [chan <! >!]]
            [clojure.string :as str]))

(def async-jaeger-documents
  (sif/async-request-fn
   GET identity "/cwan/jaeger-docs" :multi-jaeger))

(def async-soda-api-stats
  (sif/async-request-fn
    GET (sif/par-wrap :control-name) "/api/soda-api/stats" :jaeger-stats))

(def async-jaeger-stats
  (sif/async-request-fn
    GET (sif/par-wrap :control-name) "/api/jaeger/stats" :jaeger-stats))

(def async-jaeger-control-sets
  (sif/async-request-fn
   GET sif/nil-fn "/api/jaeger/control-sets" :jaeger-control-sets))

(def async-cusip-linking
  (sif/async-request-fn
    GET (sif/par-wrap :control-name) "/api/cusip-matching/data-for-valentines-tree" :cusip-linking))

(def async-jaeger-lm-values
  (sif/async-request-fn
   GET (fn [cusips]
         {:cusips (str/join "," cusips)})
   "/api/jaeger/lm-values" :jaeger-lm-values))

(def async-jaeger-filenames
  (sif/async-request-fn
   GET (sif/par-wrap :collection) "/cwan/jaeger-filenames" :jaeger-filenames))

(def async-jaeger-collections
  (sif/async-request-fn
   GET sif/nil-fn "/cwan/jaeger-collections" :jaeger-coll))

(def async-jaeger-notarize
  (sif/async-request-fn
   POST identity "/api/jaeger/notarize-value" :jaeger-notarize))

; (defn async-jaeger-notarize [params handler & [error-handler]]
;   (let [channel (chan)]
;     (POST (str js/context "/api/jaeger/notarize-value")
;           {:response-format :json
;            :keywords? true
;            :params params
;            :handler #(go (>! channel {:jaeger-notarize %}))
;            :error-handler #(go (>! channel {:error-jaeger-notarize %}))})
;     (go (let [result (<! channel)]
;           (or (some-> result :jaeger-notarize handler)
;               ((or error-handler print-error) (:error-jaeger-notarize result)))))))
