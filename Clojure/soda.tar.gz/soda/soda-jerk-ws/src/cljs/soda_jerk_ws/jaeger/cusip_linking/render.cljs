(ns soda-jerk-ws.jaeger.cusip-linking.render
  (:require [clojure.pprint :as pprint]
            [soda-jerk-ws.jaeger.service-interop :as svc]
            [soda-jerk-ws.jaeger.cusip-linking.logic :as logic]
            [soda-jerk-ws.jaeger.cusip-linking.icons :as icons]
            [soda-jerk-ws.jaeger.cusip-linking.controls :as controls]
            [goog.string :as gstring]
            [goog.string.format]))

(defn percent [num denom]
  (cond
    (= num 0) " --- ",
    (= num denom) " 100% ",
    (and num denom (pos? num) (pos? denom))
    (pprint/cl-format nil " ~,1f% " (/ num denom 0.01)),
    :else " --- "))


(defn header-cell [label attrs]
  [:th.rotate attrs
   [:div {:style {:float "right"}}
    [:span label]]])

(def description
  {"CUSIP"                   "Identifier to link on"
   "Doc. precision"          "doc has correct values"
   "Doc. linking count"     "doc was linked to the right number of cusips"
   "Doc. jaeger count"      "jaeger produced the correct number of cusips"
   "Sec. precision"          "Number of correctly linked cusips over total securities produced"
   "Sec. precision w/o dup." "Same as Sec. precision without duplicate securities"
   "maturity-date"           "Used to match edgar-prospectus"
   "coupon-rate"             "Used to match edgar-prospectus"
   "first-coupon-date"       "Used to match edgar-prospectus"
   "dated-date"              "Used to match edgar-prospectus"
   "coupon-frequency"        "Used to match edgar-prospectus"
   "rate-type"               "Used to match edgar-prospectus"
   "offering-amount"         "Used to match edgar-prospectus"
   "offering-amount-code"    "Used to match edgar-prospectus"
   "ticker-symbol"           "Used to match edgar-equity"
   "new-indicator"           "Used to differentiate the newer of two identical securities ('com new' in issue description)"
   "where-traded"            (str "Where-traded indicates where trading happened, 'not applicable' or 'not available' indicate this cusip might be a red herring"
                                  "\n Drops the score considerably in that case.")
   "Possible Red-herring"    (str "Something indicated this might not be the best security.  For example:"
                                  "-where-traded was 'not applicable' or 'not available'")
   "Probability"             "A score for cusip linking.  Bayesian score so closer to zero is a better score."
   "CIKs"                    "List of CIKs from document.  Links to cik-to-cusip6 endpoint."}
  )

(defn header-row [fields]
  [:thead>tr
   [:th.borderless]
   [:th.borderless]
   (for [field fields]
     (header-cell field {:key            field
                         :data-toggle    "tooltip"
                         :data-placement "bottom"
                         :title          (get description field)}))
   [:th {:style {:width "100%"}}]])

(defn percent-cell [tag num total]
  [tag
   [:div {:style {:text-align "right"
                  :cursor     "help"
                  :margin     "2px 2px 2px 10px"}
          :title (str num " / " total)}
    (percent num total)]])


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;helper funcions;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defn concatv [& v]
  (into [] (apply concat v)))
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;Color Defs;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(def md5-row-style   {:text-shadow [2 2]   :color "#000000" :background-color "#df4646" :vertical-align "middle"})
(def correct-style   {:text-align "center" :color "#000000" :background-color "#eea7cb"})
(def missing-style   {:text-align "center" :color "#ffffff" :background-color "#E48397"})
(def incorrect-style {:text-align "center" :color "#ffffff" :background-color "#ff7878"})

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;Security Info Table;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn make-icon [cusips-matched-on k]
  (if-let [k (keyword (k cusips-matched-on))]
        (icons/icon k true)
        "---"))

(defn matched-on-row [cusips-matched-on cusip-match-record fields]
  (map #(vector :td {:data-toggle    "tooltip"
                     :data-placement "bottom"
                     :title          (str "cusip-db:\t" (:cusip-db-value (% cusip-match-record))
                                          "\njaeger-value:\t" (:jaeger-value (% cusip-match-record)))
                     :style          {:cursor "help" :align "center"}}
                (make-icon cusips-matched-on %)) fields))

(defn sub-row [state {:keys [cusip cusip-matched-on cusip-match-record
                             truth correct incorrect missing probability
                             possible-cusips text]}]
  [:tr {:style (cond correct correct-style missing missing-style incorrect incorrect-style)}
   [:td (cond
          missing "Expected cusip not found."
          (and cusip (not (or cusip-matched-on truth))) "Explicitly found in document"
          possible-cusips
          [:span.input-group-btn
           (controls/button (merge controls/dropdown-attrs {:class "btn btn-drop-down btn-xs"})
                            "other-possible-cusips" [:span.fa.fa-sort-desc])
           [:ul.dropdown-menu
            (for [possible-cusip possible-cusips]
              [:li {:key (str possible-cusip)}
               (into [] (concat [:a {:href (str js/context "/cusip-db/cusip/" (:cusip possible-cusip)) :target "_blank"}
                                 (str (:cusip possible-cusip) " Probability: "
                                      (-> (update (:probability possible-cusip) :match #(cljs.pprint/cl-format nil "~,2f" %))
                                          (update  :match #(cljs.pprint/cl-format nil "~,2f" %))))]
                                (interleave (map #(str "  " (name %) ":") (:important-fields @state ))
                                            (map (partial make-icon (:cusip-matched-on possible-cusip)) (:important-fields @state)))))])]])]
   [:td]
   [:td
       (cond
         cusip [:a {:style (cond correct correct-style missing missing-style incorrect incorrect-style)
                    :title (if text (str "Came from: '" text "'"))
                    :href  (str js/context "/cusip-db/cusip/" cusip):target "_blank"} cusip]

         (and (not cusip) (or correct truth))
         [:div {:title (if text (str "Came from: '" text "'"))} "no expected cusip"]
         (and (not cusip) incorrect)
         [:div {:title (if text (str "Came from: '" text "'"))} "did not link"])] ;cusip column
   [:td]                                                 ;blank column
   [:td]                                                 ;blank column
    [:td]                                                 ;blank column
   [:td (cond
          (and cusip incorrect) (icons/icon :incorrect true)
          incorrect (icons/icon :no-link true)
          missing (icons/icon :missing true)
          correct (icons/icon :valid true))]             ;correctness column
    [:td]                                                 ;blank column
   [:td]                                                 ;blank column
   (matched-on-row cusip-matched-on cusip-match-record (:important-fields @state)) ;match column

   [:td {:style {:align "center"}} (if probability (cljs.pprint/cl-format nil "~,2f" (:match probability)))]
   [:td (if (first (:jaeger-value (:ticker-symbol cusip-match-record)))
          [:a {:href  (str js/context "/api/cusip-matching/ticker-to-cusip-9?ticker=" (first (:jaeger-value (:ticker-symbol cusip-match-record))))
               :target "_blank"}
           [:button {:style {:color "#000"}:class "button btn-xs"} "Ticker"]] )]
   [:td]]                                                 ;blank column
  )

(defn document-row [{:keys [md5 cusip-docs link-noise jaeger-noise precision actual-num-securities]} state]
  [[:tbody
    [:tr {:style md5-row-style :vertical-align "middle"}
     [:td {:style {:vertical-align "middle"}}
      [:b [:a {:target "_blank" :href (if (every? (comp nil? :cusip-matched-on) cusip-docs)
                                        (str "#jaeger/duct-tape/" (name md5))
                                        (str js/context "/overmind/food/raw?md5=" (name md5)))} [:div {:style {:display :inline :color "#000000"}} md5]]]]
     [:td [:a {:target "_blank" :href (str js/context "/overmind/food/raw?md5=" (name md5))} [:div {:style {:display :inline :color "#000000"}} "(DOC)"]]]
     [:td [:button {:class "button btn-xs" :style {:background-color "#df4646"} :data-target (str "#" (name md5)) :data-toggle "collapse" :aria-expanded true}
           "Expand/Collapse"]]
     [:td {:style {:text-align "center" :vertical-align "middle"}} ;doc precision
      (cond
        (= precision "correct") (icons/icon :correct-doc true)
        (= precision "partial-correct") (icons/icon :partial-correct-doc true)
        (= precision "incorrect") (icons/icon :incorrect-doc true)
        :default (icons/icon :default))]
     [:td {:style {:text-align "center" :vertical-align "middle"}} ;doc linked noise
      (cond
        (= link-noise "correct-noise") (icons/icon :correct-noise true)
        (= link-noise "less-noise") (icons/icon :less-noise true)
        (= link-noise "more-noise") (icons/icon :more-noise true)
        :default (icons/icon :default))]
     [:td {:style {:text-align "center" :vertical-align "middle"}} ;doc noise
      (cond
        (= jaeger-noise "correct-noise") (icons/icon :correct-j-noise true)
        (= jaeger-noise "less-noise") (icons/icon :less-j-noise true)
        (= jaeger-noise "more-noise") (icons/icon :more-j-noise true)
        :default (icons/icon :default))]
     [:td] [:td] [:td] (repeat (count (:important-fields @state)) [:td]) [:td]
     [:td
      (if (seq (some :ciks cusip-docs))
        [:div {:style {:text-align "center"}}
         [:span.input-group-btn
          (controls/button (merge controls/dropdown-attrs {:class "btn btn-drop-down btn-xs"})
                           "ciks" [:span.fa.fa-sort-desc])
          [:ul.dropdown-menu
           (for [cik (some :ciks cusip-docs)]
             [:li {:key (str cik)}
              [:a {:href (str js/context "/api/cusip-matching/cik-to-cusip-6?ciks=" cik "&collection=cik-cusip6" (:cusip cik)) :target "_blank"}
               (str cik)]])]]]
        [:div {:title "no cik found" :style {:text-align "center"}} (icons/icon :no-cik-found)])] [:td]]]
   [:tbody {:id    md5
            :class (if (and (= precision "correct")
                            (= link-noise "correct-noise")
                            (= jaeger-noise "correct-noise")) "collapse" "collapse in")}
    (map #(sub-row state %)  cusip-docs)]])



(defn stats-row [jaeger-docs]
  (let [cusip-docs   (->> jaeger-docs (map :cusip-docs) flatten (remove :missing))
        deduped-cusip-docs (->> jaeger-docs (map :cusip-docs) (map #(->> (remove :missing %) (group-by :cusip) (map (comp first second)))) flatten )
        cusip-c  (->> cusip-docs (filter :correct) count)
        cusip-ic (->> cusip-docs (filter #(and (:incorrect %) (:cusip %))) count)
        cusip-pc (->> cusip-docs (filter #(and (not (:correct %))
                                               (nil? (:cusip %)))) count)
        deduped-cusip-c  (->> deduped-cusip-docs (filter :correct) count)
        deduped-cusip-ic (->> deduped-cusip-docs (filter #(and (:incorrect %) (:cusip %))) count)
        deduped-cusip-pc (->> deduped-cusip-docs (filter #(and (:incorrect %) (nil? (:cusip %)))) count)
        total-doc (count jaeger-docs)
        total-cusip (count cusip-docs)
        total-cusip-deduped (count deduped-cusip-docs)
        precision-c  (count (filter (fn [{:keys [precision]}]    (#{"correct"}           precision   )) jaeger-docs))
        precision-ic (count (filter (fn [{:keys [precision]}]    (#{"incorrect"}         precision   )) jaeger-docs))
        precision-pc (count (filter (fn [{:keys [precision]}]    (#{"partial-correct"} precision   )) jaeger-docs))
        link-noise-c (count (filter (fn [{:keys [link-noise]}]   (#{"correct-noise"}     link-noise  )) jaeger-docs))
        link-noise-ic(count (filter (fn [{:keys [link-noise]}]   (#{"more-noise"}        link-noise  )) jaeger-docs))
        link-noise-pc(count (filter (fn [{:keys [link-noise]}]   (#{"less-noise"}        link-noise  )) jaeger-docs))
        j-noise-c    (count (filter (fn [{:keys [jaeger-noise]}] (#{"correct-noise"}     jaeger-noise)) jaeger-docs))
        j-noise-ic   (count (filter (fn [{:keys [jaeger-noise]}] (#{"more-noise"}        jaeger-noise)) jaeger-docs))
        j-noise-pc   (count (filter (fn [{:keys [jaeger-noise]}] (#{"less-noise"}        jaeger-noise)) jaeger-docs))]
    [[:tr
      [:td ]
      [:td {:style {:text-align "right"}}
       (icons/icon :precision true)]

      [:td ]
      (percent-cell :td precision-c (+ precision-c precision-ic))
      (percent-cell :td link-noise-c (+ link-noise-c link-noise-ic))
      (percent-cell :td j-noise-c (+ j-noise-c j-noise-ic))
      (percent-cell :td cusip-c (+ cusip-c cusip-ic))
      (percent-cell :td deduped-cusip-c (+ deduped-cusip-c deduped-cusip-ic))]
     [:tr
      [:td]
      [:td {:style {:text-align "right"}}
       (icons/icon :recall true)]
      [:td ]
      (percent-cell :td precision-c (+ precision-c precision-pc))
      (percent-cell :td link-noise-c (+ link-noise-c link-noise-pc))
      (percent-cell :td j-noise-c (+ j-noise-c j-noise-pc))
      (percent-cell :td cusip-c (+ cusip-c cusip-pc))
      (percent-cell :td deduped-cusip-c (+ deduped-cusip-c deduped-cusip-pc))]
     [:tr
      [:td]
      [:td {:style {:text-align "right"}}
       (icons/icon :green true)]
      [:td ]
      (percent-cell :td precision-c total-doc)
      (percent-cell :td link-noise-c total-doc)
      (percent-cell :td j-noise-c total-doc)
      (percent-cell :td cusip-c total-cusip)
      (percent-cell :td deduped-cusip-c total-cusip-deduped)]
     [:tr
      [:td]
      [:td {:style {:text-align "right"}}
       (icons/icon :yellow true)]
      [:td ]
      (percent-cell :td precision-pc total-doc)
      (percent-cell :td link-noise-pc total-doc)
      (percent-cell :td j-noise-pc total-doc)
      (percent-cell :td cusip-pc total-cusip)
      (percent-cell :td deduped-cusip-pc total-cusip-deduped)]
     [:tr
      [:td]
      [:td {:style {:text-align "right"}}
       (icons/icon :red true)]
      [:td ]
      (percent-cell :td precision-ic total-doc)
      (percent-cell :td link-noise-ic total-doc)
      (percent-cell :td j-noise-ic total-doc)
      (percent-cell :td cusip-ic total-cusip)
      (percent-cell :td deduped-cusip-ic total-cusip-deduped)]
     [:tr
      [:td]
      [:td {:style {:text-align "right"}}
       (icons/icon :acceptable true)]
      [:td ]
      (percent-cell :td (+ precision-c precision-pc) total-doc)
      (percent-cell :td (+ link-noise-c link-noise-pc) total-doc)
      (percent-cell :td (+ j-noise-c j-noise-pc) total-doc)
      (percent-cell :td (+ cusip-c cusip-pc) total-cusip)
      (percent-cell :td (+ deduped-cusip-c deduped-cusip-pc) total-cusip-deduped)]]))

(defn toggle-sort-order [{:keys [sort-order sort-type]} new-field]
  (if (= new-field sort-type)
    (cond
      (= :md5 new-field) identity
      (= new-field :precision) (into #{} (map #(get {"correct" "incorrect", "incorrect" "partial-correct", "partial-correct" "correct"} %) sort-order))
      (#{:link-noise :jaeger-noise} new-field) (into #{} (map #(get {"correct-noise" "less-noise", "less-noise" "more-noise", "more-noise" "correct-noise"} %) sort-order)))
    (cond
      (= :md5 new-field) identity
      (= new-field :precision) #{"incorrect" "partial-correct"}
      (#{:link-noise :jaeger-noise} new-field) #{"more-noise" "less-noise"})))

(defn sort-field-button [state field]
  [:th.btn-default
   {:key      field
    :style    {:text-align "center"
               :cursor     "pointer"}
    :type     "button"
    :title    (str "Sort by " (name field) )
    :on-click #(swap! state assoc :sort-type field :sort-order (toggle-sort-order @state field))}
   (if (= field (:sort-type @state))
     [:span [:span.fa.fa-sort-amount-asc]
      (icons/icon type)]
     [:span.fa.fa-long-arrow-down])])

(defn sort-row [state]
  [:thead>tr
   [:th {:on-click #(swap! state assoc :sort-type :md5 :sort-order identity) }"Filename"]
   [:th ]
   [:th {:style {:text-align "center"}} "Cusip"]
   (for [field [:precision :link-noise :jaeger-noise]]
     (sort-field-button state field ))])

(defn info-table [state]
  (let [{:keys [jaeger-docs page page-size sort-type sort-order
                field-stats agg-stats md5-filter]} @state
        jaeger-docs-display (->> (filter #(re-find (re-pattern (str "(?i)" md5-filter)) (:md5 %)) jaeger-docs)
                                 (sort-by (comp sort-order sort-type))
                                 (drop (* page page-size))
                                 (take page-size) )]

    (concatv
      [:table.table.table-condensed.table-striped [:tbody.xmastable {:style {:border 1}}]
       [:tr ]]
      [(header-row
         (concat ["" "Doc. correctness" "Doc. linking volume" "Doc. jaeger volume" "Sec. precision"  "Sec. precision w/o dup." " "]
                 (map name (:important-fields @state))
                 ["Probability" "CIKs"]))]
      (stats-row jaeger-docs)
      [(sort-row state)]
      (apply concatv (mapv #(document-row % state) jaeger-docs-display)))))

(defn header [state]
  [:div {:style {:white-space :no-wrap :padding "8px"}}
   [:img {:width 100 :height 100 :style {:display :inline}
          :src "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTB_DN25f0mkMz7HZ0UDr2jcPSLPGGEkTkfyyObZgjoVjj1PTogog"}]
   [:h1 {:style {:display :inline :white-space :no-wrap :position :absolute}} "The Valentine Tree"]
   [:tr (controls/all-controls state nil)]])

(defn render
  "Entry point for rendering the valentines tree."
  [state & {:keys [soda-api?]}]
  (logic/init-state state)
  (logic/memoized-get-all-jaeger-docs state soda-api?)
  [:div {:style {:background-color "#eea7cb" :margin "0em 0em"}}
   [:div {:style {:background-color "#eea7cb" :margin "0em 2em"}}
    (header state)
    (info-table state)
    [controls/page-controls state
     (:page @state) (:page-size @state)
     (-> @state :jaeger-docs count)]]])