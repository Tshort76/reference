(ns soda-jerk-ws.jaeger.stats.controls
  (:require [clojure.string :as str]
            [soda-jerk-ws.jaeger.stats.logic :as logic]
            [soda-jerk-ws.jaeger.stats.util :as util]))

(def dropdown-attrs
  {:type "button"
   :class "dropdown-toggle"
   :data-toggle "dropdown"
   :aria-haspopup true
   :aria-expanded false})

(defn button [attrs & content]
  (into [:button.btn.btn-default
         (merge {:type "button"} attrs)]
        content))

(defn page-controls [state page page-size doc-num]
  (let [max-page (Math/floor (/ doc-num page-size))
        btn-style {:style {:line-height "2rem"}}]
    [:div.input-group {:style {:width "6em"}}
     [:span.input-group-btn
      (button {:on-click (fn [] (swap! state assoc :page 0))}
              [:span.fa.fa-fast-backward btn-style])
      (button {:on-click (fn [] (swap! state update :page #(max 0 (dec %))))}
              [:span.fa.fa-chevron-left btn-style])
      (button dropdown-attrs
              "Page Size: " page-size " " [:span.fa.fa-sort-desc])
      [:ul.dropdown-menu
       (for [size [10 20 30 40 50]]
         [:li {:key (str "ps" size)}
          [:a {:on-click #(swap! state assoc :page-size size :page 0)}
           "Page Size: " size]])]]
     [:span.input-group-addon "Page: " (inc page) " / " (inc max-page)]
     [:span.input-group-btn
      (button {:on-click (fn [] (swap! state update :page #(min max-page (inc %))))}
              [:span.fa.fa-chevron-right btn-style])
      (button {:on-click (fn [] (swap! state assoc :page max-page))}
              [:span.fa.fa-fast-forward btn-style])]]))

(defn jaeger-selector [state current-jaeger all-jaegers]
  [:div.btn-group
   [button dropdown-attrs
    "Visible Jaeger: " (or current-jaeger "All") " " [:span.fa.fa-sort-desc]]
   [:ul.dropdown-menu
    [:li>a {:on-click #(swap! state logic/update-jaeger-filter nil)}
     "All"]
    (for [jaeger (sort all-jaegers)]
      [:li {:key (str "jgr_" jaeger)}
       [:a {:on-click #(swap! state logic/update-jaeger-filter jaeger)}
        jaeger]])]])

(defn bool->str [b]
  (if b "Yes" "No"))

(defn toggle-only-provided-fields [state]
  (let [{:keys [only-soda-fields? only-lm-fields? only-soda-data? only-lm-data?]} @state]
    [:div.btn-group
     [:div.btn-group
      [button dropdown-attrs
       "Fields: " (cond (and only-soda-fields? only-lm-fields?) "Soda & LM"
                          only-soda-fields? "Soda"
                          only-lm-fields? "LM"
                          :else "all")
       " " [:span.fa.fa-sort-desc]]
      [:ul.dropdown-menu
       (util/tooltip
        [:li>a {:on-click #(swap! state logic/update-soda-lm-field-filter {:only-soda-fields? true :only-lm-fields? true})}
          "Soda & LM"]
        "Only show fields with Soda and LM data")
       (util/tooltip
        [:li>a {:on-click #(swap! state logic/update-soda-lm-field-filter {:only-soda-fields? true :only-lm-fields? false})}
          "Soda"]
        "Only show fields with Soda data")
       (util/tooltip
        [:li>a {:on-click #(swap! state logic/update-soda-lm-field-filter {:only-soda-fields? false :only-lm-fields? true})}
          "LM"]
        "Only show fields with LM data")
       (util/tooltip
        [:li>a {:on-click #(swap! state logic/update-soda-lm-field-filter {:only-soda-fields? false :only-lm-fields? false})}
          "all"]
        "Show all fields")]]

     [:div.btn-group
      [button dropdown-attrs
       "Securities: " (cond (and only-soda-data? only-lm-data?) "Soda & LM"
                              only-soda-data? "Soda"
                              only-lm-data? "LM"
                              :else "all")
       " " [:span.fa.fa-sort-desc]]
      [:ul.dropdown-menu
       (util/tooltip
        [:li>a {:on-click #(swap! state logic/update-soda-lm-field-filter {:only-soda-data? true :only-lm-data? true})}
          "Soda & LM"]
        "Only show securities with Soda and LM data")
       (util/tooltip
        [:li>a {:on-click #(swap! state logic/update-soda-lm-field-filter {:only-soda-data? true :only-lm-data? false})}
          "Soda"]
        "Only show securities with Soda data")
       (util/tooltip
        [:li>a {:on-click #(swap! state logic/update-soda-lm-field-filter {:only-soda-data? false :only-lm-data? true})}
          "LM"]
        "Only show securities with LM data")
       (util/tooltip
        [:li>a {:on-click #(swap! state logic/update-soda-lm-field-filter {:only-soda-data? false :only-lm-data? false})}
          "all"]
        "Show all securities")]]]))

(defn control-set-selector [state current-control-set all-control-sets soda-api?]
  [:div.btn-group
   [:div.btn-group
    [button dropdown-attrs
     (if soda-api? "Agg Cache Data" "Jaeger Data") " " [:span.fa.fa-sort-desc]]
    [:ul.dropdown-menu
     [:li>a {:href (str "#soda-api/stats/" current-control-set)}
      "Agg Cache Data"]
     [:li>a {:href (str "#jaeger/stats/" current-control-set)}
      "Jaeger Data"]]]
   [:div.btn-group
    [button dropdown-attrs
     "Control Set: " (or current-control-set "???") " " [:span.fa.fa-sort-desc]]
    [:ul.dropdown-menu
     (for [control-set (sort all-control-sets)]
       [:li {:key control-set}
        [:a {:href (str "#" (if soda-api? "soda-api" "jaeger")"/stats/" control-set)}
         control-set]])]]])

(defn cusip-filter [state]
  [:div.input-group {:style {:width "20em"}}
   [:span.input-group-addon "Cusip Filter"]
   [:input.form-control
    {:type "text"
     :value (:cusip-filter @state)
     :on-change #(swap! state assoc :cusip-filter
                        (some-> % .-target .-value
                                str/upper-case
                                (str/replace #"[^0-9A-Z#@*]" "")
                                not-empty))}]])
(defn ticker-filter [state]
  [:div.input-group {:style {:width "20em"}}
   [:span.input-group-addon "Ticker Filter"]
   [:input.form-control
    {:type "text"
     :value (:ticker-filter @state)
     :on-change #(swap! state assoc :ticker-filter
                        (some-> % .-target .-value
                                str/upper-case
                                (str/replace #"[^0-9A-Z#@*]" "")
                                not-empty))}]])

(defn all-controls [state soda-api?]
  [:div.controlbox {:style {:display :inline-block :float :left}}
   [page-controls state
    (:page @state) (:page-size @state)
    (-> @state :jaeger-docs count)]
   [control-set-selector state (:control-set @state) (:all-control-sets @state) soda-api?]
   (when-not soda-api?
     [jaeger-selector state (:current-jaeger @state) (:all-jaegers @state)])
   [cusip-filter state]
   (when (:tickers? @state) [ticker-filter state])
   [toggle-only-provided-fields state]])
