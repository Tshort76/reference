(ns soda-jerk-ws.judy.transitions "A collection of functions that aggregate changes for app-state updates.")

(defn basic-schema [schema]
  (select-keys schema [:app-state :feedback? :debug? :success-image :bid :presentation :viewer :meta]))

(defn basic-meta [meta]
  (select-keys meta [:username :comment :document]))

(defn ->edit-existing-entry [state {:keys [meta entity-map] :as entry}]
  (-> state
      (dissoc :prospectus-options :message
              :processed-documents :unprocessed-overmind-entries)
      (into {:entity-map (dissoc entity-map :_id)
             :meta (merge meta (select-keys (:meta state) [:username]))
             :app-state :entry
             :current-entity (-> entity-map first first)})))

(defn ->edit-entity [state id]
  (-> state
      (dissoc :prospectus-options :message
              :processed-documents :unprocessed-overmind-entries)
      (into {:current-entity id :app-state :entry})))

(defn ->table-view [state]
  (-> state
      (dissoc :prospectus-options :message
              :processed-documents :unprocessed-overmind-entries)
      (into {:app-state :table})))

(defn ->choose-prospectus [state]
  (-> state
      (dissoc :entity-map :current-entity :prospectus-options
              :hiccup-prospectus :highlight-ids :prospectus-word-id-list
              :processed-documents :errors :entities)
      (into {:app-state :selection})
      (update :meta basic-meta)))

(defn ->await-result [state]
  (-> state
      basic-schema
      (update :meta basic-meta)
      (into {:app-state :await-result})))

(defn ->success-choose [state]
  ;(.log js/console (-> state cljs.pprint/pprint with-out-str))
  (-> state
      basic-schema
      (update :meta basic-meta)
      (into {:app-state :choose-next-action})))
