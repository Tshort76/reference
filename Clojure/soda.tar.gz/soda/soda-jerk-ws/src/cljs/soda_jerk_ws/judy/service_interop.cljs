(ns soda-jerk-ws.judy.service-interop "All Judy interop with services go here."
  (:require [soda-jerk-ws.common.service-interop-functions :as sif]
            [ajax.core :refer [GET POST]]))

(def async-unprocessed-documents
  (sif/async-request-fn
   GET (sif/par-wrap :data-type) "/overmind/available" :unprocessed))

(def async-processed-documents
  (sif/async-request-fn
   GET (sif/par-wrap :data-type) "/cwan/meta-docs" :processed))

(def async-entity-map
  (sif/async-request-fn
   GET (sif/par-wrap :id) "/cwan/document" :entity))

(def async-submit-prospectus
  (sif/async-request-fn
   POST identity "/cwan/submit_prospectus" :submit-prospectus))

(def async-overmind
  (sif/async-request-fn
   GET (sif/par-wrap :md5) "/overmind/process" :overmind))

(def async-hiccup-prospectus
  (sif/async-request-fn
   GET (sif/par-wrap :md5) "/overmind/hiccup" :html))

; (def async-remove-job
;   (sif/async-request-fn
;    GET (sif/par-wrap :md5) "/overmind/remove-manual-job" :remove-job))

(def async-entities-for-file
  (sif/async-request-fn
   GET identity "/cwan/documents" :multi-entities))
