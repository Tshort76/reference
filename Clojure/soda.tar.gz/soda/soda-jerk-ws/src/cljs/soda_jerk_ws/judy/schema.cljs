(ns soda-jerk-ws.judy.schema
  (:require [schema.core :as s]
            [schema.coerce :as coerce]
            [ecs.schema :as ecs]
            [cljs.pprint :refer [pprint]]))

(def soda-jerk-ws-app-states
  [:selection :entry :await-result :choose-next-action :table])

(def soda-jerk-ws-presentation-options [:side-by-side])

(def global-schema
  {:app-state (apply s/enum soda-jerk-ws-app-states)
   (s/optional-key :feeback?) s/Bool
   (s/optional-key :debug?) s/Bool
   (s/optional-key :success-image) s/Str
   :presentation (apply s/enum soda-jerk-ws-presentation-options)
   (s/optional-key :viewer) (s/enum :pdf :html)
   :meta {:username s/Str
          (s/optional-key :comment) s/Str
          (s/optional-key :filename) s/Str}})

(def unprocessed-entry-schema
  {:_id s/Str :md5 s/Str :filename s/Str :result s/Str :file-type s/Keyword :new? s/Bool})

(def selection-schema
  (update
   (into global-schema
         {(s/optional-key :unprocessed-overmind-entries) [unprocessed-entry-schema]})
   :meta into (into (zipmap (map s/optional-key (keys unprocessed-entry-schema))
                            (vals unprocessed-entry-schema))
                    {(s/optional-key :vocabulary) s/Keyword})))

(def data-entry-schema (conj global-schema
                             ecs/Entry
                             {:current-entity s/Keyword
                              (s/optional-key :hiccup-prospectus) [s/Any]
                              (s/optional-key :prospectus-word-id-list) [s/Any]}))

(def schemas
  {:selection selection-schema
   :entry data-entry-schema
   :await-result global-schema
   :choose-next-action global-schema})

(defn error-check [{:keys [app-state] :as state}]
  (let [c (coerce/coercer (schemas app-state) coerce/json-coercion-matcher)
        {:keys [error] :as s} (c state)]
    (when error (pprint {:app-state app-state
                            :errors error}))))
