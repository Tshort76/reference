(ns soda-jerk-ws.judy.core
  (:require [reagent.core :as r]
            [soda-jerk-ws.pages.prospectus-selection :as jps]
            [soda-jerk-ws.pages.view-form :as form]
            [soda-jerk-ws.pages.view-table :as table]
            [soda-jerk-ws.pages.choose-next-action :as cna]
            [soda-jerk-ws.pages.await-submission :as w]
            [cljs.reader :refer [read-string]]
            [soda-jerk-ws.pages.layout :refer [side-by-side]]
            [soda-jerk-ws.common.html-utils :refer [debug-view]]))

(defn default-state []
  {:meta {:username (rand-nth ["Coelophysis" "Deinonychus" "Stegosaurus" "Torvosaurus"
                               "Utahraptor" "Camarasaurus" "Ankylosaurus" "Alamosaurus" "Microraptor"])}
   :app-state :selection
   :debug? false
   :viewer :html
   :presentation :side-by-side})

(defn reset-state [state]
  (reset! state (default-state))
  (.removeItem js/sessionStorage "soda_jerk_ws.state"))

(defmulti render-app (fn [state] (:app-state @state)))
(defmethod render-app :selection [state] (jps/render state))
(defmethod render-app :entry [state] (side-by-side state form/render))
(defmethod render-app :table [state] (side-by-side state table/render))
(defmethod render-app :await-result [state] (w/render state))
(defmethod render-app :choose-next-action [state] (cna/render state))

(defmethod render-app :default [state]
  [:div.container
   [:h3 "Unknown :app-state"]
   [:h3 {:on-click #(reset-state state)} "Reset :app-state"]
   (debug-view @state)])

(defn postload [state]
  (when-let [hljs-id (.getElementById js/document "state-code")]
    (.highlightBlock js/hljs hljs-id)))

(defn dehydrate [state]
  (-> state
      (dissoc :hiccup-prospectus
              :prospectus-word-id-list
              :processed-documents
              :unprocessed-overmind-entries)))

(defn judy-page []
  (let [state (r/atom (or (some-> (.getItem js/sessionStorage "soda_jerk_ws.state")
                                  read-string)
                          (default-state)))]
    (add-watch
     state
     :save-on-change
     (fn [_ _ o n]
       (when (not= o n)
         (.setItem js/sessionStorage "soda_jerk_ws.state"
                   (or (dehydrate n)
                       (default-state))))))
    ;Ingredients to the secret sauce:
    ;; - https://github.com/Day8/re-frame/wiki/Creating-Reagent-Components
    ;; - http://facebook.github.io/react/docs/component-specs.html#lifecycle-methods
    (r/create-class
     {:component-did-mount (partial postload state)
      :component-did-update (partial postload state)
      :reagent-render (fn [](render-app state))})))
