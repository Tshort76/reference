(ns soda-jerk-ws.overrides.editor-view
  (:require [reagent.session :as session]
            [soda-jerk-ws.overrides.controls :as controls]
            [soda-jerk-ws.overrides.override-actions :as overrides]
            [soda-jerk-ws.overrides.types :as types]
            [medley.core :as med]
            [overrides.core :as orc]
            [cljs.pprint :as pp]
            [reagent.core :as r]))

(defn override-label []
  [:div
   [:h1 "Override"]
   (controls/labelled-input :boolean "Show Changes" [:show-override-changes])])

(defn doc-label []
  [:div
   [:h1 "Target Document"]
   (controls/labelled-input :boolean "Show Changes" [:show-target-changes])])

(defn override-editor-controls []
  [:div#editor-controls
   (let [notes-path [:override-draft :notes]]
     (controls/labelled-input :text "Notes: " notes-path :key (session/get-in notes-path)))
   [:button.btn.btn-default
    {:on-click #(do (types/upsert-override)
                    (types/go-to-page (types/view-url)))}
    "Submit Changes"]
   [:a.btn.btn-default
    {:href (types/view-url)}
    "Abandon Changes"]
   ;[:button.btn.btn-default
   ; {:on-click #(do (prn "Override Draft:")
   ;                 (pp/pprint (session/get :override-draft)))}
   ; "(Debug) Print Override-Doc"]
   ])


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Override Tree
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn primary-label [text]
  [:span.label.label-primary text])

(defn default-label [text]
  [:span.label.label-default text])

(defn type->icon [type]
  (when type
    (or (some->> type
                 {:string "ABC"
                  :number "123"
                  :boolean "T/F"
                  :null "null"
                  :date [:span.glyphicon.glyphicon-calendar]}
                 default-label)
        (some->> type
                 {:map "{x: y}"
                  :list "[...]"}
                 primary-label))))

(defn input-type [input]
  (cond (string? input) (if (re-matches #"\d{4}-\d{2}-\d{2}" input)
                          :date
                          :string)
        (number? input) :number
        (boolean? input) :boolean
        (nil? input) :null
        :else nil))

(defn data-type [data]
  (cond (map? data) :map
        (coll? data) :list
        :else nil))

(defn first-or-this [x]
  (if (coll? x)
    (first x)
    x))

(defn override-controls [{:keys [match set override-path] :as override}]
  [:div#override-controls
   (controls/simple-menu-dropdown
     (filterv identity
       [(when set
          {:text "Suppress field" :fn #(overrides/set-nil override-path)})
        {:text "Change set type" :fn #(overrides/change-set-type override-path)}
        (if (contains? override :match)
          {:text "Remove match" :fn #(overrides/remove-match override-path)}
          {:text "Add match condition" :fn #(overrides/add-match override-path)})
        (when match
          {:text "Match non-existence" :fn #(overrides/match-nil override-path)})
        (when (contains? override :match)
          {:text "Change match type" :fn #(overrides/change-match-type override-path)})]))
   " "
   [:span.glyphicon.glyphicon-remove {:on-click #(overrides/remove-override override-path)}]])

(defn notes-input [path]
  (controls/input
    "text"
    (session/get-in (conj path :notes))
    #(if (seq %) (session/assoc-in! (conj path :notes) %)
                 (session/update-in! path dissoc :notes))))

(defn render-override [{:keys [override-path] :as override}]
  (let [override-doc (session/get-in (cons :override-doc override-path))
        override-draft (session/get-in (cons :override-draft override-path))
        expanded (r/atom (not= override-doc override-draft))]
    (fn [{:keys [match set notes override-path] :as override}]
      (let [override-changes? (session/get :show-override-changes)
            full-override-path (vec (cons :override-draft override-path))
            target (->> (session/get-in full-override-path)
                        :path
                        (map keyword)
                        (cons :target-doc)
                        session/get-in
                        first-or-this)
            match-type (or (some input-type [match target]) :string)
            set-type (or (some input-type [set target]) :string)]
        [controls/tree-node
         [:table.override-table>tbody
          (when (contains? override :match)
            [:tr
             [:td (type->icon match-type)]
             [:td "Match:"]
             [:td (if override-changes?
                    (controls/inputx match-type (conj full-override-path :match))
                    match)]
             (when override-changes?
               [:td [override-controls override]])])
          [:tr
           [:td (type->icon set-type)]
           [:td "Set:"]
           [:td (if override-changes?
                  (controls/inputx set-type (conj full-override-path :set))
                  set)]
           (when (and override-changes? (not (contains? override :match)))
             [:td [override-controls override]])]
          [:tr.note-expander-row {:on-click #(swap! expanded not)}
           [:td {:colSpan 4} [:span (if @expanded "collapse notes" "expand notes")]]]
          (when @expanded
            [:tr [:td "Notes:"]
             [:td {:colSpan 3} (if override-changes? [notes-input full-override-path] notes)]])]
         nil :expanded true]))))

(defn override-node-label [label path & [type]]
  [:span.override-node-label
   (some-> type primary-label)
   " " (str label)
   (when (session/get :show-override-changes)
     (controls/simple-menu-dropdown
       [{:text "Add child field"
         :fn   #(overrides/add-child-field-at-node-path path)}
        {:text "Add array element"
         :fn   #(overrides/add-child-element-at-node-path path)}
        {:text "Suppress (override to remove this field and all child fields)"
         :fn #(overrides/suppress-at-node-path path)}]))
   (when (session/get :show-override-changes)
     [:span.glyphicon.glyphicon-remove {:on-click #(overrides/remove-node-path path)}])])

(defn get-overrides []
  (session/get (if (session/get :show-override-changes)
                 :override-draft
                 :override-doc)))

(defn override-tree-node
  ([] (override-tree-node
        (overrides/nest-overrides
          (get-overrides))
        []))
  ([nested-overrides path]
   (let [{:keys [fields elements overrides] :as node} (get-in nested-overrides path)
         identifiers (into {} (filter val (session/get :identifiers)))
         is-where-node (= :elements (when (< 1 (count path)) (nth path (- (count path) 2))))
         node-label (or (when is-where-node "") (last path))]
     [controls/tree-node
      (override-node-label node-label path
        (cond (empty? path) (str (name (session/get :type)) " "
                                 (.stringify js/JSON (clj->js identifiers) nil 2))
              is-where-node (str "where: " (.stringify js/JSON (clj->js (last path)) nil 2))
              fields "{x: y}"
              elements "[...]"
              :else nil))
      (doall
        (concat
          (for [override overrides]
            [render-override override])
          (for [field (keys fields)]
            (override-tree-node nested-overrides (conj path :fields field)))
          (for [element (keys elements)]
            (override-tree-node nested-overrides (conj path :elements element)))))
      :expanded true])))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Target Doc Tree
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn field-dropdown-menu [target-path]
  (controls/simple-menu-dropdown [{:text "Override current value" :fn #(overrides/override-current-value-at-target-path target-path)}
                                  {:text "Override unconditionally" :fn #(overrides/override-unconditionally-at-target-path target-path)}
                                  {:text "Suppress field" :fn #(overrides/suppress-at-target-path target-path)}]))

(defn str-no-kw [x]
  (when x (if (keyword? x)
            (name x)
            (str x))))

(defn doc-view-tree-title []
  [primary-label (str (name (session/get :type)) " "
                      (.stringify js/JSON (clj->js (into {} (filter val (session/get :identifiers)))) nil 2))])

(defn doc-view-node-title [path target]
  (let [node-label (str-no-kw (last path))]
    [:span.node-name {:key path}
     (type->icon ((some-fn input-type data-type) target))
     " " node-label " "
     (when-not (coll? target) [:span.bordered (str target)])
     " " (field-dropdown-menu (vec (rest path)))]))

(defn doc-tree-node
  ([]
   [controls/tree-node
    [doc-view-tree-title]
    (doall (for [[k v] (cond-> (session/get :target-doc)
                         (session/get :show-target-changes)
                         (orc/apply-override (get-overrides)))]
             [doc-tree-node [:target-doc k] v]))
    :expanded true])
  ([path target]
   [controls/tree-node
    [doc-view-node-title path target]
    (cond
      (map? target) (doall (for [[k v] target] [doc-tree-node (conj path k) v]))
      (coll? target) (doall (for [[i v] (med/indexed target)] [doc-tree-node (conj path i) v]))
      :else nil)]))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Init + Render
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn init-editor-session []
  (session/swap! assoc :show-override-changes true))

(defn render []
  (init-editor-session)
  (fn []
    [:div
     [:div.col-md-6.viewer
      [:div.view-label [override-label]]
      [:div#override-editor.view-tree (override-tree-node)]
      [override-editor-controls]]
     [:div.col-md-6.viewer
      [:div.view-label [doc-label]]
      [:div#doc-view.view-tree [doc-tree-node]]]]))