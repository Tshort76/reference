(ns soda-jerk-ws.overrides.core
  (:require [ajax.core :refer [GET POST DELETE]]
            [soda-jerk-ws.overrides.state :as s]
            [soda-jerk-ws.overrides.editor-view :as editor-view]
            [soda-jerk-ws.overrides.lookup-view :as lookup-view]
            [reagent.core :as r]
            [soda-jerk-ws.overrides.controls :as controls]
            [soda-jerk-ws.overrides.types :as types]
            [cljs.pprint :as pp]
            [reagent.session :as session]
            [soda-jerk-ws.overrides.prompt :as prompt]))

(defn kw-when [s] (when s (keyword s)))

(defn init-session [{:keys [type action view cusip isin lei index-name date md5 cik cusip-6]}]
  (session/swap! merge {:type (or (kw-when type) :security)
                        :action (kw-when action)
                        :view (kw-when view)
                        :identifiers {:cusip cusip :isin isin :lei lei :index-name index-name :date date :md5 md5 :cusip-6 cusip-6
                                      :cik (when cik (js/parseInt cik))}
                        :search-results {}
                        :override-draft {}
                        :target-doc {}
                        :target-draft {}})
  (s/do-search))

(defn render [query-params]
  (init-session query-params)
  (fn []
    [:div#override-app
     (case (session/get :view)
       :editor [editor-view/render]
       [lookup-view/render])
     [prompt/render]]))