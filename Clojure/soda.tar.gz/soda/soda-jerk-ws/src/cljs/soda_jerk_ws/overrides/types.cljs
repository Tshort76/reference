(ns soda-jerk-ws.overrides.types
  (:require [ajax.core :refer [GET POST DELETE]]
            [ajax.url :as url]
            [cljs.pprint :as pp]
            [medley.core :as med]
            [reagent.session :as session]
            [soda-jerk-ws.overrides.prompt :as prompt]
            [soda-jerk-ws.overrides.controls :as controls]
            [soda.core :as core]
            [medley.core :as medley]))

(def type->identifiers {:security #{:cusip :isin}, :entity #{:cik :lei :cusip-6},
                        :index #{:index-name :date}, :document #{:md5}})

(def identifier->form-type {:cusip :string, :isin :string, :cik :string, :lei :string,
                            :index-name :string, :date :date, :md5 :string, :cusip-6 :string})

(defn get-id-param-str []
  (->> :identifiers session/get (filter val) (into {}) (url/params-to-str :java) not-empty))

(defn target-doc-url-fn []
  (when-let [param-str (get-id-param-str)]
    (str js/context "/overrides/lookup-document?" param-str)))

(defn override-doc-url-fn []
  (when-let [param-str (get-id-param-str)]
    (str js/context "/overrides/override?" param-str)))

(defn format-lists [data]
  (cond
    (map? data) (med/map-vals format-lists data)
    (sequential? data) (mapv format-lists data)
    :else data))

(def aggregation {:text "Aggregated" :url-fn target-doc-url-fn :path [:search-results :aggregation]
                  :handler-fn (fn [aggregated-doc]
                                (let [aggregated-doc (dissoc (format-lists aggregated-doc) :_id)]
                                  (session/assoc-in! [:search-results :aggregation] aggregated-doc)
                                  (when (empty? (session/get :target-doc))
                                    (session/put! :target-doc aggregated-doc))
                                  (when (and (empty? (session/get :target-draft))
                                             (= :update (session/get :action)))
                                    (session/put! :target-draft aggregated-doc))))})

(def override {:text "Override" :url-fn override-doc-url-fn :path [:search-results :override]
               :handler-fn (fn [overrides]
                             (let [override (cond (empty? overrides) {}
                                                  (= 1 (count overrides)) (first overrides)
                                                  :else (do (session/put! :multiple-overrides true)
                                                            {:notes "Error: Multiple overrides found matching provided identifiers. Requires manual resolution."}))]
                               (session/assoc-in! [:search-results :override] override)
                               (when (= :update (session/get :action))
                                 (session/put! :override-draft override)
                                 (session/put! :override-doc override))))})

(def document {:text "Files Meta" :url-fn target-doc-url-fn :path [:search-results :document]
               :handler-fn (fn [document]
                             (session/assoc-in! [:search-results :document] document))})

(def type->search-results {:security [aggregation override]
                           :entity [aggregation override]
                           :index [aggregation override]
                           :document [document override]})

(defn override-exists? []
  (boolean (session/get-in [:search-results :override])))

(defn rerun-affected []
  (case (session/get :type)
    :security (do (when-let [cusip (session/get-in [:identifiers :cusip])]
                    (GET (str "/relay/soda-api?query=security/refresh/cusip/" cusip)
                         {:handler (fn [] (prn "Successfully re-ran security aggregation for cusip"))
                          :error-handler #(prn "Failed to rerun security aggregation for cusip: " %)}))
                  (when-let [isin (session/get-in [:identifiers :isin])]
                    (GET (str "/relay/soda-api?query=security/refresh/isin/" isin)
                         {:handler (fn [] (prn "Successfully re-ran security aggregation for isin"))
                          :error-handler #(prn "Failed to rerun security aggregation for isin: " %)})))
    :entity (POST (str "/entity/rerun/aggregation?" (url/params-to-str :java (medley/filter-vals identity (session/get :identifiers))))
                  {:handler (fn [] (prn "Successfully re-ran entity aggregation"))
                   :error-handler #(prn "Failed to rerun entity aggregation:" %)})
    nil))

(defn upsert-override
  ([] (upsert-override (session/get :override-draft)))
  ([override-doc]
   (let [override-type (session/get :type)]
     (POST (str js/context "/overrides/override")
           {:params (-> override-doc
                        (dissoc :_id)
                        (assoc :type (session/get :type))
                        (update :identifiers #(medley/filter-vals identity (merge % (session/get :identifiers)))))
            :handler rerun-affected
            :error-handler #(prn "Error upserting override: "%)}))))

(defn delete-override []
  (DELETE (str js/context "/overrides/override?" (get-id-param-str))
          {:handler (fn [] nil)
           :error-handler (partial prn "ERROR")}))

(defn state->url []
  (str "#overrides?type=" (name (or (session/get :type) :security))
       (when-let [view (session/get :view)] (str "&view=" (name view)))
       (when-let [action (session/get :action)] (str "&action=" (name action)))
       (when-let [id-params (get-id-param-str)] (str "&" id-params))))

(defn view-url []
  (str "#overrides?type=" (name (or (session/get :type) :security))
       (some->> (get-id-param-str) (str "&"))))

(defn go-to-page [url]
  (.open js/window url "_self"))

(defn editor-transition-fn [action]
  (session/put! :view :editor)
  (session/put! :action action)
  (go-to-page (state->url)))

(defn override-is-dnp? [{:keys [path set]}]
  (and (= path ["do-not-process"]) set))

(defn overrides-dnp? []
  (let [result (when-let [overrides (session/get-in [:search-results :override :overrides])]
                 (some override-is-dnp? overrides))]
    ;(prn "DNP")
    ;(pp/pprint result)
    result))

(defn set-do-not-process [bool & notes]
  (let [dnp-override (medley/assoc-some {:path ["do-not-process"] :set true} :notes notes)]
    (-> (session/get-in [:search-results :override])
        (update :overrides #(cond->> (filterv (complement override-is-dnp?) %)
                                     bool (cons dnp-override)))
        upsert-override)
    (when (js/confirm (if bool "Added do-not-process." "Removed do-not-process."))
      (go-to-page "#overrides"))))

(def actions {:create             {:text          "Create New Override"
                                   :predicate     #(not= :document (session/get :type))
                                   :transition-fn editor-transition-fn
                                   :submit-fn     upsert-override}
              :update             {:text          "Update Existing Override"
                                   :predicate     #(and (not= :document (session/get :type)) (override-exists?))
                                   :transition-fn editor-transition-fn
                                   :submit-fn     upsert-override}
              :delete             {:text          "Delete Existing Override"
                                   :predicate     #(and (not= :document (session/get :type)) (override-exists?))
                                   :transition-fn delete-override}
              :add-do-not-process {:text          "Do Not Process Document"
                                   :predicate     #(and (session/get-in [:search-results :override]) (not (overrides-dnp?)))
                                   :transition-fn #(prompt/show-prompt {:title   "Provide Justification"
                                                                        :body    prompt/add-do-not-process-prompt
                                                                        :actions [{:action "Submit"
                                                                                   :fn (fn [] (set-do-not-process true (session/get-in [:prompt :state :notes])))}
                                                                                  {:action "Cancel" :fn identity}]})}
              :remove-do-not-process {:text          "Remove Do-Not-Process Override"
                                      :predicate     #(and (session/get-in [:search-results :override]) (overrides-dnp?))
                                      :transition-fn #(prompt/show-prompt {:title   "Are you sure you want to remove do-not-process, with the following notes?"
                                                                           :body    (partial prompt/remove-do-not-process-prompt (session/get-in [:override-doc (overrides-dnp?) :notes]))
                                                                           :actions [{:action "Yes"
                                                                                      :fn (fn [] (set-do-not-process false))}
                                                                                     {:action "No" :fn identity}]})}})
