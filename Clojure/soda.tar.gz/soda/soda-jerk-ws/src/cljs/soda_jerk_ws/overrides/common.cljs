(ns soda-jerk-ws.overrides.common)

(defn go-to-page [url]
  (.open js/window url "_self"))

(def default-values-for-type {:string ""
                              :number 0
                              :date "1990-01-01"
                              :boolean false})

(defn value->type [x]
  (cond (string? x) :string
        (number? x) :number
        (boolean? x) :boolean
        (nil? x) :null
        :else (prn (str "Unknown type: " x))))