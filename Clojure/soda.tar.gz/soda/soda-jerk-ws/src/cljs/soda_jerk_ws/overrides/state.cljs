(ns soda-jerk-ws.overrides.state
  (:require [ajax.core :refer [GET POST DELETE]]
            [cljs.pprint :as pp]
            [reagent.core :as r]
            [soda-jerk-ws.overrides.types :as types]
            [reagent.session :as session]))

(defn go-to-page [url]
  (.open js/window url "_self"))

(defn request-schema [schema-type]
  (GET (str js/context "/json-schema/schema/" (name schema-type))
       {:keywords?     true
        :response-format :json
        :handler       #(session/assoc-in! [:schemas (keyword schema-type)] %)
        :error-handler #(do (prn (str "Error while requesting " (name schema-type) " schema:") (pp/pprint %)))}))

(defn request-schemas []
  (GET (str js/context "/json-schema/schemas")
       {:keywords?     true
        :handler       #(do (session/put! :schema-types %)
                            (doseq [schema-type %] (request-schema schema-type)))
        :error-handler #(do (prn "Error while requesting swagger json:") (pp/pprint %))}))

(defn get-chosen-schema []
  (let [schema-text (or (session/get-in [:override-doc :schema])
                        (session/get-in [:original-doc :schema]))]
    (when schema-text (keyword (subs schema-text 0 (- (count schema-text) 7))))))

(defn schema-chosen-and-loaded []
  (session/get-in [:schemas (get-chosen-schema)]))

(defn resolve-refs [schema]
  (if-let [ref (:$ref schema)]
    (let [parent-schema (session/get-in [:schemas (get-chosen-schema)])
          ref-path (mapv keyword (rest (clojure.string/split ref #"/")))]
      (-> schema (dissoc :$ref) (merge (get-in parent-schema ref-path))))
    schema))

;https://stackoverflow.com/a/17328219/975791
(defn deep-merge [a b]
  (merge-with (fn [x y]
                (cond (map? y) (deep-merge x y)
                      (vector? y) (concat x y)
                      :else y))
              a b))

(defn combine-options [schema]
  (if-let [options (or (:anyOf schema) (:allOf schema) (:oneOf schema))]
    (if (->> options (map :type) set count (> 2)) ;all same type (count 0 for inherited type, count 1 for repeated type)
      (deep-merge (dissoc schema :anyOf :allOf :oneOf)
                  (reduce deep-merge options))
      {:type "conflicting-types" :schema schema}) ;should cause error, unless special case is written for this field
    schema))

(defn get-in-schema [path]
  (when (schema-chosen-and-loaded)
    (loop [schema (session/get-in [:schemas (get-chosen-schema)])
           path path]
      (if (empty? path)
        schema
        (case (:type schema)
          "object" (recur (resolve-refs (combine-options (get-in schema [:properties (first path)]))) (rest path))
          "array" (recur (resolve-refs (combine-options (get-in schema [:items]))) (rest path))
          nil)))))

(defn do-search []
  (doseq [{:keys [text url-fn path handler-fn]} (types/type->search-results (session/get :type))]
    (let [handler-fn (or handler-fn (fn [response] (session/assoc-in! path response)))]
      (when-let [url (url-fn)]
        (GET url
             {:keywords?     true
              :handler       #(handler-fn %)
              :error-handler #(do (prn (str "Error while requesting performing " text " search:")) (pp/pprint %))})))))
