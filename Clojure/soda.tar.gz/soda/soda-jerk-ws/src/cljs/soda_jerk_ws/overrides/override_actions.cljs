(ns soda-jerk-ws.overrides.override-actions
  (:require [reagent.session :as session]
            [soda-jerk-ws.overrides.prompt :as prompt]
            [soda-jerk-ws.overrides.common :as c]
            [cljs.pprint :as pp]
            [soda.core :as core]))

;example target-doc
;{:a {:b [{:id 1 :val 2}]}}

;example override-doc
;{:overrides [{:path [:a :b}
;              :where {:id 1}
;              :overrides [{:path [:val} :set 0]]}

;THREE TYPES OF PATHS USED:
;target-path to val: [:a :b 0 :val]
;node-path to val: [:fields :a :fields :b :elements {:id 1} :fields :val]
;override-path to override affecting val: [:overrides 0 :overrides 0]

(defn nest-overrides
  "Converts an override-doc to a format more akin to target-doc (expand paths, show overrides at location they affect, etc.)
   {:fields {:a {:fields {:b {:elements {{:id 1} {:overrides [{:set 5 :override-path [:overrides 5 :overrides 0]]}]}}}}}}}"
  ([override-doc] (nest-overrides {} override-doc []))
  ([data {:keys [path where overrides] :as override} override-path]
   (condp #((set (keys %2)) %1) override
     :path (let [route (interleave (repeat :fields) path)]
             (update-in data route nest-overrides (dissoc override :path) override-path))
     :where (update-in data [:elements where] nest-overrides (dissoc override :where) override-path)
     :overrides (reduce (fn [data [i override]] (nest-overrides data override (conj (vec override-path) :overrides i)))
                        (if (seq override-path) (assoc data :override-path override-path) data)
                        (zipmap (range) overrides))
     :set (update data :overrides #(conj (vec %) (assoc override :override-path override-path)))
     ;remaining overrides are used as placeholders to create empty paths in UI, should be stripped out before submission
     (assoc data :overrides [] :override-path override-path))))

(defn search
  "Performs a postwalk-like search of the provided data and returns all nodes for which the predicate returns truthy value"
  [pred data]
  (let [nested-results (if (coll? data)
                         (apply concat (for [elem data] (search pred elem)))
                         [])]
    (if (pred data)
      (conj nested-results data)
      nested-results)))

(defn add-new-override
  ([override]
   (when override (session/put! :override-draft (add-new-override (session/get :override-draft) override))))
  ([override-doc {:keys [path where overrides] :as override}]
    (let [[i matching-override] (->> (:overrides override-doc)
                                     (map-indexed #(when (and (= path (:path %2)) (= where (:where %2))) [%1 %2]))
                                     (some identity))]
      (if (and overrides matching-override)
        (update override-doc :overrides #(let [prepared-overrides (core/remove-nth (vec %) i)
                                               new-override (add-new-override matching-override (first overrides))]
                                           (vec (conj prepared-overrides new-override))))
        (update override-doc :overrides #(vec (conj (vec %) override)))))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Functions of override-path (specific overrides in an override-doc)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn add-match [override-path]
  (let [path (->> override-path (cons :override-draft) vec)]
    (session/assoc-in! (conj path :match) (session/get-in (conj path :set)))))

(defn remove-match [override-path]
  (session/update-in! (cons :override-draft override-path) dissoc :match))

(defn match-nil [override-path]
  (session/update-in! (cons :override-draft override-path) assoc :match nil))

(defn change-match-type [override-path]
  (let [match-path (cons :override-draft (conj override-path :match))]
    (prompt/show-prompt
      {:body (partial prompt/choose-type-prompt match-path)
       :actions [{:action "Submit"
                  :fn #(session/assoc-in! match-path (c/default-values-for-type
                                                       (keyword (session/get-in [:prompt :state :type]))))}
                 {:action "Cancel" :fn identity}]})))

(defn change-set-type [override-path]
  (let [set-path (cons :override-draft (conj override-path :set))]
    (prompt/show-prompt
      {:body (partial prompt/choose-type-prompt set-path)
       :actions [{:action "Submit"
                  :fn #(session/assoc-in! set-path (c/default-values-for-type
                                                     (keyword (session/get-in [:prompt :state :type]))))}
                 {:action "Cancel" :fn identity}]})))

(defn set-nil [override-path]
  (session/update-in! (cons :override-draft override-path) assoc :set nil))

(defn remove-override [override-path]
  (session/update-in! (cons :override-draft (butlast override-path)) #(vec (core/remove-nth % (last override-path)))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Functions of node-path (nodes in override tree)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn node-path->new-override [override node-path]
  (if (empty? node-path)
    override
    (let [node-val (last node-path)
          node-key (last (butlast node-path))
          rest (take (- (count node-path) 2) node-path)]
      (case node-key
        :fields (node-path->new-override
                  (update override :path #(vec (cons node-val (vec %))))
                  rest)
        :elements (node-path->new-override
                    {:where node-val :overrides [override]}
                    rest)))))

(defn add-new-override-at-node-path [override node-path]
  (add-new-override (node-path->new-override override node-path)))

(defn add-child-element-at-node-path [node-path]
  (prompt/show-prompt
    {:body prompt/create-element-prompt
     :actions [{:action "Submit"
                :fn #(let [{:keys [element-type field-name field-value] :as x} (session/get-in [:prompt :state])
                           where-clause (if (= element-type "map") {field-name field-value} field-value)]
                       (add-new-override-at-node-path {} (conj node-path :elements where-clause)))}
               {:action "Cancel" :fn identity}]}))

(defn add-child-field-at-node-path [node-path]
  (prompt/show-prompt
    {:body prompt/create-field-prompt
     :actions [{:action "Submit"
                :fn #(add-new-override-at-node-path
                       (session/get-in [:prompt :state :override])
                       (conj node-path
                             :fields
                             (session/get-in [:prompt :state :field-name])))}
               {:action "Cancel" :fn identity}]}))

(defn overrides-containing-node-path [node-path]
  (->> (get-in (nest-overrides (session/get :override-draft)) node-path)
       (search :override-path)
       (map :override-path)))

(defn node-path-comparator-fn [[a & a-rest :as a-seq] [b & b-rest :as b-seq]]
  (and (not-empty a-seq)
       (or (empty? b-seq)
           (if (= a b)
             (node-path-comparator-fn a-rest b-rest)
             (> a b)))))

(defn remove-node-path [node-path]
  (let [node-type (last (butlast (butlast (butlast node-path))))
        overrides-to-remove (->> node-path
                                 overrides-containing-node-path
                                 (sort node-path-comparator-fn))]
    (doseq [override-path overrides-to-remove]
      (remove-override override-path))
    (when (and (< 2 (count node-path)) (not= node-type :elements))
      (add-new-override-at-node-path {} (butlast (butlast node-path))))))

(defn suppress-at-node-path [node-path]
  (add-new-override-at-node-path {:set nil} node-path))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Functions of target-path (nodes in target document tree)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn add-new-override-at-target-path
  ([override target-path] (add-new-override-at-target-path override target-path []))
  ([override target-path node-path]
   (let [target-path-index (/ (count node-path) 2)
         remaining-target-path (subvec target-path target-path-index)
         current-target-doc (if (session/get :show-target-changes) :target-draft :target-doc)]
     (if (and (empty? remaining-target-path) node-path)
       (add-new-override (node-path->new-override override node-path))
       (if (number? (first remaining-target-path))
         (let [target (session/get-in (cons current-target-doc (subvec target-path 0 (inc target-path-index))))]
           (if (map? target)
             (prompt/show-prompt
               {:body (partial prompt/choose-where-field target)
                :actions [{:action "Submit"
                           :fn #(let [field (keyword (session/get-in [:prompt :state :field]))
                                      value (session/get-in [:prompt :state :value])]
                                  (->> {field value}
                                       (conj node-path :elements)
                                       (add-new-override-at-target-path override target-path)))}
                          {:action "Cancel" :fn identity}]})
             (add-new-override-at-target-path override target-path (conj node-path :elements target))))
         (add-new-override-at-target-path override target-path
                                          (conj node-path :fields (name (first remaining-target-path)))))))))

(defn suppress-at-target-path [target-path]
  (add-new-override-at-target-path {:set nil} target-path))

(defn override-current-value-at-target-path [target-path]
  (let [current-value (session/get-in (cons :target-doc target-path))]
    (add-new-override-at-target-path {:match current-value :set current-value} target-path)))

(defn override-unconditionally-at-target-path [target-path]
  (let [current-value (session/get-in (cons :target-doc target-path))]
    (add-new-override-at-target-path {:set current-value} target-path)))