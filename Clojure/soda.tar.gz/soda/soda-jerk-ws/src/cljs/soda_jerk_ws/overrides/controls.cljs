(ns soda-jerk-ws.overrides.controls
  (:require [cljs.pprint :as pp]
            [clojure.string :as str]
            [reagent.core :as r]
            [reagent.session :as session]))

(defn labelled-control [label-text control & {:keys [tooltip classes]}]
  [(keyword (str "div.input-group" (apply str (map #(str "." %) classes))))
   [:span.input-group-addon {:title tooltip} label-text]
   control])

(defn input-dropdown [current-value dropdown-content]
  [:div.btn-group
   [:button.btn.btn-default
    {:type "button" :class "dropdown-toggle" :data-toggle "dropdown" :aria-haspopup true :aria-expanded false}
    current-value " " [:span.fa.fa-sort-desc]]
   [:ul.dropdown-menu dropdown-content]])

(defn parse-number [n]
  (or (some->> n (re-find #"-?\d+\.\d+") js/parseFloat)
      (some->> n (re-find #"-?\d+") js/parseInt)))

(defn cast-input-value [control-type value]
  (case control-type
    "number" (parse-number value)
    value))

(defn input [control-type current-value change-fn & [attrs]]
  [:input.form-control
   (merge
     {:type control-type
      :default-value current-value
      :placeholder (when (nil? current-value) "null")
      :on-blur #(some->> % .-target .-value (cast-input-value control-type) change-fn)}
     attrs)])

(defn toggle-switch [current-value change-fn]
  [:input {:type "checkbox"
           :on-change #(-> current-value not change-fn)
           :checked (boolean current-value)
           ; :data-toggle "toggle"
           ; :data-on "True"
           ; :data-off "False"
           :data-height "100%"}])

(defn textarea [current-value change-fn & {:keys [read-only] :or {read-only false}}]
  [:textarea.form-control
   {:default-value current-value :read-only read-only
    :on-blur #(-> % .-target .-value change-fn)}])

(defn inputx [type path & {:keys [key options tooltip pre-update post-update] :or {pre-update identity}}]
  (let [current (session/get-in path)
        update-fn #(do (session/assoc-in! path ((or pre-update identity) %))
                       (when post-update (post-update %)))]
    [:div {:key key}
     (case type
       :string   (input "text" current update-fn)
       :text     (textarea current update-fn)
       :number   (input "number" current update-fn)
       :date     (input "text" current update-fn) ;TODO: Date picker? Better validation?
       :boolean  (toggle-switch current update-fn)
       :enum     (input-dropdown current
                  [:div (for [option options]
                          [:li {:key option :on-click (partial update-fn option)}
                           [:span option]])])
       :null     [:span.null-control "null"]
       (input "text" current update-fn))]))

(defn labelled-input [type label path & {:keys [key options tooltip pre-update post-update]}]
  [:div.input-group {:key (or key path)}
   [:span.input-group-addon {:title tooltip} label]
   (inputx type path :options options :tooltip tooltip :pre-update pre-update :post-update post-update)])

(defn button [text on-click & {:keys [key]}]
  [:button.btn.btn-default {:type "button" :on-click on-click :key key} text])

(defn menu-dropdown [dropdown-content & {:keys [toggle-element]
                                         :or {toggle-element [:span.glyphicon.glyphicon-chevron-down]}}]
  [:div.dropdown toggle-element [:div.dropdown-content dropdown-content]])

(defn simple-menu-dropdown [content-map & {:keys [toggle-element]}]
  (let [dropdown-content (doall (for [{:keys [text fn]} (filter identity content-map)]
                                  [:a {:on-click fn :key text} text]))]
    (menu-dropdown dropdown-content :keys toggle-element)))




(defn tree-node [node-content children & {:keys [expanded] :or {expanded false}}]
  (let [node-state (r/atom {:expanded expanded})]
    (fn [node-content children]
      [:li.tree-node {:class [(if (empty? children) "leaf" (if @(r/cursor node-state [:expanded]) "expanded" "collapsed"))]}
       [:div.node-body
        [:span.expander-glyph {:on-click #(swap! node-state update :expanded not)}]
        [:div.node-content node-content]]
       [:ul.node-children (map-indexed (fn [i el] (with-meta el {:key i})) children)]])))
