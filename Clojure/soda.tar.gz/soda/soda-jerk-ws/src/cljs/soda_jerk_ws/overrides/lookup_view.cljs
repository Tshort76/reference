(ns soda-jerk-ws.overrides.lookup-view
  (:require [reagent.session :as session]
            [soda-jerk-ws.overrides.controls :as controls]
            [soda-jerk-ws.overrides.common :refer [go-to-page]]
            [soda-jerk-ws.overrides.types :as types]
            [cljs.pprint :as pp]))

(defn identifier-form []
  [:div
   (if-let [identifiers (types/type->identifiers (session/get :type))]
     (doall (for [id identifiers]
              (let [form-type (types/identifier->form-type id)]
                (controls/labelled-input form-type id [:identifiers id] :key id))))
     (prn (str "Error: Invalid override type:" (session/get :type))))
   [:button.btn.btn-default {:on-click #(go-to-page (types/state->url))} "Search"]])

(defn render-search-results []
  [:div
   [:h4 "Search Results:"]
   (doall (for [{:keys [text url-fn path]} (types/type->search-results (session/get :type))]
            (let [result (session/get-in path)]
              [:p {:key text} (str text ": ")
               (if (and result (not= result {}))
                 [:a {:href (url-fn)} "Found"]
                 "Not Found")])))
   [:p "Override Notes:"]
   [:pre>code (session/get-in (conj (:path types/override) :notes))]])

(defn override-type-control []
  (controls/labelled-control
    "Override Type: "
    (controls/input-dropdown
      (name (session/get :type))
      [:div (doall (for [type ["security" "entity" "index" "document"]]
                                            [:li {:on-click #(go-to-page (str "#overrides?type=" type)) :key type} type]))])))

(defn action-controls []
  [:div
   (doall (for [[action {:keys [text predicate transition-fn]}] types/actions]
            (when (predicate)
              (controls/button text (partial transition-fn action) :key action))))])

(defn lookup-pane []
  [:div
   [override-type-control]
   [:hr]
   [identifier-form]
   (when (session/get :search-results) [:hr])
   (when (session/get :search-results) [render-search-results])
   [:hr]
   [action-controls]])

(defn doc-view []
  (let [target-doc (-> (session/get :type) types/type->search-results first :path session/get-in)]
    [:pre>code (when target-doc (.stringify js/JSON (clj->js target-doc) nil 2))]))

(defn render []
  [:table>tbody
   [:tr
    [:td#lookup-pane.primary-view {:rowSpan 2} [lookup-pane]]
    [:td#doc-label.view-label [:span (-> (session/get :type) types/type->search-results first :text)]]]
   [:tr [:td#doc-view.secondary-view [doc-view]]]])