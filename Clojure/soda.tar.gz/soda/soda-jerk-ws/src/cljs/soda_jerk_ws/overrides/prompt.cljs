(ns soda-jerk-ws.overrides.prompt
  (:require [reagent.core :as r]
            [reagent.session :as session]
            [soda-jerk-ws.overrides.controls :as controls]
            [soda-jerk-ws.overrides.common :as c]
            [cljs.pprint :as pp]))

(defn add-do-not-process-prompt []
  (session/assoc-in! [:prompt :state :notes] "")
  (fn []
    [:div
     (controls/inputx :text [:prompt :state :notes])]))

(defn remove-do-not-process-prompt [notes]
  [:pre>code notes])

(defn choose-type-prompt [target-path]
  (session/assoc-in! [:prompt :state :type] (c/value->type (session/get-in target-path)))
  (fn []
    [:div
     (controls/labelled-input :enum "Field Type" [:prompt :state :type]
                              :options ["string" "number" "date" "boolean" "null"])]))

(defn choose-where-field [target]
  (session/assoc-in! [:prompt :state :where-type] "Existing Field")
  (fn []
    [:div
     [controls/textarea (with-out-str (pp/pprint target)) identity :read-only true]
     (controls/labelled-input :enum "Mode" [:prompt :state :where-type]
                              :options ["Existing Field" "Specify Field and Value"])
     (if (#{"Specify Field and Value"} (session/get-in [:prompt :state :where-type]))
       [:div
        (controls/labelled-input :string "Field" [:prompt :state :field])
        (controls/labelled-input :enum "Field Type" [:prompt :state :type]
                                 :options ["string" "number" "date" "boolean" "null"]
                                 :post-update #(session/assoc-in! [:prompt :state :value]
                                                                  (c/default-values-for-type (keyword %))))
        (controls/labelled-input (keyword (session/get-in [:prompt :state :type]))
                                 "Value" [:prompt :state :value])]
       (controls/labelled-input :enum "Field" [:prompt :state :field]
                                :options (mapv name (keys target))
                                :post-update #(session/assoc-in! [:prompt :state :value] (target (keyword %)))))]))

(defn create-field-prompt []
  (session/assoc-in! [:prompt :state] {:field-type "map" :field-name "" :override {}})
  (fn []
    [:div
     (controls/labelled-input :enum "Field Type" [:prompt :state :field-type]
                              :options ["map" "array" "string" "number" "date" "boolean"]
                              :post-update #(session/assoc-in!
                                              [:prompt :state :override]
                                              (if (#{"map" "array"} %)
                                                {}
                                                {:set (c/default-values-for-type (keyword %))})))
     (controls/labelled-input (session/get-in [:prompt :state :field-type]) "Field Name" [:prompt :state :field-name])]))

(defn create-element-prompt []
  (session/assoc-in! [:prompt :state] {:element-type "map" :field-type "string" :field-name "" :field-value ""})
  (fn []
    (let [{:keys [element-type field-type field-name field-value where-clause]} (session/get-in [:prompt :state])]
      [:div
       (controls/labelled-input :enum "Element Type" [:prompt :state :element-type]
                                :options ["map" "string" "number" "date" "boolean"])
       (when (= "map" element-type)
         (controls/labelled-input :string "Element ID Field Name" [:prompt :state :field-name]))
       (controls/labelled-input :enum "Element ID Type" [:prompt :state :field-type]
                                :options ["string" "number" "date" "boolean"]
                                :post-update #(session/assoc-in! [:prompt :state :field-value]
                                                                 (c/default-values-for-type (keyword %))))
       (controls/labelled-input (keyword field-type) "Field Value" [:prompt :state :field-value])])))

(defn toggle-modal []
  (.click (.getElementById js/document "modal-trigger")))

(defn show-prompt [{:keys [title body actions]}]
  (session/assoc-in! [:prompt :title] title)
  (session/assoc-in! [:prompt :body] body)
  (session/assoc-in! [:prompt :actions] actions)
  (toggle-modal))

(defn render-fn []
  (let [{:keys [title body actions]} (session/get :prompt)]
    [:div
      [:div#prompt-modal.modal.fade {:tabIndex -1 :role "dialog" :aria-labelledby "modal-label" :aria-hidden false}
       [:div.modal-dialog {:role "document"}
        [:div.modal-content
         (when title [:div.modal-header>h5#modal-label.modal-title title])
         (when body [:div.modal-body [body]])
         [:div.modal-footer
          (doall (for [i (range (count actions))]
                   (let [{:keys [action fn]} (nth actions i)]
                     [:button.btn {:class [(if (zero? i) "btn-primary" "btn-secondary")] :key i
                                   :type "button" :data-dismiss "modal" :on-click fn} action])))]]]]
     [:button#modal-trigger.btn.btn-primary {:type "button" :data-toggle "modal" :data-target "#prompt-modal"
                                             :style {:display "none"}}]]))

(defn render []
  (r/create-class
    {:display-name "Override Pop-Up Modal"
     :reagent-render render-fn}))