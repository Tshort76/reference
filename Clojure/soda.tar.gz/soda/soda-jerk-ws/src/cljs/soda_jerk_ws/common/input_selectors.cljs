(ns soda-jerk-ws.common.input-selectors
  (:require [soda-jerk-ws.common.editors :as c]))

(defmulti standard-input
  (fn [path vocab-field state field meta errors]
    (:field-type vocab-field)))

(defmethod standard-input :select [path vocab-field state field meta errors]
  (c/combo-entry path vocab-field (:options vocab-field) state field meta errors))

(defmethod standard-input :custom-select [path vocab-field state field meta errors]
  (c/fuzzy-input-entry path vocab-field (:options vocab-field) state field meta errors))

(defmethod standard-input :boolean [path vocab-field state field meta errors]
  (c/combo-entry path vocab-field {true "True" false "False"} state field meta errors))

(defmethod standard-input :multi-string [path vocab-field state field meta errors]
  (c/multi-string-entry path vocab-field state field meta errors))

(defmethod standard-input :array [path vocab-field state field meta errors]
  (c/array-entry path vocab-field state field meta errors standard-input))

(defmethod standard-input :default [path vocab-field state field meta errors]
  (c/input-entry path vocab-field state field meta errors))
