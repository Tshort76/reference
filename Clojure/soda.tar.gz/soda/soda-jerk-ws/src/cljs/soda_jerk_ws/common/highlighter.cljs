(ns soda-jerk-ws.common.highlighter
  (:require [clojure.string :as str]
            [soda-jerk-ws.common.html-parsing :as parse]))

(defn get-id-path [path]
  (into [:meta :hi-lite-ids] (drop 2 path)))

(defn mod-hi-lite-path [path]
  (into [:meta :mod-hi-lite-ids] (drop 2 path)))

(defn orig-value-path [path]
  (into [:meta :orig-values] (drop 2 path)))

(defn meta->highlight-ids [meta path]
  (letfn [(get-path [path-fn]
                    (->> path
                         path-fn
                         rest
                         (get-in meta)))]
    (or (get-path mod-hi-lite-path)
        (get-path get-id-path))))

(defn safe-int [n]
  (if (number? n)
    (int n)
    n))

(defn id->css-id [id]
  (if (string? id)
    (->> id
         parse/sanitize-id
         str)
    (str (-> id ((some-fn :page-number :page)) safe-int)
         "_" (-> id :x safe-int)
         "_" (-> id :y safe-int))))

(defn change-ids-background [state ids color]
  (.remove (js/$ "[id^='hl_']"))
  (let [data-type (-> @state :meta :data-type keyword)] 
    (doseq [id (flatten ids)]
      (if (#{:edgar-prospectus} data-type) 
        (when-let [elem (-> js/window .-frames (aget 0) .-document (.getElementById id))]
         (doto elem 
           (.setAttribute "style" (str "background-color: " (or color "yellow")))))
        (when-let [elem (.getElementById js/document (id->css-id id))]
          (let [new-rect (.createElementNS js/document "http://www.w3.org/2000/svg", "rect")
                bbox (.getBBox elem)]
            (doto new-rect
              (.setAttribute "id" (str "hl_" id))
              (.setAttribute "width" (.-width bbox))
              (.setAttribute "height" (.-height bbox))
              (.setAttribute "x" (.getAttribute elem "x"))
              (.setAttribute "y" (- (.getAttribute elem "y") (.getAttribute elem "font-size")))
              (.setAttribute "style" (str "fill:" (or color "yellow"))))
            (.prepend (js/$ "svg") new-rect)))))))

(defn scroll-to-first [[f-id & r-ids]]
  (when-let [elem (->> (if (sequential? f-id)
                         (first f-id)
                         f-id)
                       id->css-id
                       (str "#")
                       js/$
                       .offset)]
    (let [viewer (js/$ "#prospectus-viewer")
          top (- (+ (.-top elem)
                    (.scrollTop viewer))
                 (/ js/window.innerHeight 2))]
      (.animate viewer
                #js {:scrollTop top}
                500)))
  (conj (vec r-ids) f-id))

(defn clear-highlights! [state]
  (when (= :html (:viewer @state))
    (change-ids-background state (:highlight-ids @state) "")
    (swap! state dissoc :highlight-ids)))

(defn id-sorter [id]
  (let [id (if (sequential? id)
             (first id)
             id)]
    (if (map? id)
      ((juxt :page :y :x) id)
      (let [[p x y] (mapv js/parseInt
                          (-> id
                              id->css-id
                              (str/replace #"id" "")
                              (str/split #"_")))]
        [p y x]))))

(defn update-highlights-by-id! [state color-id-seq & cycle-tag]
  (if (and cycle-tag (= cycle-tag (:cycle-tag @state)))
    (swap! state update :highlight-ids scroll-to-first)
    (when (or (= :html (:viewer @state))
              (nil? (:viewer @state)))
      (change-ids-background state (:highlight-ids @state) "")
      (let [id-list (mapcat (fn [[color ids]]
                              (change-ids-background state ids color)
                              ids)
                            color-id-seq)]
        (swap! state assoc :cycle-tag cycle-tag)
        (->> id-list
             (sort-by id-sorter)
             scroll-to-first
             (swap! state assoc :highlight-ids))))))

(defn update-highlights! [state path]
  (let [mod-ids (get-in @state (mod-hi-lite-path path))
        orig-ids (get-in @state (get-id-path path))]
    (update-highlights-by-id!
     state
     [["#fb0" (concat orig-ids mod-ids)]])))

(defn update-highlight-ids! [state path coercer [selection word-id-list]]
  (swap! state assoc-in (mod-hi-lite-path path)
         (->> word-id-list
              (mapv second)
              distinct))
  (->> selection
       coercer
       (swap! state assoc-in path))
  (clear-highlights! state))

(defn reset-highlight-ids! [state path]
  (swap! state assoc-in (mod-hi-lite-path path) nil)
  (swap! state assoc-in path (get-in @state (orig-value-path path)))
  (clear-highlights! state))
