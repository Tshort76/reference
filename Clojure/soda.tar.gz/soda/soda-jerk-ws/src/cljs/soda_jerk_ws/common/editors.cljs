(ns soda-jerk-ws.common.editors
  (:require [schema.core :as scm]
            [soda-jerk-ws.common.entity-naming-utils :as enu]
            [soda-jerk-ws.common.highlighter :as hl]
            [soda-jerk-ws.common.selector :as sel]
            [soda-jerk-ws.common.field-coercers :as coerce]
            [soda-jerk-ws.common.entry-validator :as valid]
            [clojure.string :as str]))

(defn remove-nth [vect n]
  (vec (concat
         (subvec vect 0 n)
         (subvec vect (inc n) (count vect)))))

(def addon-type-map
  {:dollars "$"
   :percent "%"
   :integer "#"
   :number "#.#"
  ;  :string "\"abc\""
   :date [:span.fa.fa-calendar]})

(defn get-js-type [value]
  (.. js/Object -prototype -toString (call value)))

(defn format-date [type value]
  (if
    (and (= type :date)
         (= "[object Date]" (get-js-type value)))
    (subs (.toISOString value) 0 10)
    value))

(defn add-tooltip [tooltip]
  (when tooltip
    [:span {:data-toggle "tooltip"
            :data-placement "bottom"
            :title tooltip
            :style {:cursor "help"}}
     " " [:span.fa.fa-question-circle]]))

(defn highlight-button [state path meta]
  [:button.btn.btn-default
   {:type "button"
    :on-click #(hl/update-highlights! state path)
    :disabled (empty? (hl/meta->highlight-ids meta path))
    :title "Highlight the field's source from the document."}
   [:span.fa.fa-link
    {:style {:line-height "2rem"}}]])

(defn update-id-button [state path coercer]
  [:button.btn.btn-info
   {:type "button"
    :on-click #(do (->> @state
                        :prospectus-word-id-list
                        sel/selected-ids
                        (hl/update-highlight-ids! state path coercer))
                 (valid/update-errors! state))
    :title "Update field to the currently selected value in the document."}
   [:span.fa.fa-share-square-o
    {:style {:line-height "2rem"}}]])

(defn reset-id-button [state path]
  [:button.btn.btn-warning
   {:type "button"
    :on-click #(do (hl/reset-highlight-ids! state path)
                 (valid/update-errors! state))
    :title "Reset the field to its original value."}
   [:span.fa.fa-undo
    {:style {:line-height "2rem"}}]])

(defn update-id-button-group [state path meta vocab-field]
  [:span.input-group-btn {:role "group"}
   [update-id-button state path (coerce/gen-coercer vocab-field)]
   [reset-id-button state path]
   [highlight-button state path meta]])

(defn wrap-form [state form path vocab-field]
  [:span.form-row-wrapper
   [:span.form-row-content form]
   ;; add this back once the field adder works again
   ; [:div.form-row-right
   ;  (when-not (:required vocab-field)
   ;    [:h4>a.x-button.text-danger {:on-click #(swap! state update-in (pop path) dissoc (peek path))}
   ;     [:span.fa.fa-times]])]
   ])

(defn bidi-input [state path value vocab-field invalid?]
  (let [from-primary (coerce/coerce-from-primary vocab-field)]
    [:input.form-control
     {:type "text"
      :value (-> vocab-field :field-type (format-date (from-primary value)))
      ; :class (when invalid? "alert-danger")
      :on-change #(do (swap! state assoc-in path (-> % .-target .-value))
                    (valid/update-errors! state))
      :on-select #(swap! state assoc-in path (-> % .-target .-value))
      :on-blur #(swap! state assoc-in path
                       ((coerce/gen-coercer vocab-field) value))}]))

(defn get-addon [vocab-field]
  (let [label (:label vocab-field)
        type (-> vocab-field :field-type addon-type-map)]
    (if (and label type)
      (str label " (" type ")")
      (or type
          label))))

(defn if-wrap [wrap? head & body]
  (if wrap?
    (into head body)
    (into [:span] body)))

(defn standard-form [state path value vocab-field meta errors & [tail]]
  (let [md5 (:md5 meta)
        addon (get-addon vocab-field)]
    (if-wrap (or md5 addon tail)
      [:div.input-group
      ;  (when errors {:class "has-error"})
       (when md5 [update-id-button-group state path meta vocab-field])
       (when addon [:span.input-group-addon addon])]
      [bidi-input state path value vocab-field errors]
      tail)))

(defn header [vocab-field field-type errors]
  [:span
   [:label (enu/field-name vocab-field field-type)]
   [add-tooltip (:tooltip vocab-field)] " "
   (when errors
     [:span.label.label-danger (if (sequential? errors)
                                 (str/join " " errors)
                                 "Error in child field.")])])

(defn list-item [state path choice-key choice-value]
  [:li {:key choice-value
        :on-click #(do (swap! state assoc-in path (coerce/first-if-seq choice-key))
                     (valid/update-errors! state))}
   [:a (coerce/first-if-seq choice-value)]])

(defn fuzzy-input-entry [path vocab-field choices state value meta errors]
  [wrap-form
   state
   [:form
    [header vocab-field (peek path) errors]
    [:div.input-group
    (if (:md5 meta)
      [update-id-button-group state path meta vocab-field])
     [:span.input-group-addon.btn.btn-default
      {:data-toggle "dropdown"
       :aria-haspopup "true"
       :aria-expanded "false"}
      [:span.caret]]
     [:ul.dropdown-menu.scrollable-menu
      {:role "menu"
       :style {:width "100%"}}
      (for [c (coerce/fuzzy-filter-sort value choices)]
        (list-item state path (coerce/first-if-seq c) c))
      [list-item state path nil "Deselect"]]
     [:input.form-control.dropdown-toggle
      {:type "text"
       :aria-haspopup "true"
       :aria-expanded "false"
       :style {:width "100%"
               :textAlign "left"}
       :value (when value (if (map? choices)
                            (choices value)
                            value))
       :on-select #(-> % .-target .-parentElement .-className (set! "input-group open"))
       :on-change #(do (swap! state assoc-in path (-> % .-target .-value))
                     (valid/update-errors! state))
       :on-blur #(do (swap! state assoc-in path
                            ((coerce/gen-coercer vocab-field) value)))}]]]
   path vocab-field])

(defn combo-entry [path vocab-field choices state value meta errors]
  (let [dropdown [:button.btn.btn-default.dropdown-toggle
                  {:type "button"
                   :data-toggle "dropdown"
                   :aria-haspopup "true"
                   :aria-expanded "true"
                   :style {:width "100%" :textAlign "left"}}
                  (str (if (some? value)
                         (if (map? choices)
                           (choices value)
                           value)
                         "No Selection") "\t")
                  [:span.caret]]
        menu [:ul.dropdown-menu.scrollable-menu
              {:style {:width "100%"}}
              (if (map? choices)
                (for [[k v] choices] (list-item state path k v))
                (for [c choices] (list-item state path (coerce/first-if-seq c) c)))
              [list-item state path nil "Deselect"]]]
    [wrap-form
     state
     [:form
      [header vocab-field (peek path) errors]
      (if (:md5 meta)
        [:div.input-group
         [update-id-button-group state path meta vocab-field]
         dropdown menu]
        [:div.dropdown dropdown menu])]
     path vocab-field]))

(defn input-entry [path vocab-field state value meta errors]
  [wrap-form
   state
   [:form {:key (str "form-" path)}
    [header vocab-field (peek path) errors]
    [standard-form state path value vocab-field meta errors]
    (when-let [secondary (:secondary vocab-field)]
      [standard-form state path value secondary meta errors])]
   path vocab-field])

(defn multi-string-entry [path vocab-field state value meta errors]
  [wrap-form
   state
   [:form {:key (str "form-" path)}
    [header vocab-field (peek path) errors]
    [:div
     (doall (for [index (range (count value))
                  :let [index-path (conj path index)]]
              [:div {:key (str "form-" path "-" index)
                     :style {:marginBottom "5px"}}
               [standard-form state index-path
                (value index)
                (assoc vocab-field :field-type :string) meta errors
                [:span.input-group-btn>a.btn.btn-default
                 {:on-click #(do (swap! state update-in path remove-nth index)
                               (swap! state update-in (hl/mod-hi-lite-path path) remove-nth index))}
                 [:span.fa.fa-times {:style {:color "#aa0000" :line-height "2rem"}}]]]]))]
    [:a {:on-click
         #(do (swap! state assoc-in path (vec (conj value "")))
            (swap! state update-in (hl/mod-hi-lite-path path) (fnil conj []) nil))}
     "Add new..."]]
   path vocab-field])

(defn array-entry [path vocab-field state value meta errors subfield-fn]
  [wrap-form
   state
   [:div {:key (str "form-" path)}
    [header vocab-field (peek path) errors]
    (doall (for [index (range (count value))
                 :let [index-path (conj path index)]]
             [:div.form-row-wrapper {:key (str "form-" index-path)
                    :style {:marginBottom "5px"
                            :width "auto"}}
              [:div.form-row-content
               (for [field-name (-> vocab-field :items keys)
                     :let [path (conj path index field-name)
                           final-path [index field-name]]]
                 [:span {:key (str path ".st-in")}
                  [subfield-fn path (get-in vocab-field [:items field-name]) state
                   (get-in value final-path)
                   meta (get-in errors final-path)]])]
              [:a.btn.btn-default
               {:style {:height "3.5rem"}
                :on-click #(do (swap! state update-in path remove-nth index)
                             (swap! state update-in (hl/mod-hi-lite-path path) remove-nth index)
                             (valid/update-errors! state))}
               [:span.fa.fa-times {:style {:color "#aa0000" :line-height "2rem"}}]]]))
    [:a {:on-click
         #(do (swap! state assoc-in path (vec (conj value {})))
            (swap! state update-in (hl/mod-hi-lite-path path) (fnil conj []) {})
            (valid/update-errors! state))}
     "Add new..."]]
   path vocab-field])
