(ns soda-jerk-ws.common.service-interop-functions
  "Handy interop-with-services functions."
  (:require-macros [cljs.core.async.macros :refer [go]])
  (:require [cljs.core.async :refer [chan <! >!]]
            [cljs.pprint :refer [pprint]]))

(defn nil-fn [& _] nil)

(defn par-wrap [k] (fn [v] {k v}))

(defn print-error [e]
  (->> e pprint with-out-str (.log js/console)))

(defn async-request-fn [request-fn params-fn endpoint tag]
  (fn [params handler & [error-handler]]
    (request-fn (str js/context endpoint)
                {:response-format :json
                 :keywords? true
                 :params (params-fn params)
                 :handler (fn [response] (when response (handler response)))
                 :error-handler (fn [response] ((or error-handler print-error) response))})))