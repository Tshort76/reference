(ns soda-jerk-ws.common.field-coercers
  (:require [clojure.string :as str]
            [clj-fuzzy.metrics :refer [jaro-winkler]]))

(defn none? [v]
  (or (nil? v)
      (= "" v)))

(defn gen-num-coercer [format-fn]
  (fn [v]
    (let [num (if (string? v)
                (format-fn v)
                v)]
      (when-not (js/isNaN num)
        num))))

(def ->number
  (gen-num-coercer #(js/parseFloat (str/replace % #"[^\d.-]" ""))))

(def ->int
  (gen-num-coercer #(js/parseInt (str/replace % #"[^\d.-]" ""))))

(defn clean [v]
  (when (string? v)
    (-> v
        str/trim
        str/lower-case)))

(defn scoring-fn [target]
  (let [clean-jaro-fn (comp (partial jaro-winkler (clean target)) clean)]
    (fn [value]
      (if (sequential? value)
        (apply max (map clean-jaro-fn value))
        (clean-jaro-fn value)))))

(defn fuzzy-filter-sort [value str-list]
  (if (none? value)
    str-list
    (->> str-list
         (mapv (scoring-fn value))
         (zipmap str-list)
         (filter (comp (partial < 0) second))
         (sort-by second >)
         (mapv first))))

(defn first-if-seq [item]
  (if (sequential? item)
        (first item)
        item))

(defn gen->enum [enum]
  (let [ks (if (map? enum) (keys enum) enum)]
    (fn [target]
      (contains? ks target))))

(defn ->date [v]
  (when-not (or (none? v)
                (and (string? v)
                     (re-matches #"\s*\d\d?\D\d\d?\D\d{1,4}\s*" v))) ; ambiguous date
    (let [date (cond-> v
                       (string? v) (str/replace #"[()]" "")
                       true js/Date.)]
      (when-not (js/isNaN date)
        (.setUTCHours date 0 0 0 0)
        date))))

(defn format-text [{:keys [strip-whitespace upper-case strip-hyphens] :as blah}]
  ;; note: the functions in the list will be executed in REVERSE order
  (->> [[upper-case str/upper-case]
        [strip-whitespace #(str/replace % #"\s" "")]
        [strip-hyphens #(str/replace % #"-" "")]
        [true str/trim]]
       (filter first)
       (map second)
       (apply comp)))

(defn coerce-extra* [fun args]
  (if fun
    (fn [i] (if (number? i)
              (apply fun i args)
              i))
    identity))

(defn dec-shift [value x]
  (let [pos-x (if (pos? x) x 0)
        neg-x (if (neg? x) (- x) 0)
        pattern (re-pattern
                 (str "(\\d{" neg-x "})\\.(\\d{" pos-x "})"))
        pre (apply str (repeat neg-x "0"))
        post (apply str (repeat pos-x "0"))]
    (-> (str pre value post ".")
        (str/replace-first pattern "$2.$1")
        js/parseFloat)))

(defn coerce-to-primary [{[fun-type & args] :to-primary}]
  (coerce-extra* ({:dec-shift dec-shift}
                  fun-type)
                 args))

(defn coerce-from-primary [{[fun-type & args] :to-primary}]
  (coerce-extra* ({:dec-shift #(dec-shift %1 (- %2))}
                  fun-type)
                 args))

(defn map-if-array [f]
  (fn [x]
    (if (sequential? x)
      (map f x)
      (f x))))

(defn gen-coercer-strict [{:keys [field-type options to-primary] :as vocab-field}]
  (if-some [f (case field-type
                :date ->date
                (:number :dollars :percent) ->number
                :integer ->int
                :string (format-text vocab-field)
                :multi-string (map-if-array (format-text vocab-field))
                :select (gen->enum options)
                :boolean (gen->enum [true false])
                nil)]
    #(when-not (none? %)
       (some-> %
               f
               ((coerce-to-primary vocab-field))))
    identity))

(defn gen-coercer [x]
  (some-fn (gen-coercer-strict x) #(when-not (none? %) %)))
