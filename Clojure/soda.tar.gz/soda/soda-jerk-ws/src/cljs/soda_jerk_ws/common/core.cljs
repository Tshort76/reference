(ns soda-jerk-ws.common.core
  (:require [ajax.core :refer [GET]]
            [goog.events :as events]
            [goog.history.EventType :as EventType]
            [reagent.core :as reagent]
            [reagent.session :as session]
            [secretary.core :as secretary :refer-macros [defroute]]
            [soda-jerk-ws.jaeger.core :as jaeger]
            [soda-jerk-ws.judy.core :as j]
            [soda-jerk-ws.overrides.core :as overrides]
            [soda-jerk-ws.raptor.core :as raptor]
            [soda-jerk-ws.system-health.system-health :as health])
  (:import goog.History))

(defn partial-link-element [label url]
  (let [field-value (atom "")
        go-to-link  #(.open js/window (str js/context url @field-value) "_blank")]
    [:div label [:input {:type        "text" :on-change #(reset! field-value (-> % .-target .-value))
                         :on-key-down #(when (= (.-keyCode %) 13) (go-to-link))}]
     [:button {:on-click go-to-link} "Go"]]))

(defn home-page []
  [:div.container
   [:div.jumbotron
    [:h2 "Welcome to the SoDa Stream"]
    [:hr]
    [:h4>a {:href (str js/context "/swagger-ui")} "Visit the APIs"]
    [:hr]
    [:h4 "Xmas Trees"]
    [:ul
     [:li>a {:href "#cusip-linking/edgar-cusipless-fun"} "Valentines tree"]
     [:li>a {:href "#health/validation?control-set=edgar-multi-1000&source=jaegers&show=mvp"} "Xmas Tree 2 - Jaegers"]
     [:li>a {:href "#jaeger/stats/edgar-multi-1000"} "Xmas Tree - Jaegers"]
     [:li>a {:href "#health/validation?control-set=edgar-multi-1000&source=soda-api&show=mvp"} "Xmas Tree 2 - API"]
     [:li>a {:href "#soda-api/stats/edgar-multi-1000"} "Xmas Tree - API"]
     [:li>a {:href "http://dev-sodaqa-intake-group1-app2:1441/christmasTreeChart.html"} "Xmas tree history"]]
    [:h4 "Dashboards"]
    [:ul
     [:li>a {:href "#health"} "Health Dashboard"]
     [:li>a {:href "#health/failures"} "Failures Dashboard"]
     [:li>a {:href "#health/machine-overview"} "Machine Overview"]
     [:li>a {:href "#health/file-expectations"} "File Expectations"]
     [:li>a {:href "http://dev-sodaqa-intake-group1-app2:1441/scraperReport.html?env=prod"} "Scraper Report"]
     [:li>a {:href "http://dev-sodaqa-intake-group1-app2:1441/jobRuntimeAnalysis.html"} "Job runtime analysis"]
     [:li>a {:href "http://dev-soda-service-pygroup2-app1:8004"} "ML Dashboard"]]
    [:h4 "Data Entry / Improvement"]
    [:ul
     [:li>a {:href "http://dev-soda-intake-group1-app1:8084/surveyor#/status"} "Surveyor (dev)"]
     [:li>a {:href "http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/surveyor/source-fields"} "Surveyor Source Fields (dev)"]
     [:li>a {:href "#judy"} "Enter prospectus data"]
     [:li>a {:href "#overrides"} "Override data"]]
    [:h4 "Data Inspection/Audit"]
    [:ul
     [:li>a {:href "#raptor/synthahaul"} "Synthahaul Pipeline Inspector"]
     [:li>a {:href "#raptor/audit"} "Pipeline Audit Inspector (Raptor)"]
     [:li>a {:href "#jaeger"} "Jaeger Data"]]
    [:hr]
    [:h4 "Look up File Names:"]
    (partial-link-element "Cusip: " "/edgar/files/")
    [:br]
    [:h4 "Look up a File (by File Name):"]
    (partial-link-element "Original File: " "/overmind/original-file/?filename=")
    (partial-link-element "Edgar Prospectus: " "/overmind/food/html?filename=")
    (partial-link-element "Edgar Candidates: " "/overmind/food/edgar-candidates?filename=")
    [:h4 "Look up a File (by md5):"]
    (partial-link-element "Original File: " "/overmind/original/?md5=")
    (partial-link-element "Edgar Prospectus: " "/overmind/food/html?md5=")
    (partial-link-element "Edgar Candidates: " "/overmind/food/edgar-candidates?md5=")
    [:hr]
    [:h6 "The site formerly known as Judy"]]])

(defn page []
  [(session/get :page)])

(defn title []
  [:title (or (session/get :title) "SoDa-Jerk-WS")])

(defn css []
  (let [file (session/get :css)]
    (when file [:link {:rel "stylesheet" :href file}])))

;; -------------------------
;; Routes
(secretary/set-config! :prefix "#")

(defroute "/" []
  (session/put! :page #'home-page)
  (session/put! :title "SoDa Jerk WS - Home"))

(defroute "/health" []
  (session/put! :page #'health/health-overview)
  (session/put! :title "SoDa Health Overview"))

(defroute "/health/failures" [query-params]
  (session/put! :page (partial #'health/current-failures-page query-params))
  (session/put! :title "SoDa Failures"))

(defroute "/health/machine-overview" [query-params]
  (session/put! :page (partial #'health/machine-overview-page query-params))
  (session/put! :title "SoDa Machine Overview"))

(defroute "/health/file-expectations" [query-params]
  (session/put! :page (partial #'health/file-expectations-page query-params))
  (session/put! :title "SoDa File Expectations"))

(defroute "/health/validation" [query-params]
  (session/put! :page (partial #'health/validation-page query-params))
  (session/put! :title "SoDa Data Validation"))

(defroute "/health/validate-doc" [query-params]
  (session/put! :page (partial #'health/validate-doc-page query-params))
  (session/put! :title "Validate Document"))

(defroute "/judy" []
  (session/put! :page #'j/judy-page)
  (session/put! :title "Judy (Adjudication Tool)"))

(defroute "/raptor/synthahaul" []
  (session/put! :page #'raptor/main-page)
  (session/put! :title "Raptor Synthahaul"))

(defroute "/raptor/audit" []
  (session/put! :page #'raptor/audit-page)
  (session/put! :title "Raptor Audit"))

(defroute "/raptor/audit/:id-type/:id" {:keys [id-type id]}
  (session/put! :page (fn [] (#'raptor/audit-page id-type id)))
  (session/put! :title "Raptor Audit"))

(defroute "/jaeger/stats/:control-set" {:keys [control-set]}
  (session/put! :page (fn [] (#'jaeger/stats-page control-set)))
  (session/put! :title "Xmas Tree - Jaegers"))

(defroute "/cusip-linking/:control-set" {:keys [control-set]}
  (session/put! :page (fn [] (#'jaeger/cusip-linking-page control-set)))
  (session/put! :title "Valentines Tree - Jaegers"))

(defroute "/soda-api/stats/:control-set" {:keys [control-set]}
  (session/put! :page (fn [] (#'jaeger/stats-page control-set :soda-api? true)))
  (session/put! :title "Xmas Tree - SoDa API"))

(defroute "/jaeger/:collection/:md5" {:keys [collection md5]}
  (session/put! :page (fn [] (#'jaeger/main-page collection md5)))
  (session/put! :title "Jaeger Inspection"))

(defroute "/jaeger/:collection/:md5/:cusip" {:keys [collection md5 cusip]}
  (session/put! :page (fn [] (#'jaeger/main-page collection md5 cusip)))
  (session/put! :title "Jaeger Inspection"))

(defroute "/overrides" [query-params]
  (session/put! :page (partial #'overrides/render query-params))
  (session/put! :title "SoDa Override Tool")
  (session/put! :css "css/overrides.css"))

;; default route
(defroute "*" []
  (session/put! :page #'home-page)
  (session/put! :title "SoDa Jerk WS - Home"))

;; -------------------------
;; History
;; must be called after routes have been defined
(defn hook-browser-navigation! []
  (doto (History.)
    (events/listen
      EventType/NAVIGATE
      (fn [event]
        (secretary/dispatch! (.-token event))))
    (.setEnabled true)))

;; -------------------------
;; Initialize app
;(defn fetch-docs! []
;  (GET (str js/context "/docs") {:handler #(session/put! :docs %)}))

(defn mount-components []
  (reagent/render [#'title] (.getElementById js/document "title"))
  (reagent/render [#'page] (.getElementById js/document "app"))
  (reagent/render [#'css] (.getElementById js/document "css")))

(defn init! []
  ;(ajax/load-interceptors!)
  ;(fetch-docs!)
  (hook-browser-navigation!)
  (mount-components))