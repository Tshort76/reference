(ns soda-jerk-ws.common.ajax
  (:require-macros [cljs.core.async.macros :refer [go]])
  (:require [ajax.core :as ajax]
            [cljs.core.async :refer [<!]]))

;(defn default-headers [request]
;  (-> request
;      (update :uri #(str js/context %))
;      (update
;        :headers
;        #(merge
;          %
;          {"Accept" "application/transit+json"
;           "x-csrf-token" js/csrfToken}))))
;
;(defn load-interceptors! []
;  (swap! ajax/default-interceptors
;         conj
;         (ajax/to-interceptor {:name "default headers"
;                               :request default-headers})))
