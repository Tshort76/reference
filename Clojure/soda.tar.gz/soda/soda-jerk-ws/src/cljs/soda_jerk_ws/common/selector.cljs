(ns soda-jerk-ws.common.selector
  (:require [soda-jerk-ws.common.html-parsing :as html]))

(defn match-consumed-ids [[text-list rest-ids]]
  (let [hash-ids (->> rest-ids first last hash-set)
        [first-words rest-words] (split-with (comp hash-ids last) rest-ids)]
    [(reduce (fn [txl wrd] (if (= (first txl) (first wrd))
                             (rest txl)
                             txl))
             (rest text-list) (rest first-words))
     rest-words first-words]))

(defn consume-ids [[text-list rest-ids consumed-ids-set]]
  (->> (take (count text-list) rest-ids)
       (into (vec consumed-ids-set))))

(defn is-first-valid [[text-list rest-ids]]
  (if (-> text-list first count #{1})
    [(rest text-list)
     (rest rest-ids)]
    [text-list rest-ids]))

(defn get-id-range [id-list text-list]
  (->> [text-list id-list]
       is-first-valid
       match-consumed-ids
       consume-ids))

(defn to-id [node]
  (html/sanitize-id
   (.-id (if-not (#{1} (.-nodeType node))
           (.-parentElement node)
           node))))

(defn take-while+1-pred [pred]
  (let [a (atom pred)]
    (fn [x]
      (when @a
        (if (@a x)
          (do (reset! a nil) true)
          true)))))

(defn selected-ids [id-list]
  (when-let [sel (.getSelection js/window)]
    (when (.contains (.getElementById js/document "prospectus-viewer")
                     (.-anchorNode sel))
      (when-let [rng (and (> (.-rangeCount sel) 0)
                          (-> sel .toString count (> 0))
                          (.getRangeAt sel 0))]
        (let [first-id (some-> rng .-startContainer to-id)
              last-id (some-> rng .-endContainer to-id)
              sel-ids (->> id-list
                           (drop-while (comp not #{first-id} last))
                           (take-while (take-while+1-pred (if last-id
                                                            (comp #{last-id} second)
                                                            identity))))]
          [(.toString sel)
           sel-ids])))))
