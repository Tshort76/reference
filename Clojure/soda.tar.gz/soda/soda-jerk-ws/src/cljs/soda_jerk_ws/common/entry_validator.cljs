(ns soda-jerk-ws.common.entry-validator
  (:require [soda-jerk-ws.common.field-coercers :as coerce]
            [vocabularies.core :as vocab]
            [medley.core :as med]))

;; coercion checks
(defn get-parse-error [{:keys [field-type]}]
  (case field-type
    :date ["Please use the format YYYY-MM-DD for dates."]
    (:number :dollars :percent) ["Please enter a valid number."]
    :integer ["Please enter a valid integer."]
    (:string :multi-string) ["Something bad happened."] ; this shouldn't happen
    :select ["Invalid selection."]
    :boolean ["Invalid selection."]
    [(str "Unknown field type: " field-type)]))

(defn coerce-field [vocab-field value]
  (when (and (not (coerce/none? value))
             vocab-field)
    (if-some [cv ((coerce/gen-coercer-strict vocab-field) value)]
      {:valid cv}
      {:errors (get-parse-error vocab-field)})))

;; additional validation
(defn compare-check [entity com value com-fn com-str]
  (when (and com value)
    (let [m (if (number? com) com (entity com))
          v (if (number? value) value (count value))]
      (when (and m (com-fn v m))
        (str "Field must be no " com-str " than "
             (if (keyword? com) (name com) com)
             (when (string? value) " characters long") ".")))))

(defn max-check [entity max value]
  (compare-check entity max value > "greater"))

(defn min-check [entity min value]
  (compare-check entity min value < "less"))

(defn get-field-errors [entity {:keys [max min]} value]
  {:errors (->> [(min-check entity min value)
                 (max-check entity max value)]
                (filter identity)
                not-empty)})

;; required check
(defn required-field [field-vocab value]
  (if (and (coerce/none? value)
           (or (:required field-vocab)
               (and (some :required
                          (vals (:fields field-vocab))))))
    {:errors ["Required field."]}
    {:valid value}))

;; recursive functions
(defn deep-merge [& m]
  (cond
    (every? map? m) (apply merge-with deep-merge m)
    (every? sequential? m) (apply reduce into m)
    :else (last (filter identity m))))

(defn recurse-check [entry vocab fun]
  (->> vocab
       (map (fn [[field field-vocab]]
              (->> (if-let [sub-vocab (:items field-vocab)]
                     (reduce-kv (fn [m index sub]
                                  (->> (recurse-check sub sub-vocab fun)
                                       (med/map-vals
                                        #(->> %
                                              (med/filter-vals some?)
                                              (hash-map index)
                                              (med/filter-vals not-empty)))
                                       (med/filter-vals not-empty)
                                       (merge-with merge m)
                                       not-empty))
                                {} (field entry))
                     (if-let [sub-vocab (:fields field-vocab)]
                       (->> (recurse-check (field entry) sub-vocab fun)
                            (med/map-vals
                             (partial med/filter-vals
                               (some-fn some? not-empty)))
                            (med/filter-vals not-empty)
                            not-empty)
                       (fun field-vocab (field entry))))
                   (map (fn [[status result]] {status {field result}})))))
       flatten
       (apply merge-with merge)))

;; main function
(defn validate-entry [entry vocab]
  (let [{r-errors :errors valid :valid} (recurse-check entry vocab required-field)
        {c-errors :errors valid :valid} (recurse-check valid vocab coerce-field)
        {v-errors :errors} (recurse-check valid vocab (partial get-field-errors valid))]
    (->> (merge-with deep-merge r-errors c-errors v-errors)
         (med/filter-vals not-empty)
         not-empty)))

;; helper functions
(defn update-errors [state]
  (assoc state :errors
         (validate-entry
          (-> state :entity-map first second)
          (-> state :meta :vocabulary keyword vocab/ordered-vocabs))))

(defn update-errors! [state]
  (swap! state update-errors))
