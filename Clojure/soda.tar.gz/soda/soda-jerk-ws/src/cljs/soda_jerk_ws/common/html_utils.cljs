(ns soda-jerk-ws.common.html-utils
  (:require [clojure.string :as s]
            [cljs.pprint :refer [pprint]]))

(defn capitalize-first-words[string]
  (s/join " " (map s/capitalize (s/split (name string) #"-"))))

(defn button [label action & [options]]
  [:button.btn.btn-default (conj {:type "submit" :on-click (fn [e] (action e))} options) label])

(defn toggle-debug [state]
  [:p {:style #js {:textAlign "center"}}
   (if (:debug? @state)
     [:a {:on-click #(swap! state dissoc :debug?)} "disable debug mode"]
     [:a {:on-click #(swap! state into { :debug? true })} "enable debug mode"])])

(defn debug-view [{:keys [debug?] :as state}]
  (when debug?
    [:div
     [:h4 "Current State"]
     [:pre [:code#state-code
            (-> state
                (cond-> ,,,
                 (:prospectus-word-id-list state)
                 (assoc :prospectus-word-id-list "...")
                 (:hiccup-prospectus state)
                 (assoc :hiccup-prospectus "..."))
                pprint
                with-out-str)]]]))

(def message-types
  {:error "danger"
   :success "success"})

(defn render-message*
  ([] nil)
  ([type msg] [:div.alert {:class (str "alert-" (message-types type))} msg])
  ([type header & body]
   [:div.panel {:class (str "panel-" (message-types type))}
    [:div.panel-heading>h3.panel-title header]
    [:div.panel-body
     (map-indexed (fn [i x] [:pre {:key i} (-> x pprint with-out-str)]) body)]]))

(defn render-message [args]
  (apply render-message* args))

(defn bidi-text [state path]
  [:input.form-control
   {:type "text"
    :value (get-in @state path)
    :on-change #(swap! state assoc-in path (-> % .-target .-value))}])

(defn pretty-wrap [label html]
  [:div.form-row-wrapper>div.form-row-content>form
   [:label label]
   html])
