(ns soda-jerk-ws.arbiter.multi-resolution-page)
;   (:require [clojure.string :as str]
;             [clojure.pprint :as pprint]
;             [soda-jerk-ws.common.html-utils :refer [toggle-debug debug-view]]
;             [soda-jerk-ws.arbiter.service-interop :as svc]
;             [soda-jerk-ws.pages.layout :refer [vertical-gap]]))
;
; (defn pretty-field [class]
;   (if class
;     (->> (-> class
;              name
;              (str/split #"-"))
;          (map str/capitalize)
;          (str/join " "))
;     "UNKNOWN"))
;
; (defn format-conflicts [jaeger-doc]
;   (->> jaeger-doc
;        :jaeger-doc
;        seq
;        (sort-by first)
;        (filter (comp :conflict second))))
;
; (defn count-conflicts [state]
;   (svc/async-count-conflicts
;    nil
;    (fn [num] (swap! state assoc :remaining num))
;    (fn [])))
;
; (defn get-conflicts [state]
;   (swap! state assoc :docs [] :conflicts nil)
;   (count-conflicts state)
;   (svc/async-get-jaeger-conflicts
;    {:cusip (:cusip @state)}
;    (fn [docs] (swap! state assoc
;                      :docs docs
;                      :conflicts (mapv format-conflicts docs)))
;    (fn [] (swap! state assoc :docs []))))
;
; (defn submit-and-update [state]
;   (svc/async-update-jaeger-conflict
;    (:docs @state)
;    #(get-conflicts state)
;    (fn [])))
;
; (defn snippet [md5 ids]
;   (if (and md5 (seq ids))
;     [:iframe {:src (str js/context "/overmind/food/html?md5=" md5
;                         "&limit-context=true&ids=" (str/join "," ids))
;               :width "100%"}]
;     [:h4.padded "No Viewable Document"]))
;
; (defn create-radio-button
;   [field-name md5 update-fn idx {:keys [ids jaeger value] :as option}]
;   [:div.row {:key idx}
;    [:div.col-md-6 [snippet md5 (first (sort-by first ids))]]
;    [:div.radio.col-md-6
;     [:label
;      [:input
;       {:type "radio"
;        :name field-name
;        :id (str field-name idx)
;        :on-click (partial update-fn option)}]
;      (str value) " ( " jaeger " Jaeger )"]]])
;
; (defn form-content [state remaining index jdoc doc]
;   [:div.padded
;    vertical-gap
;    [:div
;     (for [[field {conflict :conflict :as f-val}] jdoc
;           :let [field-name (name field)]]
;       [:div {:key field-name}
;        [:h4 (pretty-field field)]
;        (->> (dissoc f-val :conflict)
;             (conj [conflict])
;             (map-indexed
;              (partial create-radio-button field-name (-> doc :meta :md5)
;                       #(swap! state assoc-in [:docs index :jaeger-doc field] %))))
;        vertical-gap])]
;    [:div.btn-group
;     [:button.btn.btn-success
;      {:type "button"
;       :disabled (or (some (comp :conflict second) (:jaeger-doc doc)) (empty? jdoc))
;       :on-click #(submit-and-update state)}
;      "Submit"]
;     [:button.btn.btn-default
;      {:type "button"
;       :on-click #(get-conflicts state)}
;      "Skip"]]])
;
;
; (defn screen [md5]
;   [:div.col-md-6.no-padding.tall
;    (if md5
;      [:iframe#doc-view.tall {:src (str js/context "/overmind/food/html?md5=" md5)
;                              :width "100%"}]
;      [:h4.padded "No Viewable Document"])])
;
; (defn render [state]
;   (let [{:keys [docs conflicts remaining cusip]} @state]
;     (when (not docs)
;       (get-conflicts state))
;     [:div
;      [:div.padded
;       [:h3 "Jaeger Arbiter"]
;       [:p "Remaining conflicts: " remaining]
;       [:p "Cusip: " cusip]]
;      (map (partial form-content state remaining) (range) conflicts docs)]))
