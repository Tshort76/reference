(ns soda-jerk-ws.arbiter.service-interop)
;   (:require [soda-jerk-ws.common.service-interop-functions :as sif]
;             [ajax.core :refer [GET POST]]))
;
; (def async-get-jaeger-conflict
;   (sif/async-request-fn
;    GET sif/nil-fn "/api/jaeger/conflict" :jaeger-conflict-get))
;
; (def async-get-jaeger-conflicts
;   (sif/async-request-fn
;    GET identity "/api/jaeger/conflicts" :jaeger-conflicts-get))
;
; (def async-count-conflicts
;   (sif/async-request-fn
;    GET sif/nil-fn "/api/jaeger/conflict/count" :jaeger-conflicts-count))
;
; (def async-update-jaeger-conflict
;   (sif/async-request-fn
;    POST identity "/api/jaeger/conflict" :jaeger-conflict-update))
