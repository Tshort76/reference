(ns soda-jerk-ws.arbiter.core)
;   (:require [reagent.core :as r]
;             [soda-jerk-ws.arbiter.resolution-page :as resolve]
;             [soda-jerk-ws.arbiter.multi-resolution-page :as multi]))
;
; (defn main-page [& [cusip]]
;   (if cusip
;     (let [state (r/atom {:cusip cusip})]
;       (r/create-class
;        {:reagent-render (fn [] (multi/render state))}))
;     (let [state (r/atom {})]
;       (r/create-class
;        {:reagent-render (fn [] (resolve/render state))}))))
