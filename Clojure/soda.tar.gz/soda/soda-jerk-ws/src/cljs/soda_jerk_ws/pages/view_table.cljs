(ns soda-jerk-ws.pages.view-table
  (:require [soda-jerk-ws.judy.transitions :as tx]
            [soda-jerk-ws.common.entity-naming-utils :as enu]
            [soda-jerk-ws.common.highlighter :as hl]
            [soda-jerk-ws.common.html-utils :as html]
            [soda-jerk-ws.pages.layout :refer [vertical-gap]]
            [vocabularies.core :as vocab]))

(defn highlight-button [state ids & contents]
  (let [contents (filter identity contents)]
    (when (seq contents)
      (into
       [:span.btn.btn-default
        {:style {:border-radius "0px" :width "100%"}
         :on-click (when ids
                     #(hl/update-highlights-by-id! state [["#fb0" ids]]))}]
       contents))))

(defn form-content [state vocab entities]
  (let [fields (keys (dissoc vocab :meta))]
    [:div.form-content>table.table.table-bordered
     [:thead>tr
      (for [field fields]
        [:th {:key field :style {:padding "0px"}}
         [highlight-button state []
          [:strong (enu/field-name (vocab field) field)]]])]
     [:tbody
      (for [entity entities]
        [:tr {:key (-> entity :meta :_id)}
         (for [field fields]
           [:td {:key field :style {:padding "0px"}}
            [highlight-button state
             (some->> entity :meta :mod-hi-lite-ids field)
             (some->> entity :entity-map first val field str)]])])]]))

(defn render [state]
  (let [{:keys [entities meta]} @state
        {:keys [vocabulary]} meta
        vocab (vocab/ordered-vocabs vocabulary)]
    [:div.form-pane.padded
     [:h3 (str "Issue Type: " (html/capitalize-first-words vocabulary))]
     vertical-gap
     [form-content state vocab entities]
     vertical-gap
     [:div {:style {:textAlign "center"}}
      [:a {:on-click #(swap! state tx/->choose-prospectus)}
       "Choose a different prospectus"]]
     [html/render-message (:message @state)]
     [html/toggle-debug state]
     [html/debug-view @state]]))
