(ns soda-jerk-ws.pages.prospectus-selection
  (:require [soda-jerk-ws.judy.transitions :as tx]
            [soda-jerk-ws.judy.service-interop :as svc]
            [ecs.core :as ecs]
            [ecs.schema :as escm]
            [vocabularies.core :as vocabs]
            [soda-jerk-ws.common.html-utils :as html]
            [clojure.string :as str]
            [soda-jerk-ws.pages.ajax :as pa]
            [clojure.string :as s]
            [soda-jerk-ws.common.editors :as ce]))

(defn clean-ids [ids]
  (mapv #(str "id" (str/replace % "|" "_")) ids))

(defn format-hi-lite-ids [entry]
  (update-in entry [:meta :hi-lite-ids]
    #(zipmap (keys %) (mapv clean-ids (vals %)))))

(defn update-state-overmind! [meta entity-map issue-id]
  #(-> %
       (into {:entity-map entity-map
              :meta (merge meta
                           (select-keys (:meta %) [:filename :username])
                           {:orig-values (-> entity-map vals first)})})
       (tx/->edit-entity issue-id)))

(defn process-overmind-response [state response]
  (swap! state dissoc :overmind-working)
  (let [{:keys [error entity-map] :as entry} response
        issue-id (ecs/get-issue-id entity-map)]
    (if-not error
      (let [{:keys [meta entity-map]} (escm/coerce-entry (format-hi-lite-ids entry))]
        (swap! state
               (update-state-overmind!
                meta entity-map issue-id)))
      (swap! state assoc :message
             [:error "There were errors!" response error]))))

(defn overmind-fail [state response]
  (swap! state assoc :message [:error "Process failed!" response])
  (swap! state dissoc :overmind-working))

(defn run-local-overmind [state]
  (swap! state assoc :overmind-working true)
  (svc/async-overmind
   (-> @state :meta :md5)
   (partial process-overmind-response state)
   (partial overmind-fail state)))

; (defn remove-job [state md5]
;   (svc/async-remove-job
;    md5
;    #(do (swap! state update :unprocessed-overmind-entries
;                (partial filter (comp #{md5} :md5)))
;         (swap! state update :meta dissoc :_id :md5 :filename :file-type :bid :food-id))
;    #(swap! state assoc :message [:error "Process failed!" %])))

(defn render-overmind-button [state]
  [:button.btn.btn-default
   {:type "submit"
    :disabled (or (:overmind-working @state)
                  (not (get-in @state [:meta :filename])))
    :on-click #(run-local-overmind state)}
   (if (:overmind-working @state) "Waiting for Overmind" "Create new Overmind entry")])

(defn render-manual-entry-button [state]
  [:button.btn.btn-default
   {:type "submit"
    :disabled (or (:overmind-working @state)
                  (not (or (get-in @state [:meta :md5])
                           (#{:floating-rate "floating-rate"}
                             (get-in @state [:meta :vocabulary])))))
    :on-click #(swap! state
                      (fn [x]
                        (-> x
                            (update :meta (fn [{:keys [vocabulary] :as m}]
                                            (-> m
                                                (dissoc :_id)
                                                (assoc :file-type :entity-map
                                                       :data-type (keyword vocabulary)))))
                            (tx/->edit-entity :manual))))}
   "Create new manual entry"])

; (defn render-remove-job-button [state]
;   [:button.btn.btn-default
;    {:type "submit"
;     :disabled (or (:overmind-working @state)
;                   (not (get-in @state [:meta :filename]))
;                   (not (get-in @state [:meta :md5])))
;     :on-click #(let [{:keys [md5 filename]} (:meta @state)]
;                  (when (js/confirm (str "Are you sure you want to remove the file "
;                                         filename " from Judy?"))
;                    (remove-job state md5)))}
;    "Remove file from Judy"])

(defn entities-for-file [state md5 vocab filename]
  (svc/async-entities-for-file
   {:md5 md5 :vocab (name vocab)}
   #(swap! state (fn [s]
                   (-> s
                       (assoc :entities %)
                       (update :meta assoc :md5 md5 :vocabulary vocab :filename filename)
                       tx/->table-view)))
   #(swap! state assoc :message [:error "Process failed!" %])))

(defn render-table-view-button [state]
  [:button.btn.btn-default
   {:type "submit"
    :disabled (or (:overmind-working @state)
                  (not (get-in @state [:meta :vocabulary]))
                  (not (get-in @state [:meta :md5])))
    :on-click #(let [{:keys [md5 vocabulary filename]} (:meta @state)]
                 (entities-for-file state md5 vocabulary filename))}
   "Compare entries"])

(defn if-filter [vocab items]
  (if vocab
    (filter #(= vocab (:file-type %)) items)
    items))

(defn retrieve-unprocessed-documents [state]
  (svc/async-unprocessed-documents
   (-> @state :meta :vocabulary)
   #(swap! state assoc :unprocessed-overmind-entries %)))

(defn retrieve-processed-documents [state]
  (svc/async-processed-documents
   (-> @state :meta :vocabulary)
   #(swap! state assoc :processed-documents %)))

(defmulti choose-document
  (fn [state vocab filename unproc edgar-search cik]
    vocab))

(defmethod choose-document :edgar-prospectus [state vocab filename unproc edgar-search cik]
  (html/pretty-wrap
    "Choose an edgar document"
    [:div
     [:div.input-group
      [:span.input-group-addon "CIK"]
      ;; use bidi-text-field here?
      [:input.text.form-control
       {:value (or cik "")
        :on-change #(let [query (-> % .-target .-value)]
                     ;(.log js/console query)
                     (swap! state assoc-in [:meta :edgar-query :cik] query)
                     (pa/edgar-cik-search state query))}]]
     [:div.dropdown
      [:button.btn.btn-default.dropdown-toggle
       {:type          "button"
        :data-toggle   "dropdown"
        :aria-haspopup "true"
        :aria-expanded "true"
        :style         {:width "100%" :textAlign "left"}}
       (or filename "No Selection") " " [:span.caret]]
      [:ul.dropdown-menu.scrollable-menu {:style {:width "100%"}}
       (for [{:keys [cik cusips filename md5 _id]} edgar-search]
         [:li {:key _id
               :on-click #(swap! state update :meta into {:filename filename :md5 md5})}
          [:a (str cik " - " filename " - " (s/join ", " cusips))]])
       [:li {:key nil :on-click #(swap! state update :meta dissoc :_id :md5 :filename :file-type :bid :food-id)}
        [:a (name "Deselect")]]]]]))

(defmethod choose-document :default [state vocab filename unproc edgar-search cik]
  (html/pretty-wrap
    "Choose an unprocessed document"
    [:div.dropdown
     [:button.btn.btn-default.dropdown-toggle
      {:type          "button"
       :data-toggle   "dropdown"
       :aria-haspopup "true"
       :aria-expanded "true"
       :style         {:width "100%" :textAlign "left"}
       :on-click      #(retrieve-unprocessed-documents state)}
      (or filename "No Selection") " " [:span.caret]]
     [:ul.dropdown-menu.scrollable-menu {:style {:width "100%"}}
      (for [{:keys [filename _id file-type] :as entry}
            (if-filter (some-> vocab name) unproc)]
        [:li {:key _id :on-click
              #(swap! state update :meta into (assoc entry :vocabulary file-type))}
         [:a filename " - " file-type]])
      [:li {:on-click #(swap! state
                              (fn [s]
                                (-> s
                                    (update :meta dissoc
                                           :_id :md5 :filename :file-type :bid :food-id)
                                    (dissoc :unprocessed-overmind-entries))))}
       [:a (name "Deselect")]]]]))

(defn render-vocab-selector [state]
  (html/pretty-wrap
   "Choose a document type"
   [:div.dropdown
    [:button.btn.btn-default.dropdown-toggle
     {:type "button"
      :data-toggle "dropdown"
      :aria-haspopup "true"
      :aria-expanded "true"
      :style {:width "100%" :textAlign "left"}}
     (name (get-in @state [:meta :vocabulary] "No Selection")) " " [:span.caret]]
    [:ul.dropdown-menu.scrollable-menu {:style {:width "100%"}}
     (for [v (map name (keys vocabs/ordered-vocabs))]
       [:li {:key v :on-click
             (fn [] (swap! state update :meta
                           #(-> %
                                (assoc :vocabulary v)
                                (dissoc :_id :md5 :filename :file-type :bid :food-id)))
               (retrieve-processed-documents state))}
        [:a (name v)]])
     [:li {:on-click #(swap! state
                             (fn [s]
                               (-> s
                                   (update :meta dissoc
                                           :_id :md5 :filename :file-type :vocabulary :bid :food-id)
                                   (dissoc :unprocessed-overmind-entries :processed-documents))))}
      [:a (name "Deselect")]]]]))

(defn retrieve-entity-map [state id]
  (svc/async-entity-map
   id
   #(swap! state tx/->edit-existing-entry %)))

(defn gen-filter [filter-string]
  (if (seq filter-string)
    (let [filter-string (str/lower-case filter-string)]
      (fn [doc]
        (->> (select-keys doc [:filename :username :cusip :pool-number])
             vals
             (map (comp str/lower-case str/trim str))
             (some #(and (string? %)
                         (.includes % filter-string))))))
    identity))

(defn vocab-filter [vocab]
  (if vocab
    #(= vocab (:vocabulary %))
    identity))

(defn filename-filter [filename]
  (if filename
    #(= filename (:filename %))
    identity))

(defn render-entries [state processed-docs filter-string vocab filename overmind-working]
  (if-let [filtered-docs
           (not-empty
            (filter
             (every-pred
              (gen-filter filter-string)
              (vocab-filter vocab)
              (filename-filter filename))
             processed-docs))]
    [:table.table.table-condensed.table-hover
     [:thead>tr
      [:th]
      [:th "Filename"]
      [:th "CUSIP"]
      [:th "Pool Number"]
      [:th "Vocabulary"]
      [:th "Username"]
      [:th "Entry Time"]]
     [:tbody
      (for [{:keys [filename cusip pool-number vocabulary md5 username _id]} filtered-docs
            :let [ts (some-> _id
                         (subs 0 8)
                         (js/parseInt 16)
                         (* 1000)
                         js/Date.)]]
        [:tr {:key _id}
         [:td>div.btn-group
          [:button.btn.btn-default
           {:type "submit"
            :disabled (or overmind-working (not vocabulary) (not md5))
            :on-click #(entities-for-file state md5 vocabulary filename)
            :title "Compare all entries from this file."}
           [:span.fa.fa-search]]
          [:button.btn.btn-default
           {:type "submit"
            :disabled (or overmind-working (not vocabulary))
            :on-click #(retrieve-entity-map state _id)
            :title "Edit this entry"}
           [:span.fa.fa-edit]]]
         [:td (or filename "-")]
         [:td (or cusip "-")]
         [:td (or pool-number "-")]
         [:td vocabulary]
         [:td username]
         [:td (str ts)]])]]
    [:h4 "No Entries Found"]))

(defn render [state]
  [:div.container
   [:h3 "Prospectus Selection"]
   [:div.alert.alert-warning [:span.fa.fa-exclamation-triangle] " "
    [:b "Remember:"] " do " [:b "not"] " enter any Bloomberg data."]
   [html/pretty-wrap "Username/ID"
    (html/bidi-text state [:meta :username])]
   [render-vocab-selector state]
   [choose-document state
    (-> @state :meta :vocabulary)
    (-> @state :meta :filename)
    (-> @state :unprocessed-overmind-entries)
    (-> @state :edgar-search-results :results)
    (-> @state :meta :edgar-query :cik)]
   [html/pretty-wrap "Filter Documents"
    (html/bidi-text state [:filter])]
   [:div
    [render-overmind-button state] " "
    [render-manual-entry-button state] " "
    [render-table-view-button state] " "]
    ; [render-remove-job-button state]]
   [render-entries state
    (:processed-documents @state)
    (-> @state :filter)
    (-> @state :meta :vocabulary)
    (-> @state :meta :filename)
    (:overmind-working @state)]
   [html/render-message (:message @state)]
   [html/toggle-debug state]
   [html/debug-view @state]])
