(ns soda-jerk-ws.pages.ajax
  (:require [ajax.core :as ajax]))

(defn edgar-cik-search [state rgx]
  (when (and rgx (pos? (count rgx)))
    (ajax/GET (str js/context "/edgar/find/cik/" rgx "/1000")
              {:handler (fn [{:keys [status body] :as res}]
                          (if (== 200 status)
                            (let [{:keys [n results]} body]
                              ;(.log js/console (.log js/console (str "Found " n " records matching " rgx ".")))
                              ;(.log js/console (.log js/console (-> res pp/pprint with-out-str)))
                              ;(.log js/console (.log js/console (str rgx "-" (-> @state :meta :edgar-query))))
                              (when (= rgx (-> @state :meta :edgar-query :cik))
                                (swap! state assoc :edgar-search-results body)))
                            (.log js/console (str "There was a problem. Error code " status "."))))})))
