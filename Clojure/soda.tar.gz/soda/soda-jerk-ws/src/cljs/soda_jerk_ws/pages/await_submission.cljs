(ns soda-jerk-ws.pages.await-submission
  (:require [soda-jerk-ws.common.html-utils :refer [render-message]]
            [soda-jerk-ws.judy.transitions :as tx]))

(defn render [state]
  [:div.container
   [:h3 "Waiting for result..."]
   [:div {:style #js {:textAlign "center"}}
    [:a {:on-click #(swap! state tx/->choose-prospectus)}
     "Click here"]
    " to return to the prospectus selection page if nothing happens."]
   [render-message (:message @state)]])
