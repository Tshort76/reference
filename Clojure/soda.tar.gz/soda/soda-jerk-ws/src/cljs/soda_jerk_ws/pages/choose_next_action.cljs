(ns soda-jerk-ws.pages.choose-next-action
  (:require [soda-jerk-ws.judy.transitions :as tx]))

(defn render [state]
  (let [{:keys [entity-map current-entity meta success-image bid]} @state]
    [:div.container
     (when success-image [:img {:src (str "img/congrats/" success-image)}])
     [:h3 "Congratulations! Your submission was successful."]
     [:h4 (str "You can track it with bid: " bid)]
     [:p {:style #js {:textAlign "center"}}
      [:a {:on-click #(swap! state tx/->choose-prospectus)} "Enter New Prospectus"]]]))
