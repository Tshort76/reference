(ns soda-jerk-ws.pages.layout
  (:require [soda-jerk-ws.judy.service-interop :as svc]
            [soda-jerk-ws.common.html-parsing :as parse]))

(def vertical-gap [:hr])

(defn layout-buttons* [state viewer presentation md5]
  (let [url (str js/context "/overmind/original/?md5=" md5)
        new-window-atts-fn #(let [width (.-innerWidth js/window) height (.-innerHeight js/window)]
                              (.open js/window url "" (str "height=" height ",width=" width))
                              (swap! state assoc :presentation :full-screen))
        new-window-content [:span.fa.fa-external-link]]
    (into [:div.btn-group {:role "group"
                           :style {:position "fixed" :bottom "20px" :left "10px"}}]
          (if (= presentation :full-screen)
            [[:button.btn.btn-default.active
              {:on-click #(swap! state assoc :presentation :side-by-side)
               :title "Put the prospectus back in the window"}
              new-window-content]]
            [[:button.btn.btn-default
              {:on-click new-window-atts-fn
               :title "Go to full screen mode, opening the prospectus in a new window"}
              new-window-content]
             " "
             [:button.btn.btn-default
              (if (= presentation :vertical)
                {:on-click #(swap! state assoc :presentation :side-by-side) :title "Switch to left/right layout"}
                {:on-click #(swap! state assoc :presentation :vertical) :title "Switch to top/bottom layout"})
              [:span.fa.fa-pause (when (= presentation :vertical) {:class "rotate90"})]]
             " "
             (if (= viewer :pdf)
               [:button.btn.btn-default
                {:on-click #(swap! state assoc :viewer :html) :title "Switch to HTML viewer"}
                [:span.fa.fa-file-pdf-o]]
               [:button.btn.btn-default
                {:on-click #(swap! state assoc :viewer :pdf) :title "Switch to PDF viewer"}
                [:span.fa.fa-file-text-o]])
             " "
             [:button.btn.btn-default
              {:on-click #(swap! state update :show-outline not)
               :title    "Toggle Outlines\nMagenta\t\tTable/Column\nCyan\t\tSuperscript\nBlue\t\tText\nGray\t\tTitle\nOrange\t\tSide-by-side"}
              [:span.fa.fa-square-o]]]))))

(defn layout-buttons [state]
  [layout-buttons* state
   (:viewer @state)
   (:presentation @state)
   (-> @state :meta :md5)])

(defn retrieve-frame-contents [state md5]
  (svc/async-hiccup-prospectus
   md5
   #(swap! state (fn [x]
                   (if (-> x :meta :md5 (= md5))
                     (assoc x
                            :hiccup-prospectus %
                            :prospectus-word-id-list (parse/word-id-list %))
                     x)))
   #(swap! state assoc :hiccup-prospectus {})))

(def memoized-retrieve-frame-contents
  (let [last-md5 (atom nil)]
    (fn [state]
      (let [md5 (get-in @state [:meta :md5])]
        (when-not (and (:hiccup-prospectus @state)
                       (= md5 @last-md5))
          (swap! state assoc :hiccup-prospectus {})
          (retrieve-frame-contents state md5))
        (reset! last-md5 md5)))))

(defn render-hiccup [hiccup state]
  (let [offset (if (= :vertical (:presentation @state)) 1 2)
        width (/ (.width (js/$ js/window)) offset)]
    [:div#prospectus-viewer
     {:style {:width      "100%"
              :height     "100%"
              :overflow-y "auto"
              :padding    "5px"}}
     (into
       [:svg {                                              ;:xmlns   "http://www.w3.org/2000/svg"
              :width   width
              :height  (str (:y (second (last hiccup))))
              :viewBox (str "0 0 " (/ width (/ 3 offset)) " " (/ (:y (second (last hiccup))) (/ 3 offset)))}]
       (cond->> hiccup (not (:show-outline @state)) (filter #(not= "rect" (first %)))))]))

(defmulti document-viewer (fn [state & [_]] (-> state deref :meta :data-type keyword)))

(defmethod document-viewer :edgar-prospectus [state & [callback]]
  (let [{:keys [meta viewer hiccup-prospectus]} @state
        {:keys [filename]} meta]
    [:iframe#doc-view.tall {:src (str js/context "/overmind/food/html?filename=" (get-in @state [:meta :filename]))
                            :onLoad callback
                            :width "100%"}]))

(defmethod document-viewer :default [state & [callback]]
  (memoized-retrieve-frame-contents state)
  (let [{:keys [viewer hiccup-prospectus]} @state]
    (if (= viewer :pdf)
      [:iframe#doc-view.tall {:src (str js/context "/overmind/original/?md5=" (get-in @state [:meta :md5]))
                              :onLoad callback
                              :width "100%"}]
      [render-hiccup hiccup-prospectus state])))

(defn head-floater [& stuffs]
  (into [:h4 {:style {:position "absolute" :top "10px" :left "10px" :margin "0px"
                      :background-color "#fff" :padding "5px" :border "1px solid #333"
                      :border-radius "5px"}}]
        stuffs))

(defmulti side-by-side (fn [state f] (:presentation @state)))

(defmethod side-by-side :default [state f & [document-load-callback]]
  (if (-> @state :meta :filename)
    [:div.wrapper
     [:div.col-md-6.no-padding.tall
      [document-viewer state document-load-callback]]
     [head-floater
      "File Name: " (-> @state :meta :filename)]
     [layout-buttons state]
     [:div.col-md-6.no-padding.tall (f state)]]
    (f state)))

(defmethod side-by-side :vertical [state f & [document-load-callback]]
  [:div.wrapper
   [:div {:style {:height "50%"}} (f state)]
   [:div {:style {:height "50%" :position "relative"}}
    [document-viewer state document-load-callback]
    [head-floater
     "File Name: " (-> @state :meta :filename)]]
   [layout-buttons state]])

(defmethod side-by-side :full-screen [state f & [document-load-callback]]
  [:div.wrapper
   [:div {:style {:height "100%"}} (f state)]
   [layout-buttons state]])
