(ns soda-jerk-ws.pages.view-form
  (:require [soda-jerk-ws.judy.transitions :as tx]
            [soda-jerk-ws.common.html-utils :refer [capitalize-first-words toggle-debug debug-view button render-message]]
            [soda-jerk-ws.pages.layout :refer [vertical-gap]]
            [soda-jerk-ws.common.input-selectors :refer [standard-input]]
            [soda-jerk-ws.common.entity-naming-utils :as enu]
            [soda-jerk-ws.judy.service-interop :as svc]
            [medley.core :as med]
            [ecs.schema :as csch]
            [schema.core :as s]
            [vocabularies.core :as vocab]))

(defn form-content [state vocab current-entity entity-map meta errors]
  [:div.form-content
   (for [field-name (keys (dissoc vocab :meta)) ;; BDT this is a hack until we add an "add field" button
         :let [path [:entity-map current-entity field-name]]]
     [:span {:key (str path ".st-in")}
      [standard-input path (vocab field-name) state
       (get-in entity-map (rest path))
       meta (field-name errors)]])])

(defn get-identifiers [{vocab-meta :meta} entity-map]
  (->> vocab-meta
       :identifiers
       (reduce-kv (fn [m k v-fn]
                    (assoc m k (v-fn (-> entity-map first last))))
                  {})
       (merge (dissoc vocab-meta :identifiers))))

(defn clean-entity [entity]
  (let [select-fn #(select-keys % (->> entity
                                       :meta
                                       :vocabulary
                                       keyword
                                       vocab/ordered-vocabs
                                       keys))
        filter-nil (partial med/remove-vals #(or (and (sequential? %) (empty? %)) (nil? %)))]
    (-> entity
        (update-in [:meta :hi-lite-ids] select-fn)
        (update-in [:meta :mod-hi-lite-ids] select-fn)
        (update-in [:meta :orig-values] select-fn)
        (update :entity-map (partial med/map-vals select-fn))
        (update-in [:meta :hi-lite-ids] filter-nil)
        (update-in [:meta :mod-hi-lite-ids] filter-nil)
        (update-in [:meta :orig-values] filter-nil)
        (update :entity-map (partial med/map-vals filter-nil)))))

(defn submit-prospectus [state entity-map meta vocab]
  (let [params (-> {:entity-map entity-map
                    :meta (-> meta
                              (assoc :source-type :judy)
                              (dissoc :_id)
                              (merge (get-identifiers vocab entity-map)))}
                   csch/coerce-entry
                   clean-entity)]
    (swap! state tx/->await-result)
    (svc/async-submit-prospectus
     params
     (fn [{:keys [success? success-image bid] :as response}]
       (swap!
        state
        #(tx/->success-choose (into % {:success-image success-image :bid bid})))))))

(defn validate [state]
  (s/check (csch/vocab->entity-schema
            (get-in state [:meta :vocabulary]))
           (select-keys state [:entity-map :meta])))

(defn render [state]
  (let [{:keys [entity-map current-entity meta errors]} @state
        vocabulary (:vocabulary meta "")
        vocab (-> vocabulary keyword vocab/ordered-vocabs)]
    [:div.form-pane.padded
     [:h3 (str "Issue Type: " (capitalize-first-words vocabulary))]
     vertical-gap
     [form-content state vocab current-entity entity-map meta errors]
     vertical-gap
     [:div {:style {:textAlign "center"}}
      [button "Submit Prospectus Entry"
       #(submit-prospectus state entity-map meta vocab)
       {:disabled (when errors true)}]]
     [:div {:style {:textAlign "center"}}
      [button "Schema Validation"
       #(js/alert (or (validate @state)
                      "Prospectus conforms to schema."))]]
     [:div {:style {:textAlign "center"}}
      [:a {:on-click
           #(when (js/confirm "Discard your work and restart?")
              (swap! state tx/->choose-prospectus))}
       "Choose a different prospectus"]]
     [render-message (:message @state)]
     [toggle-debug state]
     [debug-view @state]]))
