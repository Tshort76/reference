(ns soda-jerk-ws.system-health.control-set-overview
  (:require [clojure.pprint :as pprint]
            [soda-jerk-ws.jaeger.stats.controls :as controls]
            [soda-jerk-ws.jaeger.stats.icons :as icons]
            [soda-jerk-ws.jaeger.stats.logic :as logic]
            [soda-jerk-ws.jaeger.stats.modal :as modal]
            [soda-jerk-ws.common.service-interop-functions :as sif]
            [cljs.pprint :as pp]
            [ajax.core :refer [GET POST]]
            [soda.control-sets :as cs]
            [soda.core :as core]
            [soda-jerk-ws.jaeger.service-interop :as svc]))

(defn request-recache-present [state]
  (POST (str js/context "/analytics/validation-recache/control-set/" (:control-set @state))
        {:keywords? true
         :handler identity
         :error-handler #(do (prn "Error while attempting to refresh the cache:") (pp/pprint %))}))

(defn request-refresh-cache [state]
  (POST (str js/context "/analytics/validation-refresh/control-set/" (:control-set @state))
        {:keywords? true
         :handler identity
         :error-handler #(do (prn "Error while attempting to refresh the cache:") (pp/pprint %))}))

(defn request-validation-cache-status [state]
  (GET (str js/context "/analytics/validation-cache-status/control-set/" (:control-set @state))
       {:keywords? true
        :handler #(swap! state assoc :validation-status %)
        :error-handler #(do (prn "Error while requesting validation cache status:") (pp/pprint %))}))

(defn request-validation-data [state]
  (GET (str js/context "/analytics/validation/control-set/" (:control-set @state) "/source/" (:source @state))
       {:keywords? true
        :handler #(swap! state assoc :validation-data %)
        :error-handler #(do (prn "Error while requesting validation data:") (pp/pprint %))}))

(defn get-supported-fields [state]
  (-> @state :control-set keyword cs/control-sets :type cs/supported-fields sort))

(defn percent [num denom & {:keys [show-zeros]}]
  (cond (= num 0) (if show-zeros "0.0%" "")
        (= num denom) "100%"
        (and num denom (pos? num) (pos? denom)) (pprint/cl-format nil "~,1f%" (/ num denom .01))
        :else ""))

(defn icon [class & {:keys [color tooltip]}]
  [:span.fa.fa-fw.icon
   (cond-> {:class class}
           color (assoc-in [:style :background-color] color)
           tooltip (assoc :title tooltip))])

(def icons
  {:precision (icon :fa-crosshairs :tooltip "% of time that SoDa and validation match when both values exist")
   :volume (icon :fa-volume-up :tooltip "Volume: The % of time that SoDa returns any value")
   :recall (icon :fa-search :tooltip "Recall: valid / (valid + no-soda)")
   :valid (icon :fa-check :tooltip "SoDa value matches validation data" :color "#8f8")
   :diff (icon :fa-times :tooltip "SoDa data does not match validation data" :color "#f88")
   :no-soda (icon :fa-minus :tooltip "No SoDa data" :color "#fb4")
   :no-lm (icon :fa-question :tooltip "No validation data" :color "#ee0")
   :no-data (icon :fa-circle-thin :tooltip "No SoDa or validation data" :color "#ddd")})

(defn go-to-docs [docs]
  (let [doc-counts (into {} (map (fn [[doc instances]] [doc (count instances)]) (group-by identity docs)))
        sorted-docs (sort-by doc-counts > (set docs))
        uuid (str (random-uuid))
        _ (.setItem js/sessionStorage uuid (take 100 sorted-docs))
        {:keys [md5 cusip]} (first sorted-docs)]
    (.open js/window (str "#health/validate-doc?md5=" md5 "&cusip=" cusip "&session=" uuid "&index=" 0))))

(defn header-cell [label]
  (let [abbreviated (if (> (count label) 18) (str (subs label 0 15) "...") label)]
    [:th.rotate {:key label}
     [:div {:style {:float "right"}}
      [:span {:title label} abbreviated]]]))

(def statuses [:valid :diff :no-soda :no-lm :no-data])

(defn lookup-table-data [table-data status field]
  (first (filter #(and (= status (:status %)) (= field (:field %))) table-data)))

(def color-classes {:precision [{:pred #(<= 0.95 %) :class ".success"} {:pred #(<= 0.90 %) :class ".warning"} {:pred identity :class ".danger"}]
                    :volume [{:pred #(<= 0.85 %) :class ".success"} {:pred #(<= 0.80 %) :class ".warning"} {:pred identity :class ".danger"}]
                    :recall [{:pred #(<= 0.85 %) :class ".success"} {:pred #(<= 0.80 %) :class ".warning"} {:pred identity :class ".danger"}]
                    :valid [{:pred #(<= 0.85 %) :class ".success"} {:pred #(<= 0.80 %) :class ".warning"} {:pred identity :class ".danger"}]})

(defn cell [status docs denominator & {:keys [key show-zeros left-border]}]
  (let [numerator (count docs)
        pct (when (pos? denominator) (/ numerator denominator))
        pct-text (percent numerator denominator :show-zeros show-zeros)
        highlight-class (some->> color-classes status (filter #((:pred %) pct)) first :class)
        td (keyword (str "td" highlight-class (when (pos? numerator) ".marked") (when left-border ".left-border")))
        attrs (cond-> {:title (str numerator "/" denominator)}
                      key (assoc :key key)
                      (pos? numerator) (assoc :on-click (partial go-to-docs docs)))]
    [td attrs [:span.data-cell pct-text]]))

(defn overview-row [status table-data fields numerator-status-set denominator-status-set]
  (let [row-data (zipmap fields
                         (for [field fields]
                           {:docs (mapcat :docs (for [status numerator-status-set]
                                                  (lookup-table-data table-data status field)))
                            :total (count (mapcat :docs (for [status denominator-status-set]
                                                          (lookup-table-data table-data status field))))}))]
    [:tr {:key status} [:td (icons status)]
     (cell status (->> row-data vals (mapcat :docs)) (->> row-data vals (map :total) (apply +)) :show-zeros true)
     (for [field fields]
       (cell status (-> field row-data :docs) (-> field row-data :total) :key (str status field) :show-zeros true))
     [:td]]))

(defn stats-row [table-data status total-docs fields]
  (let [row-data (zipmap fields
                         (for [field fields]
                           {:docs (:docs (lookup-table-data table-data status field))}))]
    [:tr {:key status} [:td (icons status)]
     (cell status (->> row-data vals (mapcat :docs)) (* (count fields) total-docs) :show-zeros true)
     (for [field fields]
       (let [data (lookup-table-data table-data status field)]
         (cell status (-> row-data field :docs) total-docs :key (str status field))))
     [:td]]))

(defn stats-table [state]
  (let [{:keys [validation-data show]} @state
        supported-fields (get-supported-fields state)
        other-fields (filter #(not (some #{%} supported-fields)) (-> validation-data :data keys sort))
        fields (filter identity (if (= show "mvp") supported-fields (concat supported-fields other-fields)))
        table-data (for [status statuses field fields]
                     {:status status :field field :docs (-> validation-data :data field status :docs)})]
    [:table#validation-table.table.table-condensed.table-striped
     [:thead
      [:tr [:th] [:th "Total"] (for [field fields] (header-cell (name field))) [:th]]]
     [:tbody
      (overview-row :precision table-data fields #{:valid} #{:valid :diff})
      (overview-row :volume table-data fields #{:valid :diff :no-lm} (set statuses))
      (overview-row :recall table-data fields #{:valid} #{:valid :no-soda})
      (for [status statuses]
        (stats-row table-data status (:total-docs validation-data) fields))]]))

(defn dropdown [button-content dropdown-content]
  [:div.btn-group
   [:button.btn.btn-default
    {:type "button" :class "dropdown-toggle" :data-toggle "dropdown" :aria-haspopup true :aria-expanded false}
    button-content " " [:span.fa.fa-sort-desc]]
   [:ul.dropdown-menu dropdown-content]])

(defn xmas-tree-url [control-set source show]
  (str "#health/validation?control-set=" control-set "&source=" source "&show=" show))

(defn control-set-dropdown [state]
  (dropdown (or (:control-set @state) "???")
            [:div (doall (for [control-set (sort (:all-control-sets @state))]
                           [:li {:key control-set}
                            [:a {:href (xmas-tree-url control-set (:source @state) (:show @state))}
                            control-set]]))]))

(defn source-dropdown [state]
  (dropdown
    (:source @state)
    [:div
     [:li [:a {:href (xmas-tree-url (:control-set @state) "jaegers" (:show @state))} "jaegers"]]
     [:li [:a {:href (xmas-tree-url (:control-set @state) "soda-api" (:show @state))} "soda-api"]]]))

(defn mvp-dropdown [state]
  (dropdown
    (:show @state)
    [:div
     [:li [:a {:href (xmas-tree-url (:control-set @state) (:source @state) "mvp")} "mvp"]]
     [:li [:a {:href (xmas-tree-url (:control-set @state) (:source @state) "all-fields")} "all-fields"]]]))

;TODO: Implement this control
(defn fields-control [state]
  [:div.btn-group
   [:div.btn-group
    [:select.selectpicker {:multiple "multiple"}
     [:option {:data-content "<span class='label label-success'>Mustard</span>"}]
     [:option {:data-content "<span class='label label-success'>Ketchup</span>"}]
     [:option {:data-content "<span class='label label-success'>Relish</span>"}]]]
   [:button.btn.btn-default {:type "button"} "Apply"]])

(defn cache-control [state]
  [:div.btn-group
   (let [cache-refreshing? (-> @state :validation-status :running)]
     [:button.btn.btn-default
      (merge {:type "button" :on-click (partial request-refresh-cache state)}
             (when cache-refreshing? {:disabled "disabled"}))
      (if cache-refreshing? "Refreshing..." "Refresh")])
   (let [cache-refreshing? (-> @state :validation-status :running)]
     [:button.btn.btn-default
      (merge {:type "button" :on-click (partial request-recache-present state)}
             (when cache-refreshing? {:disabled "disabled"}))
      (if cache-refreshing? "Refreshing..." "Cache existing values")])])

(defn control [label element & {:keys [style]}] [:td (merge {} style) [:div.input-group [:span.input-group-addon label] element]])

(defn controls [state]
  [:table#health-controls
   [:tbody [:tr
            (control "Control Set:" (control-set-dropdown state))
            (control "Source:" (source-dropdown state))
            (control "Show:" (mvp-dropdown state))
            (let [last-cached (if-let [datetime (-> @state :validation-status :last-start)]
                                (-> datetime str (subs 4 24))
                                "Never")]
              (control (str "Cached: " last-cached) (cache-control state) :style {:width "100%"}))
            [:td]]]])

(def HEARTBEAT-RATE 1000)

(defn poll-cache-state [state session-id]
  (when (= session-id (aget js/window "session-id"))
    (let [cache-refreshing? (-> @state :validation-status :running)
          new-cache-state (request-validation-cache-status state)]
      (if cache-refreshing?
        (swap! state assoc :waiting-for-refresh true)
        (when (:waiting-for-refresh @state)
          (swap! state assoc :waiting-for-refresh false)
          (request-validation-data state)))
      (.setTimeout js/window (partial poll-cache-state state session-id) HEARTBEAT-RATE))))

(defn init-page-state [state]
  (when (not (:started @state))
    (let [session-id (aset js/window "session-id" (.getTime (js/Date.)))] ;Hack to kill old heartbeat on page reload
      (swap! state assoc :started true)
      (request-validation-data state)
      (poll-cache-state state session-id))))

(defn render [state]
  (let [_ (init-page-state state)]
    [:div
     (controls state)
     (stats-table state)]))