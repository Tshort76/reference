(ns soda-jerk-ws.system-health.document-inspector
  (:require [cljs.pprint :as pp]))

(defn arrow-button [state glyph f]
  (let [{:keys [session]} @state]
    (when session
      [:td [:button.btn.btn-default {:type "button" :on-click (partial f state)}
        [(keyword (str "span.glyphicon.glyphicon-" (name glyph)))]]])))

(defn go-to-page [state change-fn]
  (let [{:keys [session index metas]} @state
        i (mod (change-fn index) (count metas))
        {:keys [md5 cusip]} (nth metas i)]
    (.open js/window (str js/context "#health/validate-doc?md5=" md5 "&cusip=" cusip "&session=" session "&index=" i) "_self")))

(defn controls [state]
  (let [{:keys [md5 cusip session index metas]} @state]
    [:div
     [:table {:style {:background-color "#eee" :width "100%"}}
      [:tbody
       [:tr
        (arrow-button state :chevron-left (partial go-to-page state dec))
        [:td {:style {:width "50%"}}]
        [:td [:span.input-group-addon "MD5:"]]   [:td [:span.input-group-addon md5]]
        [:td [:span.input-group-addon "Cusip:"]] [:td [:span.input-group-addon cusip]]
        (when session [:td [:span.input-group-addon (str "(Doc " (inc index) "/" (count metas) ")")]])
        [:td {:style {:width "50%"}}]
        (arrow-button state :chevron-right (partial go-to-page state inc))]]]]))

(defn doc-view [state]
  (let [{:keys [md5 cusip]} @state]
    [:div {:style {:height "100%"}}
     [:iframe {:src (str js/context "/#jaeger/duct-tape/" md5)
               :style {:width "100%" :height "100%"}}]]))

(defn render [state]
  [:div {:style {:display "table" :position "fixed" :width "100%" :height "100%"}}
   (controls state)
   (doc-view state)])
