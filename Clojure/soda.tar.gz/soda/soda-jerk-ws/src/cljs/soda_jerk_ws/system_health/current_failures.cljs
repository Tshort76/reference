(ns soda-jerk-ws.system-health.current-failures
  (:require [ajax.core :refer [GET POST]]
            [cljs.pprint :as pp]))

(defn abbreviate [text n]
  (if (> (count text) n)
    (str (subs text 0 (- n 3)) "...")
    text))

(def categories [{:name "All" :category :all
                  :warning (str "CAUTION: This will rerun ALL jobs, including ones that had unrecoverable errors (e.g. out of memory) "
                                "and jobs that exceeded maximum number of retries. It is likely that jobs in these categories "
                                "will take down the jobs service on multiple workers. Press OK if you wish to continue.")}
                 {:name "All Cancelled" :category :all-cancelled
                  :warning (str "CAUTION: This will rerun all cancelled jobs, including jobs that exceeded maximum number of retries. "
                                "It is possible some of these jobs were unable to complete because they take down the jobs "
                                "service on whatever worker they run on. Press OK if you wish to continue.")}
                 {:name "Long Running" :category :cancelled-exceeded-est-time
                  :warning (str "CAUTION: This will rerun jobs that were cancelled after exceeding their estimated time. Most of these "
                                "jobs will run for hours, hogging consumer threads. Press OK if you wish to continue.")}
                 {:name "Manually Cancelled" :category :cancelled-manual
                  :warning (str "This will rerun all jobs that were cancelled due to human intervention. Often these are innocuous, "
                                "but sometimes jobs are manually cancelled to avoid known problems. Press OK if you wish to continue.")}
                 {:name "Too Many Retry Jobs" :category :cancelled-too-many-retries
                  :warning (str "CAUTION: This will rerun all jobs that failed to complete after exceeding the maximum "
                                "number of retries. Often, these jobs are unable to complete because they take down the "
                                "service on whatever worker they run on. Press OK if you wish to continue.")}
                 {:name "Recoverable Errors" :category :recoverable-errors
                  :warning (str "This will rerun all error'd jobs that do not kill the worker they are run on. Press OK to continue.")}
                 {:name "Unrecoverable Errors" :category :unrecoverable-errors
                  :warning (str "CAUTION: This will rerun jobs that are known to kill workers they are run on. Press OK to continue.")}])

(def priorities-map {"background" "Background"
                     nil "Normal"
                     "foreground" "Foreground"})

(def cancellation-reasons #{:manual-request :too-many-retries :auto-expired})
(defn failure->query-param [failure]
  (str (if (cancellation-reasons failure) "cancellation-reason" "error-code") "=" failure))

(defn request-unrecoverable-errors [state]
  (GET
    (str js/context "/failures/distinct" (when-not (= (:since @state) (.-MAX_SAFE_INTEGER js/Number))
                                           (str "?since=" (.format (js/moment (:since @state)) "YYYY-MM-DD"))))
       {:keywords? true
        :handler #(swap! state assoc :errors %)
        :error-handler #(do (prn "Error while requesting unrecoverable errors:") (pp/pprint %))}))

(defn request-jira-links [state]
  (GET (str js/context "/failures/all-links")
       {:keywords? true
        :handler #(swap! state assoc :jira-tickets %)
        :error-handler #(do (prn "Error while requesting Jira links:") (pp/pprint %))}))

(defn simple-post
  ([endpoint] (simple-post endpoint prn))
  ([endpoint handler]
   (POST endpoint
         {:keywords?     true :handler handler
          :error-handler #(do (prn (str "Error posting to endpoint " endpoint) (pp/pprint %)))})))

(def poll-fns->intervals {request-unrecoverable-errors 10000
                          request-jira-links 10000})

(def create-ticket-url "https://jira.arbfund.com/secure/CreateIssue.jspa")
(def ticket-base-url "https://jira.arbfund.com/browse/")

(defn normalize-jira [text]
  (cond (re-matches #"\d+" text) (str "SODA-" text)
        (re-matches #"SODA-\d+" text) text
        (re-matches #".*/browse/[A-Z]+-\d+" text) (subs (re-find #"/browse/[A-Z]+-\d+" text) 8)
        :else (do (prn (str "Cannot parse JIRA ticket: " text)) text)))

(defn link-jira [state _id value]
  (simple-post (str js/context "/failures/link?failure=" _id "&ticket=" value))
  (swap! state assoc-in [:jira-tickets _id] value)
  (swap! state update :jira-drafts #(dissoc % _id)))

(defn jira [state {:keys [_id] :as err}]
  (let [current-value (get-in @state [:jira-tickets _id])
        draft-value (get-in @state [:jira-drafts _id])]
    (if draft-value
      [:div.input-group
       [:input.form-control {:type :text :default-value draft-value :style {:width "100px"}
                             :on-change #(swap! state assoc-in [:jira-drafts _id] (-> % .-target .-value))}]
       [:span.glyphicon.glyphicon-check.input-group-addon
        {:on-click #(->> (get-in @state [:jira-drafts _id]) normalize-jira (link-jira state _id))
         :style {:top "0px"}}]]
      [:span
       [:a {:on-click #(.open js/window (if current-value (str ticket-base-url current-value) create-ticket-url) "_blank")}
        (str (if current-value current-value "Create") " ")]
       [:span.glyphicon.glyphicon-pencil {:on-click #(swap! state assoc-in [:jira-drafts _id] (str current-value))}]])))

(def MAX_AFFECTED_JOBS 20)

(defn show-rerun-bid [rv]
  (.alert js/window (str "Jobs re-scheduled with rerun-bid=" (:rerun-bid rv))))

(defn details-row [state {:keys [error jobs _id]}]
  (let [text (clojure.string/join \newline error)]
    [:table.failure-details-table.table.table-condensed.table-striped
     [:thead>tr [:td "Rerun"] [:td "Affected Jobs"] [:td "Error"]]
     [:tbody
      [:tr.no-height
       [:td.no-height] [:td.no-height]
       [:td.details-td {:row-span (inc (min (count jobs) MAX_AFFECTED_JOBS))}
        [:textarea.failure-text {:default-value text :read-only true :rows (min (count error) 20)}]]]
      (doall (for [job (take MAX_AFFECTED_JOBS jobs)]
               [:tr {:key job}
                [:td [:span.glyphicon.glyphicon-repeat
                      {:on-click
                       #(when (.confirm js/window (str "About to rerun job: " job ". Press OK to confirm."))
                          (simple-post (str js/context "/failures/rerun/job?id=" job
                                            (when (:priority @state) (str "&priority=" (:priority @state))))
                                       show-rerun-bid))}]]
                [:td {:key job}
                 [:a {:on-click #(.open js/window (str js/context "/failures/inspect/job?id=" job) "_blank")} job]]]))]]))

(defn failures-table [state]
  [:table#failures-table.table.table-condensed.table-striped.table-hover
   [:thead>tr [:th] [:th "Failure"] [:th "Count"] [:th "Jira"] [:th "Job Types"] [:th "Message"]]
   [:tbody
    (doall (for [{:keys [_id job-types error-message] :as error} (:errors @state)]
             (list
               [:tr {:key (str _id "-" (:count error) "-" (get-in @state [:jira-links _id]))}
                [:td [:span.glyphicon.glyphicon-repeat
                      {:on-click
                       #(when (.confirm js/window (str "About to rerun all jobs with failure: " _id ". Press OK to confirm."))
                          (simple-post
                            (str js/context "/failures/rerun/failure?" (failure->query-param _id)
                                 (when (:priority @state) (str "&priority=" (:priority @state))))
                            show-rerun-bid))}]]
                [:td {:data-toggle "collapse" :data-target (str "#" _id "-details")}
                 [:a {:on-click #(.open js/window (str js/context "/failures/inspect/failure?" (failure->query-param _id)) "_blank")} _id]]
                [:td {:data-toggle "collapse" :data-target (str "#" _id "-details")} (:count error)]
                [:td {:style {:white-space :nowrap}} (jira state error)]
                [:td {:data-toggle "collapse" :data-target (str "#" _id "-details")}
                 (for [job-type job-types] [:span.badge.badge-default {:key job-type} job-type])]
                [:td {:data-toggle "collapse" :data-target (str "#" _id "-details")} (abbreviate error-message 200)]]
               [:tr.collapse {:key (str _id "-" (:count error) "-details")
                              :id  (str _id "-details")}
                [:td.error-details-cell {:col-span 6}
                 (details-row state error)]])))]])

(defn header-row [state]
  [:h1.header-row
   [:span {:style {:text-decoration :underline}} "Current Failures"]
   (str " - Distinct: " (-> @state :errors count)
        ", Total: " (->> @state :errors (map :count) (apply +)) " ")])

(defn priority-dropdown [state]
  [:div.input-group.float-me
   [:span.input-group-addon {:style {:display :initial}} "Priority: "]
   [:div.btn-group
    [:button.btn.btn-default.dropdown-toggle
     {:type "button" :data-toggle "dropdown" :aria-haspopup true :aria-expanded false}
     (-> @state :priority priorities-map) " " [:span.fa.fa-sort-desc]]
    [:ul.dropdown-menu
     [:div (doall (for [priority (keys priorities-map)]
                    [:li {:key (priorities-map priority)}
                     [:a {:on-click #(swap! state assoc :priority priority)}
                      (priorities-map priority)]]))]]]])

(defn format-ms [ms]
  (if (= ms (.-MAX_SAFE_INTEGER js/Number))
    "Epoch"
    (.format (js/moment. ms) "MM/DD/YYYY hh:mm A")))

;http://eonasdan.github.io/bootstrap-datetimepicker/#no-icon-input-field-only
(defn date-filter [state]
  [:div.input-group [:span.input-group-addon "Since:"]
   [:div.input-group
    [:input#date-time-picker.form-control {:type "text" :value (format-ms (:since @state))}]]])


(defn button-fn [category warning]
  (when (.confirm js/window warning)
    (simple-post (str js/context "/failures/rerun/category?category=" (name category)))))

(defn rerun-buttons [state]
  [:div (priority-dropdown state)
   [:div.float-children.float-me
    [:h3 "Rerun: "]
    (doall (for [{:keys [name category warning]} categories]
             [:button.btn.btn-default {:key name :on-click (partial button-fn category warning)} name]))]])

(defn poll [f interval session-id]
  (when (= session-id (aget js/window "session-id"))
    (f)
    (.setTimeout js/window (partial poll f interval session-id) interval)))

(defn init-polls [state]
  (when (not (:started @state))
    (let [session-id (aset js/window "session-id" (.getTime (js/Date.)))] ;Hack to kill old pollers on page reload
      (swap! state assoc :started true)
      ;run all polls once immediately
      (doseq [f (keys poll-fns->intervals)] (f state))
      ;schedule repeated execution
      (doseq [[f interval] poll-fns->intervals] (poll (partial f state) interval session-id)))))

(defn render [state]
  (let [_ (init-polls state)]
    [:div
     (header-row state)
     (date-filter state)
     (rerun-buttons state)
     (failures-table state)]))

(def jquery (js* "$"))

(defn post-load [state]
  (.datetimepicker (jquery "#date-time-picker")) ;initialize date-time-picker
  (.on (jquery "#date-time-picker") "dp.hide"
       #(swap! state assoc :since (.valueOf (.-date %)))))