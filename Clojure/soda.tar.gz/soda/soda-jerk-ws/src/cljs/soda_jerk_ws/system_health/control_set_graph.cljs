(ns soda-jerk-ws.system-health.control-set-graph
  (:require [ajax.core :refer [GET]]
            [soda.control-sets :as cs]
            [cljsjs.plotly]))

(defn get-supported-fields [state]
  (-> @state :control-set keyword cs/control-sets :type cs/supported-fields sort))

(def statuses
  {:valid   "rgb(50, 175, 50)"
   :diff    "rgb(255, 100, 100)"
   :no-soda "rgb(220, 210, 0)"
   :no-lm   "rgb(100, 100, 255)"
   :no-data "rgb(200, 200, 200)"})

(defn stats-graph [state]
  (let [{:keys [validation-data show]} @state
        supported-fields (get-supported-fields state)
        other-fields (filter #(not (some #{%} supported-fields))
                             (-> validation-data :data keys sort))
        fields (filter identity (if (= show "mvp")
                                  supported-fields
                                  (concat supported-fields other-fields)))
        table-data (for [[status color] statuses]
                     {:x fields
                      :y (for [field fields]
                           (-> validation-data
                               :data
                               field
                               status
                               (or 0)
                               (* 100)
                               (/ (:total-docs validation-data 1))))
                      :name status
                      :marker {:color color}
                      :type "bar"})
        target-line {:x fields
                     :y (for [_ fields] 90)
                     :name "target"
                     :marker {:color "rgb(0,0,0)"}
                     :mode "lines"}]
    (.newPlot js/Plotly "awesome_chart"
              (clj->js (conj table-data target-line))
              #js {:barmode "stack"})))

(defn stats-pie-graph [state]
  (let [{:keys [validation-data show]} @state
        supported-fields (get-supported-fields state)
        other-fields (filter #(not (some #{%} supported-fields))
                             (-> validation-data :data keys sort))
        fields (filter identity (if (= show "mvp")
                                  supported-fields
                                  (concat supported-fields other-fields)))
        pie-data (map-indexed (fn [i [field status-map]]
                        {:labels (keys status-map)
                         :values (vals status-map)
                         :name   (name field)
                         :text   (name field)
                         :marker {:colors (map statuses (keys status-map))}
                         :type   "pie"})
                              (select-keys (:data validation-data) fields))]
    ;; TODO: pie charts https://plot.ly/javascript/pie-charts/#pie-chart-subplots
    (doseq [pie pie-data]
      (.newPlot js/Plotly (str (:name pie) "_piechart")
                (clj->js [pie])
                #js {:title (:name pie)
                     :height 300
                     :width 300}))))

(defn draw-all-stats [state]
  (stats-graph state)
  (stats-pie-graph state))

(defn dropdown [button-content dropdown-content]
  [:div.btn-group
   [:button.btn.btn-default
    {:type "button" :class "dropdown-toggle" :data-toggle "dropdown" :aria-haspopup true :aria-expanded false}
    button-content " " [:span.fa.fa-sort-desc]]
   [:ul.dropdown-menu dropdown-content]])

(defn xmas-tree-url [control-set source show]
  (str "#health/validation-graph?control-set=" control-set "&source=" source "&show=" show))

(defn control-set-dropdown [state]
  (dropdown (or (:control-set @state) "???")
            [:div (doall (for [control-set (sort (:all-control-sets @state))]
                           [:li {:key control-set}
                            [:a {:href (xmas-tree-url control-set (:source @state) (:show @state))}
                            control-set]]))]))

(defn source-dropdown [state]
  (dropdown
    (:source @state)
    [:div
     [:li [:a {:href (xmas-tree-url (:control-set @state) "jaegers" (:show @state))} "jaegers"]]
     [:li [:a {:href (xmas-tree-url (:control-set @state) "soda-api" (:show @state))} "soda-api"]]]))

(defn mvp-dropdown [state]
  (dropdown
    (:show @state)
    [:div
     [:li [:a {:href (xmas-tree-url (:control-set @state) (:source @state) "mvp")} "mvp"]]
     [:li [:a {:href (xmas-tree-url (:control-set @state) (:source @state) "all-fields")} "all-fields"]]]))

(defn control [label element] [:td [:div.input-group [:span.input-group-addon label] element]])

(defn controls [state]
  [:table#health-controls
   [:tbody [:tr
            (control "Control Set:" (control-set-dropdown state))
            (control "Source:" (source-dropdown state))
            (control "Show:" (mvp-dropdown state))
            [:td]]]])


(defn request-validation-data [state]
  (GET (str js/context "/analytics/validation-small/control-set/" (:control-set @state) "/source/" (:source @state))
       {:keywords? true
        :handler (fn [r] (swap! state assoc :validation-data r))
        :error-handler (fn [] nil)}))


(defn init-page-state [state]
  (when (not (:started @state))
    (swap! state assoc :started true)
    (request-validation-data state)))

(defn render [state]
  (init-page-state state)
  [:div
   (controls state)
   [:div {:id "awesome_chart"}]
   (for [[field] (-> @state :validation-data :data)
         :when field]
     [:div {:id (str (name field) "_piechart")
            :key (str (name field) "_piechart")
            :style {:float "left"}}])])
