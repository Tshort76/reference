(ns soda-jerk-ws.system-health.system-health
  (:require [reagent.core :as r]
            [soda-jerk-ws.system-health.current-failures :as cf]
            [soda-jerk-ws.system-health.control-set-overview :as cso]
            [soda-jerk-ws.system-health.control-set-graph :as csg]
            [soda-jerk-ws.system-health.document-inspector :as di]
            [soda-jerk-ws.system-health.machine-overview :as mo]
            [soda-jerk-ws.system-health.file-expectations :as fe]
            [soda.control-sets :as cs]))

(defn module [title url]
  [:div {:style {:width "100%" :background-color "#eee" :padding "20 20 20 20"}}
   [:h3.text-center {:style {:margin-top 0}} [:a {:href url} title]]
   [:iframe {:src url :style {:width "100%" :height "420px"}}]])

(defn render [state]
  [:div
   [:h1.text-center "SoDa System Health"]
   (module "API Validation" (str js/context "/#health/validation?control-set=edgar-multi-1000&source=soda-api&show=mvp"))
   [:h2 "Dashboards:"]
   [:h3>a {:href (str js/context "/#health/machine-overview")} "Machine Overview"]])

(defn parse-bool [s] (= s "true"))

(defn current-failures-page [query-params]
  (let [state (r/atom {:since 9007199254740991})]
    (r/create-class {:reagent-render (partial cf/render state)
                     :component-did-mount (partial cf/post-load state)
                     :component-did-update (partial cf/post-load state)})))

(defn machine-overview-page [{:keys [active-only span end fix-ends]
                              :or {active-only "true" span "900000" end "9007199254740991" fix-ends "true"}
                              :as query-params}]
  (let [state (r/atom {:active-only (parse-bool active-only) :span (js/parseInt span)
                       :end (js/parseInt end) :fix-ends (parse-bool fix-ends)})]
    (r/create-class {:component-did-mount (partial mo/post-load state)
                     :component-did-update (partial mo/post-load state)
                     :reagent-render (partial mo/render state)})))

(defn file-expectations-page [query-params]
  (let [state (r/atom (or query-params {}))]
    (r/create-class {:get-initial-state (partial fe/load-data state)
                     :reagent-render    (partial fe/render state)})))

(defn validation-page [{:keys [control-set source show] :as query-params}]
  (let [state (r/atom {:all-control-sets (map name (keys cs/control-sets))
                       :control-set control-set :source source :show show})]
    (r/create-class {:reagent-render (partial cso/render state)})))

(defn validation-graph-page [{:keys [control-set source show] :as query-params}]
  (let [state (r/atom {:all-control-sets (map name (keys cs/control-sets))
                       :control-set control-set :source source :show show})]
    (r/create-class {:reagent-render (partial csg/render state)
                     :component-did-mount (fn [] (csg/draw-all-stats state))
                     :component-did-update (fn [] (csg/draw-all-stats state))})))

(defn validate-doc-page [{:keys [md5 cusip session index] :as query-params}]
  (let [session-data (.getItem js/sessionStorage session)
        metas (when session-data (cljs.reader/read-string session-data))
        state (r/atom (cond-> {:md5 md5 :cusip cusip}
                              session-data (assoc :session session :index (js/parseInt index) :metas metas)))]
    (r/create-class {:reagent-render (partial di/render state)})))

(defn health-overview []
  (let [state (r/atom {})]
    (r/create-class {:reagent-render (partial render state)})))
