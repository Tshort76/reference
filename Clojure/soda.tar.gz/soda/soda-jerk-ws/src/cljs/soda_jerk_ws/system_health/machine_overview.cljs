(ns soda-jerk-ws.system-health.machine-overview
  (:require [ajax.core :refer [GET POST]]
            [cljs.pprint :as pp]
            [goog.string :as s]
            [goog.string.format]
            [medley.core :refer [dissoc-in]]))

(defn ask-confirmation [prompt] (.confirm js/window prompt))
(defn swap [v i1 i2] (assoc v i2 (v i1) i1 (v i2)))
(defn vec-remove [v i] (vec (concat (subvec v 0 i) (subvec v (inc i)))))
(def MAX_SAFE_DATE (js/Date. 8640000000000000))

(defn heartbeat-within? [seconds {:keys [last-heartbeat] :as host}]
  (when last-heartbeat
    (let [heartbeat-time-millis (.valueOf last-heartbeat)
          current-time-millis (.valueOf (js/Date.))]
      (>= heartbeat-time-millis (- current-time-millis (* seconds 1000))))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;; JOB HISTORY ;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn millis->str [millis]
  (let [hours (quot millis (* 1000 60 60))
        remainder (rem millis (* 1000 60 60))
        minutes (quot remainder (* 1000 60))
        remainder (rem remainder (* 1000 60))
        seconds (quot remainder 1000)
        milliseconds (rem remainder 1000)]
    (str hours "h " minutes "m " seconds "s " milliseconds "ms")))

(defn tooltip [id runtime] (s/format "<div><p>Job Id: %s</p><p>Runtime: %s</p></div>" id (when runtime (millis->str runtime))))

(defn jobs-on-host [state host]
  (-> @state (get-in [:jobs host]) vals flatten))

(defn jobs-on-host-or-default [state host]
  (let [jobs (jobs-on-host state host)]
    (if (pos? (count jobs))
      (sort-by (juxt :worker :started-at) jobs)
      (let [start (js/Date. (:graph-start @state))]
        [{:_id "Fake job needed for rendering" :worker "No jobs completed" :run-time 0 :started-at start :completed-at start}]))))

;26 colors for the Colour Alphabet Project: https://graphicdesign.stackexchange.com/a/3815
(def contrasting-colors ["#F0A3FF" "#0075DC" "#993F00" "#4C005C" "#005C31" "#2BCE48" "#FFCC99" "#808080"
                         "#94FFB5" "#8F7C00" "#9DCC00" "#C20088" "#003380" "#FFA405" "#FFA8BB" "#426600" "#FF0010"
                         "#5EF1F2" "#00998F" "#E0FF66" "#740AFF" "#990000" "#FFFF80" "#FFFF00" "#FF5005"])

;Job types found in prod between 2018-01-01 and 2018-03-14, ordered by frequency
(def job-types ["scrape"
                "normalize"
                "aggregate-by-identifiers"
                "update-soda-entity-view"
                "aggregate"
                "parse-file"
                "jaegerize"
                "muni-entity"
                "aggregate-entity"
                "migrate-jaeger-docs"
                "supplemental"
                "process-figi-requests"
                "daily-publication"
                "update-cusip-db-entity-view"
                "get-index-rates"
                "create-cik-to-parent-cik-universe"
                "make-mindfood"
                "process-13f"])

(def job-colors (assoc (zipmap job-types contrasting-colors)
                  "Fake job needed for rendering" "#FFFFFF"))

(defn job-type->color [job-type]
  (get job-colors job-type "#000000"))

(defn inc-date [date]
  (-> date .valueOf inc js/Date.))

(defn job-data [state job & {:keys [max-end] :or {max-end (js/Date. MAX_SAFE_DATE)}}]
  (let [color (-> job :job-def :type job-type->color)
        tooltip-content (tooltip (:_id job) (:run-time job))
        start-date (max (:started-at job) (js/Date. (:graph-start @state)))
        end-date (if (:completed-at job)
                   (min (:completed-at job) (js/Date. (:graph-end @state)) max-end)
                   (js/Date. (:graph-end @state)))]
    [(str (:worker job)) (:_id job) color tooltip-content start-date (max end-date (inc-date start-date))]))

(defn get-chart-data [state host]
  (loop [jobs (jobs-on-host-or-default state host) chart-data []]
    (if-not (seq jobs)
      chart-data
      (let [data (if (and (:fix-ends @state) (= (-> jobs first :worker) (-> jobs second :worker)))
                   (job-data state (first jobs) :max-end (-> jobs second :started-at))
                   (job-data state (first jobs)))]
        (recur (rest jobs)
               (conj chart-data data))))))

(defn populate-chart [state host]
  (let [data (js/google.visualization.DataTable.)]
    (.addColumn data "string" "Worker")
    (.addColumn data "string" "Name")
    (.addColumn data (clj->js {:type "string" :role "style"}))
    (.addColumn data (clj->js {:type "string" :role "tooltip" :p {:html true}}))
    (.addColumn data "date" "Draw Start")
    (.addColumn data "date" "Draw End")
    (.addRows data (clj->js (get-chart-data state host)))
    data))

(defn chart-options [state host]
  {:timeline {:rowLabelStyle {:fontName "Courier" :fontSize 12}
              :showBarLabels false
              :barLabelStyle {:fontSize 10}}
   :hAxis {:format "h:mm:ss"
           ;:gridlines {:count -1
           ;            :units {:minutes {:format ["HH:mm"]}
           ;                    :seconds {:format ["hh:mm:ss"]}}}
           :textStyle {:fontName "Arial" :fontSize "40" :color "red"}
           :minValue (js/Date. (:graph-start @state))
           :maxValue (js/Date. (:graph-end @state))}})

(defn safe-host-name [host]
  (clojure.string/replace host #"[^a-zA-Z\d]+" ""))

(defn get-chart [host]
  (js/google.visualization.Timeline. (.getElementById js/document (str (safe-host-name host) "-timeline"))))

(defn draw-chart [state host]
  (let [data (populate-chart state host)
        options (clj->js (chart-options state host))
        chart (get-chart host)
        click-handler (fn [& args] (->> chart .getSelection first .-row (nth (jobs-on-host-or-default state host)) :_id
                                        (str js/context "/utils/job-by-id?id=") (.open js/window)))]
    (.draw chart data options)
    (.addListener (.-events (.-visualization js/google)) chart "select" click-handler)))

;;;;;;;;;;;;;;;;;;;;;;;;;;;; JOB-TYPE KEY ;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn job-chart-keys [state host]
  [:div
   [:table.key-table
    [:thead>tr [:th] [:th "Job Type"] [:th "Count"]]
    [:tbody
     (let [job-type-freqs (->> (jobs-on-host state host) (map (comp :type :job-def)) frequencies)
           sorted-types (sort-by job-type-freqs > (keys job-type-freqs))]
       (for [job-type sorted-types]
         [:tr {:key (str host job-type)}
          [:td>p [:span.glyphicon.glyphicon-stop {:style {:color (job-type->color job-type)}}]]
          [:td>p (str " " job-type)]
          [:td>p (job-type-freqs job-type)]]))]]])

;;;;;;;;;;;;;;;;;;;;;;;;;;;; QUERIES UI ;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn valid? [query-str]
  (try
    (map? (js->clj (.parse js/JSON query-str)))
    (catch js/Error _ false)))

(defn set-queries-on-server [host queries success-handler]
  (if-not (every? valid? queries)
    (.alert js/window "Not all queries are valid.")
    (when (ask-confirmation (str "This will change the queries on " host ". Press OK to continue."))
      (POST (str js/context "/system/" host "/queries")
            {:keywords?     true
             :params        queries
             :handler       success-handler
             :error-handler #(do (prn "Error while requesting validation data:") (pp/pprint %))}))))

(defn get-displayed-queries [state host]
  (if (get-in @state [:host-states host :draft-view])
    (get-in @state [:host-states host :queries-draft])
    (get-in @state [:hosts host :queries])))

(defn update-queries [state host f]
  (let [host-state (get-in @state [:host-states host])
        new-host-state (assoc host-state :queries-draft (f (get-displayed-queries state host)) :draft-view true)]
    (if (and (:queries-draft host-state) (not (:draft-view host-state)))
      (when (ask-confirmation "This will override your saved draft. Hit OK if you want to continue.")
        (swap! state assoc-in [:host-states host] new-host-state))
      (swap! state assoc-in [:host-states host] new-host-state))))

(defn query-controls [state host i]
  [:td
   [:span.glyphicon.glyphicon-arrow-up {:on-click (fn [e] (update-queries state host #(when (pos? i) (swap % i (dec i)))))}]
   [:span.glyphicon.glyphicon-arrow-down {:on-click (fn [e] (update-queries state host #(when (< i (dec (count %))) (swap % i (inc i)))))}]
   [:span.glyphicon.glyphicon-remove.text-danger {:on-click (fn [e] (update-queries state host #(vec-remove % i)))}]])

(defn query-text-box [state host i]
  (let [query (nth (get-displayed-queries state host) i)]
    [:td {:style {:width "100%"}}
     [(if (valid? query) :textarea.query :textarea.query.invalid)
      {:rows    (inc (count (clojure.string/split-lines query))) :default-value query
       :on-blur (fn [e] (update-queries state host #(assoc % i (-> e .-target .-value))))}]]))

(defn render-queries [state host]
  [:div.queries
   (let [draft-view? (get-in @state [:host-states host :draft-view])]
     [:div
      [:h4.bold.left-label (if draft-view? "Queries Draft:" "Current Queries:")]
      (when (get-in @state [:host-states host :queries-draft])
        [:button.btn.btn-default {:on-click #(swap! state update-in [:host-states host :draft-view] not)}
         (if draft-view? "View Current" "View Draft")])])
   [:table.queries-table>tbody
    (doall (for [i (range (count (get-displayed-queries state host)))]
             [:tr {:key (str i "-" (nth (get-displayed-queries state host) i))}
              (query-controls state host i)
              (query-text-box state host i)]))
    [:tr
     [:td [:span.glyphicon.glyphicon-plus.text-success {:on-click (fn [e] (update-queries state host #(conj % "{}")))}]]
     (when (get-in @state [:host-states host :draft-view])
       [:td {:style {:text-align :right}}
        [:button.btn.btn-default {:on-click (comp #(swap! state assoc-in [:host-states host :draft-view] false)
                                                  #(update-queries state host (fn [& args] nil)))} "Discard Draft"] " "
        [:button.btn.btn-default
         {:on-click #(set-queries-on-server
                       host
                       (get-in @state [:host-states host :queries-draft])
                       (fn [_]
                         (let [new-queries (get-in @state [:host-states host :queries-draft])]
                           (swap! state (fn [cv]
                                          (-> (assoc-in cv [:host-states host :draft-view] false)
                                              (assoc-in [:hosts host :queries] new-queries)
                                              (dissoc-in [:host-states host :queries-draft])))))))}
         "Apply Drafted Changes"]])]]])

;;;;;;;;;;;;;;;;;;;;;;;;;;;; MACHINE UTILIZATION ;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn format-pct [d]
  (str (pp/cl-format nil "~,2f" (* d 100)) "%"))

(defn render-utilization [state host]
  (let [{:keys [cpu memory swap uptime heap]} (:stats (get-in @state [:utilization :data host]))]
    [:p
     "Utilization: "
     [:span.badge.badge-default (str "CPU: " (if cpu (format-pct cpu) "???"))]
     [:span.badge.badge-default (str "MEMORY: " (if memory (format-pct memory) "???"))]
     [:span.badge.badge-default (str "SWAP: " (if swap (format-pct swap) "???"))]
     [:span.badge.badge-default (str "HEAP: " (if heap (format-pct heap) "???"))]]))

;;;;;;;;;;;;;;;;;;;;;;;;;;;; STATS ROW ;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn heart [state host]
  [:span.glyphicon.glyphicon-heart {:class (if (heartbeat-within? 10 (get-in @state [:hosts host]))
                                             (if (:heart @state) "heartbeat-on" "heartbeat-off")
                                             "heartbeat-dead")
                                    :title (str "Last Heartbeat: " (get-in @state [:hosts host :last-heartbeat]))}])

(defn run-time-within-span [state job]
  (if-let [run-time (:run-time job)]
    ;completed job
    (let [start (max (- (:completed-at job) run-time) (:graph-start @state))
          end (min (:completed-at job) (:graph-end @state))]
      (- end start))
    ;incomplete job (note: inaccurate because started-at is time queued, not start time of execution)
    (- (:graph-end @state)
       (max (:started-at job) (:graph-start @state))))) ;use graph-start for start time if job started before graph

(defn idle-rate [state host jobs]
  (let [elapsed-millis (:span @state)
        num-consumers (get-in @state [:hosts host :num-consumers])
        total-thread-time (* elapsed-millis num-consumers)
        total-work-time (reduce #(+ %1 (run-time-within-span state %2)) 0 jobs)
        idle-rate (- 1 (/ total-work-time total-thread-time))]
    (max (min idle-rate 1) 0)))

(defn error-rate [jobs]
  (if (pos? (count jobs))
    (let [errored-jobs (filter :error jobs)]
      (/ (count errored-jobs) (count jobs)))
    0))

(defn render-stats [state host]
  (let [jobs (jobs-on-host state host)]
    [:p.consumer-stats
     "Job Stats: "
     [:span.badge.badge-default (str "Total Jobs: " (count jobs))]
     [:span.badge.badge-default (str "Idle Rate: " (format-pct (idle-rate state host jobs)))]
     [:span.badge.badge-default (str "Error Rate: " (format-pct (error-rate jobs)))]]))

;;;;;;;;;;;;;;;;;;;;;;;;;;;; CONTROLS ;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn machine-overview-url [state & {:keys [active-only span end fix-ends]}]
  (str "#health/machine-overview"
       "?active-only=" (if (nil? active-only) (str (:active-only @state)) active-only)
       "&span=" (or span (:span @state))
       "&end=" (or end (:end @state))
       "&fix-ends=" (or fix-ends (:fix-ends @state))))

(defn dropdown [button-content dropdown-content]
  [:div.btn-group
   [:button.btn.btn-default.dropdown-toggle
    {:type "button" :data-toggle "dropdown" :aria-haspopup true :aria-expanded false}
    button-content " " [:span.fa.fa-sort-desc]]
   [:ul.dropdown-menu dropdown-content]])

(defn set-host-action [host action]
  (POST (str js/context "/system/" host "/action")
        {:keywords? true :handler identity :params action
         :error-handler #(do (prn "Error while requesting validation data:") (pp/pprint %))}))

(defn pause-run-button [state host]
  (let [running? (= (get-in @state [:hosts host :action]) "run")]
    [:button.btn.btn-default {:on-click #(set-host-action host (if running? "pause" "run"))}
     (if running? [:span.glyphicon.glyphicon-pause] [:span.glyphicon.glyphicon-play])]))

(defn set-host-consumers [host num-consumers]
  (POST (str js/context "/system/" host "/consumers")
        {:keywords? true :handler identity :params (js/parseInt num-consumers)
         :error-handler #(do (prn "Error while requesting validation data:") (pp/pprint %))}))

(defn num-consumer-picker [state host]
  [:span "Consumers: "
   [:select {:defaultValue (get-in @state [:hosts host :num-consumers])
             :on-change #(set-host-consumers host (-> % .-target .-value))}
    (for [i (range 1 9)]
      [:option {:key (str "consumer-option-" i)} i])]])

(defn active-dropdown [state]
  (dropdown (if (nil? (:active-only @state)) "???" (str (:active-only @state)))
            [:div
             [:li [:a {:href (machine-overview-url state :active-only true)} "true"]]
             [:li [:a {:href (machine-overview-url state :active-only false)} "false"]]]))

(def span-options {"1 Min" 60000 "5 Min" 300000 "15 Min" 900000 "30 Min" 1800000 "1 Hour" 3600000})
(defn invert [m] (zipmap (vals m) (keys m)))

(defn span-dropdown [state]
  (dropdown ((invert span-options) (:span @state))
            [:div (doall (for [span (keys span-options)]
                           [:li {:key span}
                            [:a {:href (machine-overview-url state :span (span-options span))}
                             span]]))]))

(defn format-ms [ms]
  (if (= ms (.-MAX_SAFE_INTEGER js/Number))
    "Now"
    (.format (js/moment. ms) "MM/DD/YYYY hh:mm A")))

;http://eonasdan.github.io/bootstrap-datetimepicker/#no-icon-input-field-only
(defn end-picker [state]
  [:div.input-group
   [:input#date-time-picker.form-control {:type "text" :value (format-ms (:end @state))}]
   [:span.input-group-addon {:on-click #(.open js/window (machine-overview-url state :end (.-MAX_SAFE_INTEGER js/Number)) "_self")} "Set to Now"]])

(defn fix-ends-dropdown [state]
  (dropdown (if (nil? (:fix-ends @state)) "???" (str (:fix-ends @state)))
            [:div
             [:li [:a {:href (machine-overview-url state :fix-ends "true")} "true"]]
             [:li [:a {:href (machine-overview-url state :fix-ends "false")} "false"]]]))

(defn control [label element] [:td [:div.input-group [:span.input-group-addon label] element]])

(defn controls [state]
  [:table#health-controls
   [:tbody [:tr
            (control "Active Only:" (active-dropdown state))
            (control "Span:" (span-dropdown state))
            (control "End:" (end-picker state))
            (control "Fix Overlapping Jobs:" (fix-ends-dropdown state))
            [:td]]]])

;;;;;;;;;;;;;;;;;;;;;;;;;;;; APP RENDER/UPDATE FUNCTIONS ;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defn render-host [state host]
  (let [host-paused? (= (get-in @state [:hosts host :action]) "pause")]
    [:div.host-row {:key host :style {:background-color (when host-paused? "#fcc")}}
     [:tr.host-header-row>td.host-header-cell {:col-span 2}
      [:h2 host]
      (heart state host)
      [:div (pause-run-button state host)]
      (num-consumer-picker state host)
      (render-stats state host)
      (render-utilization state host)]
     [:tr.timeline-row
      [:td.timeline-cell
       [(keyword (str "div#" (safe-host-name host) "-timeline.timeline-div"))]] ;job timeline gets injected here later
      [:td.key-cell {:row-span 2 :style {:vertical-align :top}} (job-chart-keys state host)]]
     [:tr.query-row>td.query-cell (render-queries state host)]]))

(defn request-utilization-data [state]
  (GET (str js/context "/status/utilization")
       {:handler       #(swap! state assoc :utilization {:last-response (.valueOf (js/Date.)) :data %})
        :error-handler #(do (prn ("Error while requesting validation data:" ))
                            (pp/pprint %)
                            (swap! state assoc-in :utilization {:last-response (.valueOf (js/Date.))}))}))

(defn request-host-data [state]
  (GET (str js/context "/system/hosts?active=false")
       {:handler       #(let [hosts (if (:active-only @state) (filter (partial heartbeat-within? (* 10 60)) %) %)] ;within 10 minutes
                          (swap! state assoc :hosts (zipmap (map :_id hosts) hosts))
                          (request-utilization-data state))
        :error-handler #(do (prn "Error while requesting validation data:") (pp/pprint %))}))

(defn request-job-data [state]
  (when (< (or (:graph-end @state) 0) (:end @state)) ;only request job data when existing graph doesn't reach desired end
    (let [graph-end (min (:end @state) (.getTime (js/Date.)))
          graph-start (- graph-end (:span @state))]
      (GET (str js/context "/workers/jobs-between?start=" graph-start
                (when-not (= (:end @state) (.-MAX_SAFE_INTEGER js/Number)) (str "&end=" (:end @state))))
           {:keywords?     true
            :handler       #(do (swap! state assoc :jobs % :graph-start graph-start :graph-end graph-end)
                                (doseq [host (-> @state :hosts keys)]
                                  (.setOnLoadCallback (.-charts js/google) (partial draw-chart state host))))
            :error-handler #(do (prn "Error while requesting jobs:") (pp/pprint %))}))))

(defn heart-cycle [state]
  (swap! state update :heart not))

(def poll-fns->intervals {request-job-data 5000
                          request-host-data 1000
                          heart-cycle 1000})

(defn poll [f interval session-id]
  (when (= session-id (aget js/window "session-id"))
    (f)
    (.setTimeout js/window (partial poll f interval session-id) interval)))

(defn init-polls [state]
  (when (not (:started @state))
    (let [session-id (aset js/window "session-id" (.getTime (js/Date.)))] ;Hack to kill old pollers on page reload
      (swap! state assoc :started true)
      ;run all polls once immediately
      (doseq [f (keys poll-fns->intervals)] (f state))
      ;schedule repeated execution
      (doseq [[f interval] poll-fns->intervals] (poll (partial f state) interval session-id)))))

(defn sort-hosts [host-names]
  (sort-by #(conj (mapv js/parseInt (re-seq #"\d+" %)) %) ;sort first by integers found in name, then by name
           host-names))

(defn render [state]
  (let [_ (init-polls state)]
    [:div
     (controls state)
     [:table.machine-overview-hosts>tbody (doall (for [id (-> @state :hosts keys sort-hosts)] (render-host state id)))]]))

(.load (.-charts js/google) "visualization" "1.1" (clj->js {:packages ["timeline"]}))

(def jquery (js* "$"))

(defn post-load [state]
  (.datetimepicker (jquery "#date-time-picker")) ;initialize date-time-picker
  (.on (jquery "#date-time-picker") "dp.hide"
       #(.open js/window (machine-overview-url state :end (.valueOf (.-date %))) "_self")))