(ns soda-jerk-ws.system-health.file-expectations
  (:require [cljs.pprint :as pp]
            [ajax.core :refer [GET POST]]))

(defn request-utilization-data [state]
  (let [{:keys [start-date end-date]} @state
        query-params (str "?start-date=" (or start-date "2017-01-01") "&end-date=" (or end-date (subs (.toJSON (js/Date.)) 0 10)))]
    (set! (.-location js/window) (str js/context "/#health/file-expectations" query-params))
    (GET (str js/context "/expectations/files" query-params "&only-failures?=true")
         {:handler       #(swap! state assoc :data %)
          :error-handler #(do (prn ("Error while requesting validation data:"))
                              (swap! state assoc-in :utilization {:last-response (.valueOf (js/Date.))}))})))

(defn load-data [state]
  (request-utilization-data state))

(defn render-controls [state]
  [:div {:style {:text-align "center"}}
   [:label "Filter by file-type"]
   [:br]
   (reduce (fn [select file-type]
             (conj select [:option {:value file-type} file-type]))
           [:select#file-type-filter {:on-change #(let [selected (.-value (.getElementById js/document "file-type-filter"))]
                                                    (if (= selected "Nothing Selected")
                                                      (swap! state dissoc :file-type-filter)
                                                      (swap! state assoc :file-type-filter selected)))}
            [:option {:value "Nothing Selected"} "Nothing Selected"]]
           (map :file-type (:data @state)))])

(defn render-table [state]
  [:table {:style {:width "100%" :margin "20px"}}
   (reduce (fn [table {:keys [file-type expectation periods]}]
             (let [expected (:min-upload-count expectation)
                   {:keys [units magnitude]} (:period expectation)]
               (when (and (= units "days") (= 12 (count periods)))
                 (pp/pprint file-type))
               (reduce conj (conj table [:tr {:style {:height :10px}}])
                       (mapv (fn [{:keys [upload-count period-start period-end]}]
                               [:tr [:td period-start] [:td period-end] [:td file-type] [:td units] [:td expected] [:td upload-count]])
                             periods))))
           [:tbody [:tr [:th "Begin Date"] [:th "End Date"] [:th "File Type"] [:th "Period"] [:th "Expected"] [:th "Actual"]]]
           (filter (if (:file-type-filter @state)
                     #(= (:file-type %) (:file-type-filter @state))
                     identity)
                   (:data @state)))])

(defn render [state]
  [:div
   (render-controls state)
   (render-table state)])
