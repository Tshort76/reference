(ns soda-jerk-ws.raptor.service-interop
  (:require [ajax.core :refer [POST GET]]))

(defn async-synthaul-form [form file-num handler error-handler]
  (POST (str js/context"/synthahaul/upload-" file-num)
        {:body (js/FormData. form)
         :handler handler
         :error-handler error-handler
         :response-format :json
         :keywords? true}))

(defn async-file-types [handler]
  (GET (str js/context "/uploader/file-types")
       {:handler handler
        :response-format :json
        :keywords? true}))

(defn async-audit-data [id-type id handler]
  (GET (str js/context "/relay/soda-api?query=security/audit/" (name id-type) "/" id)
       {:handler handler
        :response-format :json
        :keywords? true}))
