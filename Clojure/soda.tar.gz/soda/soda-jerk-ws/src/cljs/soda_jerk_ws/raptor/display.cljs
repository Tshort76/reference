(ns soda-jerk-ws.raptor.display
  (:require [clojure.string :as str]
            [clojure.pprint :refer [pprint]]
            [soda-jerk-ws.raptor.service-interop :as svc]))

(defn id-range
  ([{:keys [min-id max-id]}]
   (id-range min-id max-id))
  ([start-id end-id]
   (when (and start-id end-id)
     (let [start (js/parseInt (.substr start-id -3) 16)
            end (inc (js/parseInt (.substr end-id -3) 16))]
       (map #(str (subs start-id 0 (- (count start-id) 3))
                  (.substr (.toString % 16) -3))
            (range start (if (<= end start)
                           (+ 4096 end)
                           end)))))))

(defn gen-get-num []
  (let [n (atom 0)]
    (fn [] (swap! n inc))))


(defn make-doc-nodes [synth-data]
  (let [get-num (gen-get-num)]
    (->> synth-data
         (mapcat
          (fn [{data :data {:keys [db coll]} :result}]
            (let [type (or (({"soda-raw"        {"data" "raw"
                                                 "jaegers" "jaeger"
                                                 "supplemental" "supple"}
                              "soda-normalized" {"data" "norm"
                                                 "agg-cache" "agg"}}
                             db {}) coll)
                           "unknown")]
              (mapv (fn [{id :_id :as doc}]
                      {:id id, :type type :data doc})
                    data))))
         distinct
         (mapv (fn [{:keys [id type data]}]
                  #js {:id    id
                       :label (str type "-doc-" (get-num))
                       :group "docs"
                       :data data})))))

(defn make-job-nodes [synth-data]
  (let [get-num (gen-get-num)
        ;; TODO: use id-set to determine number of valid input job ids
        valid-ids (->> synth-data
                       (mapcat (comp (partial mapv :_id) :data))
                       (into #{}))]
    (mapv (fn [{:keys [result job error]}]
            #js {:id    (:_id job)
                 :label (str (-> job :job-def :type) "-job-" (get-num))
                 :group (cond
                          error "error"
                          (or (= 0 (:count result))
                              (some->> (id-range (:job-def job))
                                       (filter valid-ids)
                                       count
                                       (< (:count result)))) "warn"
                          :else "jobs")
                 :data (cond-> (assoc job :result result)
                               error (assoc :error error))})
          synth-data)))

(defn make-file-nodes [synth-data]
  (->> synth-data
       (keep
        (fn [{{{:keys [md5 filename]} :job-def} :job}]
          (when md5 [md5 filename])))
       distinct
       (map
        (fn [[md5 filename]]
          #js {:id    md5
               :label filename
               :group "files"}))))

(defn make-nodes [synth-data]
  (apply concat
    ((juxt make-file-nodes
           make-doc-nodes
           make-job-nodes)
     synth-data)))


(defn extract-source-ids [source]
  (cond
    (sequential? source) (mapcat extract-source-ids source)
    (map? source) (or (some-> (:_id source) vector)
                      (mapcat extract-source-ids (vals source)))
    :else []))

(defn make-edges [synth-data]
  (distinct
   (mapcat
    (fn [{{{md5 :md5 :as job-def} :job-def job-id :_id} :job
          result :result}]
      (concat
       (mapv (fn [target-id]
               #js {:from target-id
                    :to job-id
                    :arrows "to"})
             (if md5 [md5] (id-range job-def)))
       (mapv (fn [target-id]
               #js {:from job-id
                    :to target-id
                    :arrows "to"})
             (id-range result))))
    synth-data)))


(defn get-pipeline-data [file-number state]
  (swap! state assoc :loading? true)
  (svc/async-synthaul-form
   (.getElementById js/document "fileForm")
   file-number
   (fn [docs]
     (let [nodes (new js/vis.DataSet
                   (apply array (make-nodes docs)))
           edges (new js/vis.DataSet
                   (apply array (make-edges docs)))
           all-details (fn [params]
                         (-> params
                             .-nodes
                             js->clj
                             first
                             (->> (.get nodes))
                             js->clj
                             (get "data")))]
       (doto (new js/vis.Network
               (.getElementById js/document "mynetwork")
               #js {:nodes nodes
                    :edges edges}
               #js {:nodes #js {:size 15
                                :font #js {:strokeWidth 3
                                           :strokeColor "#fff"}}
                    :layout #js {:hierarchical #js {:direction "LR"
                                                    :sortMethod "directed"}}
                    :physics #js {:enabled false}
                    :groups #js {:docs #js {:shape "dot"}
                                 :jobs #js {:shape "diamond"}
                                 :files #js {:shape "square"}
                                 :error #js {:shape "triangle"
                                             :color "#f55"}
                                 :warn #js {:shape "triangle"
                                            :color "#ff0"}}})
             (.on "click"
                  (fn [js-params]
                    (set! (-> js/document
                              (.getElementById "outSpan")
                              .-innerHTML)
                      (when-let [data (all-details js-params)]
                        (-> data pprint with-out-str))))))
       (swap! state assoc :loading? false)))
   (fn [_] (swap! state assoc :loading? false) nil)))


(defn make-form [file-types n-files]
  (into
   [:form#fileForm.form-horizontal]
   (mapcat
    (fn [i]
      [[:div.form-group
        [:label.col-sm-2.control-label
         {:for (str "file" i)} (str "File " i)]
        [:div.col-sm-10>input
         {:type "file" :name (str "file" i)}]]
       [:div.form-group
        [:label.col-sm-2.control-label
         {:for (str "file-type" i)}
         (str "File Type " i)]
        [:div.col-sm-10>select.custom-select
         {:name (str "file-type" i)}
         (for [type file-types]
           [:option {:key type :value type} type])]]])
    (range n-files))))

(defn render [state]
  (let [file-number (:file-num @state 1)
        loading? (:loading? @state)]
    [:div
     [:div#mynetwork.col-md-6.no-padding.tall
      {:style {:border "1px solid #444"}}
      [:div.vis-network>canvas
       {:width 600 :height 400}]]
     [:div.col-md-6.tall
      {:style {:overflow "auto"}}
      [:img {:width 125 :height 125 :style {:display :inline}
             :src "img/Peregrine_Falcon_with_Kill-Will_Mayall.jpg"}]
      [:h2 "Raptor: visceral pipeline inspector"]
      [:div
       [:button.btn.btn-default
        {:type "button"
         :data-toggle "collapse"
         :data-target "#uploadTab"
         :aria-expanded true
         :aria-controls "uploadTab"}
        "Toggle Uploader"]
       (when loading? [:span " " [:i.fa.fa-refresh.fa-spin.fa-fw]
                       [:span.sr-only "Loading..."]])
       [:div#uploadTab.collapse.in>div.well
        [make-form (:file-types @state) file-number]
        [:div.dropdown.col-sm-8
         [:button.btn.btn-default.dropdown-toggle
          {:type "button"
           :data-toggle "dropdown"
           :aria-haspopup true
           :aria-expanded false}
          (str file-number " Files\t")
          [:span.caret]]
         [:ul.dropdown-menu.scrollable-menu
          (for [i (range 1 7)]
            [:li {:key i
                  :on-click #(swap! state assoc :file-num i)}
             [:a (str i " Files")]])]]
        [:button.btn.btn-default
         {:type "button"
          :data-toggle "collapse"
          :data-target "#uploadTab"
          :aria-expanded true
          :aria-controls "uploadTab"
          :on-click #(get-pipeline-data file-number state)}
         "Upload"]]]
      [:h4 "Click on a node to view it's details."]
      [:pre>code#outSpan]]]))
