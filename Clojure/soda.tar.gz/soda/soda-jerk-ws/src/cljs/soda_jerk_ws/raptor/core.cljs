(ns soda-jerk-ws.raptor.core
  (:require [reagent.core :as r]
            [soda-jerk-ws.raptor.audit :as audit]
            [soda-jerk-ws.raptor.display :as display]
            [soda-jerk-ws.raptor.service-interop :as svc]))

(defn main-page []
  (let [state (r/atom {})]
    (svc/async-file-types #(swap! state assoc :file-types %))
    (r/create-class
     {:reagent-render (fn [] (display/render state))})))

(defn audit-page
  ([]
   (let [state (r/atom {})]
     (r/create-class
      {:reagent-render (fn [] (audit/render state))})))
  ([id-type id]
   (let [state (r/atom {:id-type id-type :id id})
         doc-load-fn (fn [] (when (and id-type id (not (:loaded? @state)))
                              (audit/get-pipeline-data state id-type id)))]
     (r/create-class
      {:reagent-render (fn [] (audit/render state))
       :component-did-mount doc-load-fn}))))
      ;  :component-did-update doc-load-fn
