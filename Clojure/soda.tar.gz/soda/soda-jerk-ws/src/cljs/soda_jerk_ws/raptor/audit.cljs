(ns soda-jerk-ws.raptor.audit
  (:require [clojure.string :as str]
            [clojure.pprint :refer [pprint]]
            [medley.core :as med]
            [soda-jerk-ws.graph.audit :as graph]
            [soda-jerk-ws.raptor.service-interop :as svc]))

(defn ->data-set [vec]
  (->> (apply array vec)
       (new js/vis.DataSet)))

(defn make-nodes [nodes]
  (->> nodes
       (map (fn [[i doc]]
              #js {:id i
                   :label (str/trim (str (:stage doc) "\n\n" (-> doc :value pprint with-out-str)))
                   :group "box"
                   :data doc}))
       ->data-set))

(defn make-edges [edges]
  (->> edges
       (mapv (fn [[a b]]
               #js {:from a
                    :to b
                    :arrows "to"}))
       ->data-set))

(defn render-graph [audit-edges audit-nodes]
  (let [nodes (make-nodes audit-nodes)
        edges (make-edges audit-edges)
        all-details (fn [params]
                      (-> params
                          .-nodes
                          js->clj
                          first
                          (->> (.get nodes))
                          js->clj
                          (get "data")))]
    (doto (new js/vis.Network
            (.getElementById js/document "mynetwork")
            #js {:nodes nodes
                 :edges edges}
            #js {:nodes #js {:size 15}
                             ; :font #js {:strokeWidth 3
                             ;            :strokeColor "#fff"}}
                 :layout #js {:hierarchical #js {:direction "UD"
                                                 :sortMethod "directed"}}
                 :edges #js {:smooth false}
                 :physics #js {:enabled false}
                               ; :solver "hierarchicalRepulsion"
                               ; :barnesHut #js {:avoidOverlap 1}}
                 :groups #js {:docs #js {:shape "dot"}
                              :box #js {:shape "box"}
                              :jobs #js {:shape "diamond"}
                              :files #js {:shape "square"}
                              :error #js {:shape "triangle"
                                          :color "#f55"}
                              :warn #js {:shape "triangle"
                                         :color "#ff0"}}})
          (.on "click"
               (fn [js-params]
                 (set! (-> js/document
                           (.getElementById "outSpan")
                           .-innerHTML)
                   (when-let [data (all-details js-params)]
                     (-> data pprint with-out-str))))))))

(defn get-pipeline-data [state id-type id]
  (swap! state assoc :loading? true)
  (svc/async-audit-data
   id-type id
  ;  "cusip" "3133TBA34"
  ;  "cusip" "79152QBM3"
  ; 3133TDTX4
   (fn [audit-doc]
     (swap! state assoc :audit audit-doc :loading? false :loaded true))))

(defn id->value [id]
  (some-> (.getElementById js/document id)
          .-value))

(defn update-href []
  (let [id-type (id->value "id-type-textbox")
        id (id->value "id-textbox")]
    (when (and id-type id)
      (some-> (.getElementById js/document "audit-button")
              (.setAttribute "href" (str "#raptor/audit/"
                                         id-type "/" id))))))


(defn render-audit-doc [{:keys [value valid trace] :as doc}]
  [:div
   (cond
     (contains? doc :value)
     [:button.btn.btn-primary
      {:on-click #(let [{:keys [graph compass]} (graph/trace->graph-data trace)]
                    (render-graph graph compass))}
      (str (or value "nil"))]

     (map? valid)
     (for [[k v] valid]
       [:div.row {:key k}
        [:div.col-sm-2 (name k)]
        [:div.col-sm-10 (render-audit-doc v)]])

     (sequential? valid)
     (for [[i v] (med/indexed valid)]
       [:div.row {:key i}
        [:div.col-xs-1 i]
        [:div.col-xs-11 (render-audit-doc v)]]))])


(defn render [state]
  (let [{:keys [id-type id loading?]} @state]
    [:div
     [:div.col-md-4.tall
      {:style {:border "1px solid #444" :overflow "auto"}}
      [render-audit-doc (-> @state :audit :audit-trace)]]
     [:div.col-md-4.tall.no-padding
      {:style {:border "1px solid #444"}}
      [:div#mynetwork.no-padding.tall>div.vis-network>canvas
       {:width 600 :height 400}]]
     [:div.col-md-4.tall
      {:style {:overflow "auto"}}
      [:img {:width 125 :height 125 :style {:display :inline}
             :src "img/Peregrine_Falcon_with_Kill-Will_Mayall.jpg"}]
      [:h2 "Raptor Visual Audit Inspector"]
      [:div>form.form-inline
       [:div.form-group
        [:label "ID Type"] " "
        [:input.form-control
         {:id "id-type-textbox"
          :type "text"
          :on-blur update-href}]] " "
       [:div.form-group
        [:label "ID"] " "
        [:input.form-control
         {:id "id-textbox"
          :type "text"
          :on-blur update-href}]] " "
       [:a.btn.btn-default
        {:id "audit-button"
         :href "#raptor/audit"}
        "Fetch Audit"]
       (when loading? [:span " " [:i.fa.fa-refresh.fa-spin.fa-fw]
                       [:span.sr-only "Loading..."]])]
      [:h4 "Click on a node to view it's details."]
      [:pre>code#outSpan]]]))
