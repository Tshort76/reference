(ns soda-jerk-ws.analytics.core
  (:require [analytics.metrics :as metrics]
            [taoensso.timbre :as timbre]))

(defn startup []
  (metrics/init-metric-config)
  (try (future (metrics/schedule-periodic-db-metrics))
       (catch Exception e
         (timbre/error (str "Exception while attempting to schedule DB metrics on startup.\n" e)))))