(ns soda-jerk-ws.analytics.xmas-tree
  (:require [datasources.core :as ds]
            [jaegers.soda-pipe :as sp]
            [jaegers.stats :as js]
            [monger.collection :as mc]
            [monger.query :as mq]
            [taoensso.timbre :as timbre]
            [analytics.metrics :as metrics]
            [clojure.pprint :as pp])
  (:import (java.util Date)))

(defn add-to-field-stats [{n :count docs :docs :or {n 0 docs []} :as field-stats} meta]
  {:count (inc n) :docs (conj docs (select-keys meta [:md5 :cusip]))})

(defn add-doc-to-validation-data [validation-data {doc :jaeger-doc meta :meta}]
  (into {}
        (map (fn [[field field-stats]]
               [field (let [status (keyword (or (get-in doc [field :result]) "no-data"))]
                        (update field-stats status #(add-to-field-stats % meta)))])
             validation-data)))

(defn get-validation-data [control-set source & {:keys [after]}]
  (let [results (js/all-stats control-set :soda-api? (= source :soda-api) :after after)
        all-fields (->> results (map (comp keys :jaeger-doc)) flatten (filter identity) set)
        empty-validation-data (zipmap all-fields (repeat nil))]
    {:total-docs (count results)
     :data (reduce add-doc-to-validation-data empty-validation-data results)}))

(defn jobs-finished? [bids]
  (not-any? #(mc/find-one-as-map (ds/get-db "soda_configs") "queue" {:bid %}) bids))

(defn get-cache-status [control-set]
  (dissoc (mc/find-one-as-map (ds/get-db "soda-analytics")
                              "validation-table-cache-state"
                              {:control-set control-set})
          :_id))

(defn cache-when-complete [control-set]
  (let [{{:keys [start-time bids]} :current last-run-times :last-run-times} (get-cache-status control-set)]
    ;wait for re-run jobs to finish
    (while (not (jobs-finished? bids))
      (timbre/trace (str "Control-set " control-set " is still re-running, sleeping for another 5 seconds."))
      (Thread/sleep 5000))
    (timbre/info (str "Finished re-running " control-set "!"))
    ;write results to cache
    (doseq [source [:jaegers :soda-api]]
      (let [data (get-validation-data control-set source :after start-time)
            doc (assoc data :meta {:control-set control-set :source source :time (Date.)})]
        (mc/insert (ds/get-db "soda-analytics") "validation-table-cache" doc)
        (metrics/validation-results->graphite (:data data) control-set source)
        (timbre/info "Wrote validation results to cache.")))
    ;update cache-state for control-set
    (let [end-time (Date.)
          run-time (- (.getTime end-time) (.getTime start-time))
          new-run-times (take 5 (cons run-time last-run-times))
          new-average (long (/ (apply + new-run-times) (count new-run-times)))]
      (mc/update (ds/get-db "soda-analytics")
                 "validation-table-cache-state"
                 {:control-set control-set}
                 {"$set" {:control-set control-set :running false :last-start start-time :last-end end-time
                          :last-run-times new-run-times :recent-average new-average}}
                 {:multi false}))))

(defn validation-recache-current [control-set]
  (let [start-time (Date.)
        {:keys [running last-run-times] :as cache-state} (get-cache-status control-set)]
    (if running
      (timbre/info (str "Cache is already being refreshed for control-set: " control-set))
      ;rerun control-set
      (let [_ (mc/upsert (ds/get-db "soda-analytics") "validation-table-cache-state"
                         {:control-set control-set}
                         (merge cache-state
                                {:control-set control-set :running true :current {:start-time start-time :bids []}}))]
        (cache-when-complete control-set)))))

(defn refresh-validation-cache [control-set]
  (let [start-time (Date.)
        {:keys [running last-run-times] :as cache-state} (get-cache-status control-set)]
    (if running
      (timbre/info (str "Cache is already being refreshed for control-set: " control-set))
      ;rerun control-set
      (let [bids (doall (map :bid (sp/write-data-via-queue control-set :->api? true)))
            _ (mc/upsert (ds/get-db "soda-analytics") "validation-table-cache-state"
                         {:control-set control-set}
                         (merge cache-state
                                {:control-set control-set :running true :current {:start-time start-time :bids bids}}))]
        (cache-when-complete control-set)))))

(defn get-cached-validation-data [control-set source]
  (let [cached-data (mq/with-collection
                      (ds/get-db "soda-analytics") "validation-table-cache"
                      (mq/find {:meta.control-set control-set :meta.source source})
                      (mq/sort (array-map :_id -1))
                      (mq/limit 1))]
    (if (not-empty cached-data)
      (dissoc (first cached-data) :_id)
      (do (timbre/warn (str "Did not find validation cache for control-set: " control-set " and source: " source "."))
          (get-validation-data control-set source)))))