(ns soda-jerk-ws.analytics.pipeline-health
  (:require [clj-time.core :as t]
            [monger.collection :as mc]
            [datasources.core :as ds]
            [clj-time.coerce :as tc]
            [clj-time.local :as l]
            [clojure.set :as sets]
            [clj-http.client :as client]
            [cheshire.core :as ch]
            [soda.jobs.rescheduling-utils :as sjru]
            [medley.core :as m]))


(def status-code {:ok      0
                  :warning 1
                  :error   2})

(defn since-date-time [] (t/with-time-at-start-of-day (l/local-now)))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;        publication issues       ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(def supported-universe-schemas #{"corp-schema" "mbs-schema" "muni-schema"
                                  "govt-schema" "treasury-schema"})

(def publication-deadline-UTC-hr 13)                        ;hour of day, UTC  (7 am Boise time)

(defn todays-publication-issues []
  (let [base-query {:job-def.type             "daily-publication"
                    :job-def.publication-type "universe"}
        latest-by-schema (->> (assoc base-query :completed-at {"$gte" (tc/to-date (since-date-time))})
                              (mc/find-maps (ds/get-db "soda_configs") "job_history")
                              (group-by (comp :schema :job-def))
                              (map (comp (partial apply max-key (comp tc/to-long tc/from-date :completed-at)) second)))]
    {:did-not-run (sets/difference supported-universe-schemas (into #{} (map (comp :schema :job-def) latest-by-schema)))
     :errors      (filter :error latest-by-schema)
     :empty-files (filter (comp #(and % (zero? %)) :num-records :output) latest-by-schema)
     :unscheduled (sets/difference supported-universe-schemas
                                   (->> base-query
                                        (mc/find-maps (ds/get-db "soda_configs") "queue")
                                        (map (comp :schema :job-def))
                                        (into #{})))}))


(defn publication-issues-summary [& [issues]]
  (as-> (or issues (todays-publication-issues)) x
        (update x :errors (partial map (comp :schema :job-def)))
        (update x :empty-files (partial map (comp :schema :job-def)))
        (filter (comp seq second) x)
        (into {} x)))


(defn publication-status []
  (let [issues-summary (publication-issues-summary)]
    (-> {:timestamp     (tc/to-date (t/now))
         :status_code   (if (empty? issues-summary)
                          (status-code :ok)
                          (if (< (t/hour (t/now)) publication-deadline-UTC-hr) (status-code :warning)
                                                                               (status-code :error)))
         :status_msg    (if (empty? issues-summary) "soda_file_publication looks good" "file publication issues, see issues summary for details")
         :issue-summary (or (not-empty issues-summary) [])})))


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;        Rules Violations          ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


(defn rules-status []
  (let [rules (-> "http://dev-sodaqa-intake-group1-app1:1441/rules-violations/rules-by-categories/Schema" client/get :body (ch/parse-string keyword))
        violations (->> rules
                        (map (fn [{:keys [_id description]}]
                               [description (-> (str "http://dev-sodaqa-intake-group1-app1:1441/rules-violations/prod/rule-all/" _id)
                                                client/get
                                                :body
                                                (ch/parse-string keyword))]))
                        (filter (comp seq second))
                        (into {})
                        (m/map-vals count))]
    {:timestamp     (tc/to-date (t/now))
     :status_code   (if (empty? violations) (status-code :ok) (status-code :warning))
     :status_msg    (if (empty? violations) "SoDa data quality is okay" "Rule violations, see issue-summary for counts and the rules report itself for details")
     :issue-summary (or (not-empty violations) [])}))


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;      Miscellaneous checks        ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn can-mbs-status []
  (let [published? (pos? (mc/count (ds/get-db "soda_configs") "job_history" {:job-def.type       "publish-scraped-file"
                                                                             :published-files    {"$exists" true}
                                                                             :job-def.scraper-id "canadian-mbs-factors"
                                                                             :completed-at       {"$gt" (tc/to-date (t/first-day-of-the-month- (t/now)))}}))
        late? (t/after? (t/now) (t/with-time-at-start-of-day (sjru/nth-biz-day 7 (t/now))))]
    {:timestamp   (tc/to-date (t/now))
     :status_code (if (and late? (not published?)) (status-code :warning) (status-code :ok))
     :status_msg  (if (and late? (not published?)) "Canadian mbs data has not been published this month!"
                                                   "Canadian mbs data seems to be okay")}))
