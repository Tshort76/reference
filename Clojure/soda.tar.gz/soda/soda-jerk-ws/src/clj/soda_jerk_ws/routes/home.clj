(ns soda-jerk-ws.routes.home
  (:require [clojure.data.json :as json]
            [clojure.string :as str]
            [compojure.core :refer [ANY GET defroutes]]
            [doc-transforms.core :as doc-xforms]
            [doc-transforms.mindfood :as doc-xforms-mf]
            [enhanced-hickory.core :as ehc]
            [enhanced-hickory.util :as ehu]
            [environ.core :refer [env]]
            [hiccup.core :as h]
            [hiccup.element :as he]
            [hiccup.page :as hp]
            [hiccup.util :as hu]
            [html.utils :as html]
            [soda.data.file-system :as sdfs]
            [soda-jerk-ws.layout :refer [*app-context*]]
            [soda-jerk-ws.routes.overmind-html :as over-html]
            [ring.middleware.anti-forgery :refer [*anti-forgery-token*]]
            [soda-jerk-ws.routes.data-flows :as df]
            [edgar.debug-utils :as du]
            [edgar.html-utils :as edgar-html]
            ; [soda-jerk-ws.middleware]
            [soda.core :as soda]))

(defn home-page []
  (h/html
    [:head
     [:meta {:http-equiv :content-type :content "text/html; charset=UTF-8"}]
     [:meta {:name :viewport :content "width=device-width, initial-scale=1"}]
     [:div#title [:title "SoDa-Jerk-WS"]]]
    [:div#css]
     ;[:title "Soda-Jerk-WS"]

    [:body
     [:div#app
      [:div.alert.alert-info "Loading..."]]
     (hp/include-js
       "/assets/jquery/jquery.min.js"
       "/assets/bootstrap/js/bootstrap.min.js"
       "/assets/highlightjs/highlight.min.js"
       "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"
       "https://www.gstatic.com/charts/loader.js"
       "https://momentjs.com/downloads/moment.min.js" ;required for datetimepicker
       "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js" ;used for machine-history
       "/assets/visjs/vis.min.js"
       "https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js")

     (hp/include-css
       "/assets/bootstrap/css/bootstrap.min.css"
       "/assets/bootstrap/css/bootstrap-theme.min.css"
       "/assets/font-awesome/css/font-awesome.min.css"
       "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css"
       "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css"
       "/css/screen.css"
       "/css/overrides.css"
       "/assets/highlightjs/styles/agate.css"
       "/assets/visjs/vis.min.css"
       "https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css")
     (he/javascript-tag (str "var context = \"" *app-context* "\";"))
     (he/javascript-tag (str "var csrfToken = \"" *anti-forgery-token* "\";"))
     (hp/include-js "/js/soda_jerk_ws.js")]))

(defn format-list [list-string]
  (some-> list-string (str/split #",")))

(defn format-bool [bool-string]
  (when bool-string
    (case (str/lower-case bool-string)
      ("true" "t") true
      false)))

(defn request-dump [request]
  (h/html
    (for [[k v] request]
      [:p (str k ": " v)])))

(defn query-meta [{:keys [md5 filename]}]
  (when (or md5 filename)
    (let [query (cond-> {}
                        md5 (assoc :md5 md5)
                        filename (assoc :filename filename))]
      (sdfs/find-one-meta query true))))

(defn edgar-raw [filename]
  (some->> (sdfs/find-file {:filename filename} true)
           :input-stream
           slurp
           html/html-contents))

(defn edgar-enhik [filename max-page & [ids]]
  (let [max-page (soda/parse-long max-page)]
    (if max-page
      (some->> filename
               edgar-raw
               (#(ehc/html->enhik % :max-page max-page)))
      (some->> {:filename filename}
               (doc-xforms/mongo->transform :enhanced-hickory)
               :enhanced-hickory))))

(defn edgar-page [filename max-page & [ids]]
  (when-let [enhik (edgar-enhik filename max-page)]
    (ehc/enhik->html
      (cond-> enhik
        (seq ids) (ehu/add-highlights (format-list ids))))))

(defn edgar-json [filename max-page]
  (when-let [enhik (edgar-enhik filename max-page)]
    (json/write-str enhik)))

(defn muni-json [query max-page]
  (some->> query
           (doc-xforms/mongo->transform :mind-food)
           :mind-food
           doc-xforms-mf/enhik-mindfood
           json/write-str))

(defn edgar-10k-html [raw-text]
  (->> (edgar-html/submission-sections raw-text :xform-fn
         (fn [{:keys [section contents]}]
           (when (re-find #"^10-K$" section)
             (html/get-html contents))))
       (some identity)))


(defroutes
  home-routes
  (GET "/" [] (hu/with-base-url *app-context* (home-page)))
  (GET "/data-flow" [] (hu/with-base-url *app-context* (df/mermaid df/mermaid-graph1)))
  (GET "/function-chain" [] (hu/with-base-url *app-context* (df/mermaid df/mermaid-graph)))
  (GET "/job-chain" [] (hu/with-base-url *app-context* (df/mermaid df/job-graph)))
  (GET "/request-keys" request (str/join "\n" (keys request)))
  (GET "/request-dump" [] request-dump)
  (GET "/overmind/food/html" [filename md5 ids min-page max-page limit-context field-name cusip]
       (let [filename (not-empty filename)
             md5 (not-empty md5)
             ids (not-empty ids)]
         (hu/with-base-url *app-context*
           (when-let [{:keys [file-type mime-type] q-md5 :md5 q-filename :filename}
                      (query-meta {:md5 md5 :filename filename})]
             (cond
               (#{"edgar-prospectus"} file-type)
               (edgar-page (or filename q-filename) max-page ids)

               (#{"edgar-10k" "edgar-425" "edgar-8k" "edgar-15-12" "edgar-s4"} file-type)
               (some-> (cond filename {:filename filename}
                             md5 {:md5 (or md5 q-md5)}
                             :else nil)
                       (sdfs/find-file true)
                       :input-stream
                       slurp
                       ; edgar-html/submission-section-enhiks
                       ; (some (comp :ten-k :enhanced-hickory))
                       html/get-html
                       (ehc/html->enhik :max-page 200)
                       ehc/enhik->html)

               (or (#{"muni-jaeger" "canadian-analytics-data"} file-type)
                   (#{"application/pdf"} mime-type))
               (over-html/svg-doc (or md5 q-md5)
                                  {:min-page (soda/parse-long min-page)
                                   :max-page (soda/parse-long max-page)
                                   :limit-context? (format-bool limit-context)
                                   :ids (or (format-list ids)
                                            (over-html/get-ids (or md5 q-md5) (not-empty cusip) (not-empty field-name)))})

               :else nil)))))
  (GET "/overmind/food/raw" [filename md5 ids min-page max-page limit-context field-name cusip]
       (let [filename (not-empty filename)
             md5 (not-empty md5)
             ids (not-empty ids)]
         (hu/with-base-url *app-context*
           (when-let [{file-type :file-type q-md5 :md5 q-filename :filename}
                      (query-meta {:md5 md5 :filename filename})]
             (case file-type
               ; ("muni-jaeger" "canadian-analytics-data")
               ; (over-html/svg-doc (or md5 q-md5)
               ;                    {:min-page (soda/parse-long min-page)
               ;                     :max-page (soda/parse-long max-page)
               ;                     :limit-context? (format-bool limit-context)
               ;                     :ids (or (format-list ids)
               ;                              (over-html/get-ids (or md5 q-md5) (not-empty cusip) (not-empty field-name)))})

               ("edgar-prospectus")
               (edgar-raw (or filename q-filename))

               ("edgar-10k")
               (some-> (cond filename {:filename filename}
                             md5 {:md5 (or md5 q-md5)}
                             :else nil)
                       (sdfs/find-file true)
                       :input-stream
                       slurp
                       edgar-10k-html)

               nil)))))
  (GET "/overmind/food/json" [filename md5 min-page max-page]
       (when-let [{file-type :file-type q-md5 :md5 q-filename :filename :as query}
                  (query-meta {:md5 md5 :filename filename})]
         (case file-type
           ("muni-jaeger")
           (muni-json query max-page)

           ("edgar-prospectus")
           (edgar-json (or filename q-filename) max-page))))
  (GET "/overmind/food/edgar-candidates" [filename]
    (-> filename
        du/filename->sample-data
        du/data->options-html))

  ;(ANY "/repl1" []
  ;  :middleware [soda-jerk-ws.middleware/drawbridge-handler])
  ;(ANY "/repl2" request (soda-jerk-ws.middleware/drawbridge-handler request))

  ;; old endpoints
  (GET "/edgar-prospectus/:filename" [filename ids max-page]
       (hu/with-base-url *app-context* (edgar-page filename max-page ids)))
  (GET "/overmind/html/md5/:md5" [md5]
       (hu/with-base-url *app-context* (over-html/svg-doc md5)))
  (GET "/overmind/html/md5/:md5/page/:page" [md5 page ids]
       (hu/with-base-url *app-context* (over-html/svg-page md5 (soda/parse-long page) (format-list ids))))
  (GET "/overmind/html/md5/:md5/context" [md5 ids cusip field-name]
       (let [id-list (or (format-list ids)
                         (over-html/get-ids md5 cusip field-name))]
         (when (seq id-list)
           (->> id-list
                (over-html/svg-context md5)
                (hu/with-base-url *app-context*))))))
