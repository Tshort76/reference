(ns soda-jerk-ws.routes.data-flows
  (:require [hiccup.element :as he]
            [hiccup.page :as hp]
            [hiccup.core :as h]
            [ring.middleware.anti-forgery :refer [*anti-forgery-token*]]
            [soda-jerk-ws.layout :refer [*app-context*]]))

(def mermaid-graph
  "graph LR;
  File-->|\"(uploader.core/upload)\"|A;
  A-->|\"(uploader.core/upload-file)\"|B;
  B-->|\"(uploader.core/enqueue)\"|C;
  C-->|\"(uploader.core/enqueue-job)\"|X;
  Manual-->|\"(uploader.core/reprocess-file)\"|B;")

(def mermaid-graph1
  "graph TB;
  File-->|muni|*.pdf;
  *.pdf-->mind-food;
  File-->|corp|*.sgml;
  *.sgml-->|find-html|hik;
  *.sgml-->|find-text|hik;
  hik-->|add-ids|enhik;
  enhik-->tokenvec;
  tokenvec-->|regisector|feature-maps;
  feature-maps-->|mongo|soda-raw/jaegers")

(def job-graph
  "graph LR
   subgraph upload
   File-->|\"(uploader.core/upload)\"|A
   A-->|\"(uploader.core/upload-file)\"|B[\"R (abc) functions\"]
   B-->|\"(uploader.core/enqueue)\"|C
   C-->|\"(uploader.core/enqueue-job)\"|X
   Manual-->|\"(uploader.core/reprocess-file)\"|B
   end
   subgraph parse-file
   A[\"{{:keys [file-type md5]} :job-def bid :bid}\"]-->b2
   end
   subgraph :supplemental
   b1-->b2
   end
   subgraph :jaegerize
   b1-->b2
   end
   subgraph migrate-jaeger-docs
   b1-->b2
   end
   subgraph make-mindfood
   b1-->b2
   end
   subgraph :normalize
   b1-->b2
   end
   subgraph scrape
   b1-->b2
   end
   subgraph get-index-rates
   b1-->b2
   end
   c1-->a2")

(defn mermaid [chart]
  (h/html
    [:head
     [:meta {:http-equiv :content-type :content "text/html; charset=UTF-8"}]
     #_[:meta {:name :viewport :content "width=device-width, initial-scale=1"}]
     [:title "The tree of dependencies"]]
    [:body
     (hp/include-js
       "/assets/jquery/jquery.min.js"
       "/assets/bootstrap/js/bootstrap.min.js"
       "/assets/mermaid/dist/mermaid.js")
     (hp/include-css
       "/assets/bootstrap/css/bootstrap.min.css"
       "/assets/bootstrap/css/bootstrap-theme.min.css"
       "/assets/font-awesome/css/font-awesome.min.css"
       "/css/screen.css"
       "/assets/highlightjs/styles/agate.css"
       "/assets/mermaid/dist/mermaid.css")
     (he/javascript-tag (str "var context = \"" *app-context* "\";"))
     (he/javascript-tag (str "var csrfToken = \"" *anti-forgery-token* "\";"))
     (he/javascript-tag "mermaid.initialize({startOnLoad:true, useMaxWidth:true})")

     ;Why is this taking up so much space?
     [:div#centered-wrapper {:style "text-align: center"}
      [:h1 "Dependency Tree"]
      [:hr]
      [:div.mermaid {:style "display:inline-flex;border-style:solid;border-color:#000000;width:70%;height:80%;border-width:1px;"} chart]
     ;(hp/include-js "/js/soda_jerk_ws.js")
      ]]))
