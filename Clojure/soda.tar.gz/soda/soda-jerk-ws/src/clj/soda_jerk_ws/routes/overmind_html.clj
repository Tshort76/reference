(ns soda-jerk-ws.routes.overmind-html
  (:require [soda-jerk-ws.mind-food.html-conversion :as mfh]
            [soda.data.core :as sdc]
            [doc-transforms.core :as dtc]
            [jaegers.stats :as stats]
            [clojure.string :as str]))

(sdc/defcon "soda-raw" "jaegers" :updatable true)

(defn ids->color-map [ids]
  (when ids
    {"#fb0" ids}))

(defn svg-doc
  ([md5]
   (-> md5
       dtc/lazy-food
       mfh/->svg-html))
  ([md5 {:keys [min-page max-page limit-context? ids]}]
   (-> md5
       (dtc/lazy-food
        :first-page min-page
        :last-page max-page)
       (mfh/->svg-html
        :color-ids-map (when ids (ids->color-map ids))
        :filter-to-ids (when (and ids limit-context?) (some? ids))))))

(defn svg-page [md5 page ids]
  (-> md5
      (dtc/lazy-food
       :first-page page
       :last-page page)
      (mfh/->svg-html
       :color-ids-map (ids->color-map ids))))

(defn svg-context [md5 ids]
  (-> md5
      dtc/lazy-food
      (mfh/->svg-html
       :color-ids-map (ids->color-map ids)
       :filter-to-ids (some? ids))))

(def revert-field-name
  (let [revert-map (reduce (fn [m [k v]]
                             (assoc m v k))
                           {} stats/api-rename-map)]
    (fn [field]
      (let [field (keyword field)]
        (revert-map field field)))))

(defn get-ids [md5 cusip field-name]
  (when (and md5 cusip field-name)
    (let [field (revert-field-name field-name)]
      (->> (find-jaegers
            {:meta.md5 md5
             :jaeger-doc.cusip-9.value cusip
             :meta.outdated? nil}
            {:_id false
             (str "jaeger-doc." (name field) ".ids") true})
           :jaeger-doc
           field
           :ids
           (keep (->> (partial re-matches #"\d+_\d+_\d+")
                      (partial keep)
                      (comp seq)))
           (sort-by (fn [ids]
                      (-> ids
                          first
                          (str/split #"_")
                          ((juxt first last second)))))
           first))))
