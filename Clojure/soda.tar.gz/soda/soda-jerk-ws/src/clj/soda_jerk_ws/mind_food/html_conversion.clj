(ns soda-jerk-ws.mind-food.html-conversion
  (:require [clojure.string :as str]
            [clojure.walk :as walk]
            [hiccup.core :as hiccup]
            [jaegers.utils :as ju]))

(def ^:dynamic page-height 800)
(def ^:dynamic page-width 640)

(def comp->color
  {:table        "magenta"
   :table-column "magenta"
   :superscript  "cyan"
   :text         "blue"
   :title        "darkgray"
   :side-by-side "orange"})

(defn- clean-number [n]
  (-> n (* 10) (quot 1) (/ 10)))

(defn- calc-y-pos [page y]
  (+ y (* page-height (dec page))))

(defn- vals-page-number [v]
  (-> v
      flatten
      first
      :page-number))

(defn- mf->svg [{:keys [vals type x0 x1 y0 y1]}]
  (conj
   (->> vals
        flatten
        (mapv (fn [{:keys [x y font-size font text id italic? bold? superscript? width height page-number]}]
                [:text (cond-> {:id (str id)
                                :x (clean-number x)
                                :y (clean-number (calc-y-pos page-number y))
                                :font-size (if (and font-size (< font-size 30))
                                             (int font-size)
                                             10)
                                :height (clean-number height)
                                :lengthAdjust "spacingAndGlyphs"
                                :textLength (clean-number width)}
                               italic? (assoc :font-style :italic)
                               bold? (assoc :font-weight :bold)
                               superscript? (assoc :baseline-shift :super))
                 text])))
   [:rect {:x (clean-number x0)
           :y (clean-number (calc-y-pos (vals-page-number vals) y0))
           :width (clean-number (- x1 x0))
           :height (clean-number (- y1 y0))
           :style {:stroke (comp->color (keyword type) "blue")
                   :fill-opacity 0}}]))

(defn to-hiccup [objects]
  (let [min-page (if (seq objects)
                   (->> objects
                        first
                        :vals
                        vals-page-number
                        dec)
                   0)]
    (->> objects
         (walk/postwalk
          (fn [x] (if (:page-number x)
                    (update x :page-number - min-page)
                    x)))
         (mapcat mf->svg))))

(defn- to-style-string [object]
  (if (:style object)
    (update object :style #(str/join ";" (mapv (fn [[k v]] (str (name k) ":" v)) (seq %))))
    object))

(defn- highlight-map [color-ids-map]
  (reduce (fn [m [c ids]]
            (reduce (fn [m2 id]
                      (assoc m2 id c))
                    m ids))
          {} color-ids-map))

(defn- highlight-rect [[_ {:keys [x y textLength height font-size]} text] color]
  [:rect {:x x
          :y (- y (or height font-size))
          :width textLength
          :height height
          :style {:stroke color
                  :fill color}}])

(defn- make-style-fn [color-ids-map]
  (let [hlm (highlight-map color-ids-map)]
    (fn [element]
      (let [color (-> element second :id hlm)
            new-element (update element 1 dissoc :height)]
        (if color
          [(highlight-rect element color)
           new-element]
          [new-element])))))

(defn- count-pages [objects]
  (if-let [pages (seq (map :page-number objects))]
    (inc (- (apply max pages)
            (apply min pages)))
    0))

(defn- id->y-pos [id]
  ((let [[p _ y] (ju/id->vec id)]
     (when (and p y)
       (calc-y-pos p y)))))

(defn- y-range [color-ids-map]
  (let [ys (->> color-ids-map
                vals
                flatten
                (keep id->y-pos))]
    (when (seq ys)
      [(max (- (apply min ys) 100) 0)
       (+ (apply max ys) 100)])))

(defn- within-range [min-y max-y element]
  (if-let [y (-> element second :y)]
    (when (and (< y max-y)
               (> y min-y))
      (update-in element [1 :y] - min-y))
    (let [y (-> element second :y1)]
      (when (and (< y max-y)
                 (> y min-y))
        (-> element
            (update-in [1 :y1] - min-y)
            (update-in [1 :y2] - min-y))))))

(defn- draw-compass [min-y max-y]
  (when (and min-y max-y)
    (let [y-scale (/ page-height 40)
          p1 (quot min-y page-height)
          ps (-> max-y
                 (quot page-height)
                 inc
                 (- p1))]
      (concat
       [[:rect {:x 1
                :y 1
                :width 38
                :height (+ 38 (* 40 ps))
                :style {:stroke "#fff"
                        :fill "#fff"}}]
        [:rect {:x 1
                :y (quot (rem min-y page-height) y-scale)
                :width 38
                :height (quot (- max-y min-y) y-scale)
                :style {:fill "#8f8"}}]]
       (apply concat
         (for [p (range ps)]
           [[:rect {:x 1
                    :y (+ 1 (* 40 p))
                    :width 38
                    :height 38
                    :style {:stroke "#444"
                            :fill-opacity 0}}]
            [:text {:x 2
                    :y (+ 20 (* 40 p))
                    :font-size 16
                    :style {:fill "#444"}}
             (+ 1 p p1)]]))))))

(defn remove-text-height [element]
  (if (= :text (first element))
    (update element 1 dissoc :height)
    element))

(defn make-svg-groups [elements]
  (->> elements
       (filter (comp (some-fn :font-size :font-style :font-weight) second))
       (group-by (comp #(select-keys % [:font-size :font-style :font-weight]) second))
       (map (fn [[attrs elems]]
              (->> elems
                   (map #(update % 1 dissoc :font-size :font-style :font-weight))
                   (apply vector :g attrs))))
       (concat (->> elements
                    (filter (comp not (some-fn :font-size :font-style :font-weight) second))))))

(defn ->svg-html [objects & {:keys [color-ids-map show-component-boxes filter-to-ids]}]
  (let [[view-min-y view-max-y] (when (and filter-to-ids)
                                  (y-range color-ids-map))
        total-pages (count-pages objects)
        max-x (reduce max 0 (map :x1 objects))
        min-x (reduce min max-x (map :x0 objects)) ;; used to determine the right margin
        max-y (reduce max 0 (map :y1 objects))
        min-y (reduce min max-y (map :y0 objects)) ;; used to determine the bottom margin
        y? (and view-min-y view-max-y)]
    (binding [page-width (+ max-x min-x)
              page-height (+ max-y min-y)]
      (hiccup/html
       [:html
        [:head
         [:title "Sample Prospectus"]]
        [:body
         [:svg
          {:width "100%"
           :style (str "height:auto;min-width:" page-width "px;")
           :viewBox (str "0 0 " page-width " "
                         (if y?
                           (- view-max-y view-min-y)
                           (* page-height total-pages)))}
          (->> objects
               to-hiccup
               ((if show-component-boxes
                  identity
                  (partial filter #(= :text (first %)))))
               (mapcat (make-style-fn color-ids-map))
               (concat (for [p (-> total-pages inc range)
                             :let [y (* p page-height)]]
                         [:line {:x1 0 :x2 page-width
                                 :y1 y :y2 y
                                 :stroke-width 4 :stroke "#444"}]))
               ((if y?
                  (partial keep (partial within-range view-min-y max-y))
                  identity))
               (mapv remove-text-height)
               make-svg-groups
               (#(concat % (draw-compass view-min-y view-max-y)))
               (walk/postwalk to-style-string)
               (apply vector :g {:font-family "serif"}))]]]))))
