(ns soda-jerk-ws.handler
  (:require [compojure.core :refer [routes wrap-routes]]
            [compojure.route :as route]
            [environ.core :refer [env]]
            [soda-jerk-ws.layout :refer [error-page]]
            [soda-jerk-ws.middleware :as middleware]
            [soda-jerk-ws.routes.home :refer [home-routes]]
            [soda-jerk-ws.services.core :refer [service-routes]]
            [selmer.parser :as parser]
            [taoensso.timbre :as timbre]
            [analytics.metrics :as metrics]
            [soda-common.logger :as soda-logger]
            [soda-jerk-ws.analytics.core :as ac]))

(def uploader-state (atom {}))

(defn init
  "init will be called once when
   app is deployed as a servlet on
   an app server such as Tomcat
   put any initialization code here"
  []
  (soda-logger/init-logging! "com.clearwateranalytics.soda-jerk-ws")
  (if (env :dev) (parser/cache-off!))
  (timbre/info (str "\n-=[soda_jerk_ws started successfully" (when (env :dev) " using the development profile") "]=-"))
  (ac/startup))

(defn destroy
  "destroy will be called when your application
   shuts down, put any clean up code here"
  []
  (swap! uploader-state assoc :running false)
  (timbre/info "soda_jerk_ws is shutting down...")
  (timbre/info "shutdown complete!"))

;http://blog.darevay.com/2010/11/compojure-the-repl-and-vars/ - This explains using
;vars/#' vs calling out the field directly.
(def app-routes
  (routes
    (wrap-routes #'service-routes (comp metrics/wrap-api-metrics soda-logger/log-trace-wrapper))
    (wrap-routes #'home-routes (comp metrics/wrap-api-metrics soda-logger/log-trace-wrapper middleware/wrap-csrf))
    (route/not-found
      (:body
        (error-page {:status 404
                     :title  "page not found"})))))

(def app (when-not *compile-files* (middleware/wrap-base #'app-routes)))
