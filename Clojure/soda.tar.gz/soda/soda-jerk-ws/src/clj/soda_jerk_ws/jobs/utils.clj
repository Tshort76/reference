(ns soda-jerk-ws.jobs.utils
  (:require [medley.core :as medley]
            [monger.collection :as mc]
            [monger.operators :refer :all]
            [monger.query :as mq]
            [monger.result :as mr]
            [datasources.core :as dsc]
            [clj-time.core :as t]
            [clj-time.coerce :as tc])
  (:import (java.util Date)))

(defn get-db []
  (dsc/get-db "soda_configs"))

(defn post-queries [host queries]
  (mr/acknowledged? (mc/update-by-id (get-db) "soda_jobs" host {$set {:queries queries}})))

(defn post-consumers [host num-consumers]
  (mr/acknowledged? (mc/update-by-id (get-db) "soda_jobs" host {$set {:num-consumers num-consumers}})))

(defn post-action [action host]
  (mr/acknowledged? (if host
                      (mc/update-by-id (get-db) "soda_jobs" host {$set {:action action}})
                      (mc/update (get-db) "soda_jobs" {:action {$exists true}} {$set {:action action}} {:multi true}))))

(defn host-status [active?]
  (let [hosts (mc/find-maps (get-db) "soda_jobs" {:_id {$ne "configs"}})]
    (map (partial merge {:queries ["{}"]})
         (if active?
           (filter (fn [{:keys [last-heartbeat]}]
                     (t/after? (and last-heartbeat
                                    (tc/to-date-time last-heartbeat))
                               (t/minus (t/now) (t/minutes 1)))) hosts)
           hosts))))

;;;;;;;;;;;;;;;  Job level support functions  ;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defn format-job [{:keys [name job-def output error start-times error-time completed-at]}]
  (-> (merge {:name name
              :status (if (or error output) (if error "ERRORED" "finished") (if start-times "started" "queued"))
              :end-time (or error-time completed-at)
              :start-time (:time (last start-times))}
             job-def output)
      (update :min-id #(if % (.toHexString %)))
      (update :max-id #(if % (.toHexString %)))))

(defn trace-by-bid [bid & [{:keys [show-job-docs?]}]]
  (let [enqueued (mc/find-maps (get-db) "queue" {:bid bid})
        finished (mc/find-maps (get-db) "job_history" {:bid bid})]
    (cond-> {:num-enqueued-jobs (count enqueued)
             :num-finished-jobs (count finished)
             :num-running-jobs  (count (filter :start-times enqueued))}
            show-job-docs? (assoc :job-docs (concat enqueued finished)))))

(defn explode-job [job]
  (let [instance-data (:start-times job)
        base-job (dissoc job :start-times :completed-at :output)
        unfinished-jobs (map #(assoc base-job :started-at (:time %)
                                              :host (:host %)
                                              :worker (:worker %))
                             (butlast instance-data))
        finished-job (-> job
                         (dissoc :start-times)
                         (assoc :started-at (-> instance-data last :time)
                                :host (-> instance-data last :host)
                                :worker (-> instance-data last :worker)))]
    (conj (vec unfinished-jobs) finished-job)))

(defn limited-find-maps [db coll query limit]
  (mq/with-collection db coll (mq/find query) (mq/limit limit)))

(defn jobs-between
  "Returns all jobs that were running on a host between start and end times (millis since epoch).
   If end time is in the future, also return currently running jobs."
  [start & {:keys [end limit]}]
  (let [still-running (future (if (or (nil? end) (> end (System/currentTimeMillis)))
                                (mc/find-maps (get-db) "queue" {:run-after {"$gt" (Date.)} :start-times {"$exists" true}})
                                []))
        mongo-date-range-query (if end {"$lt" (Date. ^long end) "$gt" (Date. ^long start)}
                                       {"$gt" (Date. ^long start)})
        started-within-query {:start-times {"$elemMatch" {:time mongo-date-range-query}}}
        finished-within-query {:completed-at mongo-date-range-query}
        completed (future (limited-find-maps (get-db) "job_history" {"$or" [started-within-query finished-within-query]} limit))
        all-jobs (vec (medley/distinct-by :_id (concat @completed @still-running)))] ;drop duplicate docs if job completed between queries
    (->> all-jobs
         (reduce #(concat %1 (explode-job %2)) [])
         ;group-by host and worker
         (reduce (fn [m {:keys [host worker] :as job}]
                   (update-in m [host worker] #(conj (or % []) job)))
                 {}))))
