(ns soda-jerk-ws.services.surveyor
  "Surveyor interop endpoints"
  (:require [clj-time.coerce :as tmc]
            [clj-time.core :as tm]
            [clojure.string :as string]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [surveyor-interop.enqueue-questions :as questions]
            [surveyor-interop.ml.enqueue-ml-questions :as enqueue]
            [surveyor-interop.ml.negative-samples :as neg]
            [surveyor-interop.ml.process-results :as results]
            [surveyor-interop.ml.seed-ml-questions :as seed]
            [pipeline.surveyor-questions :as sq]
            [compojure.api.sweet :refer :all]))

(def services
  (context "/surveyor" []
    {:tags ["surveyor interop"]}

    (POST "/ml-question/enqueue-batch" []
      :summary "Enqueues a batch of Surveyor questions from a random sample of SODA files"
      :query-params [file-type :- (s/->EnumSchema (into (sorted-set) (keys questions/file-type->fields)))
                     {as-of-date :-
                      (describe s/Inst "End date of rolling time window. yyyy-MM-dd format, defaults to today")
                      (tmc/to-date (tm/today-at 0 0))}]
      (ok {:question-ids (enqueue/bulk-ask-questions! file-type as-of-date)}))

    (POST "/ml-question/seed-answers" []
      :summary "Seeds Surveyor questions with answers from the prediction pipeline"
      :query-params [{question-id :- (describe s/Str "Surveyor question ID") nil}
                     {tags :- (describe s/Str "Comma-separated list of tags to filter results") nil}
                     {use-all-components? :- (describe Boolean "Use seeds from all document components, or only from filtered components. Defaults to false") false}]
      (cond
        question-id (ok (seed/seed-question! question-id {:use-all-components? use-all-components?}))
        tags (ok (seed/seed-questions! (string/split tags #",\s*") {:use-all-components? use-all-components?}))
        :else (bad-request)))

    (POST "/ml-question/seed-with-negative-samples" []
      :summary "Seeds Surveyor questions with negative samples (\"other\") from the prediction pipeline"
      :query-params [{question-id :- (describe s/Str "Surveyor question ID") nil}
                     {tags :- (describe s/Str "Comma-separated list of tags to filter results") nil}
                     {use-all-components? :- (describe Boolean "Use seeds from all document components, or only from filtered components. Defaults to false") false}]
      (try
        (cond
          question-id (ok (neg/seed-question-with-negative-samples! question-id {:use-all-components? use-all-components?}))
          tags (ok (neg/seed-questions-with-negative-samples! (string/split tags #",\s*") {:use-all-components? use-all-components?}))
          :else (bad-request))
        (catch Exception e
          (not-found {:reason (str e)}))))

    (POST "/ml-question/process-results" []
      :summary "Converts Surveyor results into machine learning truth data"
      :query-params [tags :- (describe s/Str "Comma-separated list of tags to filter results")
                     {only-new? :- (describe Boolean "Only process new or updated results. Defaults to true") true}]
      (let [tags (string/split tags #",\s*")]
        (if only-new?
          (ok (results/process-results! tags results/new?))
          (ok (results/process-results! tags identity)))))

    (POST "/process/surveyor-result" []
      :query-params [question-id :- s/Str]
      :summary "Prepare surveyor results into training data that is usable by the ml-pipeline"
      (ok (sq/process-surveyor-result question-id)))

    (GET "/source-fields" []
      :summary "Returns a list of maps containing source, file-type, and fields."
      (ok (questions/source-fields)))))