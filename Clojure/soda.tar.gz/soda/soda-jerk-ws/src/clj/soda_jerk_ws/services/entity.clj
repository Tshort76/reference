(ns soda-jerk-ws.services.entity
  (:require [aggregators.entity.name-match :as nm]
            [aggregators.entity.security-issuer :as si]
            [datasources.core :as ds]
            [monger.collection :as mc]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.data.util :as util]
            [soda.jobs.job-defs :as jd]
            [soda.jobs.utils :as jutils]
            [compojure.api.sweet :refer :all]))

(def services
  (context "/entity" []
    {:tags ["Entity"]}

    (POST "/rebuild-parent-cik-universe" []
      :summary "Schedules a job to rebuild the cik to parent cik universe"
      (ok (jutils/enqueue-job (jd/create-cik-to-parent-cik-universe))))

    (POST "/rerun/aggregation" []
      :summary "Rerun aggregation for legal entity identified by cik or lei."
      :query-params [{cik :- s/Int nil}
                     {lei :- s/Str nil}]
      (if-not (or cik lei)
        (bad-request "cik or lei is required.")
        (let [ids (->> {:cik cik :lei lei} (filter (fn [[_ v]] v)) (mapv (fn [[k v]] (hash-map k v))))]
          (if-let [existing-entities (seq (mc/find-maps (ds/get-db "soda") "entity" {"$or" ids}))]
            (ok (->> existing-entities
                     (map (fn [{{:keys [input-normalized-entity]} :meta}]
                            {:meta {:input-normalized-entity input-normalized-entity}}))
                     (map (fn [m] (jd/aggregate-entity m true true)))
                     (map jutils/enqueue-job)
                     (mapv util/fix-ids)))
            (ok "No existing entities with those identifiers.")))))

    (GET "/by-name" []
      :summary (str "Given a legal entity name, and an id-type to use as source to match against, find the best "
                    "matching node, as well as the aggregated entity document that matches that id, if any exists. "
                    "Optionally pass a custom threshold, which short circuits the full search as soon as one match is "
                    "found within the given threshold.")
      :query-params [{name :- (describe s/Str "Name to fuzzy match against existing legal entity records.")
                      nil}
                     {match-using :- (describe (s/->EnumSchema nm/id-types)
                                       "Identifier type source to use as name match target. Default: lei")
                      :lei}
                     {threshold :- (describe s/Num
                                     (str "Optional threshold [0.0, 1.0] to use rather than the identifier defaults "
                                          "of (lei/cik: " nm/MAX-DISTANCE ", cusip-6: " nm/CUSIP-6-MAX-DISTANCE " "))
                      nil}]
      (cond
        (empty? name) (bad-request "name is required")
        (and threshold (or (< threshold 0.0) (< 1.0 threshold))) (bad-request "threshold must be in range [0.0, 1.0]")
        :else (let [final-threshold (or threshold (nm/max-distance match-using))]
                (when-let [{id match-using :as match-node} (nm/find-first-by-name match-using final-threshold name)]
                  (let [entity-record (mc/find-one-as-map (ds/get-db "soda") "entity"
                                                          {(if (= :cusip-6 match-using) :cusip-6s match-using) id})]
                    (ok (assoc {} :entity-record entity-record :match-node match-node)))))))

    (POST "/security-link/override" []
      :summary (str "Enter mapping of security ($id-type $id) -> entity ($id-type $id) pair for security aggregation "
                    "to use when finding a linked entity. If $force, will override any existing entry for security "
                    "($id-type $id). Optionally pass jira case, for audit trail of entry.")
      :query-params [{entity-id :- (describe s/Str "Entity identifier.")
                      nil}
                     {entity-id-type :- (describe (s/->EnumSchema nm/id-types) "Type of entity identifier.")
                      :lei}
                     {security-id :- (describe s/Str (str "Id of security to link to above entity. "
                                                          "Will re-aggregate all securities after entry. Required."))
                      nil}
                     {security-id-type :- (describe (s/->EnumSchema #{:cusip-6})
                                            "Type of security identifier. Required.")
                      :cusip-6}
                     {force :- (describe s/Bool "If entry for security-cusip-6 exists, overwrite it? Default false.")
                      false}
                     {jira-case :- (describe s/Str
                                     "Jira case where investigation for this override is documented. Optional.")
                      nil}]
      (let [sid (not-empty security-id)
            sid-type (keyword security-id-type)]
        (if-not (and sid-type sid)
          (bad-request {:reason "security-cusip-6 and id must be not empty."})
          (try (ok (si/add-override! {:security-id sid
                                      :security-id-type sid-type
                                      :entity-id (not-empty entity-id)
                                      :entity-id-type (keyword entity-id-type)
                                      :meta {:override? true :jira-case jira-case}}
                                     force))
               (catch Exception e
                 (bad-request {:reason (.getMessage e) :ex-data (ex-data e)}))))))))