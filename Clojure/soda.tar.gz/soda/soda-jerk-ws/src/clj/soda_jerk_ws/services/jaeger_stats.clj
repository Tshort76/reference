(ns soda-jerk-ws.services.jaeger-stats
  (:require [clojure.string :as str]
            [jaegers.aggregator :as agg]
            [jaegers.cusip-linking.core :as clc]
            [jaegers.edgar.prospectus.core :as edgar]
            [jaegers.md5-control-sets :as csets]
            [jaegers.muni.core :as muni]
            [jaegers.oracle :as oracle]
            [jaegers.soda-pipe :as jpipe]
            [jaegers.stats :as jstats]
            [ml.predictions :as predictions]
            [non-soda-sources.core :as nsc]
            [non-soda-sources.sources :as srcs]
            [non-soda-sources.utils :as nssu]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.data.core :refer [defcon]]
            [compojure.api.sweet :refer :all]))

(defcon "soda-raw" "testOverrides")

(defn all-jaeger-keys []
  (set (concat (keys muni/jaeger-graph) (keys edgar/jaeger-graph))))

(def endpoints
  (context "/api/jaeger" []
    {:tags ["jaeger"]}

    (GET "/stats" []
      :query-params [control-name :- (s/->EnumSchema (apply sorted-set (keys csets/control-sets)))]
      :return [{(s/optional-key :jaeger-doc) (s/maybe {s/Keyword s/Any})
                :meta {s/Keyword s/Any}
                s/Keyword s/Any}]
      :summary "Return the stats for all jaeger-docs."
      (ok (jstats/all-stats control-name)))

    (GET "/control-sets" []
      :return [s/Str]
      :summary "Returns all valid control sets."
      (ok (map name (keys csets/control-sets))))

    (GET "/lm-values" []
      :query-params [cusips :- s/Str]
      :summary "Returns the LM values for a set of cusips."
      (-> cusips
          (str/split #",")
          oracle/cusips->oracle-data
          ok))

    (POST "/refresh-cache" []
      :return s/Num
      :summary "Rebuild the LM oracle collection."
      (ok (count (oracle/refresh-cache))))

    (POST "/notarize-value" []
      :body-params [cusip :- s/Str
                    field :- s/Str
                    value :- s/Any]
      :return s/Num
      :summary "Sets the given value as the official valid solution for the given cusip and field."
      (ok (.getN (oracle/add-validation cusip field value))))

    (POST "/run-control-set" []
      :query-params [control-name :- (s/->EnumSchema (apply sorted-set (keys csets/control-sets)))
                     {starting-jaeger :- (s/->EnumSchema (apply sorted-set (all-jaeger-keys))) nil}
                     {priority :- (s/->EnumSchema (sorted-set "background" "foreground")) nil}
                     {out-date? :- Boolean false}
                     {api? :- Boolean false}
                     {run-cusipless? :- Boolean false}]
      :summary "Runs all the jaegers over the selected control set."
      (let [num-jobs (count (jpipe/write-data-via-queue control-name
                                                        :starting-jaeger starting-jaeger
                                                        :->api? api?
                                                        :priority priority
                                                        :out-date? out-date?
                                                        :run-cusipless? run-cusipless?))]
        (ok (str "Enqueued " num-jobs " jaegerize jobs."))))

    (POST "/run-md5" []
      :query-params [md5 :- s/Str
                     {starting-jaeger :- (s/->EnumSchema (apply sorted-set (all-jaeger-keys))) nil}
                     {priority :- (s/->EnumSchema (sorted-set "background" "foreground")) nil}
                     {out-date? :- Boolean false}
                     {api? :- Boolean false}
                     {run-cusipless? :- Boolean false}]
      :summary "Run jaegers on specified md5."
      (ok (jpipe/write-md5-via-queue md5
                                     :starting-jaeger starting-jaeger
                                     :->api? api?
                                     :priority priority
                                     :out-date? out-date?
                                     :run-cusipless? run-cusipless?)))

    (GET "/run-jaegers" []
      :query-params [md5 :- s/Str
                     data-type :- (s/->EnumSchema (apply sorted-set clc/find-possible-cusips-support))]
      :summary "Calculates the jaeger-doc for the given md5."
      (ok (agg/md5->cusip-linked-docs md5 data-type)))

    (GET "/run-prediction-pipeline" []
      :query-params [md5 :- s/Str
                     {use-retrieval? :- Boolean true}]
      :summary "Run the deep learning prediction pipeline on the specified md5."
      (try (ok (predictions/prediction-pipeline-by-query {:md5 md5} {:use-retrieval? use-retrieval?}))
           (catch Exception e
             (service-unavailable {:reason (str e)}))))

    (GET "/raw-extraction-tokens" []
      :query-params [md5 :- s/Str
                     {use-retrieval? :- Boolean true}]
      :summary "Run the deep learning prediction pipeline on the specified md5."
      (try (ok (predictions/raw-extraction-by-query {:md5 md5} {:use-retrieval? use-retrieval?}))
           (catch Exception e
             (service-unavailable {:reason (str e)}))))

    (POST "/extract-non-soda" []
      :query-params [md5 :- s/Str]
      :summary "Accepts an md5 and returns the extracted contents as the extraction endpoint."
      (let [file-type (keyword (:file-type (soda.data.file-system/find-one-meta {:md5 md5})))]
        (try (ok (nsc/extract-data {:md5 md5 :file-type file-type}))
             (catch Exception e
               (service-unavailable {:reason (str e)})))))

    (POST "/annotate-non-soda" []
      :query-params [md5 :- s/Str]
      :return s/Str
      :summary "Accepts an md5 and returns the surveyor highlighted url"
      (let [query (-> (soda.data.file-system/find-one-meta {:md5 md5})
                      (update :file-type keyword)
                      (select-keys [:md5 :file-type]))]
        (try (ok (nsc/highlighted-url query))
             (catch Exception e
               (service-unavailable {:reason (str e)})))))

    (POST "/classification-threshold" []
      :query-params [file-type :- (s/->EnumSchema (apply sorted-set (keys srcs/non-soda-file-type->fields)))
                     field :- s/Str
                     {threshold :- (describe s/Num "A number between 0.0 and 1.0") 0.8}]
      :summary "Set the minimum acceptable level of model confidence for a file-type/field combination
              (note: thresholds are cached for 5 minutes)"
      (ok {:num-thresholds-updated (.getN (nssu/set-prob-threshold file-type field threshold))}))))

(def endpoints-soda-api
  (context "/api/soda-api" []
    {:tags ["soda-api"]}

    (GET "/stats" []
      :query-params [control-name :- (s/->EnumSchema (apply sorted-set (keys csets/control-sets)))]
      :return [{(s/optional-key :jaeger-doc) (s/maybe {s/Keyword s/Any})
                :meta {s/Keyword s/Any}
                s/Keyword s/Any}]
      :summary "Return the stats for all soda docs."
      (ok (jstats/all-stats control-name :soda-api? true)))))