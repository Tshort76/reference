(ns soda-jerk-ws.services.relay
  (:require [clj-http.client :as http]
            [clojure.data.json :as json]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.data.source :as source]
            [compojure.api.sweet :refer :all]))

(defn- service->url [service]
  (when (= service "soda-api")
    (source/soda-api-base-url)))

(defn- request->response [request]
  (json/read-str (:body (http/get request))))

(defn relay [service query]
  (when (and service query)
    (let [url (service->url service)
          request (str url query)]
      (try
        (if-not url
          (throw (IllegalArgumentException. (str "not configured for service: " service)))
          (ok (request->response request)))
        (catch Exception e
          {:request   request
           :exception (select-keys (Throwable->map e) [:cause :data])})))))

(def services
  (context "/relay" []
    {:tags ["relay"]}

    (GET "/:service" []
      :summary "Relay for another service."
      :path-params [service :- (describe s/Str "remote service to use, eg: 'soda-api'")]
      :query-params [{query :- (describe s/Str "GET query at remove service, eg: 'security/cusip/3133T1XW7?view=sourced'") ""}]
      (relay service query))))