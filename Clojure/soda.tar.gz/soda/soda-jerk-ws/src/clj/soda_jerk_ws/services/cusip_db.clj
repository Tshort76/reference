(ns soda-jerk-ws.services.cusip-db
  (:require [aggregators.cusip-db-agg :as cdb]
            [compojure.core :as cc]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [util.auth.middleware :as auth]
            [util.auth.heimdall :as heimdall]
            [compojure.api.sweet  :refer :all]))

(def end-points
  (context "/cusip-db" []
    {:tags       ["cusip-db"]
     :middleware [#(cc/wrap-routes % (auth/create-auth-middleware #{heimdall/SODA_ADMIN heimdall/SODA_CUSIPDB}))]}

    (GET "/cusip/:cusip" []
      :return (s/maybe {s/Keyword s/Any})
      :path-params [cusip :- s/Str]
      :summary "Returns all cusip-db security information for the specified cusip-9."
      (ok (first (cdb/cusip-db :issue {:cusips [cusip]}))))

    (GET "/cusip-6/:cusip-6" []
      :return (s/maybe {s/Keyword s/Any})
      :path-params [cusip-6 :- s/Str]
      :summary "Returns all cusip-db information for the specified cusip-6."
      (ok (first (cdb/cusip-db :issuances {:cusip-6s [cusip-6]}))))))
