(ns soda-jerk-ws.services.figi
  (:require [figi.ledger-processor :as flp]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [compojure.api.sweet :refer :all]))

(def services
  (context "/figi" []
    {:tags ["Figi Processing"]}

    (POST "/enqueue-ledger-processor" []
      :summary "Enqueues a ledger processor job, if one is not already running"
      (ok (flp/ensure-worker)))

    (POST "/enqueue-retry-job" []
      :summary "Queries figi for data on securities for which we have no data"
      (ok (flp/refresh-figis {:force-retry? true})))

    (POST "/schedule-refresh" []
      :summary "Schedules a self rescheduling job to refresh figi data"
      :query-params [period :- (describe s/Int "Rescheduling frequency, in days.")
                     time-of-day-utc :- (describe s/Int "Time of day at which the job should run")]
      (ok (flp/refresh-figis-periodically {:period-in-days period :utc-hour-of-day time-of-day-utc})))))