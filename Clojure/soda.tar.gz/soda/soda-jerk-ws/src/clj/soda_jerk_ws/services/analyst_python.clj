(ns soda-jerk-ws.services.analyst-python
  (:require [ring.util.http-response :refer :all]
            [ring.util.response :as resp]
            [schema.core :as s]
            ;[ring.swagger.json-schema :refer [describe]]
            ;[compojure.api.core :refer :all]
            [compojure.api.sweet :as cw]
            [environ.core :refer [env]]
            [clojure.java.io :as io]
            [clojure.string :as cs]
            [clojure.java.shell :as shell]
            [soda-jerk-ws.middleware :as middleware])
  (:import (java.io File)))

(def scripts-available
  (->> (File. "./resources/analyst_scripts")
       file-seq
       (map #(last (cs/split (str %) #"\\")))
       (filter #(re-find #"\.py$" %))
       (map #(cs/replace % #"\.py" ""))
       (into (sorted-set))))

(def end-points
  (cw/context "/analyst-script" []
    {:tags ["analyst-script"]}
    (cw/GET "/dir" []
      :return s/Any
      :summary "Returns all of the analyst scripts in the resources."
      (ok scripts-available))
    (cw/GET "/src/:script" []
      ;:middleware []
      :path-params [script :- (s/->EnumSchema scripts-available)]
      :return s/Any
      :summary "Return the specified script."
      (ok (slurp (str "./resources/analyst_scripts/" script ".py"))))
    (cw/GET "/txt/:script" []
      ;:middleware []
      :path-params [script :- (s/->EnumSchema scripts-available)]
      :query-params [{args :- (cw/describe s/Str "All command line args required of the script.") nil}]
      :return s/Any
      :summary "Runs and returns the specified script with the following args"
      (ok
        (:out
          (if-let [args (and args (cs/split args #" "))]
            (apply (partial shell/sh "python" (str "./resources/analyst_scripts/" script)) args)
            (shell/sh "python" (str "./resources/analyst_scripts/" script))))))
    (cw/GET "/svg/:script" []
      :path-params [script :- (s/->EnumSchema scripts-available)]
      :query-params [{args :- (cw/describe s/Str "All command line args required of the script.") nil}]
      :return s/Any
      :summary "Runs and returns the specified script with the following args"
      (-> (if-let [args (and args (cs/split args #" "))]
                  (apply (partial shell/sh "python" (str "./resources/analyst_scripts/" script ".py")) args)
                  (shell/sh "python" (str "./resources/analyst_scripts/" script ".py")))
          :out
          (io/input-stream)
          ok
          (assoc-in [:headers "Content-Type"] "image/svg+xml")))))