(ns soda-jerk-ws.services.publish
  (:require [clojure.string :as str]
            [clojure.java.io :as io]
            [publishers.core :as pb]
            [ring.util.http-response :refer :all]
            [ring.util.response :as response]
            [schema.core :as s]
            [soda-common.parsers :as scp]
            [soda-data-model.json-schema :as jsc]
            [taoensso.timbre :as log]
            [compojure.api.sweet :refer :all])
  (:import (java.io FileNotFoundException)))

(def notification-services
  (context "/notify" []
    {:tags ["notify"]}

    (POST "/:coll" []
      :path-params [coll :- String]
      :summary (str "Writes a message to Titan's hornet queue instance to alert them to "
                    "the fact that data is ready for consumption.")
      (ok (cond (= "instruments" coll)
                (do (log/debug "Notifying Titan of new canMBS instruments")
                    (pb/notify-by-type :canadian-mortgage-backed-security))

                (= "factors" coll)
                (do (log/debug "Notifying Titan of new canMBS factors")
                    (pb/notify-by-type :canadian-mortgage-backed-security-factors))

                :else
                (do (log/debug (str "Attempted to notify with the erroneous value : " coll))
                    "Error : Parameter must be 'factors' or 'instruments'"))))))

(def publication-services
  (context "/publish" []
    {:tags ["publish"]}

    (POST "/can-mbs" []
      :query-params [collection :- (s/->EnumSchema #{"instruments" "factors"})
                     notify? :- Boolean]
      :summary "Publishes SoDa data, in csv format, and optionally notifies Titan."
      (ok (cond (= "instruments" collection)
                (do (log/debug "Publishing instruments")
                    (pb/publish :canadian-mortgage-backed-security notify?))

                (= "factors" collection)
                (do (log/debug "Publishing factors")
                    (pb/publish :canadian-mortgage-backed-security-factors notify?))
                :else
                (do (log/debug (str "Attempted to publish with the erroneous value : " collection))
                    "Error : Parameter must be 'factors' or 'instruments'"))))

    (POST "/universe" []
      :query-params [schema :- (s/->EnumSchema (into #{} (keys jsc/security-tag-schemas)))
                     {notify-titan? :- Boolean false}]
      :summary "Publishes SoDa data, and optionally notifies Titan."
      (log/debug "Publishing " schema)
      (ok (pb/publish-data {:publication-type :universe :schema schema :notify-titan? notify-titan?})))

    (GET "/universe" []
      :query-params [published-filename :- s/Str]
      :summary "Retrieve previously published universe file, by file path"
      (let [titan-filepath (pb/get-titan-filepath)]
        (if-not (or (not titan-filepath)
                    (str/starts-with? published-filename titan-filepath))
          (bad-request {:reason "invalid filepath"})
          (try (with-open [is (io/input-stream published-filename)]
                 (-> (slurp is)
                     clojure.data.json/read-str
                     ok
                     (response/header "Content-Type" "application/json")
                     (response/header "Content-Disposition"
                                      (str "attachment; filename=" (last (str/split published-filename #"/"))))))
               (catch FileNotFoundException fnfe
                 (log/debug fnfe "universe file not found")
                 (bad-request {:reason "invalid filepath"}))))))

    (POST "/schedule/universe" []
      :query-params [schema :- (s/->EnumSchema (into #{} (keys jsc/security-tag-schemas)))
                     {notify-titan? :- Boolean false}
                     {at-hour-MST :- s/Int 2}
                     {at-minute :- s/Int 0}]
      :summary "Publishes universe data and schedules a recurring job."
      (ok (let [hour-UTC (mod (+ 7 at-hour-MST) 24)
                minute (str (mod at-minute 60))]
            (log/debug "Publishing universe data and scheduling a recurring job")
            (pb/schedule-daily-publication {:publication-type :universe :schema schema
                                            :notify-titan?    notify-titan?
                                            :tod (str hour-UTC ":" (scp/lpad minute))}))))

    (POST "/titan-13f" []
      :query-params [{notify-titan? :- Boolean false}]
      :summary "Publishes 13f data to Titan."
      (log/debug "Publishing Titan 13f data")
      (ok (pb/publish-data {:publication-type :titan-13f, :notify-titan? notify-titan?})))

    (POST "/schedule/titan-13f" []
      :query-params [{notify-titan? :- Boolean false}]
      :summary "Publishes 13f data to Titan and schedules a recurring job."
      (log/debug "Publishing 13f data and scheduling a recurring job")
      (ok (pb/schedule-daily-publication {:publication-type :titan-13f :notify-titan? notify-titan?})))

    (POST "/13f" []
      :query-params [bdt :- String
                     edt :- String]
      :summary "Publishes 13f data to smws."
      (log/debug "Publishing 13f data")
      (ok (pb/publish-data {:publication-type :13f :bdate bdt :edate edt})))

    (POST "/schedule/13f" []
      :summary "Publishes 13f data to smws and schedules a recurring job."
      (log/debug "Publishing 13f data and scheduling a recurring job")
      (ok (pb/schedule-daily-publication {:publication-type :13f :bdate "19700101" :edate "21000101"})))))