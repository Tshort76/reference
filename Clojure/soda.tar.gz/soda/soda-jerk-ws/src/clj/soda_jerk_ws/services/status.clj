(ns soda-jerk-ws.services.status
  (:require [datasources.core :as ds]
            [monger.collection :as mc]
            [monger.query :as mq]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.data.util :as du]
            [soda-jerk-ws.analytics.pipeline-health :as saph]
            [util.app-status :as uap]
            [compojure.api.sweet :refer :all]
            [soda.data.source :as source]
            [clj-http.client :as http]
            [util.platform :as platform]))

(defn utilization-for-host [host]
  (first (mq/with-collection (ds/get-db "soda-analytics") "machine-stats"
           (mq/find {:host host})
           (mq/sort (array-map :date-time -1))
           (mq/limit 1))))

(defn utilization-for-all-hosts []
  (let [hosts (mc/distinct (ds/get-db "soda-analytics") "machine-stats" :host)]
    (zipmap hosts (map utilization-for-host hosts))))

(def end-points
  (context "/status" []
    {:tags ["status"]}

    (GET "/utilization" []
      :query-params [{host :- s/Str nil}]
      :summary "Get utilization stats for a particular host"
      (ok (du/fix-ids (if host (utilization-for-host host)
                               (utilization-for-all-hosts)))))

    (GET "/" []
      :summary "Returns the status of the soda_jerk_ws web service."
      (ok (uap/status-components->status
            {:service               "soda-jerk-ws"
             :project-version       (platform/project-version "soda-jerk-ws")
             :project-documentation "https://confluence.arbfund.com/display/DEV/Soda-Jerk-WS"}
            uap/file-system-status-component
            uap/mongo-status-component
            (uap/generic-cw-web-component "soda-api" (str (source/soda-api-base-url) "status")))))

    (GET "/system/titan-publication" []
      :query-params []
      :summary "Returns the status of the latest round of universe file publication to Titan"
      (ok (saph/publication-status)))

    (GET "/data/canadian-mbs" []
      :query-params []
      :summary "Returns the status of SoDa's canadian mbs data process"
      (ok (saph/can-mbs-status)))

    (GET "/data/rule-violations" []
      :query-params []
      :summary "Returns the number of violations for each schema level rule.  Rules without violations are excluded from the list."
      (ok (saph/rules-status)))))