(ns soda-jerk-ws.services.analytics
  (:require [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.control-sets :as cs]
            [soda-jerk-ws.analytics.xmas-tree :as xmas]
            [compojure.api.sweet :refer :all]))

(def services
  (context "/analytics" []
    {:tags ["Analyze our data and processes"]}

    (GET "/validation/control-set/:control-set/source/:source" []
      :path-params [control-set :- (s/->EnumSchema (apply sorted-set (keys cs/control-sets)))
                    source :- (s/->EnumSchema #{:jaegers :soda-api})]
      :summary "Gets cached validation results for a control set"
      (ok (xmas/get-cached-validation-data control-set source)))

    (POST "/validation-recache/control-set/:control-set" []
      :path-params [control-set :- (s/->EnumSchema (apply sorted-set (keys cs/control-sets)))]
      :summary "Refreshes cached validation results for a control set"
      (ok (do (future (xmas/validation-recache-current control-set)) nil)))

    (POST "/validation-refresh/control-set/:control-set" []
      :path-params [control-set :- (s/->EnumSchema (apply sorted-set (keys cs/control-sets)))]
      :summary "Refreshes cached validation results for a control set"
      (ok (do (future (xmas/refresh-validation-cache control-set)) nil)))

    (GET "/validation-cache-status/control-set/:control-set" []
      :path-params [control-set :- (s/->EnumSchema (apply sorted-set (keys cs/control-sets)))]
      :summary "Gets the status of the cache for a control set (current run state, last run, average time, etc.)"
      (ok (xmas/get-cache-status control-set)))

    (GET "/validation-small/control-set/:control-set/source/:source" []
      :path-params [control-set :- (s/->EnumSchema (apply sorted-set (keys cs/control-sets)))
                    source :- (s/->EnumSchema #{:jaegers :soda-api})]
      :summary "Gets cached validation results for a control set"
      (ok (update (xmas/get-cached-validation-data control-set source)
                  :data (fn [data] (->> (vals data)
                                        (map (fn [field-val]
                                                 (->> (vals field-val)
                                                      (map :count)
                                                      (zipmap (keys field-val)))))
                                        (zipmap (keys data)))))))))