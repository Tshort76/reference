(ns soda-jerk-ws.services.ice
  (:require [ring.util.http-response :refer :all]
            [schema.core :as s]
            [compojure.api.sweet :refer :all]
            [soda.jobs.job-defs :as jdefs]
            [soda.jobs.utils :as jutils]
            [environ.core :refer [env]]))

(def end-points
  (context "/ice-corporate-actions" []
           {:tags ["ice corporate actions"]}
           (POST "/refresh-event-ids" []
                 :return s/Any
                 :summary "Refreshes the set of all unique combinations of event-id and revision-id for ICE CAS events."
                 (ok (or (jutils/enqueue-job (jdefs/refresh-ice-ids)) {})))))
