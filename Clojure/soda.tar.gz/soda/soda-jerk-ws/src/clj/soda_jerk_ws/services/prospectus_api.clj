(ns soda-jerk-ws.services.prospectus-api
  "API for interacting with prospectuses within databases. Separates the concerns of prospectus-db
  interop with the actual service calls."
  (:require [ecs.schema :as esch]
            [soda.data.core :as sdc]
            [soda.jobs.job-defs :as jdefs]
            [soda.jobs.utils :as jutils]
            [unmarshallers.entity-map-parser :as emp]))

(sdc/defcon "soda-raw" "data" :basename "raw-data")

(defn submit-prospectus [entity-map]
  (->> entity-map
       emp/parse
       vector
       bulk-write-raw-data
       first
       (assoc {} :id)
       jdefs/normalize
       jutils/enqueue-job))
