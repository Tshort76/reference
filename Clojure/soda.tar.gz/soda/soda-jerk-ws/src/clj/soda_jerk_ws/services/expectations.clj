(ns soda-jerk-ws.services.expectations
  (:require [clj-time.coerce :as c]
            [clj-time.core :as t]
            [clj-time.format :as f]
            [clj-time.periodic :as p]
            [clj-time.predicates :as tp]
            [clojure.spec.alpha :as spec]
            [datasources.core :as ds]
            [medley.core :refer [filter-vals assoc-some map-vals map-keys]]
            [monger.collection :as mc]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.jobs.rescheduling-utils :as ru]
            [compojure.api.sweet :refer :all]))

(defn before-or-equal? "d1 <= d2 ?" [d1 d2]
  (and d1 d2 (some identity ((juxt t/before? t/equal?) d1 d2))))

(def period-type->interval
  {:days     (t/days 1)
   :weeks    (t/days 7)
   :months   (t/months 1)
   :quarters (t/months 3)
   :years    (t/years 1)})

(spec/def ::period-type (set (keys period-type->interval)))

(defn next-period-start-date [d period-type]
  {:pre [(spec/valid? ::period-type period-type)]}
  (let [day (t/with-time-at-start-of-day d)]
    (t/with-time-at-start-of-day
      (condp (partial = period-type) period-type
        :days day
        :weeks (t/plus day (t/days (mod (- 8 (t/day-of-week day)) 7)))
        :months (if (tp/first-day-of-the-month? day)
                  day
                  (->> (t/months 1)
                       (t/plus day)
                       t/first-day-of-the-month))
        :quarters (let [fdtq (ru/first-day-this-quarter day)]
                    (if (tp/same-date? fdtq day)
                      fdtq
                      (ru/first-day-nxt-quarter day)))

        :years (let [fdty (t/first-day-of-the-month (t/year day) 1)]
                 (if (tp/same-date? fdty day)
                   fdty
                   (t/plus fdty (t/years 1))))))))

(defn periods-between [start-date end-date period-type]
  {:pre [(spec/valid? ::period-type period-type)]}
  (let [start-days-within-period
        (take-while #(before-or-equal? % end-date)
                    (p/periodic-seq (next-period-start-date start-date period-type)
                                    (period-type->interval period-type)))]
    (map (fn [f s] (t/interval f s)) start-days-within-period (rest start-days-within-period))))

(defn file-counts-within-period-by-day [start-date end-date file-type]
  (when (and start-date end-date (before-or-equal? start-date end-date))
    (let [ed (t/with-time-at-start-of-day end-date)
          sd (t/with-time-at-start-of-day start-date)]
      (->> (mc/find-maps (ds/get-db "soda-raw") "files-meta"
                         {:file-type file-type :effective-start-date {"$gte" (c/to-date sd)
                                                                      "$lt"  (c/to-date ed)}})
           (map (comp t/with-time-at-start-of-day c/from-date :effective-start-date))
           frequencies))))

(defn periods->adjusted-periods [n periods]
  (when (and periods (< 0 n))
    (if (= 1 n)
      periods
      (->> periods
           (partition n)
           (map (fn [is] (t/interval (t/start (first is)) (t/end (last is)))))))))

(defn upload-count-per-file-type-period
  [start-date end-date {{{:keys [units magnitude]} :period} :expectation ft :file-type}]
  (let [periods (->> units
                     keyword
                     (periods-between start-date end-date)
                     (periods->adjusted-periods magnitude))
        counts-per-day (file-counts-within-period-by-day start-date end-date ft)]
    (reduce-kv
      (fn [m day cnt]
        (if-let [period (some #(when (t/within? % day) %) (keys m))]
          (update-in m [period :upload-count] + cnt)
          m))
      (into {} (map #(conj [% {:upload-count 0}]) periods))
      counts-per-day)))

(defn get-all [start-date end-date]
  (let [file-expectations (map #(dissoc % :_id)
                               (mc/find-maps (ds/get-db "soda_configs") "file-expectations"))]
    (reduce (fn [m fe] (assoc m fe (upload-count-per-file-type-period start-date end-date fe)))
            {} file-expectations)))

(defn dt->yyyy-MM-dd [dt]
  (f/unparse (f/formatters :year-month-day) dt))

(defn get-file-expectations-report
  ([start-date end-date only-failures?]
   (->> (get-all start-date end-date)
        (map (fn [[{{:keys [min-upload-count]} :expectation :as k} v]]
               (assoc k :periods
                        (->> (map (fn [[k v]] (assoc v :period-start (dt->yyyy-MM-dd (t/start k))
                                                       :period-end (dt->yyyy-MM-dd (t/end k)))) v)
                             (filter (fn [{:keys [upload-count]}]
                                       (if-not only-failures? true (< upload-count min-upload-count))))
                             (sort-by :period-start)))))
        ;TODO leave these in? or have flag to display/not display?
        (filter (fn [{:keys [periods]}] (seq periods))))))

(def services
  (context "/expectations" []
    {:tags ["expectations"]}

    (GET "/files" []
      :query-params [{start-date :- (describe s/Str "yyyy-MM-dd, default 2017-01-01") "2017-01-01"}
                     {end-date :- (describe s/Str "yyyy-MM-dd, default today") (f/unparse (f/formatters :year-month-day) (t/now))}
                     {only-failures? :- (describe s/Bool "show all periods, or only those that fail? default false") false}]
      :summary "File download count expectations vs actual, by file-type, for file-type periods within period start-date to end-date"
      (let [sd (c/from-string start-date)
            ed (c/from-string end-date)]
        (if-not (before-or-equal? sd ed)
          (bad-request {:bad-request-reason "start-date must be <= end-date"})
          (ok (get-file-expectations-report sd ed only-failures?)))))))

(comment
  (def data (get-all (t/minus (t/now) (t/months 15)) (t/now)))

  (def irregular-scrapers "These are typically scheduled as needed, so we don't care to check them regularly"
    #{"treasury-direct-R-universe" "cusip-db-master-issuer"
      "cusip-db-master-issue" "cusip-db-master-attribute" "famc-mbs-1"
      "famc-mbs-2"})

  (def tmp
    (->> data
         (map
           (fn [[exp uploads]]
             (let [min-count (get-in exp [:expectation :min-upload-count])
                   prev-period-data (->> uploads
                                         (sort-by (comp t/start first))
                                         (take-last 2) first)
                   actual-cnt (:upload-count (second prev-period-data))]
               {:file-type    (:file-type exp)
                :min-count    min-count
                :actual-count (:upload-count (second prev-period-data))
                :okay?        (and actual-cnt (>= actual-cnt min-count))
                :period       (first prev-period-data)})))
         (remove :okay?)
         (remove (comp irregular-scrapers :file-type))))

  ;For investigation
  (defn investigate [file-type]
    (let [exp (mc/find-one-as-map (ds/get-db "soda_configs") "file-expectations" {:file-type file-type})
          _ (println (:expectation exp))
          fe (-> exp
                 ;(assoc-in [:expectation :period :units] "months")
                 ;(assoc-in [:expectation :period :magnitude] 1)
                 )]
      {:total-files (mc/count (ds/get-db "soda-raw") "files-meta" {:file-type file-type})
       :periods     (->> (upload-count-per-file-type-period (t/minus (t/now) (t/months 15)) (t/now) fe)
                         (sort-by (comp t/start first)))}))
  )