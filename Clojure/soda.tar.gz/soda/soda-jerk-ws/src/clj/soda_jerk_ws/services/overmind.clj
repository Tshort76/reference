(ns soda-jerk-ws.services.overmind
  (:require [clojure.java.io :as io]
            [datasources.core :as ds]
            [doc-transforms.core :as dtc]
            [jaegers.edgar.equity.header-scraper :as header]
            [monger.collection :as mc]
            [ring.swagger.upload :as upload]
            [ring.middleware.multipart-params :as multi-part]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda-jerk-ws.mind-food.html-conversion :as html]
            [soda-jerk-ws.util.downloader :as j-down]
            [compojure.api.sweet :refer :all])
  (:import (java.io File)))

(def create-endpoints
  (context "/overmind" []
    {:tags ["overmind"]
     :summary "Overmind Automation"}

    (GET "/original/" []
      :query-params [md5 :- s/Str]
      :summary "Get a stored document."
      (j-down/get-file-from-mongo {:md5 md5}))

    (GET "/original-file/" []
      :query-params [filename :- s/Str]
      :summary "Get a stored document."
      (j-down/get-file-from-mongo {:filename (ring.util.codec/form-decode filename)}))

    (GET "/mind-food/" []
      :query-params [md5 :- s/Str]
      :summary "Get the mind-food for a document."
      (ok (dtc/mongo->transform :mind-food {:md5 md5})))

    (GET "/mind-food-file/" []
      :query-params [filename :- s/Str]
      :summary "Get the mind-food for a document."
      (ok (dtc/mongo->transform :mind-food {:filename filename})))

    (POST "/mind-food-for-upload" []
      :multipart-params [file :- upload/TempFileUpload]
      :middleware [multi-part/wrap-multipart-params]
      :summary "Get the mind-food for a file not already uploaded to the file-store. Does not save the file to the file-store."
      (let [^File tf (:tempfile file)
            resp (dtc/file->transform
                   :mind-food
                   (-> (assoc file :input-stream (io/input-stream tf))
                       (dissoc :tempfile)))]
        (.delete tf)
        (ok resp)))

    (POST "/refresh-cached-transform/" []
      :query-params [md5 :- s/Str
                     transform-type :- (s/->EnumSchema #{:mind-food :enhanced-hickory})]
      :summary "Refresh the cached transform for a document."
      (->> (dtc/mongo->transform (keyword transform-type) {:md5 md5} {:update-cache? true})
           boolean
           (array-map :success)
           ok))

    (GET "/available" []
      :query-params [data-type :- s/Str]
      :return [{:_id s/Str
                :md5 s/Str
                :filename s/Str
                :file-type s/Str
                (s/optional-key :bid) s/Str
                (s/optional-key :food-id) s/Str}]
      :summary "Return a list of unprocessed documents from the message queue."
      (ok (->> (mc/find-maps (ds/get-db "soda-raw") "files-meta"
                             {:file-type data-type}
                             {:_id 1, :md5 1, :filename 1, :file-type 1})
               (group-by :filename)
               (mapv (comp #(update % :_id str)
                           #(cond-> % (:food-id %) (update :food-id str))
                           last
                           (partial sort-by (comp str :_id))
                           second))
               (sort-by :filename))))

    (GET "/hiccup" []
      :query-params [md5 :- String]
      :summary "Return the hiccup version of a mind-food prospectus."
      (if-let [h (html/to-hiccup (dtc/lazy-food md5))]
        (ok h)
        (bad-request (str md5 " does not exist in our file store."))))

    (GET "/10k-header-data" []
      :query-params [md5 :- String]
      :summary "Returns experimental 10k security data found at the top of the file."
      (ok (header/md5->titles {:md5 md5})))))