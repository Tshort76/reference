(ns soda-jerk-ws.services.scrapers
  (:require [clj-time.coerce :as tc]
            [clj-time.core :as t]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [scrapers.core :as sc]
            [scrapers.utils :as su]
            [compojure.api.sweet :refer :all])
  (:import (java.util Date)))

(def services
  (context "/scrapers" []
    {:tags ["Scrapers"]}

    (POST "/schedule" []
      :query-params [scraper-id :- (s/->EnumSchema (sc/scrapeable-file-types))]
      :summary "Schedules a self-rescheduling scraper"
      (ok (or (su/schedule-scrape scraper-id (su/params (keyword scraper-id) (t/now)))
              {:failed? true
               :reason :already-scheduled})))

    (POST "/schedule/all" []
      :summary      "Schedules all scrapers that are not already scheduled ... Idempotent."
      (ok (sc/ensure-scheduled-tasks)))

    (POST "/scrape" []
      :query-params [scraper-id :- (s/->EnumSchema (sc/scrapeable-file-types))
                     {as-if-today-was :- (describe s/Inst "Run the scraper with the params that would have been used when it ran on the specified date. yyyy-MM-dd format, defaults to today") (new Date)}
                     {just-verify? :- (describe Boolean "TRUE -> preview params without enqueuing a job") false}]
      :summary      "Enqueues a scraper to run with the parameters that would have been used if it ran on as-if-today-was instead"
      (ok (let [scrape-def (sc/scrape-def-with-now-as scraper-id (tc/from-date as-if-today-was))]
            (if just-verify? scrape-def (su/schedule-one-scrape scraper-id scrape-def)))))

    (POST "/update-password" []
      :query-params [site-id :- (s/->EnumSchema (su/all-site-ids))
                     password :- String]
      :summary "Update the password for a site"
      (ok (su/update-password site-id password)))

    (POST "/add-credentials" []
      :query-params [site-id :- String
                     password :- String
                     {user-name :- String nil}]
      :summary "Add a new site-id and password combination for the scrapers"
      (ok (su/add-credentials site-id {:password password :user-name user-name})))))