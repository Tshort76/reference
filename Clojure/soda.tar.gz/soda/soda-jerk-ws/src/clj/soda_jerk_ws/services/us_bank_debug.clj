(ns soda-jerk-ws.services.us-bank-debug
  (:require [clojure.java.io :as io]
            [ring.swagger.upload :as upload]
            [ring.middleware.multipart-params :as multi-part]
            [ring.util.http-response :refer :all]
            [ring.util.io :as ring-io]
            [ring.util.response :as response]
            [schema.core :as s]
            [soda.data.file-system :as sdfs]
            [unmarshallers.us-bank-factors :as us-bank]
            [compojure.api.sweet :refer :all]))

(defn format-stream [stream]
  (let [headers {"Content-Type" "application/vnd.ms-excel"
                 "Accept-Ranges" "bytes"
                 "Content-Disposition" "attachment; filename=audit.xls;"}]
    (update (response/response stream)
            :headers conj headers)))

(defn query->input-stream [{:keys [md5 filename]}]
  (-> (if md5
        {:md5 md5}
        {:filename filename})
      (assoc :file-type "us-bank-factors")
      sdfs/find-file))

(def end-points
  (context "/us-bank" []
    {:tags ["us-bank"]}

    (GET "/debug" []
      :query-params [{md5 :- s/Str nil}
                     {filename :- s/Str nil}]
      :summary "Return us-bank debug data for an existing us-bank-factors file."
      (-> {:md5 md5
           :filename filename}
          query->input-stream
          :input-stream
          (->> (partial us-bank/debug-file))
          ring-io/piped-input-stream
          format-stream))

    (POST "/debug" []
      :multipart-params [file :- upload/TempFileUpload]
      :middleware [multi-part/wrap-multipart-params]
      :summary "Return us-bank debug data for a given us-bank-factors file."
      (let [results (->> file
                         :tempfile
                         io/input-stream
                         (partial us-bank/debug-file)
                         ring-io/piped-input-stream)]
        (-> file :tempfile .delete)
        (format-stream results)))

    (GET "/headers" []
      :query-params [{md5 :- s/Str nil}
                     {filename :- s/Str nil}
                     {use-mongo :- s/Bool false}]
      :return {s/Keyword s/Any}
      :summary (str "Return the headers found for each field for an existing us-bank-factors file. The use-mongo flag "
                    "determines if the parser specs in soda-raw.test-us-bank-parsers should be used.")
      (-> {:md5 md5 :filename filename}
          query->input-stream
          :input-stream
          (us-bank/find-header-types use-mongo)
          ok))

    (POST "/headers" []
      :multipart-params [file :- upload/TempFileUpload]
      :middleware [multi-part/wrap-multipart-params]
      :return {s/Keyword s/Any}
      :summary "Return the headers found for each field for a given us-bank-factors file."
      (let [results (->> file
                         :tempfile
                         io/input-stream
                         us-bank/find-header-types)]
        (-> file :tempfile .delete)
        (ok results)))

    (GET "/parse" []
      :query-params [{md5 :- s/Str nil}
                     {filename :- s/Str nil}
                     {use-mongo :- s/Bool false}]
      :return [{s/Keyword s/Any}]
      :summary (str "Return the parser results for an existing us-bank-factors file. The use-mongo flag determines "
                    "if the parser specs in soda-raw.test-us-bank-parsers should be used.")
      (-> {:md5 md5 :filename filename}
          query->input-stream
          (us-bank/unmarshal use-mongo)
          ok))

    (POST "/parse" []
      :multipart-params [file :- upload/TempFileUpload]
      :middleware [multi-part/wrap-multipart-params]
      :return [{s/Keyword s/Any}]
      :summary "Return the parser results for a given us-bank-factors file."
      (let [results (->> file
                         :tempfile
                         io/input-stream
                         us-bank/unmarshal)]
        (-> file :tempfile .delete)
        (ok results)))))