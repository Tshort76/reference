(ns soda-jerk-ws.services.utilities
  (:require [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.data.util :as sdu]
            [soda.jobs.utils :as sju]
            [soda-jerk-ws.jobs.utils :as u]
            [compojure.api.sweet :refer :all]))

(def services
  (context "/utils" []
    {:tags ["Job Tracking"]}

    (GET "/between-ids" []
      :query-params [db :- String
                     coll :- String
                     min-id-hex :- String
                     max-id-hex :- String]
      :summary "Returns all the documents that were entered with the document containing the specified id"
      (ok (sju/docs-in-batch db coll min-id-hex max-id-hex)))

    (GET "/job-by-id" []
      :query-params [id :- String]
      :summary "Gets a job by id, regardless of completion status (may be in queue or job_history)"
      (ok (sdu/fix-ids (sju/job-by-id id))))

    (GET "/in-batch" []
      :return   {s/Keyword s/Any}
      :query-params [bid :- String
                     {show-job-docs? :- s/Bool false}]
      :summary  "Return summary information on all jobs with the specified batch id."
      (ok (u/trace-by-bid bid {:show-job-docs? show-job-docs?})))))