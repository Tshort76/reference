(ns soda-jerk-ws.services.unresolved-failures
  (:require [pipeline.job-execution :as pje]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [scrapers.utils :as su]
            [soda.data.util :as du]
            [soda.jobs.unresolved-failures :as uf]
            [compojure.api.sweet :refer :all]))

(def services
  (context "/failures" []
    {:tags ["Unresolved Failures"]}

    ; Aggregate
    (GET "/distinct" []
      :query-params [{since :- s/Inst nil}]
      :summary "Returns one document per distinct failure: includes affected jobs/types, failure details, count, etc."
      ;effectively unlimited for now - may need to change later if they cause problems
      (ok (du/fix-ids (uf/distinct-failures :look-limit 10000 :return-limit 1000 :since since))))

    ; Rerun
    (POST "/rerun/category" []
      :query-params [category :- (s/->EnumSchema (apply sorted-set (keys uf/unresolved-failure-queries)))
                     {priority :- (s/->EnumSchema (sorted-set "background" "foreground")) nil}]
      :summary "Reruns all unresolved failures in a given category"
      (-> category (uf/rerun-unresolved-failures-by-category :priority priority) ok))

    (POST "/rerun/matching-job" []
      :query-params [id :- s/Str
                     {priority :- (s/->EnumSchema (sorted-set "background" "foreground")) nil}]
      :summary "Reruns all unresolved failures whose failures exactly match that of the given job"
      (-> id (uf/rerun-unresolved-failures-with-matching-failures :priority priority) ok))

    (POST "/rerun/failure" []
      :query-params [{error-code :- s/Str nil}
                     {cancellation-reason :- (s/->EnumSchema #{:manual-request :too-many-retries :auto-expired}) nil}
                     {priority :- (s/->EnumSchema (sorted-set "background" "foreground")) nil}]
      :summary "Reruns all failed jobs with the given failure or cancellation-reason"
      (-> (or error-code cancellation-reason) (uf/rerun-unresolved-failures-with-failure :priority priority) ok))

    (POST "/rerun/job" []
      :query-params [id :- s/Str
                     {priority :- (s/->EnumSchema (sorted-set "background" "foreground")) nil}]
      :summary "Reruns the unresolved failed job with the given id"
      (-> id (uf/rerun-unresolved-failure-by-id :priority priority) du/fix-ids ok))

    (POST "/rerun/job-type" []
      :query-params [job-type :- (s/->EnumSchema (apply sorted-set (keys pje/job-type->spec)))
                     {priority :- (s/->EnumSchema (sorted-set "background" "foreground")) nil}]
      :summary "Reruns the unresolved failed job(s) with the given job-type"
      (-> (uf/rerun-unresolved-failures {:job-def.type job-type} :priority priority ) du/fix-ids ok))

    (POST "/rerun/scraper-id" []
      :query-params [scraper-id :- (s/->EnumSchema (apply sorted-set (keep :_id (su/scraper-specs))))
                     {priority :- (s/->EnumSchema (sorted-set "background" "foreground")) nil}]
      :summary "Reruns the unresolved failed scrape job(s) with the given scraper-id"
      (-> (uf/rerun-unresolved-failures {:job-def.scraper-id scraper-id} :priority priority ) du/fix-ids ok))

    ; Inspect
    (GET "/inspect/category" []
      :query-params [category :- (s/->EnumSchema (apply sorted-set (keys uf/unresolved-failure-queries)))]
      :summary "Returns unresolved failures in the given category, limited to 100 documents"
      (-> category (uf/inspect-unresolved-failures-by-category :limit 100) du/fix-ids ok))

    (GET "/inspect/matching-job" []
      :query-params [id :- s/Str]
      :summary "Returns up to 100 unresolved failed jobs with the same failure as the failed job with the given id"
      (-> id (uf/inspect-unresolved-failures-with-matching-failures :limit 100) du/fix-ids ok))

    (GET "/inspect/failure" []
      :query-params [{error-code :- s/Str nil}
                     {cancellation-reason :- (s/->EnumSchema #{:manual-request :too-many-retries :auto-expired}) nil}]
      :summary "Returns unresolved failures the given failure, limited to 100 documents"
      (-> (or error-code cancellation-reason) (uf/inspect-unresolved-failures-with-failure :limit 100) du/fix-ids ok))

    (GET "/inspect/job" []
      :query-params [id :- s/Str]
      :summary "Returns the unresolved failed job with the given id"
      (-> id uf/inspect-unresolved-failure-by-id du/fix-ids ok))

    ; Count
    (GET "/count/category" []
      :query-params [category :- (s/->EnumSchema (apply sorted-set (keys uf/unresolved-failure-queries)))]
      :summary "Returns the count of unresolved failures in the given category"
      (-> category uf/count-unresolved-failures-by-category ok))

    (GET "/count/matching-job" []
      :query-params [id :- s/Str]
      :summary "Returns the count of unresolved failures with the same error as the failed job with the given id"
      (-> id uf/count-unresolved-failures-with-matching-failures ok))

    (GET "/count/failure" []
      :query-params [{error-code :- s/Str nil}
                     {cancellation-reason :- (s/->EnumSchema #{:manual-request :too-many-retries :auto-expired}) nil}]
      :summary "Reruns the count of unresolved failures with the given failure"
      (-> (or error-code cancellation-reason) uf/count-unresolved-failures-with-failure ok))

    ; Jira Links
    (GET "/all-links" []
      :summary "Gets the map of failures to Jira tickets"
      (let [links (uf/get-all-links)]
        (ok (zipmap (map :_id links) (map :ticket links)))))

    (POST "/link" []
      :query-params [failure :- s/Str
                     ticket :- s/Str]
      :summary "Reruns all failed jobs with the given failure or cancellation-reason"
      (ok (uf/upsert-link failure ticket)))))