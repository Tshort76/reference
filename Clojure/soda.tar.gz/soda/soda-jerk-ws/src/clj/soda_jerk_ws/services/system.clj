(ns soda-jerk-ws.services.system
  (:require [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda-jerk-ws.jobs.utils :as u]
            [soda.jobs.utils :as sju]
            [compojure.api.sweet :refer :all]))

(def services
  (context "/system" []
    {:tags ["System status"]}

    (GET "/hosts" []
      :query-params [{active :- s/Bool true}]
      :summary "Returns the state of all workers across all hosts. If active is true, only return active hosts."
      (ok (u/host-status active)))

    (GET "/load" []
      :summary "Return the number of running jobs and the number of queued jobs, across all hosts"
      (ok (sju/jobs-summary)))

    (GET "/enqueued-jobs" []
      :query-params [{limit :- s/Int 100}]
      :summary "Returns the jobs that have errored"
      (ok (take limit (sju/enqueued))))

    (GET "/running-jobs" []
      :query-params [{limit :- s/Int 100}]
      :summary "Returns the jobs that have errored"
      (ok (take limit (sju/running))))

    (GET "/errors" []
      :query-params [{as-of :- String ""}
                     {limit :- s/Int 100}]
      :summary "Returns the jobs that have errored"
      (ok (take limit (sju/errors as-of))))

    (GET "/recent-jobs" []
      :query-params [{as-of-date :- String "1970-01-01 00:00:00"}
                     {limit :- s/Int 100}]
      :summary "Returns the [limit] most recently completed jobs with completed-at newer than [as-of-date] (YYYY-mm-dd HH:MM:SS)"
      (ok (take limit (sju/recent-completes as-of-date))))

    (POST "/pause-workers" []
      :summary "Prevents all worker threads across all hosts from starting new jobs"
      (ok (u/post-action "pause" nil)))

    (POST "/resume-workers" []
      :summary "Causes all worker threads on all hosts to resume running jobs"
      (ok (u/post-action "run" nil)))

    (POST "/:host/action" []
      :path-params [host :- s/Str]
      :body [action (s/->EnumSchema #{"run" "pause"})]
      :summary "Sets the action property on the specified host"
      (ok (u/post-action action host)))

    (POST "/:host/consumers" []
      :path-params [host :- s/Str]
      :body [num-consumers s/Int]
      :summary "Sets the number of consumers on the specified host"
      (ok (u/post-consumers host num-consumers)))

    (POST "/:host/queries" []
      :path-params [host :- s/Str]
      :body [queries [s/Any]]
      :summary "Set queries that host will use to look for jobs to run."
      (ok (u/post-queries host queries)))))