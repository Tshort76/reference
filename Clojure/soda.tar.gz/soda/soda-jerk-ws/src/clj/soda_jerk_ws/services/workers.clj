(ns soda-jerk-ws.services.workers
  (:require [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.data.util :as du]
            [soda-jerk-ws.jobs.utils :as u]
            [compojure.api.sweet :refer :all])
  (:import (java.net InetAddress)))

(def services
  (context "/workers" []
    {:tags ["Control Workers"]}

    (POST "/:action" []
      :path-params [action :- (s/->EnumSchema #{:pause :run})]
      :query-params [{this-host-only :- Boolean true}]
      :summary "Prevents all worker threads across all hosts from starting new jobs"
      (ok (u/post-action (name action) (when this-host-only (.getHostName (InetAddress/getLocalHost))))))

    (GET "/jobs-between" []
      :query-params [start :- s/Int
                     {end :- s/Int nil}
                     {limit :- s/Int 1000}] ;millis since epoch
      :summary "Return the stats for all jaeger-docs."
      (ok (du/fix-ids (u/jobs-between start :end end :limit limit))))))