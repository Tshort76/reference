(ns soda-jerk-ws.services.overrides
  (:require [datasources.core :as ds]
            [monger.collection :as mc]
            [pipeline.aggregator :as agg]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.data.file-system :as sdfs]
            [soda.data.util :as sdu]
            [soda-jerk-ws.services.relay :as relay]
            [surveyor-interop.enqueue-questions :as surv-op]
            [compojure.api.sweet :refer :all]))

(defn identifiers->override-type [{:keys [cusip isin cik lei index-name date md5 cusip-6] :as identifiers}]
  (let [security? (or cusip isin)
        entity? (or cik lei cusip-6)
        index? (and index-name date)
        document? md5]
    (cond (< 1 (count (filter identity [security? entity? index? document?])))
          (throw (IllegalArgumentException. (str "Cannot mix identifiers of different types: " identifiers)))

          security? :security
          entity? :entity
          index? :index
          document? :document
          :else (throw (IllegalArgumentException. (str "Invalid combination of override identifiers: " identifiers))))))

(defn identifiers->or-clause [identifiers & {:keys [prepend]}]
  (->> identifiers
       (filter (fn [[k v]] v))
       (mapv (fn [[k v]] {(keyword (str prepend (name k))) v}))))

(defn- get-target-doc-match [identifiers identifier-keys start-path]
  (some->> (select-keys identifiers identifier-keys)
           (filter (fn [[_ v]] (if (string? v) (not (empty? v)) v)))
           first
           (map #(if (keyword? %) (name %) (str %)))
           (apply format (str start-path "/%s/%s"))))

(defn identifiers->match-condition [{:keys [index-name date md5] :as identifiers} & {:keys [prepend]}]
  (case (identifiers->override-type identifiers)
    :security {:target-doc   (get-target-doc-match identifiers [:cusip :isin] "security")
               :override-doc {"$or" (identifiers->or-clause identifiers :prepend prepend)}}
    :entity {:target-doc   (get-target-doc-match identifiers [:cik :lei :cusip-6] "entity")
             :override-doc {"$or" (identifiers->or-clause identifiers :prepend prepend)}}
    :index (let [mc {(keyword (str prepend "index-name")) index-name, (keyword (str prepend "date")) date}]
             {:target-doc   mc
              :override-doc mc})
    :document (let [mc {(keyword (str prepend "md5")) md5}]
                {:target-doc   mc
                 :override-doc mc})))

(defn find-overrides [identifiers]
  (mc/find-maps (ds/get-db "soda") "overrides"
    (:override-doc (identifiers->match-condition identifiers :prepend "identifiers."))))

(defn lookup-document [identifiers]
  (let [override-type (identifiers->override-type identifiers)
        match-condition (:target-doc (identifiers->match-condition identifiers))]
    (case override-type
      :security (:body (relay/relay "soda-api" match-condition))
      :entity   (:body (relay/relay "soda-api" match-condition))
      :index    (mc/find-one-as-map (ds/get-db "soda") "index" match-condition)
      :document (mc/find-one-as-map (ds/get-db "soda-raw") "files-meta" match-condition)
      (throw (IllegalArgumentException. (str "Cannot look up " override-type "s in aggregation"))))))

(defn identifiers->md5s [{:keys [md5 isin cusip]}]
  (cond md5 [md5]
        cusip (->> (agg/dredge :cusip cusip) (keep (comp :md5 :meta)) distinct seq)
        isin (->> (agg/dredge :isin isin) (keep (comp :md5 :meta)) distinct seq)
        :else nil))

(defn upsert-override [{:keys [identifiers] :as override}]
  (when-let [match-condition (:override-doc (identifiers->match-condition identifiers :prepend "identifiers."))]
    (when-let [md5s (identifiers->md5s identifiers)]
      (->> (sdfs/find-all-meta {:md5 {:$in md5s}})
           (run! (fn [meta] (surv-op/ask-question meta {:tags ["override"]})))))
    (mc/upsert (ds/get-db "soda") "overrides" match-condition override)))

(defn remove-override [identifiers]
  (when-let [match-condition (:override-doc (identifiers->match-condition identifiers :prepend "identifiers."))]
    (mc/remove (ds/get-db "soda") "overrides" match-condition)))

(def services
  (context "/overrides" []
    {:tags ["Overrides"]}

    (GET "/override" []
      :query-params [{cusip :- s/Str nil}
                     {isin :- s/Str nil}
                     {cik :- s/Int nil}
                     {lei :- s/Str nil}
                     {index-name :- s/Str nil}
                     {date :- s/Str nil}
                     {md5 :- s/Str nil}
                     {cusip-6 :- s/Str nil}]
      :summary "Returns any override(s) matching the provided identifiers."
      (try (let [identifiers {:cusip cusip :isin isin :cik cik :lei lei :index-name index-name :date date :md5 md5 :cusip-6 cusip-6}]
             (ok (sdu/fix-ids (find-overrides identifiers))))
           (catch IllegalArgumentException e
             (bad-request (.getMessage e)))))

    (POST "/override" []
      :body [override-doc s/Any]
      :summary "Adds an override-doc to the overrides collection."
      (try (ok (boolean (upsert-override override-doc)))
           (catch IllegalArgumentException e
             (bad-request (.getMessage e)))))

    (DELETE "/override" []
      :query-params [{cusip :- s/Str nil}
                     {isin :- s/Str nil}
                     {cik :- s/Int nil}
                     {lei :- s/Str nil}
                     {index-name :- s/Str nil}
                     {date :- s/Str nil}
                     {md5 :- s/Str nil}]
      :summary "Removes an override-doc to the overrides collection."
      (try (let [identifiers {:cusip cusip :isin isin :cik cik :lei lei :index-name index-name :date date :md5 md5}]
             (ok (boolean (remove-override identifiers))))
           (catch IllegalArgumentException e
             (bad-request (.getMessage e)))))

    (GET "/lookup-document" []
      :query-params [{cusip :- s/Str nil}
                     {isin :- s/Str nil}
                     {cik :- s/Int nil}
                     {lei :- s/Str nil}
                     {index-name :- s/Str nil}
                     {date :- s/Str nil}
                     {md5 :- s/Str nil}
                     {cusip-6 :- s/Str nil}]
      :summary "Returns any override(s) matching the provided identifiers."
      (try (let [identifiers {:cusip cusip :isin isin :cik cik :lei lei :index-name index-name :date date :md5 md5 :cusip-6 cusip-6}]
             (ok (sdu/fix-ids (lookup-document identifiers))))
           (catch IllegalArgumentException e
             (bad-request (.getMessage e)))))))