(ns soda-jerk-ws.services.execute
  (:require [aggregators.core :as agg]
            [clojure.pprint :refer [pprint]]
            [clojure.string :as cs]
            [clojure.walk :as walk]
            [jaegers.md5-control-sets :refer [control-sets]]
            [normalizers.core :as pn]
            [normalizers.identifiers :as nid]
            [pipeline.jobs.security-agg :as pjsa]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.jobs.utils :as jutils]
            [soda-data-model.json-schema :as schemas]
            [taoensso.timbre :as log]
            [unmarshallers.core :as u]
            [uploader.core :as up]
            [compojure.api.sweet :refer :all]
            [vocabularies.core :as v])
  (:import (java.util UUID)))

(defn reaggregate-by-id
  "ids is a list of {:cusip \"cusip-string\"} or {:isin \"isin-string\"}"
  [ids]
  (let [bid (str (UUID/randomUUID))
        jobs (->> ids
                  pjsa/build-aggregate-jobs
                  (map (fn [j] (assoc j :bid bid))))]
    (doall (map jutils/enqueue-job jobs))
    {:bid bid :job-count (count jobs)}))

(defn reaggregate-by-cusip [cusips]
  (->> cusips
       (remove nil?)
       (map (fn [c] {:cusip c}))
       reaggregate-by-id))

(defn reaggregate-by-schema [schema]
  (-> schema
      agg/get-cache-identifiers
      reaggregate-by-id))

(def services
  (context "/exec" []
    {:tags ["Execute Jobs"]}

    (POST "/rerun/job" []
      :query-params [job-id :- String]
      :summary "Reruns a job, given the hexadecimal representation of the jobs ObjectId"
      (ok (jutils/rerun-job job-id)))

    (POST "/reprocess-file" []
      :query-params [{md5 :- String nil}
                     {filename :- String nil}
                     {priority :- (s/->EnumSchema (sorted-set "background" "foreground")) nil}]
      :summary "Reprocesses a file"
      (when (or md5 filename)
        (ok (or (up/reprocess-file {:md5 md5 :filename filename :priority (not-empty priority)})
                "Was unable to find a matching file."))))

    (POST "/reprocess-files/id" []
      :query-params [id :- (s/->EnumSchema nid/security-identifiers)
                     value :- String]
      :summary "Reprocesses all files of specified identifier"
      (ok (map #(up/reprocess-file {:md5 %})
               (let [md5s (atom [])]
                 (walk/postwalk (fn [m] (if-let [md5 (get m :md5)] (swap! md5s conj md5) m))
                                (agg/aggregate (keyword id) value {:audit? true}))
                 (distinct @md5s)))))

    (POST "/reprocess-files/file-type" []
      :query-params [file-type :- (s/->EnumSchema (up/uploadable-types))]
      :summary "Reprocesses all files of specified file-type. Please be cautious using this endpoint."
      :description "Please be cautious using this endpoint, as it will reprocess everything associated with this file-type."
      (log/with-level :error
        (ok (->> file-type
                 jutils/find-reprocessable-files
                 (pmap #(up/reprocess-file (assoc (select-keys % [:md5 :filename]) :priority "background")))
                 (mapcat identity)
                 (keep :bid)
                 count
                 (str "Documents were enqueued for processing. Total # of spawned jobs: ")))))

    (POST "/rerun/normalization/structured" []
      :query-params [file-type :- (s/->EnumSchema (u/normalizable-file-types))]
      :summary "Renormalizes all files of a certain file-type"
      (log/with-level :error
        (ok (->> (jutils/renormalize file-type)
                 (keep :job-count)
                 (reduce + 0)
                 (str "Documents were enqueued for normalization. Total # of spawned jobs: ")))))

    (POST "/rerun/normalization/md5" []
      :query-params [md5-list :- String]
      :summary "Renormalizes files with the given md5's. The md5's are expected to be comma-separated."
      (-> md5-list
          (cs/split #",")
          jutils/renormalize-md5s
          ok))

    (POST "/rerun/normalization/entity-maps" []
      :query-params [data-type :- (s/->EnumSchema (apply sorted-set (keys v/raw-vocabs)))
                     id-type :- (s/->EnumSchema #{:cusip :pool-number :isin})]
      :summary "Renormalizes entity-maps of a certain data-type.  The id-type defines the primary key for the documents"
      (log/with-level :error
        (ok (->> id-type
                 (pn/->normalized-entity-maps (name data-type))
                 count
                 (str "Documents were enqueued for normalization.  Total # of spawned jobs: ")))))

    (POST "/rerun/unmarshall/structured" []
      :query-params [file-type :- (s/->EnumSchema (u/structured-file-types))]
      :summary "Re-unmarshals and re-normalizes all files of a certain file-type"
      (log/with-level :error
        (ok (->> file-type
                 jutils/reunmarshal
                 count
                 (str "Documents were enqueued for unmarshalling. Total # of spawned jobs: ")))))

    (GET "/rerun/inspect" []
      :query-params [file-type :- (s/->EnumSchema (u/structured-file-types))]
      (ok (jutils/inspect-renormalize file-type)))

    (POST "/rerun/aggregation/schema" []
      :query-params [schema :- (s/->EnumSchema (set schemas/security-schema-field-names))]
      :summary "Rerun aggregation for all documents in agg-cache with given schema"
      (ok (reaggregate-by-schema schema)))

    (POST "/rerun/aggregation/cusips" []
      :query-params [cusips :- String]
      :summary "Rerun aggregation the list of cusips given"
      (ok (->> (cs/split cusips #",")
               (map cs/trim)
               reaggregate-by-cusip)))

    (POST "/rerun/aggregation/control-set" []
      :query-params [control-set :- (s/->EnumSchema (apply sorted-set (keys control-sets)))]
      :summary "Rerun aggregation on a given control-set"
      (ok (->> control-set
               keyword
               control-sets
               (map :cusip)
               reaggregate-by-cusip)))))