(ns soda-jerk-ws.services.security
  (:require [aggregators.core :as ac]
            [aggregators.derive :as ad]
            [normalizers.identifiers :as nid]
            [pipeline.aggregator :as agg]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [compojure.api.sweet :refer :all])
  (:import (org.bson.types ObjectId)))

(cheshire.generate/add-encoder ObjectId cheshire.generate/encode-str)

(defn std-response [x]
  (ok (or x {})))

(def services
  (context "/security" []
    {:tags ["security"]}

    (GET "/refresh/:identifier-type/:id" []
      :return (s/maybe {s/Keyword s/Any})
      :path-params [identifier-type :- (s/->EnumSchema nid/security-identifiers)
                    id :- s/Str]
      :query-params [{view :- (s/->EnumSchema ad/views) nil}]
      :summary "Forces agg-cache to update for the specified security"
      (ok (or (ac/soda-instrument identifier-type id {:view view :refresh-cache? true}) {})))

    (GET "/:identifier-type/:id" []
      :return (s/maybe {s/Keyword s/Any})
      :path-params [identifier-type :- (s/->EnumSchema nid/security-identifiers)
                    id :- s/Str]
      :query-params [{include-private-data? :- s/Bool nil}
                     {include-fhlmc-data? :- s/Bool nil}
                     {include-fnma-data? :- s/Bool nil}
                     {view :- (s/->EnumSchema ad/views) nil}
                     {aggregation-date :- s/Str nil}
                     {no-overrides? :- s/Bool nil}
                     {force-aggregation? :- s/Bool nil}]
      :summary "Returns all security information for the specified id of a given type."
      (std-response (ac/soda-instrument identifier-type id
                                        {:view                  view
                                         :include-private-data? include-private-data?
                                         :include-fhlmc-data?   include-fhlmc-data?
                                         :include-fnma-data?    include-fnma-data?
                                         :date-limit            aggregation-date
                                         :no-overrides?         no-overrides?
                                         :force-aggregation?    force-aggregation?})))

    (GET "/:identifier-type/:id/:field" []
      :return (s/maybe s/Any)
      :path-params [identifier-type :- (s/->EnumSchema nid/security-identifiers)
                    id :- s/Str
                    field :- s/Str]
      :query-params [{include-private-data? :- s/Bool nil}
                     {include-fhlmc-data? :- s/Bool nil}
                     {include-fnma-data? :- s/Bool nil}
                     {view :- (s/->EnumSchema ad/views) nil}
                     {aggregation-date :- s/Str nil}
                     {no-overrides? :- s/Bool nil}
                     {force-aggregation? :- s/Bool nil}]
      :summary "Returns a specific field for the specified id of a given type"
      (std-response ((keyword field)
                     (ac/soda-instrument identifier-type id
                                         {:view                  view
                                          :include-private-data? include-private-data?
                                          :include-fhlmc-data?   include-fhlmc-data?
                                          :include-fnma-data?    include-fnma-data?
                                          :date-limit            aggregation-date
                                          :no-overrides?         no-overrides?
                                          :force-aggregation?    force-aggregation?}))))

    (POST "bulk/:identifier-type" []
      :return (s/maybe [(s/maybe {s/Keyword s/Any})])
      :path-params [identifier-type :- (s/->EnumSchema nid/security-identifiers)]
      :form-params [ids :- [s/Str]]
      :summary "Deprecated: Returns all security information for the specified ids of a given type"
      (ok (filter identity (pmap (partial agg/aggregate identifier-type) ids))))))