(ns soda-jerk-ws.services.cusip-matching
  (:require [aggregators.entity.cusip6-finder :as cusip6-finder]
            [jaegers.cusip-linking.cik :as cik]
            [jaegers.cusip-linking.core :as clc]
            [jaegers.cusip-linking.stats :as cls]
            [jaegers.md5-control-sets :as csets]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [compojure.api.sweet :refer :all]))

(def cfi-code-options #{"" "D....." "E....." "E[^P]...." "ES...." "C...." "CI..." "CB..." "(?:ES|CI|CB)..."})

(def endpoints
  (context "/api/cusip-matching" []
    {:tags ["cusip-matching"]}

    (GET "/run-edgar-jaegers-cusipless" []
      :query-params [md5 :- s/Str
                     {data-type :- (s/->EnumSchema (apply sorted-set clc/find-possible-cusips-support)) :edgar-prospectus}]
      :summary "Runs jaegers on a document then tries to link cusips.  Only use for edgar."
      (ok (clc/derive-cusips {:md5 md5} (keyword data-type))))

    (GET "/rebuild-cik-cusip-6/cik" []
      :query-params [cik :- s/Str]
      :summary "Rebuilds cik->cusip-6 collection manually.  Meant for Data-pig."
      (ok (cusip6-finder/update-cik->cusip6-database! cik)))

    (GET "/cik-to-cusip-6" []
      :query-params [ciks :- s/Str]
      :summary "Takes a list of ciks and returns all related cusip-6s"
      (ok (cik/ciks->cusip-6s [ciks])))

    (GET "/cik-to-cusip-9" []
      :query-params [cik :- s/Str
                     {field-filter :- (s/->EnumSchema (apply sorted-set clc/field-filter-fn-support)) nil}
                     {cfi-code :- (s/->EnumSchema cfi-code-options) nil}
                     {registered? :- Boolean false}]
      :summary "Takes a list of ciks and returns all related cusip-9s (edgar)."
      (ok (map :cusip (cik/ciks->cusips [cik]
                                        :field-filter field-filter
                                        :cfi-code (re-pattern (or cfi-code ""))
                                        :registered? registered?))))

    (GET "/cik-to-cusip-db" []
      :query-params [cik :- s/Str
                     {field-filter :- (s/->EnumSchema (apply sorted-set clc/field-filter-fn-support)) nil}
                     {cfi-code :- (s/->EnumSchema cfi-code-options) nil}
                     {registered? :- Boolean false}]
      :summary "Takes a list of ciks and returns all related cusip-db-docs (edgar)."
      (ok (cik/ciks->cusips [cik]
                            :field-filter field-filter
                            :cfi-code (re-pattern (or cfi-code ""))
                            :registered? registered?)))

    (GET "/ticker-to-cusip-9" []
      :query-params [ticker :- s/Str
                     {field-filter :- (s/->EnumSchema (apply sorted-set clc/field-filter-fn-support)) nil}
                     {cfi-code :- (s/->EnumSchema cfi-code-options) nil}
                     {no-figi :- Boolean false}
                     {no-cusip-db :- Boolean false}
                     {registered? :- Boolean false}]
      :summary "Takes a list of tickers and returns all related cusip-9s (edgar)."
      (ok (cik/tickers->cusips [ticker]
                               {:field-filter field-filter
                                :cfi-code     (re-pattern (or cfi-code ""))
                                :no-figi      no-figi
                                :no-cusip-db  no-cusip-db
                                :registered?  registered?})))
    (GET "/ticker-to-cusip-db" []
      :query-params [ticker :- s/Str
                     {field-filter :- (s/->EnumSchema (apply sorted-set clc/field-filter-fn-support)) nil}
                     {cfi-code :- (s/->EnumSchema cfi-code-options) nil}
                     {no-figi :- Boolean false}
                     {no-cusip-db :- Boolean false}
                     {registered? :- Boolean false}]
      :summary "Takes a list of tickers and returns all related cusip-db-docs (edgar)."
      (ok (cik/tickers->cusip-db-docs [ticker]
                                      {:field-filter field-filter
                                       :cfi-code     (re-pattern (or cfi-code ""))
                                       :no-figi      no-figi
                                       :no-cusip-db  no-cusip-db
                                       :registered?  registered?})))

    (GET "/data-for-valentines-tree" []
      :query-params [control-name :- (s/->EnumSchema (apply sorted-set (keys csets/control-sets)))]
      :summary "Takes a training-set and displays info on how it did during the last jaegerization for cusip-linking"
      (ok (cls/statistical-data control-name)))))