(ns soda-jerk-ws.services.job-debugging
  (:require [clojure.edn :as edn]
            [clojure.java.io :as io]
            [clojure.string :as str]
            [pipeline.mock-job :as mock]
            [ring.swagger.upload :as upload]
            [ring.middleware.multipart-params :as multi-part]
            [ring.util.http-response :refer :all]
            [ring.util.io :as rio]
            [schema.core :as s]
            [compojure.api.sweet :refer :all])
  (:import [java.util.zip DeflaterInputStream InflaterInputStream]))

(defn wrap-result-as-file [result compress?]
  (-> result
      (cond-> compress? DeflaterInputStream.)
      ok
      (update :headers conj
              {"Content-Type"        "application/edn"
               "Accept-Ranges"       "bytes"
               "Content-Disposition" (str "attachment; filename=ramen." (if compress? "zip" "edn") ";")})))

(defn string->input-stream [string]
  (rio/piped-input-stream (fn [os] (spit os string))))

(defn insta-job->stream [insta-job]
  (-> insta-job
      pr-str
      (str/replace #"#object\[org\.bson\.types\.ObjectId 0x\w+ (\"\w{24}\")\]" second) ;; edn can't handle object-ids
      string->input-stream))

(defn stream->insta-job [insta-stream]
  (-> insta-stream slurp edn/read-string))

(def endpoints
  (context "/job-debugging" []
    {:tags ["job debugging"]
     :summary "Tools to help with debugging jobs."}

    (GET "/generate-job-instance" []
      :query-params [job-id :- s/Str
                     {compress :- s/Bool true}]
      :summary "Uses a job-id to create a ready-to-run job instance."
      (-> job-id
          mock/make-insta-job
          insta-job->stream
          (wrap-result-as-file compress)))

    (POST "/run-job-instance" []
      :multipart-params [job-instance :- upload/TempFileUpload
                         {compressed :- s/Bool nil}]
      :middleware [multi-part/wrap-multipart-params]
      :return {s/Keyword s/Any}
      :summary "Runs a job instance, returning any results or errors."
      (let [file (:tempfile job-instance)
            compressed? (if (some? compressed)
                          compressed
                          (-> job-instance :filename (str/ends-with? ".zip")))
            _ (prn job-instance compressed?)
            result (-> file
                       io/input-stream
                       ((if compressed? #(InflaterInputStream. %) identity))
                       stream->insta-job
                       mock/run-insta-job
                       ok)]
        (.delete file)
        result))))