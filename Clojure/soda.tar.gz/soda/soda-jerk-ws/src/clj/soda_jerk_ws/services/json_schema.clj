(ns soda-jerk-ws.services.json-schema
  (:require [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda-data-model.json-schema :as schemas]
            [compojure.api.sweet :refer :all]))

(def end-points
  (context "/json-schema" []
    {:tags ["JSON Schema"]}

    (GET "/schemas" []
      :summary "Returns the enumeration of schemas"
      (ok (->> schemas/security-and-entity-schemas keys (map name))))

    (GET "/schema/:type" []
      :path-params [type :- (->> schemas/security-and-entity-schemas
                                 keys
                                 (map name)
                                 (apply s/enum))]
      :summary "Returns the json schema for a particular security type"
      (ok (schemas/security-and-entity-schemas (keyword type))))))