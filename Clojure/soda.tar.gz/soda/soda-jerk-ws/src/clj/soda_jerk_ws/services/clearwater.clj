(ns soda-jerk-ws.services.clearwater
  (:require [clojure.string :refer [includes? lower-case starts-with?]]
            [datasources.core :as ds]
            [ecs.core :as ecs]
            [ecs.schema :as cs]
            [jaegers.soda-pipe :as pipe]
            [monger.collection :as mc]
            [monger.db :as mdb]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.data.core :as sdc]
            [soda-jerk-ws.services.prospectus-api :refer [submit-prospectus]]
            [compojure.api.sweet :refer :all])
  (:import (org.bson.types ObjectId)))

(sdc/defcon "soda-raw" "data" :basename "raw-data")

(defn jaeger-doc-values [doc]
  (zipmap (keys doc) (map :value (vals doc))))

(def create-endpoints
  (context "/cwan" []
    {:tags ["cwan"]
     :summary "Clearwater Analytics"}

    (GET "/meta-docs" []
      :query-params [data-type :- s/Str]
      :summary "Return the meta-data for existing entries."
      (->> (raw-data {:meta.data-type data-type}
                     [:meta.vocabulary :meta.username
                      :meta.data-type :meta.md5 :meta.filename
                      :meta.cusip :meta.pool-number])
           (map #(-> %
                     (dissoc :meta)
                     (merge (:meta %))
                     (update :_id str)))
           ok))

    (GET "/document" []
      :query-params [id :- s/Str]
      :return cs/Entry
      :summary "Return an existing entry based on document id."
      (ok (when-let [entity (find-raw-data {:_id (ObjectId. id)})]
            (-> entity
                ecs/to-meta-and-ecs-maps
                cs/coerce-entry
                (assoc-in [:meta :_id] (-> entity :_id str))
                (dissoc entity :_id)))))

    (GET "/documents" []
      :query-params [md5 :- s/Str
                     vocab :- s/Str]
      :return cs/Entries
      :summary "Return existing entries based on vocab and md5."
      (->> (raw-data {:meta.md5 md5
                      :meta.vocabulary vocab})
           (map ecs/to-meta-and-ecs-maps)
           (map cs/coerce-entry)
           (map #(update-in % [:meta :_id] str))
           ok))

    (GET "/jaeger-docs" []
      :query-params [md5 :- s/Str
                     {cusip :- s/Str nil}]
      :return [{:jaeger-doc {s/Keyword s/Any}
                :meta {s/Keyword s/Any}
                s/Keyword s/Any}]
      :summary "Return jaeger-docs for a given md5."
      (ok (pipe/*query->jaeger-data (if cusip {:md5s [md5] :cusips [cusip]}
                                              {:md5s [md5]}))))

    (GET "/jaeger-stats" []
      :query-params [collection :- s/Str]
      :return [{:jaeger-doc {s/Keyword s/Any}
                :meta {s/Keyword s/Any}
                s/Keyword s/Any}]
      :summary "Return jaeger-docs from a collection."
      (->> (mc/find-maps (ds/get-db "mekadragon") collection)
           (map #(-> %
                     (update :meta select-keys [:filename :md5])
                     (update :_id str)
                     (update :jaeger-doc jaeger-doc-values)))
           ok))

    (GET "/jaeger-filenames" []
      :query-params [collection :- s/Str]
      :summary "Return the distinct filenames and md5s for the jaeger-docs from a collection."
      (->> [:meta.md5 :meta.filename :meta.vocabulary :meta.username]
           (mc/find-maps (ds/get-db "mekadragon") collection {})
           (map #(update % :_id str))
           ok))

    (GET "/jaeger-collections" []
      :query-params []
      :summary "Returns a list of jaeger collections."
      (-> "mekadragon"
          ds/get-db
          mdb/get-collection-names
          ok))

    (GET "/matching-document-names" []
      :query-params [filename :- s/Str]
      :return       [s/Str]
      :summary      "Return list of entered documents. A matching string can be provided."
      (let [all-docs (->> (raw-data)
                          (map (comp :filename :meta))
                          (filter identity)
                          distinct sort vec)]
        (ok (cond->> all-docs
                     filename (filter #(starts-with? (lower-case %) (lower-case filename)))))))

    (POST "/submit_prospectus" []
      :return {:success? s/Bool
               (s/optional-key :success-image) (s/maybe s/Str)
               :bid s/Str
               :message s/Str}
      :body [body s/Any]
      :summary "Submit a prospectus map."
      (let [entry (update body :meta dissoc :_id)
            {:keys [msg bid]} (submit-prospectus entry)]
        (ok {:success? (some? bid), :bid bid, :message msg})))))