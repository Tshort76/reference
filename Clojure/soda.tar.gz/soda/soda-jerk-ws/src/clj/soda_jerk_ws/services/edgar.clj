(ns soda-jerk-ws.services.edgar
  (:require [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.data.file-system :as files]
            [soda.data.identifiers :as identifiers]
            [compojure.api.sweet :refer :all]))

(defn edgarsearch [q n]
  (let [res (->> q
                 (into {:file-type :edgar-prospectus})
                 files/find-all-meta
                 (map (fn [{:keys [cusips cik] :as m}]
                        (update
                          (into
                            (select-keys m [:filename :md5 :_id])
                            {:cik (or cik "") :cusips (or cusips [])})
                          :_id str))))]
    {:n (count res) :results (cond->> res (not (neg? n)) (take n))}))

(defn files-from-cusip [cusip name-only?]
  (->> cusip
       identifiers/get-identifiers-by-cusip
       ((fn [ids] (if name-only? (map :filename ids) ids)))
       set))

(def services
  (context "/edgar" []
    {:tags ["edgar"]}

    (GET "/find/:id-type/:rgx/:max-results" []
      :path-params [id-type :- (s/enum "cik", "cusips"), rgx :- s/Str, max-results :- s/Int]
      :return {:n s/Int :results [{:_id s/Str :cik s/Str :filename s/Str :md5 s/Str :cusips [s/Str]}]}
      :summary "Find records for an identifier given a regex"
      (ok (edgarsearch {(->> id-type keyword) { :$regex rgx }} max-results)))

    (GET "/files/:cusip" []
      :path-params [cusip :- s/Str]
      :return #{s/Str}
      :summary "Get all source files that contain information about a cusip"
      (ok (files-from-cusip cusip true)))

    (GET "/files/:cusip/:name-only" []
      :path-params [cusip :- s/Str, name-only :- s/Bool]
      :return #{s/Any}
      :summary "Get all source files (and optionally, other data) that contain information about a cusip"
      (ok (files-from-cusip cusip name-only)))))