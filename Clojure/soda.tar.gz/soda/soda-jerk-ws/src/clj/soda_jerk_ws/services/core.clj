(ns soda-jerk-ws.services.core
  (:require [compojure.api.sweet :as sweet]
            [compojure.core :as cc]
            [ring.util.http-response :refer :all]
            [soda-jerk-ws.services.analytics :as analytics]
            [soda-jerk-ws.services.analyst-python :as py]
            [soda-jerk-ws.services.api-cacher :as api-cacher]
            [soda-jerk-ws.services.clearwater :as clearwater-services]
            [soda-jerk-ws.services.cusip-db :as cusip-db]
            [soda-jerk-ws.services.cusip-matching :as cusip-matching]
            [soda-jerk-ws.services.edgar :as edgar]
            [soda-jerk-ws.services.entity :as entity]
            [soda-jerk-ws.services.execute :as execute]
            [soda-jerk-ws.services.expectations :as expectations]
            [soda-jerk-ws.services.figi :as figi]
            [soda-jerk-ws.services.ice :as ice]
            [soda-jerk-ws.services.jaeger-stats :as jaeger-stats]
            [soda-jerk-ws.services.job-debugging :as job-debugging]
            [soda-jerk-ws.services.json-schema :as json-schema]
            [soda-jerk-ws.services.overmind :as overmind-services]
            [soda-jerk-ws.services.overrides :as overrides]
            [soda-jerk-ws.services.publish :as publish]
            [soda-jerk-ws.services.relay :as relay]
            [soda-jerk-ws.services.scrapers :as scrapers]
            [soda-jerk-ws.services.security :as security]
            [soda-jerk-ws.services.status :as status-services]
            [soda-jerk-ws.services.surveyor :as surveyor]
            [soda-jerk-ws.services.system :as system]
            [soda-jerk-ws.services.unresolved-failures :as unresolved-failures]
            [soda-jerk-ws.services.us-bank-debug :as us-bank]
            [soda-jerk-ws.services.utilities :as utilities]
            [soda-jerk-ws.services.workers :as workers]
            [taoensso.timbre :as log]
            [uploader.ws :as uploader]
            [util.auth.middleware :as auth]
            [util.platform :as platform])
  (:import (org.bson.types ObjectId)))

;Encodes bson ids as strings.
(cheshire.generate/add-encoder ObjectId cheshire.generate/encode-str)

(defn excep-handler [^Exception e & _]
  (log/error e)
  (throw e))

(def service-routes
  (sweet/api
    {:swagger    {:ui   "/swagger-ui"
                  :spec "/swagger.json"
                  :data {:info {:version     (platform/project-version "soda-jerk-ws")
                                :title       "SoDa Jerk ws"
                                :description "Web Service for serving data to internal users and/or applications"}}}
     :exceptions {:handlers {:compojure.api.exception/default excep-handler}}}
    (sweet/GET "/auth-redirect-landing" []
      :summary "Page used for redirect by auth-ws."
      ;handling of the jwt query param and persisting logged in state is handled by the auth middleware
      (ok {:message "Logged in. Please make your request again."}))
    (sweet/ANY "/logout" []
      :summary "Log out the current user."
      (auth/logout-response))
    #'api-cacher/services
    #'analytics/services
    #'py/end-points
    #'clearwater-services/create-endpoints
    #'cusip-db/end-points
    #'cusip-matching/endpoints
    #'edgar/services
    #'entity/services
    #'execute/services
    #'expectations/services
    #'figi/services
    #'ice/end-points
    #'jaeger-stats/endpoints
    #'jaeger-stats/endpoints-soda-api
    #'json-schema/end-points
    #'job-debugging/endpoints
    #'overmind-services/create-endpoints
    #'overrides/services
    #'publish/notification-services
    #'publish/publication-services
    #'relay/services
    #'scrapers/services
    #'security/services
    #'status-services/end-points
    #'surveyor/services
    #'system/services
    #'unresolved-failures/services
    #'uploader/create-endpoints
    #'us-bank/end-points
    #'utilities/services
    #'workers/services))