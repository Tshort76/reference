(ns soda-jerk-ws.services.synthahaul
  (:require [pipeline.synthetic :as synth]
            [ring.swagger.upload :as upload]
            [ring.middleware.multipart-params :as multi-part]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [uploader.core :as up]
            [compojure.api.sweet :refer :all]))

(defn configure-args [{:keys [filename content-type tempfile]} file-type]
  {:file tempfile :meta {:upload-type (keyword file-type)
                         :filename filename
                         :content-type content-type}})

(def filetype-enum (s/->EnumSchema (up/uploadable-types)))

(defn delete-tempfile [file]
  (-> file :tempfile .delete))

(defn pipe-then-delete [files->types]
  (let [result (synth/synthetic-files-pipe (mapv configure-args (keys files->types) (vals files->types)))]
    (run! delete-tempfile (keys files->types))
    result))

(def create-endpoints
  (context "/synthahaul" []
    {:tags ["synthahaul"]
     :summary "The synthetic data pipeline."}

    (POST "/upload-1" []
      :multipart-params
      [file0 :- upload/TempFileUpload file-type0 :- filetype-enum]
      :middleware [multi-part/wrap-multipart-params]
      :return [{s/Keyword s/Any}]
      :summary "Upload a file to process."
      (ok (pipe-then-delete {file0 file-type0})))

    (POST "/upload-2" []
      :multipart-params
      [file0 :- upload/TempFileUpload file-type0 :- filetype-enum
       file1 :- upload/TempFileUpload file-type1 :- filetype-enum]
      :middleware [multi-part/wrap-multipart-params]
      :return [{s/Keyword s/Any}]
      :summary "Upload 2 files to be processed."
      (ok (pipe-then-delete {file0 file-type0
                             file1 file-type1})))

    (POST "/upload-3" []
      :multipart-params
      [file0 :- upload/TempFileUpload file-type0 :- filetype-enum
       file1 :- upload/TempFileUpload file-type1 :- filetype-enum
       file2 :- upload/TempFileUpload file-type2 :- filetype-enum]
      :middleware [multi-part/wrap-multipart-params]
      :return [{s/Keyword s/Any}]
      :summary "Upload 3 files to be processed."
      (ok (pipe-then-delete {file0 file-type0
                             file1 file-type1
                             file2 file-type2})))

    (POST "/upload-4" []
      :multipart-params
      [file0 :- upload/TempFileUpload file-type0 :- filetype-enum
       file1 :- upload/TempFileUpload file-type1 :- filetype-enum
       file2 :- upload/TempFileUpload file-type2 :- filetype-enum
       file3 :- upload/TempFileUpload file-type3 :- filetype-enum]
      :middleware [multi-part/wrap-multipart-params]
      :return [{s/Keyword s/Any}]
      :summary "Upload 4 files to be processed."
      (ok (pipe-then-delete {file0 file-type0
                             file1 file-type1
                             file2 file-type2
                             file3 file-type3})))

    (POST "/upload-5" []
      :multipart-params
      [file0 :- upload/TempFileUpload file-type0 :- filetype-enum
       file1 :- upload/TempFileUpload file-type1 :- filetype-enum
       file2 :- upload/TempFileUpload file-type2 :- filetype-enum
       file3 :- upload/TempFileUpload file-type3 :- filetype-enum
       file4 :- upload/TempFileUpload file-type4 :- filetype-enum]
      :middleware [multi-part/wrap-multipart-params]
      :return [{s/Keyword s/Any}]
      :summary "Upload 5 files to be processed."
      (ok (pipe-then-delete {file0 file-type0
                             file1 file-type1
                             file2 file-type2
                             file3 file-type3
                             file4 file-type4})))

    (POST "/upload-6" []
      :multipart-params
      [file0 :- upload/TempFileUpload file-type0 :- filetype-enum
       file1 :- upload/TempFileUpload file-type1 :- filetype-enum
       file2 :- upload/TempFileUpload file-type2 :- filetype-enum
       file3 :- upload/TempFileUpload file-type3 :- filetype-enum
       file4 :- upload/TempFileUpload file-type4 :- filetype-enum
       file5 :- upload/TempFileUpload file-type5 :- filetype-enum]
      :middleware [multi-part/wrap-multipart-params]
      :return [{s/Keyword s/Any}]
      :summary "Upload 6 files to be processed."
      (ok (pipe-then-delete {file0 file-type0
                             file1 file-type1
                             file2 file-type2
                             file3 file-type3
                             file4 file-type4
                             file5 file-type5})))))