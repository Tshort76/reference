(ns soda-jerk-ws.services.api-cacher
  (:require [clojure.pprint :as pp]
            [datasources.core :as ds]
            [monger.collection :as mc]
            [pipeline.api-cacher :as ac]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [compojure.api.sweet :refer :all]
            [analysis.daily-delta :as dd])
  (:import (clojure.lang ExceptionInfo)))

(defn path-params->param-map [path path-params]
  (let [template-parts (map #(subs % 1 (dec (count path))) (clojure.string/split (or path "") #"/"))
        path-parts (clojure.string/split (or path-params "") #"/")]
    (when (= (count template-parts) (count path-parts))
      (zipmap template-parts path-parts))))

(defn exception->response [e]
  (internal-server-error
    (cond (instance? ExceptionInfo e) {:error (.getMessage e) :error-data (ex-data e)}
          (instance? Exception e) {:error (.getMessage e)
                                   :error-data {:type (.getName (class e))
                                                :exception-as-string (with-out-str (pp/pprint e))}}
          :else {:error "Unknown Error" :error-data {}})))

(defn fastest-response
  "Tries to hit the endpoint, and retrieve from cache. "
  [{{:keys [url-map param-map timeout]} :params :as request}]
  (let [opts (when timeout {:timeout (Long/parseLong timeout)})
        fresh-error (promise)
        fresh-response (delay (try (ac/fresh-api-hit param-map url-map opts)
                                   (catch Exception e (deliver fresh-error e) nil)
                                   (finally (deliver fresh-error nil))))
        cached-response (delay (ac/get-cached-response url-map param-map))
        fastest (promise)]
    (future (deliver fastest (:data @fresh-response))
            (when @fresh-response
              (ac/cache-the-response @fresh-response (:cache-collection url-map) (:history-collection url-map))))
    (future (deliver fastest (:data @cached-response)))
    (if @fastest
      (ok (:data @fastest))
      (if-let [result (or (:data @fresh-response) (:data @cached-response))] ;result = slowest between API and cache data
        (ok result)
        (exception->response @fresh-error)))))

(defn url-map-middleware
  "Middle-ware function to add url-map to request.  Shorts with bad request if cache-name is bad."
  [handler]
  (fn [{{:keys [cache-name]} :params :as request}]
    (if-let [url-map (ac/memoized-name->url-map cache-name)]
      (handler (assoc-in request [:params :url-map] url-map))
      (bad-request {:error (str "Cache with name " (or cache-name "nil") " does not exist.")}))))

(defn api-param-middleware
  "Middle-ware to make the param map from the path and the url-map.  Shorts with bad request if parameters don't match up."
  [handler]
  (fn [{{:keys [cache-name url-map *]} :params :as request}]
    (try
      (let [param-map (path-params->param-map (re-find #"(?<=/).*" (:path url-map)) *)]
        (handler (assoc-in request [:params :param-map] param-map)))
      (catch Exception e
        (bad-request {:problem "Wasn't able to add api-parameters"
                      :error-msg (.getMessage e)
                      :error (str e)})))))

(def services
  (context "/api-cacher" []
    {:tags ["API Cacher"]}

    (GET "/stale/:cache-name/*" {{:keys [url-map param-map]} :params :as request}
      :summary "Returns the currently-cached value, If nothing is cached attempts a fresh api hit.  Does not cache result."
      :middleware [url-map-middleware api-param-middleware]
      (if-let [cached-record (ac/get-cached-response url-map param-map)]
        (ok (:data cached-record))
        (try
          (ok (:data (ac/fresh-api-hit param-map url-map)))
          (catch Exception e (exception->response e)))))

    (GET "/cache/:cache-name/*" request
      :summary "Returns the faster truthy value between a fresh api hit and previously-cached values.  Does cache the result"
      :middleware [url-map-middleware api-param-middleware]
      (fastest-response request))

    (GET "/update/:timeout/:cache-name/*" request
      :summary "Returns the faster truthy value between a fresh api hit and previously-cached values.  Does cache the result"
      :middleware [url-map-middleware api-param-middleware]
      (fastest-response request))

    (GET "/fresh/:cache-name/*" {{:keys [url-map param-map]} :params :as request}
      :summary "Returns the value from a fresh api hit.  Does cache the result"
      :middleware [url-map-middleware api-param-middleware]
      (try (let [fresh-response (ac/fresh-api-hit param-map url-map)]
             (ac/cache-the-response fresh-response (:cache-collection url-map) (:history-collection url-map))
             (ok (:data fresh-response)))
           (catch Exception e (exception->response e))))

    (GET "/redirect/:cache-name/*" {{:keys [cache-name url-map param-map]} :params :as request}
      :summary "Redirect to the target route.  Does not cache the result."
      :middleware [url-map-middleware api-param-middleware]
      (try
        (permanent-redirect (ac/inject-vars-in-url (:url-template url-map) param-map))
        (catch Exception e (bad-request {:error-msg (.getMessage e) :error (str e)}))))

    (GET "/refresh/:cache-name" {{cache-name :cache-name {:keys [cache-collection]} :url-map} :params}
      :summary "Enqueues jobs to recache all previously cached entries."
      :middleware [url-map-middleware]
      (try
        (->> (mc/find-maps (ds/get-db ac/CACHER_DB) cache-collection {})
             (map :params)
             (ac/schedule-cache-jobs cache-name)
             count
             (hash-map :status :success :jobs-enqueued)
             ok)
        (catch Exception e (exception->response e))))

    (POST "/batch-update/:cache-name" [cache-name]
      :summary "Enqueues jobs for the given api"
      :body [body s/Any]
      (->> (ac/schedule-cache-jobs cache-name body)
           count
           (hash-map :status :success :jobs-enqueued)
           ok))
    (POST "/schedule-daily-delta" []
      :summary "Enqueues jobs for the daily delta"
      (ok (dd/schedule-daily-delta)))))