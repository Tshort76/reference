(ns soda-jerk-ws.util.scraper)
;   (:require [cheshire.core :as ch]
;             [clj-http.client :as client]
;             [clojure.string :as s]
;             [soda_jerk_ws.db.core :as ed]
;             [monger.collection :as mc])
;
; (def cookie-str "Disclaimer2=Moodys; expires=Mon, 12-Oct-2065 13:16:32 GMT; path=/")
; (def cookies (conj {} (clj-http.cookies/decode-cookie cookie-str)))
; (def state-codes
;   ["AL" "AK" "AZ" "AR" "CA" "CO" "CT" "DE" "DC" "FL" "GA" "HI" "ID" "IL" "IN" "IA" "KS"
;    "KY" "LA" "ME" "MD" "MA" "MI" "MN" "MS" "MO" "MT" "NE" "NV" "NH" "NJ" "NM" "NY" "NC"
;    "ND" "OH" "OK" "OR" "PA" "RI" "SC" "SD" "TN" "TX" "UT" "VT" "VA" "WA" "WV" "WI" "WY"
;    "GU" "MP" "PR" "VI"])
;
; (defn scrape-soda_jerk_ws-data [url]
;   (->> (client/get url {:cookies cookies})
;        :body
;        (re-find #"\Q[{\E.+\Q}]\E")
;        ch/parse-string))
;
; (def issuer-remap { "id" :id "tp" :type "itp" :issuer-type "nm" :name })
; (def issue-remap { "IID" :issue-id "IDES" :issue-description "DDT" :dated-date })
;
; (defn source-and-normalize [{:keys [raw source]} m]
;   (vec (for [record raw :let [mx (zipmap (vals m) (map record (keys m)))]]
;          (into mx { :raw record :source source }))))
;
; (defn scrape-state-data [state-code]
;   (let [url (str "http://emma.msrb.org/IssuerHomePage/State?state=" state-code)]
;     (source-and-normalize { :raw (scrape-soda_jerk_ws-data url) :source url } issuer-remap)))
;
; (defn scrape-issuer-data [issuer-id issuer-type]
;   (let [id-str (str "id=" issuer-id)
;         type-str (str "type=" issuer-type)
;         url (str "http://emma.msrb.org/IssuerHomePage/Issuer?" id-str "&" type-str)]
;     (source-and-normalize {:raw (scrape-soda_jerk_ws-data url) :source url } issue-remap)))
;
; (defn doc-matcher [s] (re-seq #"\Qhref=\E\"/(.+)\Q.pdf\E\"\Q target=\E\"\Q_blank\E\"\Q>\E(.+)\Q</a>\E" s))
;
; (defn scrape-issue-data [issuer-id]
;   (let [id-str (str "id=" issuer-id)
;         url (str "http://emma.msrb.org/IssueView/IssueDetails.aspx?" id-str)]
;     {:source url
;      :documents (->> (client/get url {:cookies cookies})
;          :body
;          doc-matcher
;          (map (juxt #(s/trim (% 2)) #(str "http://emma.msrb.org/" (% 1) ".pdf")))
;          (sort-by (juxt first second))
;          vec)}))
;
; (defn datum->soda[collection-name record]
;   (if (mc/find-one ed/db collection-name record)
;     (prn "Already have record.")
;     (do
;       (mc/insert-and-return ed/db collection-name record)
;       (prn "Added new record\n" record))))
;
; (defn data->soda[collection-name records]
;   (doseq [record records] (datum->soda collection-name record)))
;
; (defn state-data->soda[state-code]
;   (data->soda "issuers_universe" (scrape-state-data state-code)))
;
; (defn issuer-data->soda[issuer-id issuer-type]
;   (data->soda "issues_universe" (scrape-issuer-data issuer-id issuer-type)))
;
; (defn issue-data->soda[issue-id]
;   (data->soda "issue_universe" [(scrape-issue-data issue-id)]))
;
; (defn update-emma-issuers-universe-by-state [state-code]
;   { state-code (count (state-data->soda state-code)) })
;
; (defn update-emma-issuers-universe []
;   (reduce into (map update-emma-issuers-universe-by-state state-codes)))
;
; (defn update-emma-issues-universe []
;   (doseq [issuer (mc/find-maps ed/db "issuers_universe")
;           :let [inserted-data (issuer-data->soda (:id issuer) (:type issuer))]]
;     (if (empty? inserted-data)
;       (prn (str "Data already up to date for " issuer))
;       (prn (str "Inserted issues data for " issuer)))))
;
; (defn update-emma-issue-universe []
;   (->> (mc/find-maps ed/db "issues_universe")
;        (take 1000)
;        (map :issue-id)
;        (map issue-data->soda)))
;
; (defn doc-matcher [line]
;   (first (filter #(re-find #"\QOfficial Statement \E" (:doc-description %))
;                  (for [[_ doc-name doc-description]
;                        (re-seq #"\Qhref=\E\"/(.+\Q.pdf\E)\"\Q target=\E\"\Q_blank\E\"\Q>\E(.+)\Q</a>\E" line)]
;                    {:doc-name doc-name :doc-description (s/trim doc-description)}))))
;
; (defn get-prospectus-filename [cusip]
;   (->> (client/get (str "http://emma.msrb.org/Main/QuickSearch?quickSearchText=" cusip) {:cookies cookies})
;        :body doc-matcher :doc-name))
