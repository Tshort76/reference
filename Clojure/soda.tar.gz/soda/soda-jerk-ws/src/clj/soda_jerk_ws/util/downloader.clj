(ns soda-jerk-ws.util.downloader
  (:require [clojure.java.io :as cjio]
            [ring.util.io :as rio]
            [ring.util.response :as r]
            [pantomime.mime :refer [mime-type-of]]
            [soda.data.file-system :as sdfs]))

;; {headers {thing thing1 thing2 thing3}

(defn add-headers-to-response [response headers]
  (conj response {:headers (conj (:headers response) headers)}))

(defn get-content-type [info]
  (let [mime (some-> (:filename info) mime-type-of)]
    (if (and mime (not= mime "application/octet-stream"))
      mime
      (or (:mime-type info) "text/plain"))))

;Accept-Ranges:bytes
;Content-Length:120166
;Content-Location:http://www.cmhc-schl.gc.ca/incibuin/2014/02/96500215.pdf
;Content-Type:application/pdf

;;MSR this is really ugly, but I kept having
;;compiler errors using -> macro with
;;(fn arguments)
(defn get-file-from-mongo
  [search-map]
  (if-let [info (sdfs/find-file search-map)]
    (let [stream (->> info
                      :input-stream
                      (partial cjio/copy)
                      rio/piped-input-stream)
          headers {"Content-Type"        (get-content-type info)
                   "Accept-Ranges"       "bytes"
                   "Accept-Encoding"     "gzip"
                   "Content-Disposition" (str "inline; filename=\"" (:filename info) "\"")}
          response (r/response stream)]
      (add-headers-to-response response headers))
    (r/not-found search-map)))
