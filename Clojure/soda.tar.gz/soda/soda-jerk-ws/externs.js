var hljs = function(){};
hljs.highlightBlock = function(id){};
hljs.animate = function(css, px){};
var vis = function(){};
vis.DataSet = function(data){};
vis.Network = function(elem, data, options){};
var Plotly = {};
Plotly.newPlot = function(elem, data, layout){};
