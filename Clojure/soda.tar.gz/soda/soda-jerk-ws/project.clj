(defproject
  com.clearwateranalytics/soda-jerk-ws "1.49-SNAPSHOT"
  :description "soda-jerk-ws is the web UI for prospectus data"
  :parent-project {:coords  [com.clearwateranalytics/soda-meta-parent "0.2-SNAPSHOT"]
                   :inherit [:global-vars
                             :license
                             :managed-dependencies
                             :min-lein-version
                             :parent
                             :url
                             :javac-options]}
  :dependencies
  [[cheshire]
   [clj-fuzzy]
   [clj-http]
   [clj-time]
   [cljs-ajax]
   [cljs-http]
   [cljsjs/plotly]
   [com.cemerick/clojurescript.test]
   [com.cemerick/drawbridge :exclusions [ring/ring-core commons-io]]
   [com.clearwateranalytics/overmind "1.46-SNAPSHOT" :exclusions [org.slf4j/slf4j-nop com.fzakaria/slf4j-timbre]]
   [com.clearwateranalytics/soda-common "1.46-SNAPSHOT" :exclusions [org.slf4j/slf4j-nop com.fzakaria/slf4j-timbre]]
   [com.clearwateranalytics/soda-pipeline "1.47-SNAPSHOT" :exclusions [org.slf4j/slf4j-nop com.fzakaria/slf4j-timbre]]
   [com.cognitect/transit-clj "0.8.319"]
   [com.cognitect/transit-cljs "0.8.256"]
   [com.fasterxml.jackson.core/jackson-databind]            ;; necessary to prevent this error: https://www.cvedetails.com/cve/CVE-2018-7489/
   [com.google.guava/guava "28.2-jre"]
   [com.novemberain/monger :exclusions [com.google.guava/guava]] ; https://github.com/luminus-framework/luminus-template/issues/288
   [com.novemberain/pantomime]
   [com.taoensso/timbre]
   [org.slf4j/slf4j-api]
   [org.slf4j/log4j-over-slf4j]
   [org.slf4j/jul-to-slf4j]
   [org.slf4j/jcl-over-slf4j]
   [compojure]
   [environ]
   [hipo]
   [javax.servlet/javax.servlet-api :scope "provided"]
   [luminus-immutant :exclusions [org.jboss.logging/jboss-logging ch.qos.logback/logback-classic]]
   [luminus-nrepl]
   [markdown-clj]
   [medley]
   [metosin/compojure-api]
   [metosin/muuntaja]
   [metosin/ring-http-response]
   [metosin/ring-swagger-ui]
   [org.clojure/clojure]
   [org.clojure/clojurescript "1.10.597" :scope "provided"]
   [org.clojure/core.async]
   [org.clojure/tools.nrepl]
   [org.clojure/tools.reader "1.3.2"]
   [org.webjars.bower/mermaid]
   [org.webjars/bootstrap]
   [org.webjars/font-awesome]
   [org.webjars/highlightjs]
   [org.webjars/jquery]
   [org.webjars/visjs]
   [prismatic/schema]
   [prone]
   [reagent-utils "0.3.3"]
   [reagent "0.8.1"]
   [ring]
   [ring-middleware-format]
   [ring-webjars]
   [ring/ring-defaults]
   [clj-commons/secretary "1.2.4"]
   [selmer]]

  :plugins
  [[lein-parent "0.3.4"]
   [lein-environ "1.1.0"]
   [lein-cljsbuild "1.1.7"]
   ;; Temporary fix for https://github.com/sattvik/leinjacker/issues/14
   ;; which breaks the uberwar build. Remove leinjacker dependency when this issue has a fix release.
   [kirasystems/leinjacker "0.4.3"]
   [lein-modules "0.3.11"]
   [lein-ring "0.12.5"]
   [lein-pprint "1.2.0"]
   [com.clearwateranalytics/lein-cwan-alpha "0.2.11"]]

  ;; The following is used when the class path is too long (error 206 on Windows)
  :eval-in ~(if (= "Linux" (System/getProperty "os.name")) :subprocess :classloader)

  ; :offline? true
  :aot :all

  :repositories ^:replace [["releases" {:url "https://artifactory.arbfund.com/releases-group"}]
                           ["snapshots" {:url "https://artifactory.arbfund.com/snapshots-group"}]]

  :source-paths ["src/clj" "src/cljc" "src/cljs"]
  ; :test-paths ["test/clj"]

  :packaging "war"

  :jvm-opts ["-server"]
  :resource-paths ["resources" "target/cljsbuild"]

  :main soda-jerk-ws.core

  :war-resources-path "src/main/webapp"

  :ring {:handler soda-jerk-ws.handler/app
         :init    soda-jerk-ws.handler/init
         :destroy soda-jerk-ws.handler/destroy}

  :clean-targets ^{:protect false} [:target-path
                                    [:cljsbuild :builds :app :compiler :output-dir]
                                    [:cljsbuild :builds :app :compiler :output-to]]

  :cljsbuild
  {:builds
   {:app
    {:source-paths ["src/cljs" "src/cljc"]
     :compiler     {:main          "soda-jerk-ws.app"
                    :output-dir    "resources/public/js/out"
                    :output-to     "resources/public/js/soda_jerk_ws.js"
                    :asset-path    "/js/out"
                    :optimizations :none
                    :pretty-print  true
                    :externs       ["react/externs/react.js" "externs.js"]}}}}

  :figwheel {:http-server-root "public"
             :server-port      3449
             :nrepl-port       7002
             :css-dirs         ["resources/public/css"]
             :ring-handler     soda-jerk-ws.handler/app}

  :profiles
  {:uberjar       {:omit-source    true
                   :env            {:production true}
                   :hooks          [leiningen.cljsbuild]
                   :cljsbuild      {:builds
                                    {:app
                                     {:source-paths ["env/prod/cljs"]
                                      :compiler     {:source-map    "resources/public/js/soda_jerk_ws.js.map"
                                                     :optimizations :simple
                                                     :pretty-print  false}}}}
                   :aot            :all
                   :uberjar-name   "soda-jerk-ws.jar"
                   :source-paths   ["env/prod/clj"]
                   :resource-paths ["env/prod/resources"]}
   :dev           [:project/dev :profiles/dev]
   :test          [:project/test :profiles/test]
   :project/dev   {:dependencies   [[ring/ring-mock "0.3.2"]
                                    [ring/ring-devel "1.6.3"]
                                    [pjstadig/humane-test-output "0.8.3"]
                                    [cider/piggieback "0.4.2"]
                                    [figwheel-sidecar "0.5.18"]]
                   :repl-options   {:nrepl-middleware [cider.piggieback/wrap-cljs-repl]}
                   :plugins        [[lein-figwheel "0.5.18"]
                                    [lein-doo "0.1.7" :exclusions [org.clojure/clojure]]
                                    [org.clojure/clojurescript "1.10.238"]]
                   :injections     [(require 'pjstadig.humane-test-output)
                                    (pjstadig.humane-test-output/activate!)]
                   :env            {:dev        "true"
                                    :port       "3000"
                                    :nrepl-port "7000"}
                   :cljsbuild      {:builds
                                    {:app
                                     {:source-paths ["env/dev/cljs"]
                                      :compiler     {:source-map    true
                                                     :optimizations :none}}}}
                   :aot            :all
                   :resource-paths ["env/dev/resources"]
                   :source-paths   ["env/dev/clj"]}
   :project/test  {:env            {:test       "true"
                                    :port       "3001"
                                    :nrepl-port "7001"}
                   :resource-paths ["test/resources"]}
   :profiles/dev  {}
   :profiles/test {}}
  :repl-options {:init (do
                         (require '[soda-common.logger :as soda-logger])
                         (soda-logger/init-logging! "com.clearwateranalytics.soda-jerk-ws"))})
