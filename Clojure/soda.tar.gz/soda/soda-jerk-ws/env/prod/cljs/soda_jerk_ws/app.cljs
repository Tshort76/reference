 (ns soda-jerk-ws.app
   (:require [soda-jerk-ws.common.core :as core]))

;;ignore println statements in prod
(set! *print-fn* (fn [& _]))

(core/init!)

