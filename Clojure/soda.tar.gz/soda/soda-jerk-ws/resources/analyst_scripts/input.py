import sys
import json

__help = """
Example Input:
python input.py 3 4 test
"""

args = sys.argv[1:] # drop the python filename

if len(args) == 0:
    print(__help)
else:
    total = 0
    badargs = []
    for arg in args:
        try:
            total = total + int(arg)
        except ValueError as e:
            badargs.append(arg)
            
    ret = {"total":total,"non-int-args":badargs,"args":args}
    json.dump(ret,sys.stdout)