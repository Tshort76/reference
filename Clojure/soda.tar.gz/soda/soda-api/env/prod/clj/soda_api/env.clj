(ns soda-api.env
  (:require [taoensso.timbre :as log]))

(def defaults
  {:init       (fn [] (log/info "-=[soda-api started successfully]=-"))
   :middleware identity})
