(ns soda-api.dev-middleware
  (:require [clojure.stacktrace :as stack]
            [soda-api.layout :refer [*app-context* error-page]]
            [ring.middleware.reload :refer [wrap-reload]]
            [selmer.middleware :refer [wrap-error-page]]
            [taoensso.timbre :as log]
;;             [prone.middleware :refer [wrap-exceptions]]
            ))


(defn wrap-internal-error [handler]
  (fn [req]
    (try
      (handler req)
      (catch Throwable t
        (log/error "CAUGHT EXCEPTION: "
                   (with-out-str (stack/print-stack-trace t)))
        (error-page {:status 500
                     :title "Something very bad has happened!"
                     :message "We've dispatched a team of highly trained gnomes to take care of the problem."})))))


(defn wrap-dev [handler]
  (-> handler
      wrap-reload
      wrap-error-page
      wrap-internal-error
;;       wrap-exceptions
      ))
