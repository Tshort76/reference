(ns soda-api.env
  (:require [selmer.parser :as parser]
            [taoensso.timbre :as log]
            [soda-api.dev-middleware :refer [wrap-dev]]))

(def defaults
  {:init
   (fn []
     (parser/cache-off!)
     (log/info "\n-=[soda-api started successfully using the development profile]=-"))
   :middleware wrap-dev})
