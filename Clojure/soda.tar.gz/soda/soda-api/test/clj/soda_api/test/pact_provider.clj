(ns soda-api.test.pact-provider
  (:require [clojure.test :refer :all]
            [datasources.core :as ds]
            [soda-api.core :as core]
            [soda-api.test.pact-utils :as pact]
            [monger.collection :as mc])
  (:import (java.net ServerSocket)))

; Tests in this namespace are connected to fongo because
; the fongo key is set to true in profiles/test env key

(defn get-free-port []
  (with-open [socket (ServerSocket. 0)]
    (.getLocalPort socket)))

(def test-port (get-free-port))

; Inserts unit test entities into fongo
(defn insert-test-entities [entities]
  (mc/insert-batch
    (ds/get-db "soda-normalized")
    "entity"
    (map #(assoc % :unit-test-entity true) entities)))

; Removes all unit test entities from fongo
(defn remove-test-entities []
  (mc/remove (ds/get-db "soda-normalized") "entity" {:unit-test-entity true}))

(use-fixtures
  :once
  (fn [tests]
    (core/start-app [test-port])
    (tests)
    (core/stop-app)))

; Provider-side pact test against the pact with solvency2-etl (REGU team) as a consumer.
(deftest solvency2-pact-test
  (do
    (insert-test-entities
      [{:lei    "21380063ZX54EUEMBR73"
        :Entity {:LegalName         "ICAP WCLK LIMITED"
                 :LegalJurisdiction "GB"
                 :HeadquartersAddress {:Country "GB"}}
        :meta   {:data-type             "gleif-golden-copy-level-1"
                 :date-of-applicability "2018-01-01"}}
       {:lei    "5493009UWRK48KKUD358"
        :Entity {:LegalName         "TP ICAP PLC"
                 :LegalJurisdiction "GB"
                 :HeadquartersAddress {:Country "GB"}}
        :meta   {:data-type             "gleif-golden-copy-level-1"
                 :date-of-applicability "2018-01-01"}}
       {:lei          "21380063ZX54EUEMBR73"
        :Relationship {:RelationshipStatus "ACTIVE"
                       :RelationshipType   "IS_ULTIMATELY_CONSOLIDATED_BY"
                       :StartNode          {:NodeID "21380063ZX54EUEMBR73"}
                       :EndNode            {:NodeID "5493009UWRK48KKUD358"}}
        :meta         {:data-type             "gleif-golden-copy-level-2"
                       :date-of-applicability "2018-01-01"}}])
    (let [failures (pact/verify-provider "soda-api" "solvency2-etl" test-port)]
      (is (empty? failures)))
    (remove-test-entities)))
