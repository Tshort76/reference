(ns soda-api.test.pact-utils
  (:import [au.com.dius.pact.provider ProviderInfo ConsumerInfo ProviderClient HttpClientFactory ProviderVerifier ProviderUtils DefaultVerificationReporter]
           [au.com.dius.pact.model BrokerUrlSource Interaction PactReader Pact ProviderState]
           [au.com.dius.pact.provider.broker PactBrokerClient]
           (java.util HashMap)))

; This namespace contains the infrastructure needed to easily run provider-side pact tests.
; The verify-provider function is intended to be called from a provider-side unit test.
; This could be moved to a separate test library if other projects besides soda-api need pact verification

(defn setup-provider
  [provider-name port]
  (doto (ProviderInfo. provider-name)
    (.setProtocol "http")
    (.setHost "localhost")
    (.setPort port)
    (.setPath "/")))

(defn setup-consumer
  [provider-name consumer-name]
  (doto (ConsumerInfo.)
    (.setName consumer-name)
    (.setPactSource
      (BrokerUrlSource. (str "http://pactbroker/pacts/provider/" provider-name "/consumer/" consumer-name "/latest") "http://pactbroker"))))

(defn ^Pact load-pact
  [^ConsumerInfo consumer]
  (PactReader/loadPact (.getPactSource consumer)))

(defn setup-verifier
  [^Interaction interaction ^ProviderInfo provider ^ConsumerInfo consumer]
  (letfn [(add-report-states [^ProviderVerifier verifier]
            (doseq [^ProviderState provider-state (.getProviderStates interaction)]
              (.reportStateForInteraction verifier (.getName provider-state) provider consumer true)))]
    (doto (ProviderVerifier.)
      (.initialiseReporters provider)
      (.reportVerificationForConsumer consumer provider)
      (add-report-states)
      (.reportInteractionDescription interaction))))

(defn- provider-version
  []
  (if-let [version (System/getProperty "pact.provider.version")]
      (ProviderUtils/getProviderVersion version)
      "0.0.0"))

(defn verify-provider
  "Verifies whether a provider conforms to a pact defined by a consumer"
  [provider-name consumer-name port]
  (let [provider (setup-provider provider-name port)
        consumer (setup-consumer provider-name consumer-name)
        pact (load-pact consumer)
        failures (HashMap.)
        verification-reporter DefaultVerificationReporter/INSTANCE]
    (doseq [^Interaction interaction (.getInteractions pact)
            :let [description (.getDescription interaction)
                  verifier (setup-verifier interaction provider consumer)
                  client (ProviderClient. provider (HttpClientFactory.))]]
      (.verifyResponseFromProvider verifier provider interaction description failures client)
      (.reportResults verification-reporter pact (empty? failures) (provider-version) (PactBrokerClient. "http://pactbroker" {})))
    failures))
