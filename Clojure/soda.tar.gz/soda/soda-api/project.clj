(defproject
  com.clearwateranalytics/soda-api "1.49-SNAPSHOT"
  :description "A web service to serve up data to external users and/or applications"
  :parent-project {:coords  [com.clearwateranalytics/soda-meta-parent "0.2-SNAPSHOT"]
                   :inherit [:global-vars
                             :license
                             :managed-dependencies
                             :min-lein-version
                             :parent
                             :url
                             :javac-options]}
  :dependencies
  [[cheshire]
   [com.clearwateranalytics/soda-common "1.46-SNAPSHOT" :exclusions [org.slf4j/slf4j-nop com.fzakaria/slf4j-timbre]]
   [com.clearwateranalytics/soda-pipeline "1.47-SNAPSHOT" :exclusions [org.slf4j/slf4j-nop com.fzakaria/slf4j-timbre]]
   [com.taoensso/timbre]
   [compojure]
   [environ]
   [luminus/ring-ttl-session]
   [luminus-nrepl]
   [markdown-clj]
   [metosin/compojure-api]
   [metosin/ring-http-response]
   [metosin/ring-swagger]
   [org.clojure/clojure]
   [org.clojure/tools.nrepl]
   [org.immutant/web]
   [org.slf4j/slf4j-api]
   [org.slf4j/log4j-over-slf4j]
   [org.slf4j/jul-to-slf4j]
   [org.slf4j/jcl-over-slf4j]
   [ring/ring-defaults]
   [ring/ring-servlet]
   [ring-middleware-format]
   [ring-webjars]
   [selmer]]

  :plugins
  [[lein-parent "0.3.4"]
   [lein-environ "1.1.0"]
   ;; Temporary fix for https://github.com/sattvik/leinjacker/issues/14
   ;; which breaks the uberwar build. Remove leinjacker dependency when this issue has a fix release.
   [kirasystems/leinjacker "0.4.3"]
   [lein-modules "0.3.11"]
   [lein-ring "0.12.4"]
   [lein-pprint "1.2.0"]
   [com.clearwateranalytics/lein-cwan-alpha "0.2.11"]]

  ;; The following is used when the class path is too long (error 206 on Windows)
  :eval-in ~(if (= "Linux" (System/getProperty "os.name")) :subprocess :classloader)

  :aot :all

  :repositories ^:replace
[["releases" {:url "https://artifactory.arbfund.com/releases-group"}]
 ["snapshots" {:url "https://artifactory.arbfund.com/snapshots-group"}]]

  ;Adding "env/prod/clj" gets us past install, but this should go somewhere else.
  :source-paths ["src/clj" "src/cljc" "env/prod/clj"]
  :test-paths ["test/clj"]

  :packaging "war"

  :jvm-opts ["-server"]
  :resource-paths ["resources", "test/resources"]

  :main soda-api.core

  :war-resources-path "src/main/webapp"

  :ring
  {:handler soda-api.handler/app
   :init    soda-api.handler/init
   :destroy soda-api.handler/destroy}

  :profiles
  {:uberjar       {:omit-source    true
                   :env            {:production true
                                    :dev        false}
                   :aot            :all
                   :uberjar-name   "soda-api.jar"
                   :source-paths   ["env/prod/clj"]
                   :resource-paths ["env/prod/resources"]}
   :dev           [:project/dev :profiles/dev]
   :test          [:project/test :profiles/test]
   :project/dev   {:dependencies   [[prone "1.1.2"]
                                    [ring/ring-mock "0.3.0"]
                                    [ring/ring-devel "1.6.1"]
                                    [pjstadig/humane-test-output "0.8.1"]]
                   :source-paths   ["env/dev/clj"]
                   :resource-paths ["env/dev/resources"]
                   :injections     [(require 'pjstadig.humane-test-output)
                                    (pjstadig.humane-test-output/activate!)]
                   :aot            :all
                   ;;when :nrepl-port is set the application starts the nREPL server on load
                   :env            {:dev        "true"
                                    :port       "3200"
                                    :nrepl-port "7200"}}
   :project/test  {:env          {:test       "true"
                                  :port       "3201"
                                  :nrepl-port "7201"
                                  :fongo true}
                   :dependencies [[au.com.dius/pact-jvm-provider-junit_2.12]]}
   :profiles/dev  {}
   :profiles/test {}}

  :repl-options {:init (do
                         (require '[soda-common.logger :as soda-logger])
                         (soda-logger/init-logging! "com.clearwateranalytics.soda-api"))})
