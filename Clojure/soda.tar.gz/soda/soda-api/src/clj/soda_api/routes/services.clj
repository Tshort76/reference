(ns soda-api.routes.services
  (:require [soda-api.services.corporate-actions :as corporate-actions]
            [soda-api.services.csv :as csv]
            [soda-api.services.cusip-db :as cusip-db]
            [soda-api.services.entity :as entity]
            [soda-api.services.extraction :as extraction]
            [soda-api.services.figi :as figi]
            [soda-api.services.gleif :as gleif]
            [soda-api.services.ice :as ice]
            [soda-api.services.index :as index]
            [soda-api.services.pdf :as pdf]
            [soda-api.services.report :as report]
            [soda-api.services.security :as security]
            [soda-api.services.source :as source]
            [soda-api.services.status :as status]
            [soda-api.services.ticker :as ticker]
            [ring.util.http-response :refer :all]
            [taoensso.timbre :as log]
            [util.auth.middleware :as auth]
            [compojure.api.sweet :refer :all]
            [util.platform :as platform]))

(defn excep-handler [^Exception e data request]
  (log/error e)
  (internal-server-error {:message (str "Error while processing request: " (.getMessage e))}))

(def service-routes
  (api
    {:swagger    {:ui   "/swagger-ui"
                  :spec "/swagger.json"
                  :data {:info {:version     (platform/project-version "soda-api")
                                :title       "SoDa API"
                                :description "Web Service for serving data to external users and/or applications"}}}
     :exceptions {:handlers {:compojure.api.exception/default excep-handler}}}
    (routes
      (GET "/auth-redirect-landing" []
        :summary "Page used for redirect by auth-ws."
        ;handling of the jwt query param and persisting logged in state is handled by the auth middleware
        (ok {:message "Logged in. Please make your request again."}))
      (ANY "/logout" []
        :summary "Log out the current user."
        (auth/logout-response))
      security/end-points
      index/end-points
      figi/end-points
      cusip-db/end-points
      csv/end-points
      report/end-points
      status/end-points
      entity/end-points
      corporate-actions/end-points
      gleif/end-points
      ice/end-points
      source/end-points
      ticker/end-points
      extraction/end-points
      pdf/end-points)))