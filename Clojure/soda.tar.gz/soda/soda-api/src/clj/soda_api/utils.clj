(ns soda-api.utils
  (:require
    [ring.util.http-response :refer :all]))

(defn std-response [x] (ok (or x {})))
