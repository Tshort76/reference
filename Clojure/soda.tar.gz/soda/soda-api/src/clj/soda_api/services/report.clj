(ns soda-api.services.report
  (:require [publishers.reports :as r]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda-data-model.json-schema :refer [report-schemas]]
            [compojure.api.sweet :refer :all]))

(def end-points
  (context "/report" []
    {:tags ["Reports"]}

    (GET "/13f" []
      :return s/Any
      :query-params [{bdt :- s/Str nil} {edt :- s/Str nil}]
      :summary "Returns the 13f report for the specified quarter or the report that was used to determine 13F status on a specified date"
      (ok (r/generate-report {:type :13f :bdate bdt :edate edt})))

    (GET "/schema/:type" []
      :return s/Any
      :path-params [type :- (->> report-schemas
                                 keys
                                 (map name)
                                 (apply s/enum))]
      :summary "Returns the json schema for a particular report type"
      (ok (report-schemas (keyword type))))))