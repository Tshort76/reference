(ns soda-api.services.status
  (:require [ring.util.http-response :refer :all]
            [util.app-status :as uap]
            [compojure.api.sweet :refer :all]
            [util.platform :as platform]))

(def end-points
  (context "/status" []
    {:tags ["status"]}

    (GET "/" []
      :summary "Returns the status of the soda-api web service."
      (ok (uap/status-components->status {:service         "soda-api"
                                          :project-version (platform/project-version "soda-api")
                                          :project-documentation "https://confluence.arbfund.com/display/DEV/Soda-API"}
                                         uap/file-system-status-component
                                         uap/mongo-status-component)))))