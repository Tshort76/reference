(ns soda-api.services.csv
  (:require [aggregators.core :as agg]
            [clojure.pprint :as pp]
            [clojure.string :as str]
            [clojure-csv.core :as csv]
            [ring.util.http-response :refer :all]
            [ring.util.response :as response]
            [soda.data.core :as sdc]
            [compojure.api.sweet :refer :all]))

(defn format-field [x]
  (cond (sequential? x) (str/join "," x)
        (float? x) (pp/cl-format nil "~f" x)
        (nil? x) ""
        :else x))

(defn map-list->csv [maps fields]
  (->> maps
       (map (fn [m] (map #(str (format-field (% m)))
                         (keys fields))))
       (into [(vals fields)])
       csv/write-csv))

(def instrument-fields
  (array-map
    (comp :coupon-rate first :coupon-rates) "coupon-rate"
    :pool-number "pool-number"
    (fn [x] (some-> x :coupon-frequency str/lower-case)) "coupon-frequency"
    :cusip "cusip"
    :issue-date "issue-date"
    (fn [x] (some-> x :day-count str/lower-case)) "day-count"
    :original-balance "original-balance"
    :first-coupon-date "first-coupon-date"
    :maturity-date "maturity-date"
    :floating-rate-index "floating-rate-index"
    :floating-rate-spread "floating-rate-spread"
    :underlying-issuer-names "underlying-issuer-names"
    :coupon-payment-day "coupon-payment-day"
    :country-of-domicile "country-of-domicile"
    :country-of-incorporation "country-of-incorporation"
    :country-of-issue "country-of-issue"
    :issuer-name "issuer-name"
    :currency "currency"
    :mortgage-backed "mortgage-backed"
    (fn [x] (some-> x :coupon-rate-type str/lower-case)) "coupon-rate-type"
    :payment-delay "payment-delay"))

(def factors-fields
  (array-map
    :coupon-rate "coupon-rate"
    :pool-number "pool-number"
    :cusip "cusip"
    :factor "factor"
    :begin-date "factors$begin-date"
    :monthly-interest-factor "monthly-interest-factor"
    :liquidation-value "liquidation-value"
    :partial-prepayment-value "partial-prepayment-value"
    :principal-balance-due-1-months-prior-to-maturity "principal-balance-due-1-months-prior-to-maturity"
    :principal-balance-due-2-months-prior-to-maturity "principal-balance-due-2-months-prior-to-maturity"
    :principal-balance-due-3-months-prior-to-maturity "principal-balance-due-3-months-prior-to-maturity"
    :principal-balance-due-4-months-prior-to-maturity "principal-balance-due-4-months-prior-to-maturity"
    :principal-balance-due-5-months-prior-to-maturity "principal-balance-due-5-months-prior-to-maturity"
    :wac "wac"
    :weighted-average-remaining-amortization "weighted-average-remaining-amortization"
    :weighted-interest-adjustment-date "weighted-interest-adjustment-date"
    :current-principal-amount "current-principal-amount"))

(defn agg-doc->csv-factor-rows [doc]
  (let [{:keys [coupon-rates pool-number cusip factors monthly-interest-factors prepayment-values
                principal-balance-due-forecasts weighted-average-analytics]}  doc]
    (->> (concat coupon-rates factors monthly-interest-factors prepayment-values
                 principal-balance-due-forecasts weighted-average-analytics)
         (group-by :begin-date)
         vals
         (map (partial reduce merge {:pool-number pool-number :cusip cusip})))))

(sdc/defcon "soda-normalized" "data" :basename "norm-data")
(sdc/defcon "soda-normalized" "agg-cache" :basename "agg-data")

(defn cusip->agg-doc [cusip]
  (or (find-agg-data {:cusip cusip})
      (agg/do-aggregation :cusip cusip))) ;; if it's not in the cache, build it ourselves

(defn dredge-canadian-cusips []
  (->> (norm-data {:meta.data-type :canadian-mortgage-backed-security-factors} [:cusip])
       (keep :cusip)
       (into #{})))

(defn csv-response [data filename]
  (-> data
      response/response
      (response/header "Content-Type" "text/csv")
      (response/header "Content-Disposition" (str "attachment; filename=" filename ".csv"))))

;; This is just here for canadian-mbs support.
;; We'll need to fix this if we hope to support anything else through
;; this endpoint.
(def end-points
  (context "/csv" []
    {:tags ["CSV"]}

    (GET "/instrument/canadian-mortgage-backed-security" []
      :summary "Returns CSV instrument output for canadian-mortgage-backed-security."
      (-> (dredge-canadian-cusips)
          (->> (map cusip->agg-doc))
          (map-list->csv instrument-fields)
          (csv-response "canadian-mbs")))

    (GET "/factor/canadian-mortgage-backed-security-factors" []
      :summary "Returns CSV factor output for canadian-mortgage-backed-security-factors."
      (-> (dredge-canadian-cusips)
          (->> (map cusip->agg-doc)
               (mapcat agg-doc->csv-factor-rows))
          (map-list->csv factors-fields)
          (csv-response "canadian-mbs-factors")))))