(ns soda-api.services.ice
  (:require [ring.util.http-response :refer :all]
            [compojure.api.sweet  :refer :all]
            [schema.core :as s]
            [soda-api.utils :as util]
            [medley.core :as med]
            [aggregators.ice.core :as ice]))

(def end-points
  (context
    "/ice" []
    {:tags ["ice"]}
    (GET "/cas" []
         :query-params [{cusip :- s/Str nil}
                        {isin :- s/Str nil}
                        {ticker :- s/Str nil}
                        {sedol :- s/Str nil}
                        {as-of-date :- (describe s/Str "yyyy-MM-dd") nil}
                        {include-deleted :- (describe s/Bool "whether to include events
                        with status=\"Deleted Announcement\" (defaults to false)") false}]
         :return s/Any
         :summary "Returns highest revision for each ICE CAS event prior to as-of-date for the specified identifier(s)"
         (if (every? empty? [cusip isin ticker sedol])
           (bad-request {:reason "An identifier is required (cusip, isin, ticker, or sedol)."})
           (util/std-response
             (or (ice/get-highest-revision
                   (med/assoc-some {} :cusip cusip :isin isin :ticker ticker :sedol sedol :as-of-date as-of-date)
                   :include-deleted? include-deleted)
                 []))))

    (GET "/cas/event" []
         :query-params [{id-event :- (describe s/Int "required") nil}
                        {id-revision :- (describe s/Int "optional") nil}]
         :return s/Any
         :summary "Returns all revisions ICE CAS data for an id-event."
         (if id-event
           (util/std-response
             (or (ice/get-ice-cas
                   (med/assoc-some {} :id-event id-event :id-revision id-revision))
                 []))
           (bad-request {:reason "id-event is required."})))

    (GET "/cas/all-events" []
         :return s/Any
         :summary "Returns all distinct ICE CAS id-revision/id-event pairs.
         Due to the large volume of data, avoid hitting this endpoint from Swagger-UI or a browser.
         Instead, hit this endpoint programmatically: <base-url>/ice/cas/all-events"
         (util/std-response
           (or (ice/get-all-events) [])))

    (GET "/cas/date/:date-type/:date" []
         :return s/Any
         :path-params [date-type :- (s/->EnumSchema #{"entry-date", "ex-date", "effective-date",
                                                      "record-date", "announcement-date"})
                       date :- (describe s/Str "yyyy-MM-dd")]
         :query-params [{type :- (s/->EnumSchema ice/corporate-action-types) nil}
                        {include-deleted :- (describe s/Bool "whether to include events
                        with status=\"Deleted Announcement\" (defaults to false)") false}]
         :summary "Returns highest revision for each ICE CAS event on a given day.
         Due to the large volume of data, avoid hitting this endpoint from Swagger-UI or a browser.
         Instead, hit this endpoint programmatically: <base-url>/ice/cas/date/<date-type>/<date>"
         (ok (or (ice/get-highest-revision (med/assoc-some {(keyword date-type) date} :type (when type type))
                                       :include-deleted? include-deleted) [])))

    (GET "/cas/raw/all/:id" []
         :return s/Any
         :path-params [id :- (describe s/Str "cusip, isin, ticker, or sedol")]
         :summary "Returns all revisions for raw ICE CAS events for an id."
         (ok (or (ice/get-ice-cas {:instrument.code.value id} :raw? true) [])))

    (GET "/cas/raw/:id" []
         :return s/Any
         :path-params [id :- (describe s/Str "cusip, isin, ticker, or sedol")]
         :query-params [{include-deleted :- (describe s/Bool "whether to include events
                        with status=\"Deleted Announcement\" (defaults to false)") false}]
         :summary "Returns highest revision for each raw ICE CAS event for an id."
         (ok (or (ice/get-highest-revision {:instrument.code.value id}
                                       :raw? true
                                       :include-deleted? include-deleted) [])))

    (GET "/cas/audit" []
         :query-params [{cusip :- s/Str nil}
                        {isin :- s/Str nil}
                        {ticker :- s/Str nil}
                        {sedol :- s/Str nil}
                        {as-of-date :- (describe s/Str "yyyy-MM-dd") nil}]
         :return s/Any
         :summary "Returns ICE CAS audit data prior to as-of-date for the specified identifier(s)"
         (if (every? empty? [cusip isin ticker sedol])
           (bad-request {:reason "An identifier is required (cusip, isin, ticker, or sedol)."})
           (util/std-response
             (or (ice/audit
                   (med/assoc-some {} :cusip cusip :isin isin :ticker ticker :sedol sedol :as-of-date as-of-date))
                 []))))

    (GET "/cost-basis/raw/:cusip" []
         :return s/Any
         :path-params [cusip :- (describe s/Str "cusip identifier for the security")]
         :query-params [{begin-date :- (describe s/Str "yyyy-MM-dd, inclusive") nil}
                        {end-date :- (describe s/Str "yyyy-MM-dd, inclusive") nil}]
         :summary "Returns raw ICE cost basis data for a cusip."
         (ok (or (ice/get-cost-basis cusip :begin-date begin-date :end-date end-date :raw? true) [])))

    (GET "/cost-basis/:cusip" []
         :return s/Any
         :path-params [cusip :- (describe s/Str "cusip identifier for the security")]
         :query-params [{begin-date :- (describe s/Str "yyyy-MM-dd, inclusive") nil}
                        {end-date :- (describe s/Str "yyyy-MM-dd, inclusive") nil}]
         :summary "Returns normalized ICE cost basis data for a cusip."
         (ok (or (ice/get-cost-basis cusip :begin-date begin-date :end-date end-date) [])))

    (GET "/cost-basis/all/cusips" []
         :return s/Any
         :query-params [{begin-date :- (describe s/Str "yyyy-MM-dd, inclusive") nil}
                        {end-date :- (describe s/Str "yyyy-MM-dd, inclusive") nil}]
         :summary "Returns all cusips with the last date seen within an optional date-of-applicability range."
         (ok (or (ice/get-all-cost-basis-cusips {:begin-date begin-date :end-date end-date}) [])))))
