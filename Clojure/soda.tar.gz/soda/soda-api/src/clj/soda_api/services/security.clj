(ns soda-api.services.security
  (:require [aggregators.core :as ac]
            [aggregators.derive :as ad]
            [normalizers.identifiers :as nid]
            [pipeline.aggregator :as agg]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda-api.utils :as u]
            [soda-data-model.json-schema :refer [security-and-entity-schemas]]
            [compojure.api.sweet :refer :all])
  (:import (org.bson.types ObjectId)))

(cheshire.generate/add-encoder ObjectId cheshire.generate/encode-str)

(def end-points
  (context "/security" []
    :tags ["security"]
    (GET "/audit/:identifier-type/:id" []
      ; :return (s/maybe {s/Keyword s/Any})
      :path-params [identifier-type :- (s/->EnumSchema nid/security-identifiers)
                    id :- s/Str]
      :query-params [{include-private-data? :- s/Bool nil}
                     {include-fhlmc-data? :- s/Bool nil}
                     {include-fnma-data? :- s/Bool nil}
                     {view :- (s/->EnumSchema ad/views) nil}
                     {aggregation-date :- s/Str nil}]
      :summary "Returns all sourcing and audit information for the specified security"
      (ok (ac/soda-instrument identifier-type id
                               {:audit? true
                                :view view
                                :include-private-data? include-private-data?
                                :include-fhlmc-data? include-fhlmc-data?
                                :include-fnma-data? include-fnma-data?
                                :date-limit aggregation-date})))
    (GET "/audit/:identifier-type/:id/:field" []
      :path-params [identifier-type :- (s/->EnumSchema nid/security-identifiers)
                    id :- s/Str
                    field :- s/Str]
      :query-params [{include-private-data? :- s/Bool nil}
                     {include-fhlmc-data? :- s/Bool nil}
                     {include-fnma-data? :- s/Bool nil}
                     {view :- (s/->EnumSchema ad/views) nil}
                     {aggregation-date :- s/Str nil}]
      :summary "Returns all sourcing and audit information for the specified cusip and field"
      (ok (get-in (ac/soda-instrument identifier-type id
                                       {:audit? true
                                        :view view
                                        :include-private-data? include-private-data?
                                        :include-fhlmc-data? include-fhlmc-data?
                                        :include-fnma-data? include-fnma-data?
                                        :date-limit aggregation-date})
                  [:audit-trace :valid (keyword field)])))
    (GET "/dredge/:identifier-type/:id" []
      :return (s/maybe [{s/Keyword s/Any}])
      :path-params [identifier-type :- (s/->EnumSchema nid/security-identifiers)
                    id :- s/Str]
      :query-params [{include-private-data? :- s/Bool nil}
                     {include-fhlmc-data? :- s/Bool nil}
                     {include-fnma-data? :- s/Bool nil}]
      :summary "Returns the results of dredging the data for the specified security"
      (u/std-response (agg/dredge identifier-type id {:include-private-data? include-private-data?
                                                      :include-fhlmc-data? include-fhlmc-data?
                                                      :include-fnma-data? include-fnma-data?})))
    (GET "/schema/:type" []
      :return s/Any
      :path-params [type :- (->> security-and-entity-schemas
                                    keys
                                    (map name)
                                    (apply s/enum))]
      :summary "Returns the json schema for a particular security type"
      (u/std-response (security-and-entity-schemas (keyword type))))
    (GET "/:identifier-type/:id" []
      :return (s/maybe {s/Keyword s/Any})
      :path-params [identifier-type :- (s/->EnumSchema nid/security-identifiers)
                    id :- s/Str]
      :query-params [{include-private-data? :- s/Bool nil}
                     {include-fhlmc-data? :- s/Bool nil}
                     {include-fnma-data? :- s/Bool nil}
                     {view :- (s/->EnumSchema ad/views) nil}
                     {aggregation-date :- s/Str nil}
                     {no-overrides? :- s/Bool nil}]
      :summary "Returns all security information for the specified id of a given type."
      (u/std-response (ac/soda-instrument identifier-type id
                                          {:view view
                                           :include-private-data? include-private-data?
                                           :include-fhlmc-data? include-fhlmc-data?
                                           :include-fnma-data? include-fnma-data?
                                           :date-limit aggregation-date
                                           :no-overrides? no-overrides?})))
    (GET "/:identifier-type/:id/:field" []
      :return (s/maybe s/Any)
      :path-params [identifier-type :- (s/->EnumSchema nid/security-identifiers)
                    id :- s/Str
                    field :- s/Str]
      :query-params [{include-private-data? :- s/Bool nil}
                     {include-fhlmc-data? :- s/Bool nil}
                     {include-fnma-data? :- s/Bool nil}
                     {view :- (s/->EnumSchema ad/views) nil}
                     {aggregation-date :- s/Str nil}
                     {no-overrides? :- s/Bool nil}]
      :summary "Returns a specific field for the specified id of a given type"
      (u/std-response ((keyword field)
                       (ac/soda-instrument identifier-type id
                                            {:view view
                                             :include-private-data? include-private-data?
                                             :include-fhlmc-data? include-fhlmc-data?
                                             :include-fnma-data? include-fnma-data?
                                             :date-limit aggregation-date
                                             :no-overrides? no-overrides?}))))))