(ns soda-api.services.source
  (:require [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.data.source :as source]
            [soda-data-model.json-schema :refer [report-schemas]]
            [compojure.api.sweet :refer :all]))

(def end-points
  (context "/source" []
    {:tags ["Source documents"]}

    (GET "/doc-urls" []
      :return       s/Any
      :query-params [{cusip :- s/Str nil} {pool-number :- s/Str nil}]
      :summary "Returns document links for cusip and pool-number."
      (ok (or (source/fetch-doc-urls cusip pool-number) [])))))