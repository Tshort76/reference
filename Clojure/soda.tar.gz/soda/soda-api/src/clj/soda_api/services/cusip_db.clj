(ns soda-api.services.cusip-db
  (:require [aggregators.cusip-db-agg :as cdb]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda-api.utils :as u]
            [util.auth.heimdall :as heimdall]
            [util.auth.middleware :as auth]
            [compojure.api.sweet :refer :all]
            [compojure.core :as cc]))

(def end-points
  (context "/cusip-db" []
    {:tags ["cusip-db"]
     :middleware [#(cc/wrap-routes % (auth/create-auth-middleware #{heimdall/SODA_ADMIN heimdall/SODA_CUSIPDB}))]}

    (GET "/cusip/:cusip" []
      :return (s/maybe {s/Keyword s/Any})
      :path-params [cusip :- s/Str]
      :summary "Returns all cusip-db security information for the specified cusip-9."
      (u/std-response (first (cdb/cusip-db :issue {:cusips [cusip]}))))

    (GET "/cusip-6/:cusip-6" []
      :return (s/maybe {s/Keyword s/Any})
      :path-params [cusip-6 :- s/Str]
      :summary "Returns all cusip-db information for the specified cusip-6."
      (u/std-response (first (cdb/cusip-db :issuances {:cusip-6s [cusip-6]}))))))