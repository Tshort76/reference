(ns soda-api.services.figi
  (:require [figi.core :as figi]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda-api.utils :as u]
            [compojure.api.sweet :refer :all]))

(def end-points
  (context "/figi" []
    {:tags ["figi"]}

    (GET "/:identifier-type/:id" []
      :path-params [identifier-type :- (-> figi/api-id-map keys set s/->EnumSchema)
                    id :- s/Str]
      :summary "Returns all FIGI security information for the specified id of a given type"
      (u/std-response (figi/lazily-query-figi {identifier-type id})))))