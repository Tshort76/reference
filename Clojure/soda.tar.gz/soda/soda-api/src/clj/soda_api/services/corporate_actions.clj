(ns soda-api.services.corporate-actions
  (:require [clj-http.client :as http]
            [clojure.set :as set]
            [clojure.string :as str]
            [datasources.core :as ds]
            [environ.core :refer [env]]
            [hickory.core :as hc]
            [hickory.select :as hs]
            [medley.core :refer [assoc-some find-first]]
            [monger.collection :as mc]
            [normalizers.identifiers :as nid]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.core :as soda]
            [soda.data.source :as sds]
            [soda-api.utils :as u]
            [surveyor-interop.enqueue-questions :as si]
            [taoensso.timbre :as log]
            [compojure.api.sweet :refer :all]))

(def base-surveyor-url (or (:surveyor-address env) "http://soda-surveyor:8084/surveyor/"))

;https://sashat.me/2017/01/11/list-of-20-simple-distinct-colors/
(def colors ["#e6194b" "#3cb44b" "#ffe119" "#4363d8" "#f58231" "#911eb4" "#46f0f0" "#f032e6"
             "#bcf60c" "#fabebe" "#008080" "#e6beff" "#9a6324" "#fffac8" "#800000" "#aaffc3"
             "#808000" "#ffd8b1" "#000075" "#a9a9a9"])

(defn- parse-id [id-type id]
  (if-not (#{:cik :fdic-certificate-number} id-type)
    id
    (if-let [id-long (soda/parse-long id)]
      id-long
      (throw (Exception. (str "invalid " id-type ": " id))))))

(defn- get-security-doc [identifier-type id]
  (mc/find-one-as-map (ds/get-db "soda-normalized") "agg-cache" {identifier-type id}))

(defn- get-entity-doc [identifier-type id]
  (mc/find-one-as-map (ds/get-db "soda") "entity" {identifier-type id}))

(defn- get-raw-jaegers-doc [{:keys [_id]}]
  (when _id
    (let [db (ds/get-db "soda-raw")
          {{raw-jaegers-id :_id} :meta} (mc/find-map-by-id db "data" _id)]
      (mc/find-map-by-id db "jaegers" raw-jaegers-id))))

(defn edgar-text-url->edgar-filing-detail-url [turl]
  (when (not-empty turl)
    (let [[_ base-url num-with-dashes] (re-find #"(.*)\/([^\/]+).txt" turl)
          num (str/replace num-with-dashes "-" "")]
      (when (every? not-empty [base-url num-with-dashes num])
        (str base-url "/" num "/" num-with-dashes "-index.htm")))))

(defn get-cached-form-url [edgar-text-url]
  (:form-url (mc/find-maps (ds/get-db "soda")
                           "edgar-taxability-status-source-url-to-form-url"
                           {:source-url edgar-text-url})))

(defn cache-form-url! [{:keys [source-url form-url] :as d}]
  (when (and (not-empty source-url) (not-empty form-url))
    (mc/upsert (ds/get-db "soda") "edgar-taxability-status-source-url-to-form-url"
               (select-keys d [:source-url]) d)))

(defn- get-taxability-document-link [edgar-text-url]
  (if-let [cached-form-url (get-cached-form-url edgar-text-url)]
    cached-form-url
    (when-let [form-url (some->> (edgar-text-url->edgar-filing-detail-url edgar-text-url)
                                 http/get
                                 :body
                                 hc/parse
                                 hc/as-hickory
                                 (hs/select (hs/descendant (hs/class "tableFile")
                                                           (hs/tag :tr)))
                                 (map :content)
                                 (map (fn [v] (filter map? v)))
                                 (find-first (fn [columns] (->> (nth columns 3)
                                                                :content
                                                                first
                                                                (= "S-4"))))
                                 ((fn [row] (nth row 2)))
                                 ((comp :href :attrs first :content))
                                 (str "https://www.sec.gov"))]
      (cache-form-url! {:source-url edgar-text-url :form-url form-url})
      form-url)))

(defn- assoc-rd [audit-doc]
  (if-let [{{[{:keys [url]}] :edgar} :meta :as raw-jaeger-doc} (get-raw-jaegers-doc audit-doc)]
    (assoc-some audit-doc :rd raw-jaeger-doc :source-document-url (get-taxability-document-link url))
    audit-doc))

(defn- get-custom-view [{:keys [jaeger-doc meta]}]
  (let [ids-per-class (mapv (fn [[field {:keys [docs]}]]
                              (reduce (fn [acc {:keys [ids]}] (update acc :i concat (flatten ids)))
                                      {:t (name field) :i []}
                                      docs))
                            (select-keys jaeger-doc (keys (:edgar-corporate-action si/file-type->fields))))]
    {:md5 (:md5 meta) :highlights (mapv (fn [doc color] (assoc doc :c color))
                                        ids-per-class (cycle colors))}))

(defn- get-surveyor-view-id [{:keys [md5] :as custom-view}]
  (let [{{:keys [view-id]} :body :keys [status reason-phrase]}
        (http/post
          (str base-surveyor-url "api/view/cache")
          {:content-type :json
           :as           :json
           :body         (clojure.data.json/write-str custom-view)})]
    (if-not (= 200 status)
      (log/debug (str "surveyor response code=" status
                      ", reason=" reason-phrase
                      " when creating custom view for md5=" md5))
      view-id)))

(defn- get-surveyor-view-link [view-id]
  (when (not-empty view-id)
    (str (sds/resolve-url base-surveyor-url)
         "answer-question#/custom-highlight?id=" view-id)))

(defmulti get-corporate-actions-entity
  (fn [identifier-type _]
    (cond
      (nid/security-identifiers identifier-type) :by-security
      (nid/entity-identifiers identifier-type) :by-entity
      :else :default)))

(defmethod get-corporate-actions-entity :default
  [identifier-type _]
  (throw (IllegalAccessException. (str "invalid identifier-type for corporate-action lookup. type=" identifier-type))))

(defmethod get-corporate-actions-entity :by-security
  [identifier-type id]
  (when-let [entity-keys (some-> (get-security-doc identifier-type id)
                                 :issuer
                                 (select-keys (vec nid/entity-identifiers)))]
    (some (fn [[id-type id]] (get-entity-doc id-type id)) entity-keys)))

(defmethod get-corporate-actions-entity :by-entity
  [identifier-type id]
  (get-entity-doc identifier-type id))

(defn get-corporate-actions-audit [identifier-type id]
  (when-let [{{{ca-audits :corporate-actions} :audit} :meta cas :corporate-actions}
             (get-corporate-actions-entity identifier-type id)]
    (let [ca-audits-with-rd (map assoc-rd ca-audits)
          surveyor-view-links (mapv (comp get-surveyor-view-link get-surveyor-view-id get-custom-view :rd)
                                    ca-audits-with-rd)]
      (mapv (fn [ca audit link] (assoc ca :audit (assoc (dissoc audit :rd)
                                                        :source-highlighting-url link)))
            cas ca-audits-with-rd surveyor-view-links))))

(def end-points
  (context "/corporate-actions" []
    {:tags ["corporate actions"]}

    (GET "/:identifier-type/:id" []
      :path-params [identifier-type :- (s/->EnumSchema (set/union nid/entity-identifiers
                                                                  nid/security-identifiers))
                    id :- s/Str]
      :return s/Any
      :summary "Corporate actions for legal entity specified by id."
      (u/std-response (or (:corporate-actions (get-corporate-actions-entity identifier-type (parse-id identifier-type id)))
                          [])))

    (GET "/audit/:identifier-type/:id" []
      :path-params [identifier-type :- (s/->EnumSchema (set/union nid/entity-identifiers
                                                                  nid/security-identifiers))
                    id :- s/Str]
      :return s/Any
      :summary "Source documentation for corporate actions for legal entity specified by id."
      (u/std-response (or (get-corporate-actions-audit identifier-type (parse-id identifier-type id))
                          [])))))