(ns soda-api.services.entity
  (:require [aggregators.entity.muni :as muni]
            [aggregators.entity.utils :as au]
            [datasources.core :as ds]
            [medley.core :refer [dissoc-in]]
            [monger.collection :as mc]
            [normalizers.identifiers :as nid]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.core :as soda]
            [soda.data.file-system :as fs]
            [soda.data.source :as source]
            [soda-api.utils :as u]
            [compojure.api.sweet :refer :all]))

(def id-type->schema
  {:lei                     "corp"
   :cik                     "corp"
   :cusip-6                 "muni"
   :fdic-certificate-number "corp"})

(defmulti get-entity (fn [id-type & _] (id-type->schema id-type)))

(defmethod get-entity :default
  [id-type & _]
  (throw (UnsupportedOperationException. (str "FIXME: get-entity called on id type: " id-type))))

(defmethod get-entity "corp"
  ([identifier-type id] (get-entity identifier-type id au/publishable))
  ([identifier-type id format-fn]
    (when (and id identifier-type)
      (some-> {(keyword identifier-type) id}
              ((fn [m] (if-let [[k v] (first (select-keys m [:cik :fdic-certificate-number]))]
                         (when-let [id-long (soda/parse-long v)]
                           (assoc m k id-long))
                         m)))
              ((fn [q] (mc/find-one-as-map (ds/get-db "soda") "entity" q)))
              (format-fn)))))

(defmethod get-entity "muni"
  ([_ id] (au/publishable (muni/get-muni id)))
  ([_ id format-fn]
    (when id (some-> (muni/get-muni id) (format-fn)))))

(defn get-audit-sources [audit suppress-sources?]
  (let [lookup (memoize (fn [db col id] (mc/find-map-by-id (ds/get-db db) col id)))
        lookup-meta (memoize (fn [md5] (fs/find-one-meta {:md5 md5})))]
    (clojure.walk/postwalk
      (fn [v]
        (if-not (and (map? v) (contains? v :source))
          v
          (if suppress-sources?
            (dissoc v :source)
            (let [{{:keys [_id collection database]} :source} v]
              (if-not (and _id collection database)
                (dissoc v :source)
                (let [{:keys [meta] :as src} (lookup database collection _id)
                      {:keys [md5] :as doc} (or meta src)
                      source (if md5 (lookup-meta md5)
                                     (assoc doc :database database :collection collection))]
                  (merge v {:source source})))))))
      audit)))

(defn audit-fmt [publish-fn suppress-sources? {{:keys [audit]} :meta :as entity}]
  {:full-output (publish-fn entity) :audit (get-audit-sources audit suppress-sources?)})

(defn get-entity-audit [identifier-type id suppress-sources?]
  (assoc (get-entity identifier-type id (partial audit-fmt au/publishable suppress-sources?))
         :doc-url (str (source/soda-api-base-url) "entity/" (name identifier-type) "/" id)))

(def end-points
  (context "/entity" []
    {:tags ["entity"]}

    (GET "/:identifier-type/:id" []
      :path-params [identifier-type :- (s/->EnumSchema nid/entity-identifiers)
                    id :- s/Str]
      :return s/Any
      :summary "Aggregated legal entity information."
      (u/std-response (get-entity identifier-type id)))

    (GET "/audit/:identifier-type/:id" []
      :path-params [identifier-type :- (s/->EnumSchema nid/entity-identifiers)
                    id :- s/Str]
      :query-params [{suppress-sources :- s/Bool false}]
      :return s/Any
      :summary "Returns all sourcing and audit information for the specified legal entity."
      (u/std-response (get-entity-audit identifier-type id suppress-sources)))))