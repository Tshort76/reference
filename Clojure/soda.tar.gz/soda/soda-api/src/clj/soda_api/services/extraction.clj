(ns soda-api.services.extraction
  (:require [non-soda-sources.core :as c]
            [non-soda-sources.sources :as srcs]
            [pdf-transforms-core.tokens.pdf-extractor :as ptc]
            [ring.middleware.multipart-params :as mpp]
            [ring.swagger.upload :as upload]
            [schema.core :as s]
            [uploader.core :as up]
            [compojure.api.sweet :refer :all]))

(defn file->extracted-data [file file-type]
  (-> file
      (assoc :client-data? true :upload-type file-type)
      up/upload
      vals ffirst
      (assoc :file-type file-type)
      c/extract-data))

(def end-points
  (context "/extract" []
    {:tags ["extraction"]
     :summary "Upload non-SoDa files for data extraction"}

    (POST "/file" []
      :multipart-params [file :- upload/TempFileUpload
                         file-type :- (s/->EnumSchema (apply sorted-set (keys srcs/non-soda-file-type->fields)))]
      :middleware [mpp/wrap-multipart-params]
      :return s/Any
      :summary "Accepts a file and returns the extracted contents."
      (let [response (cond (not= (:content-type file) "application/pdf")
                           {:status 400
                            :body   {:user-error "Input must be a PDF file"}}

                           (ptc/is-encrypted? (:tempfile file))
                           {:status 400
                            :body   {:user-error "Input must not be encrypted (i.e. password protected)"}}

                           :else
                           {:status 200
                            :body   (file->extracted-data file file-type)})]
        (-> file :tempfile .delete)
        response))))