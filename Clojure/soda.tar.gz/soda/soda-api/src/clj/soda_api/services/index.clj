(ns soda-api.services.index
  (:require [aggregators.index.core :as aggi]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda-api.utils :as u]
            [soda-data-model.json-schema :refer [index-schema]]
            [compojure.api.sweet :refer :all]))

(def end-points
  (context "/index" []
    :tags ["index"]
    (GET "/schema/:type" []
      :return s/Any
      :path-params [type :- (->> ["index-schema"]
                                 (apply s/enum))]
      :summary "Returns the json schema for a particular security type"
      (u/std-response index-schema))
    (GET "/:index-name" []
      :path-params [index-name :- (s/->EnumSchema (apply sorted-set aggi/index-names))]
      :query-params [{start-date :- s/Inst nil}
                     {end-date :- s/Inst nil}]
      :return s/Any
      :summary "Returns index data across a date range"
      (u/std-response (aggi/index-values-across index-name start-date end-date)))
    (GET "/:index-name/:date" []
      :path-params [index-name :- (s/->EnumSchema (apply sorted-set aggi/index-names))
                    date :- s/Inst]
      :return s/Any
      :summary "Returns single data point given a date"
      (u/std-response (aggi/index-value-on index-name date)))
    (POST "/refresh/:index-name" []
      :path-params [index-name :- (s/->EnumSchema (apply sorted-set aggi/index-names))]
      :return s/Any
      :summary "refreshes the index cache"
      (u/std-response (aggi/refresh-cache index-name)))))