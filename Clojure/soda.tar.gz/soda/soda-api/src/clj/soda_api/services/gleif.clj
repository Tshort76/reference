(ns soda-api.services.gleif
  (:require [aggregators.utils :as au]
            [clj-time.coerce :as c]
            [clj-time.core :as t]
            [datasources.core :as ds]
            [medley.core :refer [assoc-some]]
            [monger.collection :as mc]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda-api.utils :as u]
            [taoensso.timbre :as log]
            [compojure.api.sweet :refer :all]
            [normalizers.specs.gleif :as gleif-norm]))

(defn clean [norm-doc] (dissoc norm-doc :_id :meta))

(defn doa-comp-filter [as-of-date-str {{:keys [date-of-applicability]} :meta}]
  (or (empty? as-of-date-str)
      (t/before?
        (c/from-string date-of-applicability)
        (c/from-string as-of-date-str))))

(defn get-level-2 [lei as-of-date]
  (some->> (mc/find-maps (ds/get-db "soda-normalized") "entity" {:meta.data-type                  "gleif-golden-copy-level-2"
                                                                 :lei                             lei
                                                                 :Relationship.RelationshipStatus "ACTIVE"})
           (filter (partial doa-comp-filter as-of-date))
           au/latest-by-meta))

(defn get-level-1 [lei as-of-date]
  (some->> (mc/find-maps (ds/get-db "soda-normalized") "entity" {:meta.data-type "gleif-golden-copy-level-1"
                                                                 :lei            lei})
           (filter (partial doa-comp-filter as-of-date))
           au/latest-by-meta
           :Entity
           ((fn [m] (assoc m :LEI lei)))
           clean))

(defn clean-level-1 [as-of-date data]
  (some->> data
           (filter (partial doa-comp-filter as-of-date))
           (sort-by (comp :date-of-applicability :meta))
           (reduce (fn [acc {:keys [lei] :as m}] (assoc acc lei m)) {})
           vals
           (map (fn [{:keys [lei Entity]}] (assoc Entity :LEI lei)))
           (mapv clean)))

(defn search-level-1-by-name [entity-name as-of-date]
  (or (clean-level-1
        as-of-date
        (mc/find-maps (ds/get-db "soda-normalized") "entity"
                      {:meta.data-type "gleif-golden-copy-level-1"
                       "$or"           [{:Entity.LegalName entity-name}
                                        {:Entity.OtherEntityNames entity-name}]}))

      []))

(defn fuzzy-search-level-1-by-name [entity-name as-of-date permissive]
  (let [canonical-name (gleif-norm/canonize-name entity-name)]
    (or (clean-level-1
          as-of-date
          (mc/find-maps (ds/get-db "soda-normalized") "entity"
                        (assoc (if permissive
                                 {:meta.canonical-names {"$regex" canonical-name} :meta.data-type "gleif-golden-copy-level-1"}
                                 {:meta.canonical-names canonical-name}) :meta.data-type "gleif-golden-copy-level-1")))
        [])))

(defn find-ultimate-parent-lei [lei as-of-date]
  (when (not-empty lei)
    (let [up-lei (loop [leis-seen #{lei} current-lei lei]
                   (if-let [{{{r-lei :NodeID} :EndNode
                              r-type          :RelationshipType} :Relationship} (get-level-2 current-lei as-of-date)]
                     (cond
                       (leis-seen r-lei) (do (log/debug "loop detected in ultimate-parent gleif data for child-lei="
                                                        lei ", using as ultimate-parent lei=" current-lei)
                                             current-lei)
                       (= "IS_ULTIMATELY_CONSOLIDATED_BY" r-type) r-lei
                       :else (recur (conj leis-seen r-lei) r-lei))
                     current-lei))]
      (when (not= lei up-lei) up-lei))))

(defn assoc-ultimate-parent [as-of-date {:keys [LEI] :as doc}]
  (when doc
    (assoc-some doc :UltimateParent (when-let [up-lei (find-ultimate-parent-lei LEI as-of-date)]
                                      (get-level-1 up-lei as-of-date)))))

(def end-points
  (context "/gleif" []
    {:tags ["gleif"]}

    (GET "/" []
      :query-params [{lei :- s/Str nil}
                     {as-of-date :- (describe s/Str "yyyy-MM-dd, default today.") nil}]
      :return s/Any                                         ;TODO spec this?
      :summary "Gleif data, by lei, including ultimate-parent (if any)."
      (if (empty? lei)
        (bad-request {:reason "lei is required."})
        (u/std-response (or (some->> (get-level-1 lei as-of-date)
                                     (assoc-ultimate-parent as-of-date))
                            {}))))

    (GET "/ultimate-parent" []
      :query-params [{lei :- s/Str nil}
                     {as-of-date :- (describe s/Str "yyyy-MM-dd, default nil.") nil}]
      :return s/Any                                         ;TODO spec this?
      :summary "Gleif level-1 data for ultimate-parent of lei, if any."
      (if (empty? lei)
        (bad-request {:reason "lei is required."})
        (u/std-response (or (some-> (find-ultimate-parent-lei lei as-of-date)
                                    (get-level-1 as-of-date))
                            {}))))
    (GET "/search" []
      :query-params [{entity-name :- (describe s/Str "name of legal-entity") nil}
                     {as-of-date :- (describe s/Str "yyyy-MM-dd, default today.") nil}]
      :summary "Search for matching gleif records."
      (u/std-response (if (empty? entity-name) [] (->> (search-level-1-by-name entity-name as-of-date)
                                                       (mapv (partial assoc-ultimate-parent as-of-date))))))
    (GET "/fuzzy-search" []
      :query-params [{entity-name :- (describe s/Str "name of legal-entity") nil}
                     {as-of-date :- (describe s/Str "yyyy-MM-dd, default today.") nil}
                     {permissive :- (describe s/Bool "whether to use regex search (slower performance when permissive=true)") false}]
      :summary "Search for matching gleif records using a canonical name representation."
      (u/std-response
        (if (empty? entity-name)
          []
          (->> (fuzzy-search-level-1-by-name entity-name as-of-date permissive)
               (mapv (partial assoc-ultimate-parent as-of-date))))))
    (GET "/canonical-name" []
      :query-params [{entity-name :- (describe s/Str "name of legal-entity") ""}]
      :summary "Returns the input name and the canonical-name."
      (u/std-response
        {:name           entity-name
         :canonical-name (gleif-norm/canonize-name entity-name)}))
    ))