(ns soda-api.services.pdf
  (:require [non-soda-sources.visuals :as viz]
            [ring.middleware.multipart-params :as mpp]
            [ring.swagger.upload :as upload]
            [ring.util.response :as r]
            [schema.core :as s]
            [compojure.api.sweet :refer :all])
  (:import (java.io FileInputStream)))

(defn wrap-input-stream [is]
  (assoc (r/response is)
         :headers {"Content-Type"        "application/pdf"
                   "Accept-Ranges"       "bytes"
                   "Content-Disposition" "attachment; filename=annotated_doc.pdf;"}))

;TODO display format for the boundaries array
(def end-points
  (context "/annotate" []
    {:tags ["annotate"]
     :summary "Upload pdf files and a vector of boundaries to get highlights"}

    (POST "/pdf" []
      :multipart-params [file :- upload/TempFileUpload
                         bounds :- s/Any]
      :middleware [mpp/wrap-multipart-params]
      :summary "Accepts a file and a json array of boundary objects and returns an annotated pdf file."
      (if-let [boundaries (viz/parse-json-boundaries bounds)]
        (-> (:tempfile file)
            FileInputStream.
            (viz/annotated-doc boundaries)
            wrap-input-stream)
        {:status  400
         :headers {}
         :body    {:user-error "Invalid bounds, expected a json array of objects with each object containing numeric data associated with the following keys: x0, x1, y0, y1, and page-number"}}))))

; Test code for validating extraction and annotation.
(comment
  (defn extract-and-annotate
    "Performs extraction and annotation on a file and outputs the
    annotated file to your /tmp directory."
    [md5 file-type]
    (let [bounds (->> {:md5 md5 :file-type (keyword file-type)}
                      non-soda-sources.core/extract-data
                      :data
                      clojure.data.json/write-str
                      viz/parse-json-boundaries)]
      (-> {:md5 md5}
          soda.data.file-system/find-file
          :input-stream
          (viz/annotated-doc bounds)
          soda-api.services.pdf/wrap-input-stream)))

  (defn test-extract-and-annotate
    "Retrieves n random files with file-type and performs
    extraction and annotation on them. Annotated files can be
    found in your /tmp directory."
    [file-type n]
    (let [md5s (->> {:file-type file-type}
                    soda.data.file-system/find-all-meta
                    (map :md5)
                    shuffle
                    (take n))]
      (map #(extract-and-annotate % file-type) md5s)))

  ; File with text-direction 90.0
  (extract-and-annotate "4fd2c3ec50c03fe116467fa7b2185284"
                        "lp-general-partner-report")

  ; File with text-direction 0.0
  (extract-and-annotate "303ee5d88eef4e42a84dba3e8f2c2ec8"
                        "lp-general-partner-report")

  (test-extract-and-annotate "lp-general-partner-report" 3)
  (test-extract-and-annotate "blackrock-trade-ticket" 3)
  )