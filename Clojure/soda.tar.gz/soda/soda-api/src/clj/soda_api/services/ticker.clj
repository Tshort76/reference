(ns soda-api.services.ticker
  (:require [clojure.data :as data]
            [ring.util.http-response :refer :all]
            [schema.core :as s]
            [soda.data.core :as sdc]
            [soda-api.utils :as u]
            [compojure.api.sweet :refer :all]))

(sdc/defcon "soda-normalized" "data" :basename "norm")
(sdc/defcon "soda-normalized" "agg-cache" :basename "agg")

(def ids [:cusip :isin :share-class-figi])

(defn is-subset? [sub main]
  (let [[main-only sub-only] (data/diff main sub)]
    (boolean (and main-only (not sub-only)))))

(defn filter-subsets [data]
  (remove #(some (partial is-subset? %) data)
          data))

(defn ticker->ids [ticker-data]
  (->> ticker-data
       (filter (apply some-fn ids))
       (sort-by (juxt (comp :date-of-applicability :meta) :_id)
                #(compare %2 %1))
       (map #(select-keys % ids))
       distinct
       filter-subsets))

(def end-points
  (context "/ticker" []
    {:tags ["ticker"]}

    (GET "/identifiers/:ticker" []
      :path-params [ticker :- s/Str]
      :summary "Returns all security identifiers for a given ticker"
      (u/std-response (ticker->ids (norm {:primary-exchange-ticker ticker}
                                         (conj ids :meta.date-of-applicability)))))

    (GET "/agg-identifiers/:ticker" []
      :path-params [ticker :- s/Str]
      :summary "Returns all security identifiers for a given ticker"
      (u/std-response (ticker->ids (agg {:primary-exchange-ticker ticker :schema "equity-schema"}
                                        ids))))))