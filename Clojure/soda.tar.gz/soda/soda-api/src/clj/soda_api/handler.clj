(ns soda-api.handler
  (:require [analytics.metrics :as metrics]
            [compojure.core :refer [routes wrap-routes]]
            [compojure.route :as route]
            [soda-api.env :refer [defaults]]
            [soda-api.layout :refer [error-page]]
            [soda-api.middleware :as middleware]
            [soda-api.routes.home :refer [home-routes]]
            [soda-api.routes.services :refer [service-routes]]
            [soda-common.logger :as soda-logger]
            [taoensso.timbre :as log]))

(defn init
  "init will be called once when
   app is deployed as a servlet on
   an app server such as Tomcat
   put any initialization code here"
  []
  (soda-logger/init-logging! "com.clearwateranalytics.soda-api")
  (metrics/init-metric-config)
  ((:init defaults)))

(defn destroy
  "destroy will be called when your application
   shuts down, put any clean up code here"
  []
  (shutdown-agents)
  (log/info "soda-api has shutdown!"))

(def app-routes
  (routes
    (wrap-routes #'service-routes (comp metrics/wrap-api-metrics soda-logger/log-trace-wrapper))
    (wrap-routes #'home-routes middleware/wrap-csrf)
    (route/not-found
      (:body
        (error-page {:status 404
                     :title "page not found"})))))

(def app (when-not *compile-files*
           (middleware/wrap-base #'app-routes)))