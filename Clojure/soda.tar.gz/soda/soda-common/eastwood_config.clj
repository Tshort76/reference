(disable-warning
  {:linter :suspicious-expression
   :for-macro 'clojure.core/and
   :if-inside-macroexpansion-of #{'clojure.spec.alpha/keys 'clojure.spec.alpha/every}
   :within-depth 10
   :reason "clojure.spec makes calls that macro-expand to call clojure.core/and with one argument."})

(disable-warning
  {:linter :constant-test
   :if-inside-macroexpansion-of #{'monger.query/with-collection}
   :within-depth 10
   :reason "monger.query/with-collection will sometimes unecessarily check that a string is a string."})