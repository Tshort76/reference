# Introduction to soda-common

This is a test of docs.

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
