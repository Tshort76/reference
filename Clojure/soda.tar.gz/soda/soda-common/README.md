# soda-common

Common functionality for the Sourced Data project.

## Usage

The key stages of sourcing data are:
1. Chunking the data into a semi-raw format that looks like the final product with values unparsed.
2. Normalizing the data by parsing the data into actual values and then doing any required downselection or other manipulation to get a final product.

## Examples

Retrieving records from Mongo
```clojure
(-> {:meta.md5 "66f2806e089c18c659d3b88e7381318b"}
    raw/structured-instruments
    first
    parse
    :D)
```

Chunking Data
```clojure
(prn "Test")
```

## TODO


## License

Copyright © 2015 Clearwater Analytics

Distributed under the Eclipse Public License either version 1.0 or (at
your option) any later version.
