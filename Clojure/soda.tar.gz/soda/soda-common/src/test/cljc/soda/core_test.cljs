(ns soda.core-test
  (:require [clojure.test :refer :all]
            [soda.core :refer :all]))

