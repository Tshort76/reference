(ns overrides.core-test
  (:require [clojure.test :refer :all]
            [overrides.core :refer :all]))

(def data {:a 1
           :nested-map {:a 1}
           :const-array ["AAA"]
           :const-list `("AAA")
           :time-series [{:time 1 :val 1}]
           :time-list `({:time 1 :val 1})})

(deftest override-add-remove-change
  (testing "Overrides can add fields and array-elements"
    (is (= (apply-override
             data
             {:overrides [{:path [:b] :match nil :set 2} ;add field to map
                          {:path [:nested-map :b] :match nil :set 2} ;add field to nested map
                          {:path [:const-array] :where "BBB" :match nil :set "BBB"} ;add element to const array
                          {:path [:const-list] :where "BBB" :match nil :set "BBB"}
                          {:path [:time-series] :where {:time 2} :match nil :set {:time 2 :val 2}} ;add element to time series
                          {:path [:time-list] :where {:time 2} :match nil :set {:time 2 :val 2}}]})

           {:a 1 :b 2
            :nested-map {:a 1 :b 2}
            :const-array ["AAA" "BBB"]
            :const-list `("AAA" "BBB")
            :time-series [{:time 1 :val 1} {:time 2 :val 2}]
            :time-list `({:time 1 :val 1} {:time 2 :val 2})})))
  (testing "Overrides can remove fields and array-elements"
    (is (= (apply-override
             data
             {:overrides [{:path [:a] :match 1 :set nil} ;remove field from map
                          {:path [:nested-map :a] :match 1 :set nil} ;remove field from nested map
                          {:path [:const-array] :where "AAA" :match "AAA" :set nil} ;remove element from const array
                          {:path [:const-list] :where "AAA" :match "AAA" :set nil}
                          {:path [:time-series] :where {:time 1} :match {:val 1} :set nil} ;remove element from time series
                          {:path [:time-list] :where {:time 1} :match {:val 1} :set nil}]})

           {:nested-map {}
            :const-array []
            :const-list ()
            :time-series []
            :time-list ()})))
  (testing "Overrides can update fields and array-elements"
    (is (= (apply-override
             data
             {:overrides [{:path [:a] :match 1 :set 2} ;update field in map
                          {:path [:nested-map :a] :match 1 :set 2} ;update field in nested map
                          {:path [:const-array] :where "AAA" :set "BBB"} ;update element in const array
                          {:path [:const-list] :where "AAA" :set "BBB"}
                          {:path [:time-series] :where {:time 1} :match {:val 1} :set {:time 1 :val 2}} ;update element in time series
                          {:path [:time-list] :where {:time 1} :match {:val 1} :set {:time 1 :val 2}}]})

           {:a 2 :nested-map {:a 2}
            :const-array ["BBB"]
            :const-list `("BBB")
            :time-series [{:time 1 :val 2}]
            :time-list `({:time 1 :val 2})}))))

(deftest override-matching
  (testing "Overrides won't add fields and array-elements if match clause does not match target"
    (is (= (apply-override
             data
             {:overrides [{:path [:b] :match 2 :set 2} ;add field to map
                          {:path [:nested-map :b] :match 2 :set 2} ;add field to nested map
                          {:path [:const-array] :where "BBB" :match "XXX" :set "BBB"} ;add element to const array
                          {:path [:const-list] :where "BBB" :match "XXX" :set "BBB"}
                          {:path [:time-series] :where {:time 2} :match {:val 2} :set {:time 2 :val 2}} ;add element to time series
                          {:path [:time-list] :where {:time 2} :match {:val 2} :set {:time 2 :val 2}}]})

           data)))
  (testing "Overrides won't remove fields and array-elements if match clause does not match target"
    (is (= (apply-override
             data
             {:overrides [{:path [:a] :match 2 :set nil} ;remove field from map
                          {:path [:nested-map :a] :match 2 :set nil} ;remove field from nested map
                          {:path [:const-array] :where "AAA" :match "XXX" :set nil} ;remove element from const array
                          {:path [:const-list] :where "AAA" :match "XXX" :set nil}
                          {:path [:time-series] :where {:time 1} :match {:val 2} :set nil} ;remove element from time series
                          {:path [:time-list] :where {:time 1} :match {:val 2} :set nil}]})

           data)))
  (testing "Overrides won't update fields and array-elements if match clause does not match target"
    (is (= (apply-override
             data
             {:overrides [{:path [:a] :match 2 :set 2} ;update field in map
                          {:path [:nested-map :a] :match 2 :set 2} ;update field in nested map
                          {:path [:const-array] :where "AAA" :match "XXX" :set "BBB"} ;update element in const array
                          {:path [:const-list] :where "AAA" :match "XXX" :set "BBB"}
                          {:path [:time-series] :where {:time 1} :match {:val 2} :set {:time 1 :val 2}} ;update element in time series
                          {:path [:time-list] :where {:time 1} :match {:val 2} :set {:time 1 :val 2}}]})

           data))))

(deftest override-array
  (testing "Able to override an entire array"
    (is (= (apply-override data {:overrides [{:path [:const-array] :set [1 2 3]}
                                             {:path [:const-list] :set [1 2 3]}]}) ;override :const-array regardless of current contents
           {:a 1 :nested-map {:a 1}
            :const-array [1 2 3]
            :const-list [1 2 3]
            :time-series [{:time 1 :val 1}]
            :time-list [{:time 1 :val 1}]}))
    (is (= (apply-override data {:overrides [{:path [:const-array] :set `(1 2 3)}
                                             {:path [:const-list] :set `(1 2 3)}]})
           {:a 1 :nested-map {:a 1}
            :const-array `(1 2 3)
            :const-list `(1 2 3)
            :time-series [{:time 1 :val 1}]
            :time-list [{:time 1 :val 1}]}))))

(deftest override-new-route
  (testing "Able to override at non-existent route"
    (is (= (apply-override {} {:overrides [{:path [:a :b :c] :set 1}]})
           {:a {:b {:c 1}}}))))

(deftest override-nil
  (testing "Overrides work on nil input"
    (is (= (apply-override nil {:overrides [{:path [:a] :match nil :set 1}]})
           {:a 1}))))

(deftest override-nested
  (testing "Overrides work when applied to nested target, not only top-level doc"
    (is (= (apply-override
             data
             {:overrides [{:path [:time-series] :where {:time 1} :overrides [{:path [:x] :set 1}]}
                          {:path [:time-list] :where {:time 1} :overrides [{:path [:x] :set 1}]}]})
           {:a 1 :nested-map {:a 1}
            :const-array ["AAA"]
            :const-list `("AAA")
            :time-series [{:time 1 :val 1 :x 1}]
            :time-list `({:time 1 :val 1 :x 1})}))))

(deftest override-match-subset
  (testing "Match applies correctly when subset of nested target map"
    (is (= (apply-override {:a {:a 1 :b {:c 2} :c []}}
                           {:overrides [{:path [:a] :match {:b {:c 2}} :set 1}]})
           {:a 1}))))

(deftest override-invalid-where
  (testing "Override fails when 'where' clause is used on a non-collection target"
    (is (= (apply-override data {:overrides [{:path [:a] :where 1 :set 2}]})
           data))))

(deftest override-extra-keys
  (testing "Extra keys in override document (e.g. notes) are harmless"
    (is (= (apply-override {} {:type :security
                               :identifiers {:cusip "123456789"}
                               :notes "bla bla bla"
                               :overrides [{:path [:a] :set 1 :notes "setting a to 1"}]})
           {:a 1}))))

(deftest override-string-path
  ;When reading override from mongo, path elements are read as strings. Rather than walking the entire override each
  ;time they are read to convert them, it makes more sense for now to just keywordize them during override application
  (testing "String paths in override should be keywordized before application"
    (is (= (apply-override {:aaa {:bbb {:ccc 2}}} {:overrides [{:path ["aaa" "bbb" "ccc"] :set 1}]})
           {:aaa {:bbb {:ccc 1}}}))))

;TODO test logging? (no longer match warning, 'inappropriate use of where' warning)

(deftest partial-overrides
  (let [override-doc {:overrides
                      [{:path [:b] :match nil :set 2}
                       {:path [:nested-map :b] :match nil :set 2}
                       {:path [:const-array] :where "BBB" :match nil :set "BBB"}
                       {:path [:time-series] :where {:time 2} :match nil :set {:time 2 :val 2}}]}]
    (testing "Partial override where path leads to a top level field"
      (is (= (apply-override data override-doc #{[:b]})
             (assoc data :b 2))))
    (testing "Partial override where path leads to a nested map"
      (is (= (apply-override data override-doc #{[:nested-map :b]})
             (assoc-in data [:nested-map :b] 2))))
    (testing "Partial override where path leads to a const array"
      (is (= (apply-override data override-doc #{[:const-array]})
             (update data :const-array (fn [old val] (conj old val)) "BBB"))))
    (testing "Partial override where path leads to a time series"
      (is (= (apply-override data override-doc #{[:time-series]})
             (update data :time-series (fn [old val] (conj old val)) {:time 2 :val 2}))))
    (testing "Partial override on all paths is same as applying full override"
      (is (= (apply-override data override-doc #{[:b] [:nested-map :b] [:const-array] [:time-series]})
             (apply-override data override-doc))))))
