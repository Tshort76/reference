(ns util.date-time-test
    (:require
      [util.date-time :refer :all]
      [clojure.test :refer :all]))

(defn year-diff-test [dt1 dt2 expect]
  (is (= (year-diff-30-360 dt1 dt2) expect)))

(testing "year-diff-30-360"
    (year-diff-test #inst"2017-01-01" #inst"2016-01-01" 1)
    (year-diff-test #inst"2016-07-01" #inst"2016-01-01" 1/2)
    (year-diff-test #inst"2016-03-31" #inst"2016-03-30" 0)
    (year-diff-test #inst"2017-02-28" #inst"2017-02-27" 1/120)
    (year-diff-test #inst"2016-02-29" #inst"2016-02-28" 1/180)
    (year-diff-test #inst"2016-04-30" #inst"2016-01-31" 1/4))

(testing "->30day"
    (is (= (->30day 2016 01 29) 29))
    (is (= (->30day 2016 01 30) 30))
    (is (= (->30day 2016 01 31) 30))
    (is (= (->30day 2016 02 28) 28))
    (is (= (->30day 2016 02 29) 30))
    (is (= (->30day 2000 02 28) 28))
    (is (= (->30day 1900 02 28) 30)))
