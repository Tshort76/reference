(ns soda-common.parsers-test
  (:require [clojure.test :refer :all]
            [soda-common.parsers :refer :all]))

(defn date-only [v] (select-keys v [:date]))

(deftest time-parse-test
  (testing "Can I parse any conceivable date?"
    (is (= {:date #inst"2034-02-02"} (date-only (parse "February 2, 2034"))))
    (is (= {:date #inst"2034-02-20"} (date-only (parse "February 20, 2034"))))
    (is (= {:date #inst"2034-02-02"} (date-only (parse "Feb. 2, 2034"))))
    (is (= {:date #inst"2034-02-20"} (date-only (parse "February 20, 2034"))))
    (is (= {:date #inst"2034-06-20"} (date-only (parse "June 20, 2034"))))
    ;;This happened once.
    (is (= {:date #inst"2010-06-23"} (date-only (parse (str "June" (char 160) "23, 2010")))))
    (is (= {:date #inst"2010-06-23"} (date-only (parse "June 23, 2010"))))
    (is (= {:date #inst"2034-08-12"} (date-only (parse "12 Aug 2034"))))
    (is (= {:date #inst"2034-08-12"} (date-only (parse "12 Aug. 2034"))))
    (is (= {:date #inst"2034-08-12"} (date-only (parse "Aug. 12, 2034"))))
    (is (= {:date #inst"2034-08-12"} (date-only (parse "Aug. 12 2034"))))
    (is (= {:date #inst"2034-02-02"} (date-only (parse "2/2/2034"))))
    (is (= {:date #inst"2034-10-01"} (date-only (parse "10/01/2034"))))
    (is (= {:date #inst"2034-02-28"} (date-only (parse "2034-02-28"))))
    ;Should we allow this?
    ;(is (= {:date #inst"2034-02-28"} (parse "2034 02 28")))
    (is (= {:month-of-year "02", :day-of-month "02"} (parse "February 2")))
    (is (= {:month-of-year "02", :year "2045"} (parse "February 2045")))))

(deftest number-parse-test
  (testing "Can I parse any conceivable number?"
    (is (= 4 (:integer (parse "4"))))
    (is (= 45 (:integer (parse "45"))))
    (is (= 455 (:integer (parse "455"))))
    (is (= 455000 (:integer (parse "0455000"))))
    (is (= 455000334 (:integer (parse "455,000,334"))))
    (is (= 455000.35 (:double (parse "455,000.35"))))
    (is (= 455000.78951 (:double (parse "0455000.78951"))))
    (is (= 455000334.244145 (:double (parse "455,000,334.244145"))))
    (is (= 455000334.244145 (:double (parse "+455,000,334.244145"))))
    (is (= -455000334.244145 (:double (parse "-455,000,334.244145"))))
    (is (= 0.244145 (:double (parse ".244145"))))
    (is (= 0.244145 (:double (parse "0.244145"))))
    (is (= -455000 (:integer (parse "-455,000"))))
    (is (= {:dollars 455000} (parse "$455,000")))
    (is (= {:dollars 455000} (parse "$455000")))
    (is (= {:percent 1.2} (parse "1.2  %")))
    (is (= {:integer 1972} (parse "1972")))))

;;Unused since 2016.12.02 - 2017.03.06 (Mark)
;(parse "June 3, 2010-2020")
;(parse "July 3, 2010 to July 3, 2020")
;(parse "June 3, 2010 to July 3, 2020")
;(parse "Aug 3, 2010 to July 3, 2020")
;(parse (str "June" (char 160) "23, 2010"))
;(parse (str "June" \space "23, 2010"))
;(parse "12/01/20")
;(string->parse-tree "2034-02-28")
;(string->parse-tree "12/01/20")
;(parse "2034-02-28")
;(string->parse-tree "10/01/2034")
;(parse "10/01/2034")
;(parse "this isn't anything")