(ns soda-common.cusip-test
  (:require [clojure.test :refer :all]
            [soda-common.cusip :refer :all]))

(def cusip-isin-map
  {"11070JLW8"
   "06417GCD8"
   "31396AQA5"
   "31417BLF2"
   "671324DC2"
   "31419B5D3"
   "92922FYA0"
   "299348BY7"
   "68428VCK6"
   "499746RU1"
   "88059TEK3"
   "3136G2VJ3"
   "918826DW5"
   "64972GHD9"
   "20367QAB3"
   "44890NTK6"
   "604129H82"
   "3128X2ZC2"
   "31394Y5J9"
   "899645VA0"})

(deftest test-731452HM3
  (testing "Checkdigit for 731452HM3"
    (is (valid? "731452HM3"))))

(deftest test-824178XD4
  (testing "Checkdigit for 824178XD4"
    (is (valid? "824178XD4"))))

(deftest test-many-cusips
  (testing "Checkdigit for many cusips"
    (doseq [c (keys cusip-isin-map)]
      (is (valid? c)))))
