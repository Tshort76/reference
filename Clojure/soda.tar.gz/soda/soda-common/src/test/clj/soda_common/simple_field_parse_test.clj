(ns soda-common.simple-field-parse-test
  (:require [clojure.test :refer :all]
            [soda-common.simple-field-parse :refer :all]))

;(pattern->parser {:field-type :float :pattern "13.2"})

(deftest test-float
  (testing "float(13.2)"
    (let [spec {:field-type :float :pattern "13.2"}
          parser (pattern->parser spec)
          safe-parser (gen-safe-parser spec)
          raw "000000387734900"]
      (is (== 3877349.0 (parser raw)))
      (is (= {:pattern spec
              :value 3877349.0
              :raw-chunk raw}
             (safe-parser raw))))
    (let [parser (pattern->parser {:field-type :float})]
      (is (== 0.45 (parser ".45")))
      (is (== 45 (parser "045"))))))

(deftest test-string
  (testing "string(6)"
    (let [parser (pattern->parser {:field-type :string})]
      (is (= "AA0001" (parser "AA0001")))
      (is (= "U S  BANK, NA" (parser "U S  BANK, NA                                               "))))))

(deftest test-no99-int
  (testing "99999"
    (let [parser (pattern->parser {:field-type :int-no99})]
      (is (nil? (parser "999999")))
      )))


(deftest test-date
  (testing "date(YYMMDD)"
    (let [parser (pattern->parser {:field-type :date :pattern "YYMMDD"})]
      (is (= #inst "2001-01-01" (parser "010101")))))
  (testing "date(MMDDYY)"
    (let [parser (pattern->parser {:field-type :date :pattern "MMDDYY"})]
      (is (nil? (parser "      ")))
      (is (= #inst "1999-07-01" (parser "070199")))
      (is (= #inst "2040-07-01" (parser "070140")))
      (is (= #inst "2079-07-01" (parser "070179")))
      (is (= #inst "1980-07-01" (parser "070180"))))))

(deftest test-int
  (testing "int(5)"
    (let [parser (pattern->parser {:field-type :int})]
      (is (= 12345 (parser "12345")))
      (is (= 2 (parser "00002"))))
    (let [parser (pattern->parser {:field-type :int})]
      (is (= 20160401 (parser "20160401"))))))

(deftest test-good-value?
  (testing "good-value?"
    (is (= "0001" (good-value? "0001")))))
