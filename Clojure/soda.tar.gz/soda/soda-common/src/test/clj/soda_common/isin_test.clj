(ns soda-common.isin-test
  (:require [clojure.test :refer :all]
            [soda-common.isin :refer :all]))

(def cusip-isin-map
  {"11070JLW8" "US11070JLW89"
   "06417GCD8" "US06417GCD88"
   "31396AQA5" "US31396AQA50"
   "31417BLF2" "US31417BLF21"
   "671324DC2" "US671324DC26"
   "31419B5D3" "US31419B5D38"
   "92922FYA0" "US92922FYA01"
   "299348BY7" "US299348BY73"
   "68428VCK6" "US68428VCK61"
   "499746RU1" "US499746RU16"
   "88059TEK3" "US88059TEK34"
   "3136G2VJ3" "US3136G2VJ37"
   "918826DW5" "US918826DW53"
   "64972GHD9" "US64972GHD97"
   "20367QAB3" "US20367QAB32"
   "44890NTK6" "US44890NTK62"
   "604129H82" "US604129H827"
   "3128X2ZC2" "US3128X2ZC24"
   "31394Y5J9" "US31394Y5J96"
   "899645VA0" "US899645VA09"})

(deftest test-many-isins
  (testing "Checkdigit for many cusips"
    (doseq [[c i] cusip-isin-map]
      (is (and (valid? i)
               (= i (cusip->isin "US" c)))))))

(deftest cusip->us-isin-test
  (testing "Conversion of CUSIP to US ISIN."
    (is (= "US38373WA407" (cusip->isin "US" "38373WA40")))
    (is (= "US38374EMD66" (cusip->isin "US" "38374EMD6")))
    (is (= "US38374ESD03" (cusip->isin "US" "38374ESD0")))
    (is (= "US36201AQD36" (cusip->isin "US" "36201AQD3")))
    (is (= "US36203B3C67" (cusip->isin "US" "36203B3C6")))
    (is (= "US36203BKC71" (cusip->isin "US" "36203BKC7")))
    (is (= "US36203DYJ35" (cusip->isin "US" "36203DYJ3")))
    (is (= "US36203EZR25" (cusip->isin "US" "36203EZR2")))))
