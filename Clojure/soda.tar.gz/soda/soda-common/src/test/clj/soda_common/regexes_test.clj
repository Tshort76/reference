(ns soda-common.regexes-test
  (:require
    [clojure.test :refer :all]
    [soda-common.regexes :as re]))

(deftest dates
  (testing "month-day-year"
    (is (re-find re/month-day-year "3.1.01"))
    (is (re-find re/month-day-year "3.1.2001"))
    (is (re-find re/month-day-year "3-1-2001"))
    (is (re-find re/month-day-year "March 1, 2001"))
    (is (re-find re/month-day-year "Mar 1, 2001"))
    (is (re-find re/month-day-year "March 1, 99"))
    (is (re-find re/month-day-year "March 1 2001"))
    (is (re-find re/month-day-year "3,1,2001"))
    (is (re-find re/month-day-year "3/1/2001")))
  (testing "date"
    (is (= "April 15, 2023" (first (re-find re/date "Notes due 2023: April 15, 2023")))))
  (testing "bugs and edge cases"
    (is (nil? (re-find re/month-day-year "March 32, 2001")))
    (is (nil? (re-find re/date "2014: $1,000,000,000")))))
