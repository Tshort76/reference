(ns soda-common.priceyield-test
  (:require [clojure.test :refer :all]
            [soda-common.priceyield :refer [price yield]]))

(deftest price-yield-1
  (testing "yield 0.0224 price 114.16661"
    (let [data
          {:settlement {:year 2014 :month 1 :day 7}
           :maturity {:year 2019 :month 7 :day 1}
           :rate 0.05
           :yield 0.0224
           :price 114.16661
           :redemption 100.0
           :frequency 2}]
      (is (and (< (Math/abs (- (price data) (:price data))) 1E-6)
               (< (Math/abs (- (yield data) (:yield data))) 1E-6))))))

(deftest price-yield-2
  (testing "yield 0.035 price 102.3471639"
    (let [data
          {:settlement {:year 2016 :month 5 :day 15}
           :maturity {:year 2019 :month 7 :day 1}
           :rate 0.043
           :yield 0.035
           :price 102.3471639
           :redemption 100.0
           :frequency 2}]
      (is (and (< (Math/abs (- (price data) (:price data))) 1E-6)
               (< (Math/abs (- (yield data) (:yield data))) 1E-6))))))

(deftest price-yield-3
  (testing "yield 0.035 price 102.3471639 day 31"
    (let [data
          {:settlement {:year 2016 :month 5 :day 31}
           :maturity {:year 2019 :month 7 :day 1}
           :rate 0.043
           :yield 0.035
           :price 102.316474
           :redemption 100.0
           :frequency 2}]
      (is (and (< (Math/abs (- (price data) (:price data))) 1E-6)
               (< (Math/abs (- (yield data) (:yield data))) 1E-6))))))

(deftest price-yield-4
  (testing "yield 0.035 price 11.302926"
    (let [data
          {:settlement {:year 2016 :month 5 :day 30}
           :maturity {:year 2019 :month 7 :day 1}
           :rate 0.043
           :yield 0.035
           :price 111.302926
           :redemption 110.0
           :frequency 2}]
      (is (and (< (Math/abs (- (price data) (:price data))) 1E-6)
               (< (Math/abs (- (yield data) (:yield data))) 1E-6))))))

(deftest price-yield-5
  (testing "yield 0.01339749 price 107.71"
    (let [data
          {:settlement {:year 2016 :month 1 :day 27}
           :maturity {:year 2017 :month 12 :day 15}
           :rate 0.055
           :yield 0.01339749
           :price 107.71
           :redemption 100.0
           :frequency 2}]
      (is (and (< (Math/abs (- (price data) (:price data))) 1E-6)
               (< (Math/abs (- (yield data) (:yield data))) 1E-6))))))

(deftest price-yield-6
  (testing "yield -0.00859906 price 106.95299976539287"
    (let [data
          {:settlement {:year 2016 :month 1 :day 27}
           :maturity {:year 2017 :month 4 :day 1}
           :rate 0.05
           :yield -0.00859906
           :price 106.95299976539287
           :redemption 100.0
           :frequency 2}]
      (is (and (< (Math/abs (- (price data) (:price data))) 1E-6)
               (< (Math/abs (- (yield data) (:yield data))) 1E-6))))))

(deftest price-yield-7
  (testing "1 payment period"
    (let [data
          {:settlement {:year 2019 :month 6 :day 1}
           :maturity {:year 2019 :month 7 :day 1}
           :rate 0.043
           :yield 0.035
           :price 100.0612622905
           :redemption 100.0
           :frequency 2}]
      (is (and (< (Math/abs (- (price data) (:price data))) 1E-6)
               (< (Math/abs (- (yield data) (:yield data))) 1E-6))))))