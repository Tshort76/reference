(ns mongo-indices-test
  (:require [clojure.test :refer :all]
            [clojure.edn :as edn]))

(testing "is indices file parseable?"
  (is (vector? (edn/read-string (slurp (clojure.java.io/resource "indices/mongo_indices.edn"))))))