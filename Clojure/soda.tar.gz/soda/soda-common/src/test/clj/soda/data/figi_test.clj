(ns soda.data.figi-test
  (:require [clojure.test :refer :all]
            [soda.data.figi :as figi]
            [monger.collection :as mc]
            [datasources.core :refer [with-fongo]]))

(defn figi-with [{:keys [doa id meta-id figi cusip]}]

  {:_id   id
   :meta  {:_id                   meta-id
           :date-of-applicability doa},
   :figi  (or figi "BBG0009G70R7"),
   :cusip (or cusip "31315NEY6")})



(deftest querying-normalization
  ;;wrapped with-fongo so that real db connections aren't being made
  (with-fongo
    (testing "Uses date of applicability and doa to choose most recent for a figi"
      (with-redefs [mc/find-maps (fn [& _] [(figi-with {:doa 1 :id 0 :meta-id 4})
                                            (figi-with {:doa 2 :id 0 :meta-id 4})
                                            (figi-with {:doa 2 :id 3 :meta-id 0})
                                            (figi-with {:doa 2 :id 1 :meta-id 4})])]
        (is (= [(figi-with {:doa 2 :id 3 :meta-id 0})] (figi/query-norm-figi {})))))

    (testing "Returns only records for the most recent doa"
      (with-redefs [mc/find-maps (fn [& _] [(figi-with {:doa 1 :id 0 :meta-id 4})
                                            (figi-with {:doa 2 :id 0 :meta-id 4})
                                            (figi-with {:doa 2 :id 3 :meta-id 0})
                                            (figi-with {:doa 3 :id 0 :meta-id 4 :figi "abc"})
                                            (figi-with {:doa 2 :id 3 :meta-id 0 :figi "abc"})
                                            (figi-with {:doa 2 :id 1 :meta-id 4})])]
        (is (= [(figi-with {:doa 3 :id 0 :meta-id 4 :figi "abc"})] (figi/query-norm-figi {})))))

    (testing "Returns most recent record for each figi, but only for most recent doa"
      (with-redefs [mc/find-maps (fn [& _] [(figi-with {:doa 1 :id 0 :meta-id 4})
                                            (figi-with {:doa 2 :id 3 :meta-id 0 :figi "def"})
                                            (figi-with {:doa 3 :id 3 :meta-id 0})
                                            (figi-with {:doa 3 :id 0 :meta-id 4 :figi "abc"})
                                            (figi-with {:doa 2 :id 3 :meta-id 0 :figi "abc"})])]
        (is (= #{(figi-with {:doa 3 :id 0 :meta-id 4 :figi "abc"})
                 (figi-with {:doa 3 :id 3 :meta-id 0})}
               (into #{} (figi/query-norm-figi {}))))))

    (testing "Returns most recent records for all cusips, but only for most recent doa"
      (with-redefs [mc/find-maps (fn [& _] [(figi-with {:doa 1 :id 0 :meta-id 4})
                                            (figi-with {:doa 2 :id 3 :meta-id 0 :figi "def"})
                                            (figi-with {:doa 3 :id 3 :meta-id 0})
                                            (figi-with {:doa 3 :id 0 :meta-id 4 :figi "abc"})
                                            (figi-with {:doa 2 :id 3 :meta-id 0 :figi "abc"})
                                            (figi-with {:doa 3 :id 0 :meta-id 4 :cusip "abc"})
                                            (figi-with {:doa 2 :id 3 :meta-id 0 :cusip "abc"})])]
        (is (= #{(figi-with {:doa 3 :id 0 :meta-id 4 :figi "abc"})
                 (figi-with {:doa 3 :id 3 :meta-id 0})
                 (figi-with {:doa 3 :id 0 :meta-id 4 :cusip "abc"})}
               (into #{} (figi/query-norm-figi {}))))))))

