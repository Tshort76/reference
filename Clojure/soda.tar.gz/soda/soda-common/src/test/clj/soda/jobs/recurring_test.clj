(ns soda.jobs.recurring-test
  (:require
    [clj-time.core :as t]
    [soda.jobs.recurring :as r]
    [soda.jobs.rescheduling-utils :as ru]
    [soda.jobs.utils :as jutils]
    [clojure.test :refer :all]))


(deftest unique-scheduling-tests
  (with-redefs [t/now (fn [] (t/date-time 2017 6 5))
                ru/unique? (fn [x] (empty? x))
                jutils/enqueue-job identity]
    (testing "Respect uniqueness of scheduled jobs"
      (is (= :duplicate (:status (r/schedule! {:published-on [:daily] :tods ["8:00"]} {:dummy true}))))
      (is (= :success (:status (r/schedule! {:published-on [:daily] :tods ["8:00"]} {})))))))


(deftest rescheduling-on-failures
  (with-redefs [t/now (fn [] (t/date-time 2017 6 5 9))
                jutils/enqueue-job identity]

    (testing "Failed, no retry, single times of day"
      (is (= {:retry-num 0, :job-def {}, :stime #inst"2017-06-06T08:00:00.000-00:00", :status :success}
             (r/reschedule! {:published-on [:daily] :tods ["8:00"]}
                            {:retry-num 0 :job-def {}}
                            true                            ;say that the job failed
                            identity))))

    (testing "Failed, no retry, second time of day"
      (is (= {:retry-num 1, :job-def {}, :stime #inst"2017-06-05T12:00:00.000-00:00", :status :warning}
             (r/reschedule! {:published-on [:daily] :tods ["8:00" "12:00"]}
                            {:retry-num 0 :job-def {}}
                            true                            ;say that the job failed
                            identity))))

    (testing "Failed, with no retry, after trying all times for the day"
      (is (= {:retry-num 0, :job-def {}, :stime #inst"2017-06-06T08:00:00.000-00:00", :status :success}
             (r/reschedule! {:published-on [:daily] :tods ["8:00" "8:30"]}
                            {:retry-num 2 :job-def {}}
                            true                            ;say that the job failed
                            identity))))

    (testing "Failed, retry specs present"
      ;daily retry, no time of day (tod) in the future
      (is (= {:retry-num 1, :job-def {}, :stime #inst"2017-06-06T08:00:00.000-00:00", :status :warning}
             (r/reschedule! {:published-on [:nth-biz-day 6] :tods ["8:00"] :retry-specs {:type :daily, :max-attempts 5, :only-biz-days? true}}
                            {:retry-num 0 :job-def {}}
                            true                            ;say that the job failed
                            identity)))
      ;daily retry, time of day (tod) in the future
      (is (= {:retry-num 1, :job-def {}, :stime #inst"2017-06-05T12:00:00.000-00:00", :status :warning}
             (r/reschedule! {:published-on [:nth-biz-day 6] :tods ["8:00" "12:00"] :retry-specs {:type :daily, :max-attempts 5, :only-biz-days? true}}
                            {:retry-num 0 :job-def {}}
                            true                            ;say that the job failed
                            identity)))
      ;hourly retry
      (is (= {:retry-num 1, :job-def {}, :stime #inst"2017-06-05T10:00:00.000-00:00", :status :warning}
             (r/reschedule! {:published-on [:nth-biz-day 6] :tods ["8:00"] :retry-specs {:type :hourly, :max-attempts 5}}
                            {:retry-num 0 :job-def {}}
                            true                            ;say that the job failed
                            identity)))
      ;max retries hit
      (is (= {:retry-num 0, :job-def {}, :stime #inst"2017-07-10T08:00:00.000-00:00", :status :error, :msg "Exhausted all retry attempts without success"}
             (r/reschedule! {:published-on [:nth-biz-day 6] :tods ["8:00"] :retry-specs {:type :hourly, :max-attempts 5}}
                            {:retry-num 5 :job-def {}}
                            true                            ;say that the job failed
                            identity)))
      ;max retries (with multiple tods) hit
      (is (= {:retry-num 0, :job-def {}, :stime #inst"2017-07-10T08:00:00.000-00:00", :status :error, :msg "Exhausted all retry attempts without success"}
             (r/reschedule! {:published-on [:nth-biz-day 6] :tods ["8:00"] :retry-specs {:type :hourly, :max-attempts 5}}
                            {:retry-num 10 :job-def {}}
                            true                            ;say that the job failed
                            identity)))
      ;total retries is (count tods) * max-attempts
      (is (= {:retry-num 6, :job-def {}, :stime #inst"2017-06-05T12:00:00.000-00:00", :status :warning}
             (r/reschedule! {:published-on [:nth-biz-day 6] :tods ["8:00" "12:00"] :retry-specs {:type :daily, :max-attempts 5, :only-biz-days? true}}
                            {:retry-num 5 :job-def {}}
                            true                            ;say that the job failed
                            identity))))))


(deftest rescheduling-on-success
  (with-redefs [t/now (fn [] (t/date-time 2017 6 5 9))
                jutils/enqueue-job identity]

    (testing "Don't reschedule"
      (is (nil? (r/reschedule! {:published-on [:daily] :tods ["8:00"]}
                               {:retry-num 0 :job-def {:reschedule? false}}
                               false
                               identity))))

    (testing "Sweet Success"
      (is (= {:retry-num 0, :job-def {:updated? true}, :est-time 144444 :stime #inst"2017-07-10T12:00:00.000-00:00", :status :success}
             (r/reschedule! {:published-on [:nth-biz-day 6] :tods ["12:00" "18:00"] :retry-specs {:dummy true} :est-time 144444}
                            {:retry-num 0 :job-def {}}
                            false
                            #(assoc-in % [:job-def :updated?] true)))))

    (testing "Sweet Success, take max est-time"
      (is (= {:retry-num 0, :job-def {:updated? true}, :est-time 123 :stime #inst"2017-07-10T12:00:00.000-00:00", :status :success}
             (r/reschedule! {:published-on [:nth-biz-day 6] :tods ["12:00" "18:00"] :retry-specs {:dummy true} :est-time 14}
                            {:retry-num 0 :job-def {} :est-time 123}
                            false
                            #(assoc-in % [:job-def :updated?] true)))))

    (testing "Success, but more tods"
      (is (= {:retry-num 0, :job-def {}, :est-time 456, :stime #inst"2017-06-05T12:00:00.000-00:00", :status :success}
             (r/reschedule! {:published-on [:daily] :run-every-tod? true :tods ["6:00" "12:00" "18:00"] :retry-specs {:dummy true}}
                            {:retry-num 0 :job-def {} :est-time 456}
                            false
                            identity))))

    (testing "Success on last tod"
      (is (= {:retry-num 0, :job-def {}, :stime #inst"2017-06-06T06:00:00.000-00:00", :status :success}
             (r/reschedule! {:published-on [:daily] :run-every-tod? true :tods ["6:00" "9:00"] :retry-specs {:dummy true}}
                            {:retry-num 0 :job-def {}}
                            false
                            identity))))))
