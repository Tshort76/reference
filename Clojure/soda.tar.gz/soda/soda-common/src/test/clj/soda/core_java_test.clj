(ns soda.core-java-test
  (:require [clojure.test :refer :all]
            [soda.core :refer :all]
            [soda-common.cusip :as cusip]))

(def testfn
  (comp #(map (fn [m] (cond-> m (map? m) (select-keys [:re-match :value]))) %) regex-split))

(deftest regex-split-test
  (testing "Various use cases of regex-split"
    (is (= (testfn "I am 1 f 4 faes" #"\d+" :parser parse-long :validator #(< % 10))
           ["I am " {:re-match "1", :value 1} " f " {:re-match "4", :value 4} " faes"]))
    (is (= (testfn "I am 1 f 4" #"\d+" :parser parse-long :validator #(< % 10))
           ["I am " {:re-match "1", :value 1} " f " {:re-match "4", :value 4}]))
    (is (= (testfn "1I am 1 f 4" #"\d+" :parser parse-long :validator #(< % 10))
           [{:re-match "1", :value 1} "I am " {:re-match "1", :value 1} " f " {:re-match "4", :value 4}]))
    (is (= (testfn "1 + 21 - 11 = 9" #"\d+" :parser parse-long :validator #(< % 10))
           [{:re-match "1", :value 1} " + 21 - 11 = " {:re-match "9", :value 9}]))
    (is (= (testfn "1 + 21 - 11 = 99" #"\d+" :parser parse-long :validator #(< % 10))
           [{:re-match "1", :value 1} " + 21 - 11 = 99"]))
    (is (= (testfn "aaa1211W1" #"\d+" :parser parse-long :validator #(< % 10))
           ["aaa1211W" {:re-match "1", :value 1}]))
    (is (= (testfn "aaa1211W1" #"\d+" :parser parse-long :validator #(> % 10))
           ["aaa" {:re-match "1211", :value 1211} "W1"]))
    (is (= (testfn "aaa" #"\d+" :parser parse-long :validator #(< % 10))
           ["aaa"]))
    (is (= (testfn "1 + 21 - 11 = 99" #"\d+" :parser parse-long :validator #(> % 10))
           ["1 + " {:re-match "21", :value 21} " - " {:re-match "11", :value 11} " = " {:re-match "99", :value 99}]))
    (is (= (testfn "1 + 21 - 11 = 99" #"\d+")
           [{:re-match "1", :value "1"}
            " + "
            {:re-match "21", :value "21"}
            " - "
            {:re-match "11", :value "11"}
            " = "
            {:re-match "99", :value "99"}]))
    (is (= (testfn "1 + 21 - 111 = 99" #"\d+" :validator #(even? (count %)))
           ["1 + " {:re-match "21", :value "21"} " - 111 = " {:re-match "99", :value "99"}]))
    (is (= (testfn "199" #"\d+" :parser parse-long)
           [{:re-match "199", :value 199}]))
    (is (= (testfn "199" #"\d+" :parser parse-long :validator even?)
           ["199"]))))

(deftest cusip-test
  (testing "Cusips (good and bad)"
    (is (= (testfn "94986RPX3 is a valid cusip, but 94986RPX2 is not." cusip/corp :validator cusip/cusip?)
           [{:re-match "94986RPX3", :value "94986RPX3"} " is a valid cusip, but 94986RPX2 is not."]))
    (is (= (testfn "The cusip 94986RPX3 is valid, but 94986RPX2 is not." cusip/corp :validator cusip/cusip?)
           ["The cusip " {:re-match "94986RPX3", :value "94986RPX3"} " is valid, but 94986RPX2 is not."]))))
