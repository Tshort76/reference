(ns soda.jobs.rescheduling-utils-test
  (:require [clojure.test :refer :all]
            [clj-time.core :as t]
            [soda.jobs.rescheduling-utils :as ru]))

(defmacro is-next
  "Tests that the next available publication date from now-date is equal to
   next-date, as calculated by published-on spec.
  
   published-on is a vector of [frequency & args].
   now-date and next-date are vectors of the form [YYYY mm dd]."
  [published-on now-date next-date & [message]]
  `(with-redefs [t/now (constantly (t/date-time ~@now-date))]
     (is (= (ru/next-available-date ~published-on) (t/date-time ~@next-date)) ~(or message ""))))

(deftest next-available-date-tests
  (testing "monthly scheduling"
    (is-next [:nth-biz-day 2] [2017 6 5] [2017 7 4])
    (is-next [:nth-biz-day 6] [2017 6 5] [2017 7 10])
    (is-next [:nth-biz-day-prior-to 1 4] [2017 6 5] [2017 7 3])
    (is-next [:nth-biz-day-prior-to 2 15] [2017 6 5] [2017 7 13])
    (is-next [:nth-biz-day-after 2 1] [2017 6 5] [2017 7 4])
    (is-next [:nth-biz-day-after 2 15] [2017 6 5] [2017 7 18])
    (is-next [:nth-day 5] [2017 6 5] [2017 7 5])
    (is-next [:nth-day 2] [2017 6 5] [2017 7 2])
    (is-next [:nth-day 9] [2017 6 5] [2017 7 9]))
  (testing "daily scheduling"
    (is-next [:daily] [2017 6 5] [2017 6 6] "weekday->weekday")
    (is-next [:daily] [2017 6 9] [2017 6 10] "weekday->weekend")
    (is-next [:daily] [2017 6 10] [2017 6 11] "weekend->weekend")
    (is-next [:daily] [2017 6 11] [2017 6 12] "weekend->weekday")
    (is-next [:daily] [2016 2 28] [2016 2 29] "leap year")
    (is-next [:daily] [2017 2 28] [2017 3 1] "non-leap year"))
  (testing "business-daily scheduling"
    (is-next [:biz-daily] [2017 10 6] [2017 10 9] "friday->monday")
    (is-next [:biz-daily] [2017 10 7] [2017 10 9] "saturday->monday")
    (is-next [:biz-daily] [2017 10 8] [2017 10 9] "sunday->monday")
    (is-next [:biz-daily] [2017 10 9] [2017 10 10] "monday->tuesday")
    (is-next [:biz-daily] [2017 9 29] [2017 10 2] "september friday->october monday")
    (is-next [:biz-daily] [2017 10 31] [2017 11 1] "october weekday->november weekday") 
    (is-next [:biz-daily :lag-days 0] [2017 10 6] [2017 10 9] "friday->monday") 
    (is-next [:biz-daily :lag-days 1] [2017 10 6] [2017 10 7] "friday->saturday")
    (is-next [:biz-daily :lag-days 1] [2017 10 7] [2017 10 10] "saturday->tuesday")
    (is-next [:biz-daily :lag-days 1] [2017 10 8] [2017 10 10] "sunday->tuesday")
    (is-next [:biz-daily :lag-days 1] [2017 10 9] [2017 10 10] "monday->tuesday")
    (is-next [:biz-daily :lag-days 1] [2017 10 10] [2017 10 11] "tuesday->wednesday")
    (is-next [:biz-daily :lag-days 1] [2017 6 30] [2017 7 1] "june friday->july saturday")
    (is-next [:biz-daily :lag-days 1] [2017 10 31] [2017 11 1] "october weekday->november weekday")
    (is-next [:biz-daily :lag-days 2] [2017 10 7] [2017 10 8] "saturday->sunday")
    (is-next [:biz-daily :lag-days 2] [2017 10 8] [2017 10 11] "sunday->wednesday"))
  (testing "weekly scheduling"
    (is-next [:nth-week-day 1] [2017 6 5] [2017 6 12])
    (is-next [:nth-week-day 4] [2017 6 5] [2017 6 15])
    (is-next [:nth-week-day 1] [2017 6 30] [2017 7 3]))
  (testing "quarterly scheduling"
    (is-next [:quarterly] [2017 1 1] [2017 4 1] "start q1->q2")
    (is-next [:quarterly] [2017 4 1] [2017 7 1] "start q2->q3")
    (is-next [:quarterly] [2017 6 5] [2017 7 1] "mid q2->q3")
    (is-next [:quarterly] [2017 9 30] [2017 10 1] "end q3->q4")
    (is-next [:quarterly] [2017 12 31] [2018 1 1] "end q4->q1")))
