(ns soda.data.mind-food-test
  ; (:require [clojure.java.io :as io]
  ;           [clojure.test :refer :all]
  ;           [datasources.core :as ds]
  ;           [mount.core :refer [defstate] :as mount]
  ;           [soda.data.file-system :as sdfs]
  ;           [soda.data.mind-food :as mf])
  ; (:import (java.io File))
  )

;; This test fails on devbuild because it can't access a file-system
#_(deftest process-file-0001047469-16-009587
  (testing "Storing and conversion of 0001047469-16-009587.txt to mind-food."
    (let [_ (mount/start-with {#'datasources.core/connection (ds/fongo-connection)})
          file (-> "soda/data/0001047469-16-009587.txt" io/resource .getFile File.)
          {:keys [filename md5] :as fs-res} (sdfs/add-file file {:file-type :edgar-prospectus})
          {:keys [file-type]} (sdfs/find-one-meta {:filename filename})
          mind-food (vec (mf/mind-food (select-keys fs-res [:filename :md5])))
          _ (mount/stop)]
      (is (= "0001047469-16-009587.txt" filename))
      (is (= "9b237d693eada1f26d4b32c773c17167" md5))
      (is (= :edgar-prospectus (keyword file-type)))
      (is (= 1 (count mind-food)))
      (is (every? (first mind-food) [:file-type :md5 :filename :mind-food])))))
