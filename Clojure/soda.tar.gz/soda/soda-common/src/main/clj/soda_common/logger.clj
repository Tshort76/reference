(ns soda-common.logger
  "Logging configuration and initialization."
  (:require [taoensso.timbre :as timbre]
            [taoensso.timbre.appenders.core :as appenders]
            [environ.core :refer [env]]
            [monger.collection :as mc]
            [datasources.core :as ds])
  (:import (org.slf4j LoggerFactory MDC)
           (org.slf4j.spi LocationAwareLogger)
           (java.util UUID)
           (java.nio ByteBuffer)))

(def alphanumeric-alphabet [\0 \1 \2 \3 \4 \5 \6 \7 \8 \9
                            \A \B \C \D \E \F \G \H \I \J \K \L \M
                            \N \O \P \Q \R \S \T \U \V \W \X \Y \Z])

(def MAX_TRACE_SIZE 250)

(defn coerce-base-to-alphabet
  "Converts a number to a string of base (count alphabet) where the character set is alphabet. Assumes n is positive."
  [n alphabet]
  (loop [remainder n s ""]
    (if (zero? remainder)
      s
      (recur (quot remainder (count alphabet))
             (str s (nth alphabet (rem remainder (count alphabet))))))))

(defn uuid->number [uuid]
  (let [n (-> (doto (ByteBuffer/wrap (byte-array 16))
               (.putLong (.getMostSignificantBits uuid))
               (.putLong (.getLeastSignificantBits uuid)))
             .array
             BigInteger.)]
    ;convert result from twos-complement to unsigned
    (if (neg? n)
      (+ n (.pow (BigInteger. "2") 128))
      n)))

(defn pad [s pad-char length]
  (str (apply str (take (- length (count s)) (repeat pad-char))) s))

(defn uuid->alphanumeric-str [uuid]
  (-> uuid uuid->number (coerce-base-to-alphabet alphanumeric-alphabet) (pad (first alphanumeric-alphabet) 25)))

(defn random-alphanumeric-uuid []
  (uuid->alphanumeric-str (UUID/randomUUID)))

(def ^:dynamic *trace* (random-alphanumeric-uuid))
(def ^:dynamic *trace-index* (atom 0))
(def ^:dynamic *children-reset* false)

(defmacro reset-trace
  "Executes body with a newly established trace"
  [& body] `(binding [*trace* (random-alphanumeric-uuid)
                      *trace-index* (atom 0)]
              (do ~@body)))

(defmacro set-trace
  "Executes body with the provided trace base"
  [trace-base & body] `(binding [*trace* ~trace-base
                                 *trace-index* (atom 0)]
                         (do ~@body)))

(defn new-child-trace []
  (if *children-reset*
    (random-alphanumeric-uuid)
    (let [index (swap! *trace-index* inc)
          trace (str *trace* "." index)]
      (if (> (count trace) MAX_TRACE_SIZE)
        (throw (Exception. "Logger failed to generate child trace. It would be too big!"))
        trace))))

(defmacro prevent-trace-nesting
  "When generating child traces, generate brand new traces instead of appending to the existing trace"
  [& body] `(binding [*children-reset* true]
              (do ~@body)))

;Searchable attributes
;http://opengrok/source/xref/cwan/shared/ca-logging-interceptor/ca-logging/src/main/java/com/ca/logging/LogContext.java
(defmacro with-attribute
  "Adds any custom attribute to kibana logs."
  [^String attr value & body]
  `(do
     (. MDC put ~attr (str ~value))
     ~@body
     (. MDC remove ~attr)))

(def level-ints
  {:trace LocationAwareLogger/TRACE_INT
   :debug LocationAwareLogger/DEBUG_INT
   :info  LocationAwareLogger/INFO_INT
   :warn  LocationAwareLogger/WARN_INT
   :error LocationAwareLogger/ERROR_INT})

(def default-log-level (LocationAwareLogger/DEBUG_INT))

(defn log-trace-wrapper [handler]
  (fn [request] (reset-trace (handler request))))

;TODO add ability to specify log levels per-namespace
;as discussed here: https://github.com/ptaoussanis/timbre/issues/210
(defn temp-trace-logging
  ([] (temp-trace-logging 30))
  ([^long minutes]
   (if (= :trace (:level timbre/*config*))
     "current log level is already set to trace."
     (let [to-sleep-minutes (Math/min minutes 120)
           msg (str "setting log level to trace (will revert back to debug in " to-sleep-minutes " minutes)")]
       (do
         (timbre/info msg)
         (timbre/set-level! :trace)
         (future (Thread/sleep (* 1000 60 to-sleep-minutes))
                 (timbre/info (str "auto setting log level back to debug"))
                 (timbre/set-level! :debug))
         msg)))))

(defn- appender-fn
  "Timbre appender fn to log to JVM logging system. Set once at init."
  [logger {:keys [level msg_ ?err]}]
  (let [^String msg (force msg_)
        ^int level (or (level-ints level) default-log-level)
        ^Throwable err (force ?err)]
    (when (instance? LocationAwareLogger logger)
      (with-attribute "trace" *trace*
                      (.log logger
                            nil
                            "taoensso.timbre$_log_BANG_"
                            level
                            msg
                            nil
                            err)))))

(defn- cwan-appender [logger]
  {:enabled?  true
   :async?    false
   :min-level :debug
   :fn        (partial appender-fn logger)})

(defn init-logging!
  "Configure timbre to write logs to the JVM logging system using slf4j."
  [^String logger-name]
  (let [logger (. LoggerFactory getLogger logger-name)
        ns-blacklist (or (:ns-blacklist (mc/find-one-as-map (ds/get-db "soda_configs") "properties" {:type "logging-ns-blacklist"}))
                         [])]
    (timbre/swap-config!
      (fn [config]
        (-> (dissoc config :timestamp-opts)
            (update :ns-blacklist #(concat % ns-blacklist))
            ((fn [c] (if (:tier env)
                       (-> (assoc-in c [:appenders :cwan-appender] (cwan-appender logger))
                           (update :appenders #(dissoc % :println)))
                       (assoc-in c [:appenders :file] (appenders/spit-appender {:fname "logging.log"}))))))))))

