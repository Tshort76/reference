(ns soda-common.simple-field-parse
  (:require
    [taoensso.timbre :as timbre]
    [util.date-time :as time]
    [clojure.string :as s])
  (:import (java.text SimpleDateFormat)
           (java.time ZoneOffset)
           (java.util Date)))



(defn good-value? [v]
  (cond
    (re-matches #"\s*" v) nil
    (re-matches #"\**" v) nil
    :else v))

(defn lpad-zero [v]
  (if (re-matches #" +[0-9\.]+" v)
    (s/replace v " " "0")
    v))

(defn read-implied-float [i d s]
  (when (good-value? s)
    (let [[_ f l] (re-matches (re-pattern (str "(\\d{" i "})(\\d{" d "})")) s)]
      (when (and f l)
        (Double/parseDouble (str f "." l))))))

(defn float-parser [pattern]
  (if pattern
    (let [[_ i d t l] (re-matches #"(\d+)\.(\d+)|\*\.(\d+)|(\d+)\.\*" pattern)]
      (cond
        (and i d) #(read-implied-float i d (lpad-zero %))
        t (let [d (Integer/parseInt t)]
            (fn [s] (let [trimmed (s/trim s)]
                      (read-implied-float (- (count trimmed) d) d trimmed))))
        l (let [i (Integer/parseInt l)]
            (fn [s] (let [trimmed (s/trim s)]
                      (read-implied-float i (- (count trimmed) i) trimmed))))
        :default (timbre/debug (str "Bad float pattern \"" pattern "\"."))))
    #(when (good-value? %) (-> % s/trim Double/parseDouble))))

(defmulti pattern->parser :field-type)

(defmethod pattern->parser :string [_] #(some-> % good-value? s/trim))
(defmethod pattern->parser :int [_] #(some-> % good-value? s/trim (Integer/parseInt)))
(defmethod pattern->parser :long [_] #(some-> % good-value? s/trim (Long/parseLong)))
(defmethod pattern->parser :discard [_] (fn [_] nil))
(defmethod pattern->parser :keyword [_] #(some-> % good-value? keyword))
;;Perhaps replace this with something less nonsensical.
(defmethod pattern->parser :constant [_] #(some-> % good-value? keyword))
(defmethod pattern->parser :pass-through [_] identity)
(defmethod pattern->parser :default [pattern]
  (do
    (timbre/debug "Unknown parser for pattern \"" pattern "\".")
    (fn [_] nil)))

(defn not-all-9s? [int-string]
  (let [match (re-matches #"9+" int-string)]
    (when (not= int-string match)
      int-string)))

(defn not-all-9s-float? [float-string]
  (let [match (re-matches #"9+\.9+" float-string)]
    (when (not= float-string match)
      float-string)))


(defmethod pattern->parser :int-no99 [_] #(some-> % good-value? not-all-9s? s/trim (Integer/parseInt)))
(defmethod pattern->parser :float-no99 [_] #(some-> % good-value? not-all-9s-float? s/trim (Double/parseDouble)))

(defmethod pattern->parser :float [{:keys [pattern]}]
  (float-parser pattern))

(defmethod pattern->parser :noisy-float [{:keys [pattern]}]
  (comp (float-parser pattern) #(s/replace % #"[,$%]" "")))

(defmethod pattern->parser :money [{:keys [pattern]}]
  (comp (float-parser pattern) #(s/replace % #"[,$]" "")))

(defn date-parse [s fmt]
  (->
    (doto (SimpleDateFormat. fmt)
      (.set2DigitYearStart #inst "1980-01-01"))
    (.parse s)
    time/date->local-date
    (.atStartOfDay ZoneOffset/UTC)
    .toInstant
    Date/from))

;;If there are no dd fields than we must make a special formatter that
;;adds the day and modifies the incoming string to have a day (e.g. 01).
(defmethod pattern->parser :date [{:keys [pattern]}]
  (when pattern
    (let [fmt (s/replace pattern #"[YD]" #(s/lower-case %))]
      #(try
         (some-> % good-value? (date-parse fmt))
         (catch Exception e (timbre/debug e (str "Could not parse raw date string \""
                                                 %
                                                 "\" using pattern \""
                                                 fmt
                                                 "\".")))))))

;;MSB - Since adding good-value? to our parsers we really don't know if parsing ends in an error
;; or no value anymore. We should fix this.
(defn gen-safe-parser [pattern]
  (let [parser (pattern->parser pattern)]
    (fn [chunk]
      (into {:pattern   pattern
             :raw-chunk chunk}
            (try {:value (parser chunk)}
                 (catch Exception e {:error (.getMessage e)}))))))

;uses a queue (named stack?) to handle the traversal
;back-off=true causes the function to not include final dictionaries.
;useful for parser specs where the final dictionary describes
;the characteristics of a field.
(defn get-key-chains [a-map back-off]
  (sort (vec (set (loop [stack (map (fn [k] [k]) (keys a-map))
                         key-chains []]
                    (if (empty? stack)
                      key-chains
                      (let [top (first stack)
                            rest-of-stack (rest stack)
                            value (get-in a-map top)]
                        (if (map? value)
                          (recur (concat rest-of-stack (map (fn [k] (conj top k)) (keys value)))
                                 key-chains)
                          (recur rest-of-stack
                                 (if back-off               ;stop at the final dictionary
                                   (conj key-chains (vec (butlast top)))
                                   (conj key-chains top)))))))))))

(defn parse-record [spec m]
  (for [[k p] spec]
    [k ((gen-safe-parser p) (m k))]))

(defn parse-record-deep
  "Supports nested specs.
  Uses the get-key-chains function to find the full path to all of
  the parser definitions, then uses that path to generate both the parser
  and pull the raw data it works on"
  [spec m]
  (let [key-chains (get-key-chains spec true)]
    (for [kc key-chains]
      [kc ((gen-safe-parser (get-in spec kc)) (get-in m kc))])))


(defn parse-map [spec r]
  (reduce
    (fn [{:keys [errors] :as m} [kc {:keys [value error] :as res}]]
      (cond
        value (assoc-in m kc value)
        error (assoc-in
                (cond-> m (not errors) (assoc :errors {}))
                [:errors kc] res)
        :default m))
    (select-keys r [:meta])
    (parse-record-deep spec r)))