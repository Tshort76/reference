(ns soda-common.parsers
  (:require [clojure.instant :as ci]
            [clojure.java.io :as io]
            [clojure.string :as cs]
            [instaparse.core :as insta])
  (:import (java.time.temporal ChronoUnit)
           (java.util Date)))

(def string->parse-tree (insta/parser (io/resource "soda_common/parsers.bnf")))

(defn lpad [s](cond->> s (= 1 (count s)) (str "0")))
(def months ["JAN" "FEB" "MAR" "APR" "MAY" "JUN" "JUL" "AUG" "SEP" "OCT" "NOV" "DEC"])
(def mm (zipmap months (map (comp lpad str inc) (range (count months)))))

(defn group-meta [coll]
  (merge (-> coll first meta (select-keys [:instaparse.gll/start-index]))
         (-> coll last meta (select-keys [:instaparse.gll/end-index]))))

(defn create-date [{:keys [year month-of-year day-of-month]}]
  (-> (ci/read-instant-date (str year "-" month-of-year "-01"))
      .toInstant
      (.plus (dec (Long/parseLong day-of-month)) ChronoUnit/DAYS)
      Date/from))

(def txmap
  {:DBL             (fn [& x] {:double (Double/parseDouble (clojure.string/join x))})
   :INT             (fn [& x] {:integer (Long/parseLong (clojure.string/join x))})
   :DOL             (fn [d & [dm]] {:dollars (* (some d [:double :integer]) (or dm 1))})
   :DOL_MAG         (fn [x] (-> x cs/lower-case {"mm" 1E6 "million" 1E6 "billion" 1E9 "trillion" 1E12}))
   :NUM             (fn [x] x)
   :PCT             (fn [x] {:percent (some x [:double :integer])})
   :FOUR_DIGIT_YEAR (fn [r] {:year r})
   :TWO_DIGIT_YEAR  (fn [s] {:year (if (< (Long/parseLong s) 80) (str "20" s) (str "19" s))})
   :YEAR            (fn [r] {:year r})
   :NAMED_MONTH     (fn [s] {:month-of-year (-> s cs/upper-case (subs 0 3) mm)})
   :MONTH_ABBR      (fn [s] {:month-of-year (-> s cs/upper-case mm)})
   :INT_MONTH       (fn [s] {:month-of-year (lpad s)})
   :DAY_OF_MONTH    (fn [s] {:day-of-month (lpad s)})
   :MONTH_DAY       merge
   :DAY_MONTH       merge
   :MONTH_YEAR      merge
   :DATE            (fn [& r] (let [m (apply merge r)] (with-meta (assoc m :date (create-date m)) (group-meta r))))
   :DATE_RANGE      (fn [{from-year :year :as start} {to-year :year date :date :as end}]
                      {:date-range (->> (range (Long/parseLong from-year) (inc (Long/parseLong to-year)))
                                        (map #(create-date (assoc start :year (str %))))
                                        (remove #(when date (pos? (compare % date)))))
                       :start      start
                       :end        end})
   :S               identity})

(def parse-tree->value (partial insta/transform (assoc txmap :ANY_STRING (fn [s] {:string s}))))

(defn parse [s] (-> s string->parse-tree parse-tree->value))
