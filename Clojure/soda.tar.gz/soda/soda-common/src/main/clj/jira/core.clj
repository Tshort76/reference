(ns jira.core
  (:require [clj-http.client :as http]
            [clojure.data.json :as json]
            [taoensso.timbre :as log]
            [monger.collection :as mc]
            [medley.core :refer [assoc-some]]
            [datasources.core :as ds]))

(defn- configs []
  (if-let [configs (mc/find-one-as-map (ds/get-db "soda_configs") "properties" {:type "jira"})]
    configs
    (throw (RuntimeException. "jira configs not found in soda_configs.properties where type=jira"))))

(defn base-url [] (:base-url (configs)))

(defn creds []
  (let [{:keys [uname pwd]} (configs)]
    {:basic-auth [uname pwd]}))

(defn- body-as-map [{:keys [status body] :as m}]
  (if (= 200 status)
    (json/read-str body :key-fn keyword)
    (throw (ex-info (str "received status=" status) m))))

(defn search
  ([^String jql] (search jql 1000))
  ([^String jql max-results]
   (-> (str (base-url) "search?maxResults=" max-results "&jql=" jql)
       (http/get (creds))
       (body-as-map))))

(defn- get-project-id [project-name]
  (-> (str (base-url) "project/" project-name)
      (http/get (creds))
      (body-as-map)
      :id))

(defn get-fields-from-case [case & keys]
  (try (some-> (str (base-url) "issue/" case)
               (http/get (creds))
               (body-as-map)
               :fields
               (select-keys keys))
       (catch Exception e (throw (ex-info "exception getting fields from case" {:case case :keys keys} e)))))

(defn critical [] "Critical")
(defn major [] "Major")
(defn minor [] "Minor")

(defn create-case [{:keys [project-name issue-type summary description priority] :as m}]
  (if (some empty? [project-name issue-type summary description])
    (throw (ex-info "One of the required fields (project-name, issue-type, summary, description) is empty or nil" m))
    (if-let [project-id (try (get-project-id project-name)
                             (catch Exception e (throw (ex-info "Failed to retrieve project-id"
                                                                (assoc m :exception e)))))]
      (let [{[username _] :basic-auth :as auth} (creds)
            case {:fields {:summary     summary
                           :description description
                           :project     {:id project-id}
                           :issuetype   {:name issue-type}
                           :reporter    {:name username}
                           :priority    {:name (or priority (minor))}}}]
        (log/debug (str "submitting jira case: " (pr-str case)))
        (http/post (str (base-url) "issue")
                   (assoc auth :body
                               (json/write-str case)
                               :content-type :json)))
      (throw (ex-info (str "Project id not found for project=" project-name) m)))))

