(ns util.metrics
  (:require [chime :as chime]
            [clj-time.core :as t]
            [datasources.core :as ds]
            [monger.collection :as mc]
            [taoensso.timbre :as timbre])
  (:import (java.lang.management ManagementFactory)
           (java.net InetAddress)))

;http://docs.oracle.com/javase/7/docs/jre/api/management/extension/com/sun/management/OperatingSystemMXBean.html
(def OS-MX-bean (ManagementFactory/getOperatingSystemMXBean))
(def startup-time (System/currentTimeMillis))

(defn get-raw-machine-stats []
  (let [rt (Runtime/getRuntime)]
    {:total-physical-memory (.getTotalPhysicalMemorySize OS-MX-bean)
     :free-physical-memory  (.getFreePhysicalMemorySize OS-MX-bean)
     :committed-memory      (.getCommittedVirtualMemorySize OS-MX-bean)
     :total-swap-space      (.getTotalSwapSpaceSize OS-MX-bean)
     :free-swap-space       (.getFreeSwapSpaceSize OS-MX-bean)
     :process-cpu-load      (.getProcessCpuLoad OS-MX-bean)
     :process-cpu-time      (.getProcessCpuTime OS-MX-bean)
     :system-cpu-load       (.getSystemCpuLoad OS-MX-bean)
     :system-load-avg       (.getSystemLoadAverage OS-MX-bean)
     :process-uptime        (- (System/currentTimeMillis) startup-time)
     :heap-size             (.totalMemory rt)
     :free-heap             (.freeMemory rt)}))

(defn simplify-stats [{:keys [system-cpu-load free-physical-memory total-physical-memory
                              free-swap-space total-swap-space process-uptime
                              free-heap heap-size]}]
  {:cpu    system-cpu-load
   :memory (double (- 1 (/ free-physical-memory total-physical-memory)))
   :swap   (double (- 1 (/ free-swap-space total-swap-space)))
   :uptime process-uptime
   :heap   (double (/ (- heap-size free-heap) heap-size))})

(defn periodically-report-machine-stats
  "Report machine stats every 'interval' seconds."
  [interval]
  (chime/chime-at
    (iterate #(t/plus % (t/seconds interval)) (t/now))
    (fn [time]
      (timbre/trace "Saving snapshot of machine utilization (cpu, memory, etc) to soda-analytics/machine-stats")
      (mc/insert (ds/get-db "soda-analytics") "machine-stats"
                 (let [raw-stats (get-raw-machine-stats)]
                   {:host (.getHostName (InetAddress/getLocalHost)) :date-time (.toDate time) :stats (simplify-stats raw-stats) :raw-stats raw-stats})))))