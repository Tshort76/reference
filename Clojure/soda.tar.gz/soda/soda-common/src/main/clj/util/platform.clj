(ns util.platform
  (:require [taoensso.timbre :as timbre]
            [clojure.java.io :as io])
  (:import (java.util Properties)))

(defn windows?
  "Determines if the program is currently running on windows."
  []
  (boolean (re-find #"(?i)window" (System/getProperty "os.name"))))

(defn project-version
  "Reads in project version from jar.  Tries a few different techniques."
  [artifact]
  (or (-> artifact (str "-version") keyword environ.core/env)
      (-> "-version" keyword environ.core/env)
      (System/getProperty (str artifact ".version"))
      (try
        (-> (doto (Properties.)
              (.load (-> "META-INF/maven/com.clearwateranalytics/%s/pom.properties"
                         (format artifact)
                         (io/resource)
                         (io/reader))))
            (.get "version"))
        (catch Exception e
          (timbre/warn e "Could not find project version.")
          nil))))