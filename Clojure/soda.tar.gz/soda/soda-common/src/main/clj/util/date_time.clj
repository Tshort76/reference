(ns util.date-time
  (:require [clj-time.core :as t]
            [clj-time.format :as tf]
            [clj-time.predicates :as pr]
            [clj-time.coerce :as tc])
  (:import (java.text DecimalFormat SimpleDateFormat)
           (java.time LocalDate ZoneId ZoneOffset LocalDateTime)
           (java.time.format DateTimeFormatter)
           (java.util Calendar Date Map TimeZone)))

(defn month-abbr->month-num [abbr]
  (->> abbr
       (tf/parse (tf/formatter "MMM"))
       (tf/unparse (tf/formatter "MM"))))

(defn ^LocalDate date->local-date [^Date date]
  (some-> date .toInstant (.atZone (ZoneId/of "Z")) .toLocalDate))

(defn local-date->date [^LocalDate local-date]
  (some-> local-date (.atStartOfDay (ZoneId/of "Z")) .toInstant Date/from))

(defn yyyy-mm-dd->date [^String string-date]
  (local-date->date (LocalDate/parse string-date)))

(defn new-date [^long year ^long month ^long day]
  (local-date->date (LocalDate/of year month day)))

(defn first-of-month [date]
  (some-> date date->local-date (.withDayOfMonth 1) local-date->date))

(defn last-of-month [date]
      (some-> date date->local-date (#(.withDayOfMonth % (.lengthOfMonth %))) local-date->date))

(defn first-of-prior-month [date]
  (some-> date date->local-date (.withDayOfMonth 1) (.minusMonths 1) local-date->date))

(defn year-of-date [date]
  (some-> date date->local-date .getYear))

(defn day-of-month [date]
  (when (inst? date)
    (some-> date date->local-date .getDayOfMonth)))

(defn month-of-year [date]
  (when (inst? date)
    (some-> date date->local-date .getMonthValue)))

(defn inc-month [date & [n-months]]
  (when (inst? date)
    (some-> date date->local-date (.plusMonths (or n-months 1)) local-date->date)))

(defn dec-month [date & [n-months]]
  (when (inst? date)
    (some-> date date->local-date (.minusMonths (or n-months 1)) local-date->date)))

(def format-dd (DecimalFormat. "00"))
(defn dd [x] (.format format-dd x))
(def YYYYMMDD-format (SimpleDateFormat. "yyyyMMdd"))
(def YYYY-MM-DD-format (SimpleDateFormat. "yyyy-MM-dd"))

(defprotocol TimeFuncs
  (date->yyyymmdd [date])
  (date->yyyy-mm-dd [date])
  (to-two-year-span [date])
  (millis-since-unix [date])
  (->Date [date])
  (->LocalDateUTC [date]))

(extend-protocol TimeFuncs
  String
  (->Date [date] (tc/to-date date))

  Date
  (date->yyyymmdd [date] (some-> date ->LocalDateUTC date->yyyymmdd))
  (date->yyyy-mm-dd [date] (some-> date ->LocalDateUTC date->yyyy-mm-dd))
  (to-two-year-span [date]
    (let [tf (doto (Calendar/getInstance)
               (.setTimeZone (TimeZone/getTimeZone "Z"))
               (.setTime date)
               (.add Calendar/DAY_OF_MONTH 1)
               (.set Calendar/HOUR_OF_DAY 0)
               (.set Calendar/MINUTE 0)
               (.set Calendar/SECOND 0)
               (.set Calendar/MILLISECOND 0))
          ti (doto (Calendar/getInstance)
               (.setTimeZone (TimeZone/getTimeZone "Z"))
               (.setTime (.getTime tf))
               (.add Calendar/YEAR -2))]
      [(.getTime ti) (.getTime tf)]))
  (millis-since-unix [date] (.getTime date))
  (->Date [date] date)
  (->LocalDateUTC [date] (some-> date .toInstant (.atZone ZoneOffset/UTC) .toLocalDate))

  LocalDate
  (date->yyyymmdd [date] (.format date DateTimeFormatter/BASIC_ISO_DATE))
  (date->yyyy-mm-dd [date] (.format date DateTimeFormatter/ISO_LOCAL_DATE))
  (to-two-year-span [date] (let [tf (.plusDays date 1)] [(.minusYears tf 2) tf]))
  (millis-since-unix [date] (-> date (.atStartOfDay (ZoneId/of "UTC")) .toInstant .toEpochMilli))
  (->LocalDateUTC [date] date)
  (->Date [date] (Date. ^long (millis-since-unix date)))

  LocalDateTime
  (->Date [date] (-> date (.atZone (ZoneId/systemDefault)) .toInstant Date/from))

  Map
  (date->yyyymmdd [{:keys [year month day]}] (str year (dd month) (dd day)))
  (date->yyyy-mm-dd [{:keys [year month day]}] (str year "-" (dd month) "-" (dd day)))
  (to-two-year-span [{:keys [^long year ^long month ^long day]}]
    (let [d (LocalDate/of year month day)
          end (.plusDays d 1)
          start (.minusYears end 2)]
      [{:year (.getYear start) :month (.getMonthValue start) :day (.getDayOfMonth start)}
       {:year (.getYear end) :month (.getMonthValue end) :day (.getDayOfMonth end)}]))
  (millis-since-unix [{:keys [^long year ^long month ^long day]}]
    (let [d (LocalDate/of year month day)]
      (-> d (.atStartOfDay (ZoneId/of "UTC")) .toInstant .toEpochMilli)))
  (->Date [date] (Date. ^long (millis-since-unix date)))
  (->LocalDateUTC [{:keys [^long year ^long month ^long day]}] (LocalDate/of year month day))

  nil
  (date->yyyymmdd [& _])
  (date->yyyy-mm-dd [& _])
  (to-two-year-span [& _])
  (millis-since-unix [& _])
  (->Date [& _])
  (->LocalDateUTC [& _]))


(defn quarter-to-dates [{:keys [^long qtr ^long year]}]
  (if (and (pos? qtr) (< qtr 5))
    (let [mnth-days ([[1 1 3 31] [4 1 6 30] [7 1 9 30] [10 1 12 31]] (dec qtr))]
      [(local-date->date (->LocalDateUTC {:year year :month (first mnth-days) :day (second mnth-days)}))
       (local-date->date (->LocalDateUTC {:year year :month (nth mnth-days 2) :day (nth mnth-days 3)}))])))

(defn nth-biz-day-from-date
  "Returns the nth business day before (if prior?) or after
  <from> date"
  [n from prior?]
  (->> from
       (iterate #((if prior? t/minus t/plus) % (t/days 1)))
       rest
       (filter pr/weekday?)
       (take n)
       last))

(defn leap-year?
  "A year is a leap year if it is divisible by 4 and, if divisible by 100, then also divisible by 400
   A year is not a leap year iff it is not divisible by 4 or it is divisible by 100 but not 400"
  [year]
  (and year (zero? (mod year 4))
       (or (pos? (mod year 100))
           (zero? (mod year 400)))))

(defn ->30day
  "In the 30/360 calander, a day is transformed to 30 if it is larger than 30, or if it is the last day of the month"
  [year month day]
  (if (= 2 month)
    (if (leap-year? year)
      (if (= day 29) 30 day)
      (if (= day 28) 30 day))
    (min day 30)))

(defn year-diff-30-360 [d2 d1]
  (if (and d1 d2)
    (let [y2 (year-of-date d2)
          m2 (month-of-year d2)
          day2p (->30day y2 m2 (day-of-month d2))
          y1 (year-of-date d1)
          m1 (month-of-year d1)
          day1p (->30day y1 m1 (day-of-month d1))]
      (/ (+ (* 360 (- y2 y1))
            (* 30 (- m2 m1))
            (- day2p day1p)) 360))))
