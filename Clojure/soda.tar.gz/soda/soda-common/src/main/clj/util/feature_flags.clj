(ns util.feature-flags
  (:require [monger.collection :as mc]
            [datasources.core :as ds]
            [clojure.core.memoize :refer [ttl]]))

(defonce five-minutes-in-ms (* 1000 60 5))

(defn get-all [] (or (mc/find-one-as-map (ds/get-db "soda_configs") "properties" {:type "feature-flags"}) {}))

(defn allowed-to? [& operations]
  (let [ffs (get-all)]
    (every? #(ffs %) operations)))

(def memoized-allowed-to? (ttl allowed-to? :ttl/threshold five-minutes-in-ms))
