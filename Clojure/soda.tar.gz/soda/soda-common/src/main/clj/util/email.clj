(ns util.email
  (:require [postal.core :as postal]
            [environ.core :refer [env]]
            [monger.collection :as mc]
            [datasources.core :as ds])
  (:import (java.net InetAddress)))

(defn get-email-list [group]
  (:email-list
    (mc/find-one-as-map (ds/get-db "soda_configs") "properties"
                        {:type "email-list" :group (or group "soda-team")})))

(defn email-config [group]
  {:from (str "SodaBot@" (.. InetAddress getLocalHost getHostName) ".arbfund.com")
   :to   (or (get-email-list group) ["SoDa@clearwateranalytics.com"])})

(defn email-team [subject body & [group]]
  (postal/send-message
    {:host "intemail.arbfund.com"}
    (assoc (email-config group) :subject subject :body body)))