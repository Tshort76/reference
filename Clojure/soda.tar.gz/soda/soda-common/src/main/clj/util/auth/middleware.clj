(ns util.auth.middleware
  (:require [clj-time.coerce :as tc]
            [environ.core :refer [env]]
            [ring.util.http-response :refer :all]
            [util.auth.core :refer :all])
  (:import (java.util Locale)
           (org.joda.time.format DateTimeFormat)))

(def rfc-1123-date-time-formatter
  (.withLocale (.withZoneUTC (DateTimeFormat/forPattern "EEE, dd MMM yyyy HH:mm:ss 'GMT'")) Locale/US))

(defn seconds->cookie-date-str
  "Date strings in cookies must be formatted just so..."
  [exp-seconds]
  (.print rfc-1123-date-time-formatter (tc/from-long (* 1000 exp-seconds))))

(defn add-jwt-to-session
  "Add JWT and extracted data to the session of the incoming request."
  [request jwt]
  (assoc-in request [:session :user] {:data (token-str->validated-token-map jwt) :jwt jwt}))

(defn remove-user-data-from-session
  "Remove user data from the session with the outgoing response."
  [response]
  (update response :session dissoc :user))

(defn set-jwt-cookie
  "Add the JWT to a cookie on the outgoing response."
  [response jwt]
  (let [{:keys [exp]} (token-str->validated-token-map jwt)]
    (assoc-in response [:cookies "jwt"] {:value jwt :path "/" :expires (seconds->cookie-date-str exp)})))

(defn remove-jwt-cookie
  "Expires the JWT cookie with the outgoing response."
  [response]
  (assoc-in response [:cookies "jwt"] {:value "" :path "/" :max-age 1}))

(defn logout-response []
  (-> (ok {})
      remove-user-data-from-session
      remove-jwt-cookie))

;AUTHENTICATION MIDDLEWARE

(defn handle-authentication-middleware
  "Adds authentication info to request if it exists in: session, cookies, jwt query param, or bearer header.
  Attempt to persist authentication via session/cookies if the request appears to have been initiated from a browser.
  Generally speaking this should be wrapped around all app routes if authentication is to be used in the app."
  [next-handler]
  (fn [request]
    (cond
      ;request has already gone through an upstream instance of this middleware-fn, NOP
      (-> request keys set ::auth)
      (next-handler request)

      ;jwt in bearer header (intended for programmatic, not browser, use - does not attempt to persist session)
      (-> request (get-in [:headers "bearer"]) token-str->validated-token-map :exp expiration-in-future?)
      (let [auth-map (-> request (get-in [:headers "bearer"]) token-str->validated-token-map)]
        (-> request
            (assoc ::auth auth-map)
            next-handler))

      ;non-expired auth session
      (expiration-in-future? (get-in request [:session :user :data :exp]))
      (-> request
          (assoc ::auth (get-in request [:session :user :data]))
          next-handler)

      ;non-expired jwt in cookies
      (-> request (get-in [:cookies "jwt" :value]) token-str->validated-token-map :exp expiration-in-future?)
      (let [jwt (get-in request [:cookies "jwt" :value])]
        (-> request
            (add-jwt-to-session jwt)
            (assoc ::auth (token-str->validated-token-map jwt))
            next-handler))

      ;non-expired jwt in params
      (-> request (get-in [:query-params "jwt"]) token-str->validated-token-map :exp expiration-in-future?)
      (let [jwt (get-in request [:query-params "jwt"])]
        (-> request
            (add-jwt-to-session jwt)
            (assoc ::auth (token-str->validated-token-map jwt))
            next-handler
            (set-jwt-cookie jwt)))

      ;no jwt found, assoc nil ::auth so future middleware can NOP
      :else
      (-> request (assoc ::auth nil) next-handler))))

(defn require-authentication-middleware
  "Requires the presence of a non-expired jwt in either the session, a cookie, or a query param.
  Will redirect to the auth-ws login page (as specified in the app's env) in all other cases."
  [next-handler]
  (fn [request]
    (if (::auth request)
      (next-handler request)
      (let [user-agent-str (.toLowerCase (get-in request [:headers "user-agent"]))
            browser-request? (some #(.contains user-agent-str %) ["mozilla" "chrome" "safari" "webkit"])
            referer (get-in request [:headers "referer"])
            swagger-ui? (and (string? referer) (re-matches #".*swagger-ui.*" referer))]
        (cond
          swagger-ui?
          (unauthorized {:message "This resource is authenticated. You will have to log in to use it."})

          browser-request?
          (temporary-redirect (str "https://" (:internal-tools-domain env) "/auth-ws/?callback="
                                   (name (:scheme request)) "://" (:server-name request) ":" (:server-port request)
                                   (:servlet-context-path request) (:auth-redirect-route env)))

          :else
          (unauthorized {:message "Request is missing a valid non-expired JWT supplied via the Bearer header."}))))))

;AUTHORIZATION MIDDLEWARE

(defn request-has-permission-in-set?
  "Helper function used by request-authorized? to specify how to actually look for permissions in the request. Override
  this function to support non-heimdall permissions, or if permissions are stored in the request in a non-default way."
  [request permission-set]
  (some permission-set (get-in request [::auth :heimdall])))

(defn request-authorized?
  "Returns true if every permission argument is satisfied. Permission arguments can be either a single permission
  (must be held) or a set of permissions (at least one must be held) in a format that can be understood by
  request-has-permission-in-set?."
  ([request] request)
  ([request permission]
   (let [permission-set (if (set? permission) permission #{permission})]
     (request-has-permission-in-set? request permission-set)))
  ([request permission & more]
   (every? (partial request-authorized? request) (cons permission more))))

(defn create-require-authorization-middleware
  "Creates a handler that returns HTTP 403 Forbidden if the request does not satisfy the specified permissions."
  [& permissions]
  (fn [next-handler]
    (fn [request]
      (if (apply (partial request-authorized? request) permissions)
        (next-handler request)
        (forbidden {:message "You do not have the required permissions to do that."
                    :required-permissions permissions})))))

;AUTHENTICATION & AUTHORIZATION MIDDLEWARE

(defn create-auth-middleware
  "Handler that both assures authentication as well as ensuring any provided heimdall permissions are met."
  [& permissions]
  (comp require-authentication-middleware (apply create-require-authorization-middleware permissions)))