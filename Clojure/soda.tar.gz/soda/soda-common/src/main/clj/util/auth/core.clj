(ns util.auth.core
  (:require [clojure.walk :as walk]
            [environ.core :refer [env]]
            [ring.util.http-response :refer :all]
            [taoensso.timbre :as timbre])
  (:import (com.ca.authtoken.core AuthTokenCore$AuthTokenBuilder)
           (com.auth0.jwt.exceptions JWTDecodeException SignatureVerificationException)
           (java.util Map)))

(def auth-token-core (.build (AuthTokenCore$AuthTokenBuilder. "SoDa App")))

;stolen from clojure.walk and modified to work on java maps as well as clojure maps
(defn keywordize-keys [m]
  (let [f (fn [[k v]] (if (string? k) [(keyword k) v] [k v]))]
    (walk/postwalk (fn [x] (if (instance? Map m)
                             (into {} (map f x))
                             x))
                   m)))

(defn token-str->validated-token-map [token-str]
  (try
    (when (string? token-str)
      (keywordize-keys (.decodeToken auth-token-core token-str)))
    ;No exception during JWT decoding should prevent an attempt at responding to a request
    ;At worst, the request should proceed without info from the JWT as unauthenticated
    (catch JWTDecodeException e
      (timbre/trace e "JWT appears to be invalid - failed to decode."))
    (catch SignatureVerificationException e
      (timbre/trace e "JWT appears to be invalid - failed to decode."))
    (catch Exception e
      (timbre/trace e "Exception suppressed while attempting to decode JWT - failed to decode"))))

(defn expiration-in-future? [seconds-since-epoch]
  (pos? (- (or seconds-since-epoch 0) (quot (System/currentTimeMillis) 1000))))