(ns util.app-status
  (:require [environ.core :refer [env]]
            [clojure.java.shell :as shell]
            [datasources.core :as ds]
            [util.platform :refer [windows?]]
            [clj-http.client :as http])
  (:import (java.io File IOException)
           (java.util Date)))

(defn file-system-issue?
  "The file system is deemed okay if :source-files-filepath points to a non-empty, linux, mounted device.
   Note that this function will likely say there is an issue if the project is running locally"
  []
  (if (windows?)
    "app is not running on linux"
    (try
      (let [{:keys [exit out]} (shell/sh "stat" "--file-system" "--format=%T" (:source-files-filepath env))]
        (cond
          (= 1 exit)
          (format "non-zero exit code (%s) returned from stat command" exit)

          (not out)
          "no output returned from stat command"

          (re-find #"ext[\d]" out)
          "local filesystem (ext*) detected"

          (< (count (.listFiles (File. (:source-files-filepath env)))) 16) ; expect at least hexadecimal directories
          "too few files/directories in filesystem"))
      (catch IOException e (str e)))))

(defn app-status [app-name]
  (let [fs-error (file-system-issue?)]
    (cond-> {:status_code 0
             :status_msg  (str app-name " is up.")
             :timestamp   (str (Date.))}
      fs-error (assoc :status_msg (format "Bad file-system mount at %s: %s" (:source-files-filepath env) fs-error)
                      :status_code 2)
      (not (ds/mongo-working?)) (assoc :status_msg (str "Problem with mongo connection")
                                       :status_code 2))))

(def status-cache (atom {}))
(def status-request-frequency (* 60 1000)) ;once a minute

(defn cached-cw-app-status [status-url]
  (when (<= status-request-frequency
          (- (System/currentTimeMillis) (or (get-in @status-cache [status-url :last-request-time]) 0)))
    (swap! status-cache assoc status-url
           {:last-request-time (System/currentTimeMillis)
            :status (try (-> (http/get status-url {:throw-exceptions false})
                             :body
                             clojure.data.json/read-str
                             clojure.walk/keywordize-keys)
                         (catch Exception e
                           {:status_code 2
                            :status_msg "Error connecting to or parsing soda-api status endpoint"}))}))
  (get-in @status-cache [status-url :status]))

(defn generic-cw-web-component [component-name status-url]
  (fn [] (merge {:component component-name :endpoint status-url}
                (select-keys (cached-cw-app-status status-url) [:status_code :status_msg]))))

(defn file-system-status-component []
  (if-let [fs-error (file-system-issue?)]
    {:component "file-system"
     :status_code 2
     :status_msg (format "Bad file-system mount at %s: %s" (:source-files-filepath env) fs-error)}
    {:component "file-system"
     :status_code 0}))

(defn mongo-status-component []
  (if-not (ds/mongo-working?)
    {:component "mongo-db"
     :status_code 2
     :status_msg "Problem with mongo connection"}
    {:component "mongo-db"
     :status_code 0}))

(def startup-time (System/currentTimeMillis))

(defn status-components->status [other-properties & component-fns]
  (let [component-maps (for [f component-fns] (f))
        status-codes (->> component-maps (map :status_code) (filter number?) seq)
        overall-status-code (if status-codes (apply max status-codes) 2)] ;if no status codes provided, assume an error
    (merge other-properties
           {:status_code overall-status-code
            :status_msg (str "The status code is: " overall-status-code)
            :timestamp (str (Date.))
            :uptime (- (System/currentTimeMillis) startup-time)
            :team-documentation "https://confluence.arbfund.com/display/DEV/SoDa+On-Call+Documentation"
            :components {:ok (filter #(= 0 (:status_code %)) component-maps)
                         :warning (filter #(= 1 (:status_code %)) component-maps)
                         :critical (filter #(= 2 (:status_code %)) component-maps)}})))