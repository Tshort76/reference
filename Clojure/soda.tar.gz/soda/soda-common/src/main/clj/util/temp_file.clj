(ns util.temp-file
  (:import (java.io File)))

(defmacro let-temp-file [[file-symbol file-name file-extention] & guts]
  `(let [~file-symbol (File/createTempFile ~file-name ~file-extention)]
     (try ~@guts
       (finally (.delete ~file-symbol)))))
