(ns util.xml
  (:require [clojure.data.zip.xml :as xml1]
            [clojure.data.xml :as xml]
            [clojure.set :refer [rename-keys]]
            [clojure.zip :as zip])
  (:import (clojure.data.xml Element)))

(defn vectorize [prev new]
  (if (sequential? prev) (conj prev new) (vector prev new)))

(defn xml-elem->edn [{:keys [tag content]}]
  {tag (if (= (-> content first type) Element)
         (apply merge-with vectorize (map xml-elem->edn content))
         (first content))})

(defn xml-elem->edn-with-attrs
  "Converts an xml element into EDN, including the
  attributes for each element in the tree"
  [{:keys [tag content attrs]}]
  (let [has-attributes? (not-empty attrs)]
    {tag (if (= (-> content first type) Element)
           (let [value (apply merge-with vectorize
                              (map xml-elem->edn-with-attrs content))]
             (if has-attributes?
               (merge attrs value)
               value))
           (if has-attributes?
             (assoc attrs :value (first content))
             (first content)))}))

(defn input-stream->zipper [is]
  (-> is
      xml/parse
      zip/xml-zip
      xml1/xml1->))