(ns util.crypt
  "Support for AES encryption.  Provides support for encryption with any string,
  will fall back to the key stored in the environment if none is provided."
  (:require [environ.core :refer [env]]
            [lock-key.core :as lk]
            [taoensso.timbre :as log]))

(defn encrypt
  ([text] (if-let [key (:sym-key env)]
            (encrypt text key)
            (log/info "sym-key was NOT found in the environment!")))
  ([text key]
   (lk/encrypt-as-base64 text key)))

(defn decrypt
  ([text] (if-let [key (:sym-key env)]
            (decrypt text key)
            (log/info "sym-key was not in the environment, but you attempted to decrypt.")))
  ([text key]
   (lk/decrypt-from-base64 text key)))
