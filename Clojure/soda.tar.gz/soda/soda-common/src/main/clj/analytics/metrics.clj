(ns analytics.metrics
  (:require [chime :as chime]
            [clj-graphite.client :as raw-graphite]
            [clj-time.core :as t]
            [clojure.string :as str]
            [datasources.core :as ds]
            [environ.core :refer [env]]
            [metrics.counters :as counters]
            [metrics.histograms :as histograms]
            [metrics.meters :as meters]
            [metrics.timers :as timers]
            [metrics.reporters.graphite :as graphite]
            [monger.collection :as mc]
            [soda.server-core :as ssc]
            [taoensso.timbre :as timbre])
  (:import (com.codahale.metrics MetricFilter)
           (java.net InetAddress)
           (java.util.concurrent TimeUnit)
           (java.util Date)))

(def host (.getHostName (InetAddress/getLocalHost)))
(def environment (or (:tier env) "other"))

(def GR (graphite/reporter {:host          "graphite"
                            :port          2003
                            :prefix        ""
                            :rate-unit     TimeUnit/SECONDS
                            :duration-unit TimeUnit/MILLISECONDS
                            :filter        MetricFilter/ALL}))
(graphite/start GR 10)

(def default-metrics-config {:_id "graphite"
                             :disable-all-metrics false
                             :jobs {:enabled true}
                             :api {:enabled true}
                             :validation {:enabled true}
                             :scheduled {:enabled true :interval-seconds 5}
                             :enqueued {:enabled true :interval-seconds 5}
                             :unresolved_failures {:enabled true :interval-seconds 5}})

(def metrics-configs (atom nil))

(defn update-configs []
  (let [db-configs (mc/find-one-as-map (ds/get-db "soda-analytics") "metrics-config" {:_id "graphite"})]
    (reset! metrics-configs (merge default-metrics-config db-configs))))

(defn schedule-at-intervals [f interval-fn & {:keys [start-time] :or {start-time (t/now)}}]
  (chime/chime-at (iterate (fn [last-time] (t/plus last-time (interval-fn))) start-time)
                  (fn [t] (f))))

(defn init-metric-config []
  (try
    (timbre/debug "Reading initial metric reporting configs from DB...")
    (ssc/do-with-db-retries update-configs) ;ensure this gets called before continuing
    (schedule-at-intervals (fn []
                             (when (not= environment "other") (timbre/debug "Refreshing metric reporting configs..."))
                             (try (update-configs)
                                  (when (not= environment "other") (timbre/debug "Configs refreshed."))
                                  (catch Exception e (timbre/info (str "Error while refreshing metrics configs: " e)))))
                           (partial t/seconds 30)
                           :start-time (t/plus (t/now) (t/seconds 30)))
    (catch Exception e
      (timbre/info (str "Exception while initializing metric reporting config. Metrics will not be reported.\n" e)))))

(defn metric-path [& parts]
  (let [vec-parts (map #(if (vector? %) % [%]) parts)
        path (vec (apply concat vec-parts))]
    (mapv #(str/replace (str %) #"[^a-zA-Z0-9-_]" "_") path)))
(def API_BASE ["soda" "api" environment host])
(def JOB_BASE ["soda" "jobs" environment "workers" host])

; API Metrics

(defn request-looks-like-endpoint? [{context :context [method route] :compojure/route :as request}]
  (not (or (.contains route ".") (.contains (.toLowerCase route) "swagger"))))

(defn metric-request-handler [next-handler {context :context [method route] :compojure/route :as request}]
  (if (and (not (:disable-all-metrics @metrics-configs))
           (get-in @metrics-configs [:api :enabled]))
    (let [endpoint-base (metric-path API_BASE "endpoints" (str context route) "method" (.toUpperCase (name method)))]
      (counters/inc! (counters/counter (metric-path API_BASE "concurrent-requests")))
      (meters/mark! (meters/meter (metric-path endpoint-base "requests")))
      (let [response (timers/time! (timers/timer (metric-path endpoint-base "response-time"))
                                   (next-handler request))
            response-status-category (str (quot (:status response 0) 100) "xx")]
        (meters/mark! (meters/meter (metric-path endpoint-base "responses" response-status-category)))
        (counters/dec! (counters/counter (metric-path API_BASE "concurrent-requests")))
        response))
    (next-handler request)))

(defn wrap-api-metrics [handler]
  (fn [request]
    (if (request-looks-like-endpoint? request)
      (metric-request-handler handler request)
      (handler request))))

; Job Metrics

(defn record-job-polled [{{job-type :type} :job-def :as job} query-index priority]
  (when (and (not (:disable-all-metrics @metrics-configs))
             (get-in @metrics-configs [:jobs :enabled]))
    (meters/mark! (meters/meter (metric-path JOB_BASE ["queries" query-index "polled"])))
    (meters/mark! (meters/meter (metric-path JOB_BASE ["priorities" priority "polled"])))
    (meters/mark! (meters/meter (metric-path JOB_BASE ["job-types" job-type "polled"])))))

(defn record-missed-poll []
  (when (and (not (:disable-all-metrics @metrics-configs))
             (get-in @metrics-configs [:jobs :enabled]))
    (meters/mark! (meters/meter (metric-path JOB_BASE "poll-misses")))))

(defn record-job-complete [{:keys [cancellation-reason unrecoverable error-code run-time] :as job}]
  (when (and (not (:disable-all-metrics @metrics-configs))
             (get-in @metrics-configs [:jobs :enabled]))
    (let [job-type (get-in job [:job-def :type])
          completion-type (cond unrecoverable "unrecoverable error"
                                cancellation-reason (name cancellation-reason)
                                error-code "error"
                                :else "success")]
      (meters/mark! (meters/meter (metric-path JOB_BASE ["job-types" job-type "completion" completion-type "completed"])))
      (histograms/update! (histograms/histogram (metric-path JOB_BASE ["job-types" job-type "completion" completion-type "run-times"]))
                          run-time))))

(defn record-job-start [{{job-type :type} :job-def :as job}]
  (when (and (not (:disable-all-metrics @metrics-configs))
             (get-in @metrics-configs [:jobs :enabled]))
    (let [timer-context (timers/start (timers/timer (metric-path JOB_BASE ["job-types" job-type "processing-times"])))]
      (meters/mark! (meters/meter (metric-path JOB_BASE ["job-types" job-type "started"])))
      timer-context)))

(defn record-job-stop [timer-context]
  (when (and (not (:disable-all-metrics @metrics-configs))
             (get-in @metrics-configs [:jobs :enabled])
             timer-context)
    (timers/stop timer-context)))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Raw, unbatched, data to graphite below here. Be cautious of using this approach for lots of data ;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(def raw-graphite-client (raw-graphite/client {:host "graphite" :port 2003}))
(defn send-raw-value [path-str value]
  (.feed raw-graphite-client path-str (float value) (long (/ (System/currentTimeMillis) 1000))))

(def validation-categories [:valid :diff :no-soda :no-lm :no-data])

(defn validation-results->graphite [results control-set source]
  (when (and (not (:disable-all-metrics @metrics-configs))
             (get-in @metrics-configs [:validation :enabled]))
    (doseq [[field field-results] results]
      (let [existing-category-counts (into {} (for [[category {value :count}] field-results] [category value]))
            all-category-counts (merge (zipmap validation-categories (repeat 0)) existing-category-counts)]
        (doseq [[category value] all-category-counts]
          (send-raw-value (str "soda.db." (or (:tier env) host) ".validation." (name source) ".control-set."
                               (name control-set) ".field." (name field) ".result." (name category) ".count")
                          value))))
    (timbre/debug (str "Wrote validation results to graphite for control-set: " control-set " and source: " source))))

(defn scheduled-metrics [& {:keys [look-limit return-limit] :or {look-limit Integer/MAX_VALUE return-limit Integer/MAX_VALUE}}]
  (mc/aggregate (ds/get-db "soda_configs") "queue"
                [{"$match" {"run-after" {"$gt" (Date.)}}}
                 ;look at no more than 'look-limit' failed documents (prevent slow aggregation)
                 {"$limit" look-limit}
                 {"$group" {:_id "$job-def.type" :count {"$sum" 1}}}
                 ;return no more than 'return-limit' distinct failures (prevent large payload)
                 {"$limit" return-limit}]
                :cursor 20
                :max-time (* 1000 (dec (get-in @metrics-configs [:scheduled :interval-seconds]))))) ;1s less than interval-seconds, in ms

(defn scheduled-jobs->graphite
  "Report jobs in queue with run-time in future by type, at path 'soda.db.<env||host>.scheduled.job-type.<type>.count'"
  []
  (when (and (not (:disable-all-metrics @metrics-configs))
             (get-in @metrics-configs [:scheduled :enabled]))
    (doseq [{:keys [_id count]} (scheduled-metrics)]
      (send-raw-value (str "soda.db." (or (:tier env) host) ".scheduled.job-type." _id ".count") count))
    (when (not= environment "other") (timbre/debug "Completed reporting scheduled-job metrics."))))

(defn enqueued-metrics [& {:keys [look-limit return-limit] :or {look-limit Integer/MAX_VALUE return-limit Integer/MAX_VALUE}}]
  (mc/aggregate (ds/get-db "soda_configs") "queue"
                [{"$match" {"run-after" {"$lte" (Date.)}}}
                 ;look at no more than 'look-limit' failed documents (prevent slow aggregation)
                 {"$limit" look-limit}
                 {"$group" {:_id "$job-def.type" :count {"$sum" 1}}}
                 ;return no more than 'return-limit' distinct failures (prevent large payload)
                 {"$limit" return-limit}]
                :cursor 20
                :max-time (* 1000 (dec (get-in @metrics-configs [:enqueued :interval-seconds]))))) ;1s less than interval-seconds, in ms

(defn enqueued-jobs->graphite
  "Report jobs in queue with run-time in past by type, at path 'soda.db.<env||host>.queue.job-type.<type>.count'"
  []
  (when (and (not (:disable-all-metrics @metrics-configs))
             (get-in @metrics-configs [:enqueued :enabled]))
    (doseq [{:keys [_id count] :as X} (enqueued-metrics)]
      (send-raw-value (str "soda.db." (or (:tier env) host) ".queue.job-type." _id ".count") count))
    (when (not= environment "other") (timbre/debug "Completed reporting enqueued-job metrics."))))

(defn unresolved-failure-metrics [& {:keys [look-limit return-limit] :or {look-limit Integer/MAX_VALUE return-limit Integer/MAX_VALUE}}]
  (mc/aggregate (ds/get-db "soda_configs") "unresolved_failures"
                [;look at no more than 'look-limit' failed documents (prevent slow aggregation)
                 {"$limit" look-limit}
                 {"$group" {:_id {"error-id" {"$ifNull" ["$error-code" "$cancellation-reason"]}
                                  "job-type" "$job-def.type"}
                            :count {"$sum" 1}}}
                 ;return no more than 'return-limit' distinct failures (prevent large payload)
                 {"$limit" return-limit}]
                :cursor 20
                :max-time (* 1000 (dec (get-in @metrics-configs [:enqueued :interval-seconds]))))) ;1s less than interval-seconds, in ms

(defn unresolved-failures->graphite
  "Report unresolved-failures by error-id + job-type, at path 'soda.db.<env||host>.unresolved-failures.error-id.<id>.job-type.<type>.count'"
  []
  (when (and (not (:disable-all-metrics @metrics-configs))
             (get-in @metrics-configs [:unresolved_failures :enabled]))
    (doseq [{{:keys [error-id job-type]} :_id count :count} (unresolved-failure-metrics)]
      (send-raw-value (str "soda.db." (or (:tier env) host) ".unresolved-failures.error-id." error-id ".job-type." job-type ".count") count))
    (when (not= environment "other") (timbre/debug "Completed reporting unresolved_failure metrics."))))

(defn schedule-periodic-db-metrics []
  (timbre/debug "Scheduling periodic DB metric reporting...")
  (schedule-at-intervals (fn [] (try (scheduled-jobs->graphite)
                                     (catch Exception e (timbre/info (str "Error while reporting scheduled jobs metrics to graphite: " e)))))
                         (fn [] (t/seconds (get-in @metrics-configs [:scheduled :interval-seconds]))))
  (schedule-at-intervals (fn [] (try (enqueued-jobs->graphite)
                                     (catch Exception e (timbre/info (str "Error while reporting enqueued jobs metrics to graphite: " e)))))
                         (fn [] (t/seconds (get-in @metrics-configs [:enqueued :interval-seconds]))))
  (schedule-at-intervals (fn [] (try (unresolved-failures->graphite)
                                     (catch Exception e (timbre/info (str "Error while reporting unresolved_failures metrics to graphite: " e)))))
                         (fn [] (t/seconds (get-in @metrics-configs [:unresolved_failures :interval-seconds]))))
  (timbre/debug "DB metric reports are all scheduled."))
