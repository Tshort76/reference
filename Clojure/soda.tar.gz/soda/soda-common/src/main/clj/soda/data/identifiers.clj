(ns soda.data.identifiers
  (:require [datasources.core :as ds]
            [monger.collection :as mc]))

(defn get-identifiers-by-cusip [cusip]
  (mc/find-maps (ds/get-db "edgar") "identifiers" {:cusip cusip}))
