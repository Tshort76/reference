(ns soda.data.agencies.fannie-mae
  (:require [clojure.string :as s]
            [clj-http.client :as http]
            [clojure.data.json :as json]
            [taoensso.timbre :as timbre]))

(def base-url "https://mbsdisclosure.fanniemae.com/PoolTalk2")

(defn get-poolnum [cusip]
  (->> (http/post (str base-url "/searchResult.html ") {:form-params {:searchType "CUSIP" :searchValue cusip}})
       :body
       (re-find #"&poolTrustNo=([0-9]+)")
       second))

(defn fix-relative-urls [[k vs]]
  [k
   (map
     (fn [v]
       (if (.startsWith v "http")
         v
         (str base-url "/" v)))
     vs)])

(defn get-data-file-urls [cusip]
  (when-let [poolnum (try (get-poolnum cusip) (catch Exception e))]
    (let [query (str "?cusip=" cusip "&pooltrustno=" poolnum "&q=ONGOING")]
      {"DATA_FILE_XML"      [(str base-url "/securities.xml" query)]
       "DATA_FILE_CSV"      [(str base-url "/securities.csv" query)]
       "SECURITY_DETAILS"   [(str base-url "/securityDetails.html" query)]
       "MONTHLY_POOL_STATS" [(str base-url "/poolStats.html" query)]})))

(defn get-prospectus-urls [cusip]
  (when-let [response (try
                        (slurp (str base-url "/docs.json" "?cusip=" cusip))
                        (catch Exception e))]
    (-> response
        (s/replace #"Trust Agreement#" "")
        (json/read-str)
        (get "securityDocuments")
        (->> (map fix-relative-urls)
             (into {})))))

(defn get-urls [cusip]
  (try
    (let [urls (->> (get-prospectus-urls cusip)
                    (merge (get-data-file-urls cusip))
                    (map (fn [[k v]] {:label k :urls v})))]
      (when (not-empty urls)
        urls))
    (catch Exception e
      (timbre/debug e (str "Fannie-mae url scraper failed"))
      nil)))
