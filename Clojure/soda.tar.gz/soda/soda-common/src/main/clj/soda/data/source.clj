(ns soda.data.source
  (:require [clojure.string :as str]
            [datasources.core :as ds]
            [soda.data.agencies.ginnie-mae :as ginnie-mae]
            [soda.data.agencies.fannie-mae :as fannie-mae]
            [soda.data.agencies.freddie-mac :as freddie-mac]
            [soda.data.agencies.cmhc :as cmhc]
            [environ.core :refer [env]]
            [medley.core :as med]
            [monger.collection :as mc]
            [soda.core :as soda])
  (:import (java.net URL InetAddress)))

(defn resolve-url [raw-url]
  (let [url (URL. (if (re-find #"^[a-zA-Z]+:\/\/" raw-url)
                    raw-url
                    (str "http://" raw-url)))]
    (str (URL. (.getProtocol url)
               (-> url
                   .getHost
                   InetAddress/getByName
                   .getHostAddress
                   ((fn [h] (if (#{"127.0.0.1" "127.0.1.1"} h)
                              (.getHostName (InetAddress/getLocalHost))
                              h))))
               (.getPort url)
               (.getFile url)))))

(defn soda-jerk-base-url []
  (or (some-> env :soda-jerk-url resolve-url)
      (str "http://" (.getHostName (InetAddress/getLocalHost)) ":8084/soda-jerk-ws/")))

(defn soda-api-base-url []
  (or (some-> env :soda-api-url resolve-url)
      (str "http://" (.getHostName (InetAddress/getLocalHost)) ":8084/soda-api/")))

(defn make-links [{{md5 :md5} :meta :as doc}]
  (when md5
    (let [base-url (str (soda-jerk-base-url) "overmind/original/?md5=" md5)
          food-url (str (soda-jerk-base-url) "overmind/food/html?md5=" md5)]
      (merge {:file-url base-url}
             (->> doc
                  :jaeger-doc
                  (med/map-vals (comp flatten :ids))
                  (med/filter-vals seq)
                  (med/map-vals (soda/comp->>
                                  (str/join ",")
                                  (str food-url "&limit-context=t&ids="))))))))

(defn add-links [doc]
  (assoc-in doc [:meta :links] (make-links doc)))

(defn parent [{{:keys [collection database _id]} :meta}]
  (when (and _id collection database)
    (some-> (mc/find-map-by-id (ds/get-db database) collection _id)
            (assoc-in [:meta :mongo-location]
                      {:_id        _id
                       :collection collection
                       :database   database})
            add-links)))

(defn clean-source [{{:keys [collection database _id]} :meta}]
  {:meta {:collection collection
          :database database
          :_id _id}})

(defn get-supplemental
  "Takes a source, finds supplements from it's meta data."
  [{{supplements :supplemental} :meta :as source}]
  (map (fn [supplement] (update supplement :meta #(assoc % :mongo-location %))) supplements))

(defn memoized-deep-source-fn []
  (let [mem-parent (memoize parent)]
    (fn [r]
      (let [sources (vec (take-while identity (iterate (comp mem-parent clean-source) r)))
            supplements (vec (map mem-parent (mapcat get-supplemental sources)))]
        (vec (concat sources supplements))))))

(defn soda-db [] (ds/get-db "soda"))

(defn find-and-store-links [cusip pool-number]
  (let [doc {:cusip     cusip
             :doc-links (not-empty
                          (concat
                            (ginnie-mae/get-urls cusip)
                            (fannie-mae/get-urls cusip)
                            (freddie-mac/get-urls cusip)
                            (cmhc/get-urls pool-number)))}]
    (mc/insert (soda-db) "document_links" doc)
    doc))

(defn fetch-doc-urls [cusip pool-number]
  (when cusip
    (:doc-links (or (mc/find-one-as-map (soda-db) "document_links" {:cusip cusip})
                    (find-and-store-links cusip pool-number)))))
