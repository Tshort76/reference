(ns soda.jobs.job-defs
  (:require [clj-time.core :as t]
            [clj-time.coerce :as tc])
  (:import (org.bson.types ObjectId)))


(defn safe-min-max [min max]
  {:min-id (if min (.toHexString min) "ffffffffffffffffffffffff")
   :max-id (if max (.toHexString max) "000000000000000000000000")})

(defn parse-file [{:keys [file-type filename md5]}]
  {:job-def {:type      "parse-file"
             :file-type (name file-type)
             :filename  filename
             :md5       md5}
   :name    (str "Process file: " filename)})

(defn make-mindfood [{:keys [file-type filename md5]}]
  {:job-def {:type      "make-mindfood"
             :file-type (name file-type)
             :filename  filename
             :md5       md5}
   :name    (str "Mindfood file: " filename)})

(defn supplemental [{:keys [filename md5 file-type]}]
  {:job-def {:type      "supplemental"
             :file-type (name file-type)
             :filename  filename
             :md5       md5}
   :name    (str "Process supplemental data file: " filename)})

(defn jaegerize [{:keys [filename md5 file-type starting-jaeger ->api? run-cusipless?]}]
  {:job-def {:type            "jaegerize"
             :file-type       (name file-type)
             :filename        filename
             :md5             md5
             :starting-jaeger starting-jaeger
             :->api?          ->api?
             :run-cusipless?  run-cusipless?}
   :name    (str "Jaegerize: " filename)})

(defn migrate-jaeger-docs [{:keys [^ObjectId min-id ^ObjectId max-id]}]
  {:job-def (assoc (safe-min-max min-id max-id) :type "migrate-jaeger-docs")
   :name    (str "migration of jaeger docs with ids between " min-id " and " max-id)})

(defn normalize [{:keys [^ObjectId id ^ObjectId min-id ^ObjectId max-id] :as opts}]
  (let [min-id (or id min-id)
        max-id (or id max-id)]
    {:job-def (merge opts (assoc (safe-min-max min-id max-id) :type "normalize"))
     :name    (str "Normalization of documents with ids between " min-id " and " max-id)}))

(defn muni-entity [{:keys [^ObjectId id ^ObjectId min-id ^ObjectId max-id]}]
  (let [min-id (or id min-id)
        max-id (or id max-id)]
    {:job-def (assoc (safe-min-max min-id max-id) :type "muni-entity")
     :name    (str "Muni Entity documents with ids between " min-id " and " max-id)}))

(defn accrete-ice-ids
  "Update the set of all unique combinations of event-id and revision-id for ICE CAS events.
  This enables faster querying of all unique event-id/revision-id combos."
  [{:keys [^ObjectId min-id ^ObjectId max-id] :as opts}]
  {:job-def (merge opts (assoc (safe-min-max min-id max-id) :type "accrete-ice-ids"))
   :name    (str "Accretion of ICE CAS event and revision ids for documents with ids between " min-id " and " max-id)})

(defn refresh-ice-ids
  "Refreshes the set of all unique combinations of event-id and revision-id for ICE CAS events."
  []
  {:job-def {:type "refresh-ice-ids"}
   :name    "Refreshing the set of all unique combinations of event-id and revision-id for ICE CAS events."})

(defn aggregate-by-identifiers
  "This aggregation job is more cusip and isin specific.  Rather than be
  given a range of object ids, it is given a list of isin and/or cusips
  This makes it independent "
  [identifiers]
  {:job-def {:type        "aggregate-by-identifiers"
             :identifiers identifiers}
   :name    (str "running aggregation for " (count identifiers) " identifiers")})

(defn aggregate-entity
  "Produce and store an aggregated entity document given the inputs. This is a no-op if the current
    document with the same identifier as the input normalized entity document (eg: cik for edgar)
    is not 'stale'.

  Required input: candidate normalized entity.

  Optional inputs: matched normalized entity - if present, no new matching (fuzzy string search)
                   will occur.

  Other options are as follows:
  -match?          : If false and no matched-normalized-entity is present, will not attempt to match.
  -run-regardless? : Run the job given other params even if there is currently a representative
                     document and even if that document is not stale.

  Side-effects:
    If any existing entity documents have identifiers (cik, lei) that overlap with the
    newly created document, they will be deleted, and their non-overlapping ids inputs will be
    enqueued as new aggregate-entity jobs, but without any matching. Example - existing document has
    identifiers {:lei abc :cik 123}, and newly derived document has identifiers {:lei zyx :cik 123},
    then the existing document will be deleted, the new document inserted, and a job will be
    enqueued for the normalized entity representing {:lei abc}, but without any matching logic.
    This ensures coverage for entity identifiers while keeping unique constraints.

    In addition, any securities affected by changes to records will be enqueued for aggregation.
    Using the above example, post-insertion, all securities containing either issuer or guarantors
    that have cik=123 will be enqueued for aggregation, so that they pick up the relevant changes
    to the entity document."
  ([entity] (aggregate-entity entity true))
  ([entity match?] (aggregate-entity entity match? false))
  ([{{:keys [input-normalized-entity matched-normalized-entity] :as meta} :meta} match? run-regardless?]
   (let [will-match? (and (nil? matched-normalized-entity) match?)]
     {:job-def  {:type   "aggregate-entity"
                 :inputs (-> (select-keys meta [:input-normalized-entity :matched-normalized-entity])
                             (#(if run-regardless? (assoc % :run-regardless? true) %)))
                 :match? match?}
      :priority (when will-match? "background")
      :name     (str "Aggregating" (when will-match? "/Matching")
                     " entity data for normalized entity: "
                     input-normalized-entity)})))

(defn aggregate-fdic-sdi-entity
  "Updates the soda.entity collection by aggregating FDIC-SDI with LEI and CusipDB data"
  [{:keys [^ObjectId id ^ObjectId min-id ^ObjectId max-id]}]
  (let [min-id (or id min-id)
        max-id (or id max-id)]
    {:job-def  (assoc (safe-min-max min-id max-id) :type "aggregate-fdic-sdi-entity")
     :priority "background"
     :name     (str "Aggregated SDI entity data for ids between " min-id " and " max-id)}))

(defn fdic-sdi-securities
  "Upload file containing cusip9s found from cusip6 cusipdb search. This uploaded file will kick off aggregation for each cusip9."
  [{:keys [^ObjectId id ^ObjectId min-id ^ObjectId max-id]}]
  (let [min-id (or id min-id)
        max-id (or id max-id)]
    {:job-def  (assoc (safe-min-max min-id max-id) :type "fdic-sdi-securities")
     :name     (str "Securities SDI for ids between " min-id " and " max-id)}))

(defn create-cik-to-parent-cik-universe
  "Backup the current relationship graph, then wipe and re-create. Reason is that we won't know by
   updating the current graph when a given entities subsidiary is no longer a subsidiary, so instead
   we re-create from all of the current entity hierarchy (10k, 20f, ...) data."
  []
  {:job-def {:type "create-cik-to-parent-cik-universe"}
   :name    "Creating the universe of child-cik to parent-cik."})

(defn update-soda-entity-view
  "Updates the soda.entity-view collection, upsert style."
  [{:keys [^ObjectId id ^ObjectId min-id ^ObjectId max-id]}]
  (let [min-id (or id min-id)
        max-id (or id max-id)]
    {:job-def (assoc (safe-min-max min-id max-id) :type "update-soda-entity-view")
     :name    (str "Update soda.entity-view for ids between " min-id " and " max-id)}))

(defn invalidate-fdic-sdi-entity
  "Invalidate any fdic-sdi issuer records in soda.entity that aren't present in the most recent universe file"
   [{:keys [^ObjectId id ^ObjectId min-id ^ObjectId max-id]}]
  (let [min-id (or id min-id)
        max-id (or id max-id)]
    {:job-def (assoc (safe-min-max min-id max-id) :type "invalidate-fdic-sdi-entity")
     :name    (str "Invalidate soda.entity fdic-sdi records not found in normalized entity docs for ids between " min-id " and " max-id)}))

(defn update-cusip-db-entity-view
  "Updates the soda.entity-view collection for cusip-db"
  [{:keys [^ObjectId id ^ObjectId min-id ^ObjectId max-id]}]
  (let [min-id (or id min-id)
        max-id (or id max-id)]
    {:job-def (assoc (safe-min-max min-id max-id) :type "update-cusip-db-entity-view")
     :name    (str "Update soda.entity-view for ids between " min-id " and " max-id)}))

(def std-scrape-time 14400)

(defn scrape [{:keys [scraper-id]}]
  {:job-def  {:type       "scrape"
              :scraper-id scraper-id}
   :name     (str "scraper: " scraper-id)
   :est-time std-scrape-time})

(defn process-13f [{:keys [md5 filename]}]
  {:job-def {:type "process-13f"
             :md5  md5}
   :name    (str "Process 13f file: " filename)})

(defn parse-edgar-15-12 [{:keys [md5 filename]}]
  {:job-def {:type "parse-edgar-15-12"
             :md5  md5}
   :name    (str "Parse edgar 15-12 file: " filename)})

(defn process-td-cpi [{:keys [md5 filename]}]
  {:job-def {:type "process-td-cpi"
             :md5  md5}
   :name    (str "Process treasury direct cpi file: " filename)})

(defn process-edgar-header [{:keys [md5 filename]}]
  {:job-def {:type "process-edgar-header"
             :md5  md5}
   :name    (str "Process header data for edgar prospectus file: " filename)})

(defn update-cik->cusip6-database [{:keys [cik]}]
  {:job-def {:type "update-cik-cusip-6-mapping"
             :cik  cik}
   :priority "background"
   :name    (str "Update the cik to cusip-6 database for cik: " cik)})

(defn process-figi-requests [worker-id]
  {:job-def  {:type      "process-figi-ledger"
              :worker-id worker-id}
   :est-time 36000
   :name     (str "Figi Ledger Processor")})

(defn refresh-figis [{:keys [period-in-days utc-hour-of-day]}]
  (let [period (or period-in-days 14)
        tod (or utc-hour-of-day 6)]
    {:job-def  {:type            "periodic-figi-refresh"
                :period-in-days  period
                :utc-hour-of-day tod}
     :stime    (tc/to-date (t/plus (t/with-time-at-start-of-day (t/now))
                                   (t/days period)
                                   (t/hours tod)))
     :est-time 36000
     :name     (str "Refresh stale figi data every " period " days.")}))

(defn norm->add-transitive-doc [{:keys [^ObjectId id ^ObjectId min-id ^ObjectId max-id]}]
  (let [min-id (or id min-id)
        max-id (or id max-id)]
    {:job-def (assoc (safe-min-max min-id max-id) :type "norm->add-transitive-doc")
     :name    (str "Add transitive docs for norm docs with ids between " min-id " and " max-id)}))

(defn parse-surveyor-answer [{:keys [question-id md5 file-type] :as params}]
  {:job-def (assoc params :type "parse-surveyor-answer")
   :name (str "Parse the answer for surveyor question " question-id)})

(defn entity-name-to-id-mapping [{:keys [name cusips md5] :as params}]
  {:job-def (assoc params :type "entity-name-to-id-mapping")
   :name (str "entity name to id mapping for name: " name)})

(defn publish-scraped-file [{:keys [bid scraper-id] :as params}]
  {:job-def {:scraper-id scraper-id :type "publish-scraped-file"
             :bid bid}
            :bid bid
            :name (str "Publish the scraped-file under bid : " bid)})

(defn file-sync [{:keys [md5s] :as params}]
  {:job-def (assoc params :type "file-sync")
   :name "file-sync"})
