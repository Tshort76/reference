(ns soda.data.util
  (:require [clojure.walk :refer [prewalk]]
            [util.date-time :as dt])
  (:import (org.bson.types ObjectId)
           (java.util UUID)))

(defn format-dates [xs]
  (prewalk #(if (inst? %) (dt/date->yyyy-mm-dd %) %) xs))

(defn fix-ids [result]
  (prewalk #(if (or (instance? ObjectId %) (instance? UUID %)) (str %) %) result))
