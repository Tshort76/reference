(ns soda.data.s3
  (:require [clojure.java.io :as io]
            [environ.core :refer [env]]
            [util.feature-flags :as ff]
            [taoensso.timbre :as log]
            [perseverance.core :as perseverance])
  (:use [amazonica.aws.s3]
        [amazonica.aws.s3transfer :exclude [show-functions client-class]])
  (:import (java.util.zip GZIPInputStream)))

(def document-bucket "soda-documents")

(def credentials
  (memoize (fn []
             {:access-key    (:soda-s3-accesskey env)
              :secret-key    (:soda-s3-secret env)
              :endpoint      (:primary-s3-endpoint env)
              :client-config {:path-style-access-enabled true}})))

(defn put
  ([file-path key] (put file-path key nil))
  ([file-path key meta-data]
   (when (ff/memoized-allowed-to? :write-files-to-s3)
     (perseverance/retriable
       {:tag   ::put
        :catch [Exception]}
       (let [size (.length (io/file file-path))]
         (with-open [is (io/input-stream file-path)]
           (put-object
             (credentials)
             :bucket-name document-bucket
             :key key
             :input-stream is
             :metadata {:content-length size
                        :user-metadata  meta-data})))))))

(defn fetch-file [key]
  ;TODO note that if the calling code doesn't consume and close this input-stream, we may
  ;have issues with exhausting the underlying HTTP connection pool.
  (try (let [{is :input-stream {:keys [content-length]} :object-metadata}
             (get-object (credentials) document-bucket key)]
         (when is {:input-stream (GZIPInputStream. is)
                   :length content-length}))
       (catch Exception e (log/debug e (str "error getting file-stream from s3, key=" key)))))

(defn get-meta-data [key]
  (try (get-object-metadata (credentials) :bucket-name document-bucket :key key)
       (catch Exception e (log/debug e (str "error getting meta-data from s3, key=" key)))))
