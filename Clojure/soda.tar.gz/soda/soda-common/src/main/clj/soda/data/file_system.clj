(ns soda.data.file-system
  (:require [clojure.java.io :as io]
            [clojure.string :as str]
            [datasources.core :as ds]
            [digest]
            [monger.collection :as mc]
            [util.feature-flags :as ff]
            [soda.data.s3 :as s3]
            [perseverance.core :as perseverance]
            [taoensso.timbre :as log])
  (:import (java.util.zip GZIPInputStream GZIPOutputStream)
           (java.io FileNotFoundException File)
           (java.net InetAddress)
           (java.nio.file Files Paths)
           (java.time LocalDateTime)))

(def file-db "soda-raw")
(def file-coll "files-meta")

(defn db [] (ds/get-db file-db))

(defn find-all-meta
  ([query]
   (find-all-meta query false))
  ([query find-ignored-files?]
   (cond->> (mc/find-maps (db) file-coll query)
            (not find-ignored-files?) (remove :do-not-process))))

(defn find-one-meta
  ([query]
   (find-one-meta query false))
  ([query find-ignored-files?]
   (first (find-all-meta query find-ignored-files?))))

(defn make-path [base & rest-paths]
  (->> (into-array String rest-paths)
       (Paths/get base)
       str))

(defn- generate-relative-path [filename md5]
  (conj (mapv str (take 4 md5))
        (str md5 "_" filename ".gz")))

(defn- format-keys [meta]
  (if (:file-type meta)
    (update meta :file-type keyword)
    meta))

(defn add-file-meta [{:keys [md5] :as meta}]
  (if md5
    (mc/insert (db) file-coll meta)
    (log/warn (str "soda.data.file-system/add-file-meta: No md5 was given when attempting to insert file meta-data: " meta))))

(defn- write-file-to-mount [file filename md5 relative-path]
  (let [full-path (apply make-path (ds/base-path) relative-path)]
    (log/debug (str "Saving new file to " full-path "."))
    (io/make-parents full-path)
    (with-open [os (GZIPOutputStream. (io/output-stream full-path))]
      (io/copy file os))
    (log/debug (str "No meta found, performing fresh upload for {:md5 "
                    md5 " :filename " filename "}."))
    full-path))

(defn- write-file-to-s3 [gzip-file-path md5 meta-entry]
  (try
    (->> (perseverance/retry
           {:strategy (perseverance/progressive-retry-strategy :max-count 5)}
           (s3/put gzip-file-path md5 meta-entry))
         (assoc {} :md5 md5 :result))
    (catch Exception e (do (log/debug e (str "s3/put failed after 5 retries. md5=" md5))
                           {:md5 md5 :exception (.getMessage e)}))))

(defn add-file
  ([file] (add-file file {} nil))
  ([file meta] (add-file file meta nil))
  ([file meta check-existing-fn]
   (if (and file (instance? File file) (pos? (.length file)))
     (let [md5          (digest/md5 file)
           content-type (Files/probeContentType (.toPath file))
           filename     (or (:filename meta) (.getName file))
           existing     (find-all-meta {:md5 md5} true)
           check-result (when check-existing-fn (check-existing-fn existing))]
       (cond
         check-result
         {:added? false :md5 md5 :message check-result :file-status :exists}

         (some #(= (:filename %) filename) existing)
         (do (log/debug (str filename " already exists."))
             {:added? false :md5 md5 :filename filename :file-status :exists :message "File already exists."})

         :else
         (let [relative-path (or (some-> existing first :file-path (str/split #"/"))
                                 (generate-relative-path filename md5))
               meta-entry    (-> (or meta {})
                                 (assoc :md5 md5
                                        :filename filename
                                        :file-path (str/join "/" relative-path)
                                        :content-type content-type
                                        :byte-size (.length file)
                                        :uploader (.. InetAddress getLocalHost getHostName)))
               {:keys [final-meta result]}
               (if-not (seq existing)
                 (let [gzip-file-path (write-file-to-mount file filename md5 relative-path)
                       {{:keys [etag]} :result} (write-file-to-s3 gzip-file-path md5 meta-entry)]
                   {:result     {:added?  true :md5 md5 :filename filename
                                 :message (str "Successfully saved " filename " at " (LocalDateTime/now))}
                    :final-meta (if (not-empty etag) (assoc meta-entry :s3? true) meta-entry)})
                 {:result     {:added?  true :md5 md5 :filename filename
                               :message "File already exists. Adding meta document."}
                  :final-meta meta-entry})]

           (add-file-meta final-meta)
           result)))
     {:message "File is invalid." :added? false})))


(defn file-path->file [file-path]
  (->> (str/split file-path #"/")
       (apply make-path)
       (io/file (ds/base-path))))

(defn read-from-mount [file-path]
  (try
    (let [file ^File (file-path->file file-path)]
      (if (.exists file)
        (let [result (->> file
                          str
                          io/input-stream
                          ((if (str/ends-with? file-path ".gz")
                             #(GZIPInputStream. %)
                             identity))
                          (assoc {} :input-stream))]
          (if (:input-stream result)
            (assoc result :length (.length file))
            (log/debug (str "soda.data.file-system/meta->input-stream: Falsy input-stream: " file-path))))
        (log/debug (str "soda.data.file-system/meta->input-stream: Could not find file on path: " file-path))))
    (catch FileNotFoundException _
      (log/debug (str "soda.data.file-system/meta->input-stream: Could not find file on path: " file-path)))))

(defn meta->input-stream [{:keys [file-path md5] :as meta-data}]
  (when-let [result (if (ff/memoized-allowed-to? :read-files-from-s3)
                      (s3/fetch-file md5)
                      (read-from-mount file-path))]
    (merge meta-data result)))

(defn update-one-file-meta [query update-map]
  (mc/update (db) file-coll query
             {"$set" (dissoc update-map                     ;; prevent people from munging important data
                             :file-path "file-path"
                             :md5 "md5"
                             :pdf-md5 "pdf-md5")}))

(defn find-files
  "returns a list of files as input-streams with their meta data."
  ([query]
   (find-files query false))
  ([query find-ignored-files?]
   (->> (find-all-meta query find-ignored-files?)
        (keep (comp format-keys meta->input-stream)))))

(defn find-file
  "returns a single file as an input-stream with its meta data."
  ([query]
   (find-file query false))
  ([query find-ignored-files?]
   (some-> (find-files query find-ignored-files?)
           first
           meta->input-stream
           format-keys)))

(defn sync-to-s3 [{:keys [file-path md5] :as files-meta-entry}]
  (when (and (not-empty md5) (not-empty file-path))
    (let [full-file-path (.getAbsolutePath (file-path->file file-path))
          {{:keys [etag]} :result :as write-result} (write-file-to-s3 full-file-path md5 (dissoc files-meta-entry :_id))]
      (do (when (not-empty etag)
            (mc/update (ds/get-db "soda-raw") "files-meta" {:md5 md5} {"$set" {:s3? true}} {:multi true}))
          write-result))))

;;;;;;;;;;;;;;;;;;;;;;;;;recover from s3 to filestore;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; a starting spot for undoing accidental deletes in the filestore.

;(defn sync-from-s3 [{:keys [file-path md5] :as files-meta-entry}]
;  (when (and (not-empty md5) (not-empty file-path))
;    (try
;      (let [is (:input-stream (soda.data.s3/fetch-file md5))]
;        (with-open [tmp-file (File/createTempFile filename ".tmp")
;                    out (clojure.java.io/output-stream tmp-file)]
;          (io/copy is out)
;          (with-redefs [find-all-meta (constantly nil)]     ;pretend like there's nothing in files-meta
;            (add-file tmp-file (dissoc files-meta-entry :_id)))))
;      (mc/update (ds/get-db "soda-raw") "files-meta" {:md5 md5} {"$set" {:missing? false}} {:multi true})
;      (catch Exception e
;        (log/error e (str "Failed to restore from s3 for file: " files-meta-entry))))))

;;##################### EXTRA DANGER! ##########################################
;; These functions will irreversably destroy files. Leave commented out unless
;; you have an extremely good reason to want things gone.

; (defn meta->kill-file! [{:keys [file-path filename] :as meta}]
;   (log/info (str "Deleting file: " filename))
;   (try
;     (let [file ^File (file-path->file file-path)]
;       (if (.exists file)
;         (.delete file)
;         (log/warn (str "soda.data.file-system/meta->input-stream: Could not find file on path: " file-path
;                           " -- meta: " meta))))
;     (mc/remove (db) file-coll {:_id (:_id meta)})
;     (:md5 meta)
;     (catch FileNotFoundException _
;       (log/warn (str "soda.data.file-system/meta->input-stream: Could not find file on path: " file-path
;                         " -- meta: " meta)))))
;
; (defn kill-files! [query]
;   (when (seq query)
;     (mapv meta->kill-file! (find-all-meta query true))))
