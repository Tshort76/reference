(ns soda.data.agencies.cmhc
  (:require [clj-http.client :as http]
            [net.cgrand.enlive-html :as html]
            [clj-http.cookies :as cook])
  (:import (java.io StringReader)))

(def base-url "https://www.cmhc-schl.gc.ca")
(def cookie-str "CMHC_SCHL_MBS_SESSION=1")
(def cookies (conj {} (cook/decode-cookie cookie-str)))

(defn get-urls [pool-num]
  (when pool-num
    (-> (http/post (str base-url "/en/hoficlincl/mobase/inci/index.cfm")
                   {:cookies         cookies
                    :form-params     {:poolNumber pool-num
                                      :mode       "search"}})
        :body
        (StringReader.)
        (html/html-resource)
        (html/select [[:a (html/attr-starts :href "/incibuin")]])
        (->> (mapv #(str base-url (get-in % [:attrs :href])))
             (hash-map :label "MBS Information Circular" :urls)
             (vector)))))

(comment
 (get-urls "97506746"))
