(ns soda.data.files
  (:require [clojure.string :as str]
            [clojure.zip :as zip])
  (:import (java.io File FileOutputStream)
           (java.util.zip ZipFile)
           (org.apache.commons.io IOUtils)
           (org.apache.tika Tika)))

(def tika (Tika.))

(defn mime-type-of [^File file]
  (.detect tika file))

(defn file->fmap [tmp-file & [name]]
  (let [names (str/split (or name (.getName tmp-file)) #"/")
        parents (butlast names)]
    (cond-> {:tempfile     tmp-file
             :filename     (last names)
             :content-type (mime-type-of tmp-file)
             :size         (.length tmp-file)}
            parents (assoc-in [:meta :parent-names] parents))))

(defn- delete-empty-file [fmap]
  (if (pos? (or (:size fmap) 0))
    fmap
    (do (.delete (:tempfile fmap))
        nil)))

(defn unzip-file [file]
  (with-open [zip-file (ZipFile. file)]
    (->> (.entries zip-file)
         enumeration-seq
         (remove #(.isDirectory %))                         ; we only care about the files
         (keep (fn [zip-entry]
                 (let [tmp-file (doto (File/createTempFile "unzipped_soda_" ".tmp") (.deleteOnExit))
                       filename (.getName zip-entry)]
                   (with-open [is (.getInputStream zip-file zip-entry)
                               os (FileOutputStream. tmp-file)]
                     (IOUtils/copy is os))
                   (delete-empty-file (file->fmap tmp-file filename)))))
         (into []))))

(def unzip-blacklisted-extensions #{"xlsx"})

(defn extract-files
  "Given a file-map, returns a list of file-maps extracted from any zip files.
  The file-map will contain an {:orig? true} flag for the original document.
  All temp files return by this method must be deleted manually."
  [{:keys [upload-type] :as f}]
  (let [add-parent (fn [filename x]
                     (update-in x [:meta :parent-names]
                                (fnil conj []) filename))
        zip-file? (fn [{:keys [tempfile content-type filename] :as fmap}]
                    (and (not (unzip-blacklisted-extensions (last (str/split filename #"\."))))
                         (str/includes? (str content-type (mime-type-of tempfile)) "zip")))]
    (loop [raw-files [(assoc f :orig? true)] fmaps []]
      (if-let [{:keys [tempfile filename orig?] :as fmap} (peek raw-files)]
        (if (zip-file? fmap)
          (recur (->> (let [unzipped-files (unzip-file tempfile)]
                        (when-not orig? (.delete tempfile))
                        unzipped-files)
                      (map (partial add-parent filename))
                      (into (pop raw-files)))
                 fmaps)
          (recur (pop raw-files) (conj fmaps (assoc fmap :upload-type upload-type))))
        fmaps))))
