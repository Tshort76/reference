(ns soda.data.agencies.freddie-mac
  (:require [net.cgrand.enlive-html :as html]
            [taoensso.timbre :as timbre])
  (:import (java.net URL)))

(def base-url "http://www.freddiemac.com")

(defn valid-url? [m]
  (not (map? (first (:content m))))) ;exclude irrelevant links (i.e. acrobat reader)

(defn ok? [response]
  (empty? (html/select response [:h2 (html/text-pred #(re-matches #"Sorry,.*" %))]))) ;check for errors

(defn get-urls [cusip]
  (try
    (let [response (-> (str base-url "/mbs/cgi-bin/ocs.pl" "?CusipNum=" cusip)
                       (URL.)
                       (html/html-resource))]
      (when (ok? response)
        (->> (html/select response [:a])
             (filter valid-url?)
             (reduce (fn [m url]
                       (update m (first (:content url))
                               conj (str base-url (get-in url [:attrs :href]))))
                     {})
             (map (fn [[k v]] {:label k :urls v})))))
    (catch Exception e
      (timbre/warn e (str "Freddie-mac url scraper failed"))
      nil)))
