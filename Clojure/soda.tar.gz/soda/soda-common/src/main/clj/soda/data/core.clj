(ns soda.data.core
  (:refer-clojure :exclude [any? find remove count drop distinct empty? update])
  (:require [monger.collection :as mc]
            [monger.conversion :as mconv]
            [clojure.string :as s]
            [datasources.core :as ds]
            [monger.query :as mq])
  (:import (com.mongodb DB DBObject DBCollection)
           (clojure.lang IPersistentMap)
           (java.util Map)
           (java.util.concurrent TimeUnit)))

;Shamelessly copied from monger: https://github.com/michaelklishin/monger/blob/master/src/clojure/monger/collection.clj#L196
;Added ability to access timeout, along with a default timeout of half a second
(defn ^IPersistentMap find-and-modify
  "Atomically modify a document (at most one) and return it."
  ([^DB db ^String coll ^Map conditions ^Map document {:keys [fields sort remove return-new upsert keywordize timeout]
                                                       :or {fields nil sort nil remove false return-new false
                                                            upsert false keywordize true timeout 500}}]
   (let [coll (.getCollection db (name coll))
         maybe-fields (when fields (mconv/as-field-selector fields))
         maybe-sort (when sort (mconv/to-db-object sort))]
     (mconv/from-db-object
       ^DBObject (.findAndModify ^DBCollection coll (mconv/to-db-object conditions) maybe-fields maybe-sort remove
                                 (mconv/to-db-object document) return-new upsert timeout TimeUnit/MILLISECONDS)
       keywordize))))

(def coerced-find
  (comp (partial map (fn [{:keys [meta] :as m}]
                       (cond-> m
                         (:vocabulary meta) (update-in [:meta :vocabulary] keyword)
                         (:file-type meta) (update-in [:meta :file-type] keyword)
                         (:data-type meta) (update-in [:meta :data-type] keyword))))
        mc/find-maps))

(defn enh-meta [meta-ex {:keys [_id] :as record}]
  (-> record
      (assoc-in [:meta :_id] _id)
      (dissoc :_id)
      (clojure.core/update :meta into meta-ex)))

(defn with-sources [f ^DB db coll & args]
  {:database (.getName db)
   :collection coll
   :result (apply f db coll args)})

(defn source-process [f]
  (let [{:keys [result] :as q} f
        meta-ex (dissoc q :result)]
    (map (partial enh-meta meta-ex) result)))

(defmacro query [db coll & {:keys [query fields sort limit skip]}]
  `(mq/with-collection
     (ds/get-db ~db)
     ~coll
     ~@(cond-> []
               query (conj `(mq/find ~query))
               fields (conj `(mq/fields ~fields))
               sort (conj `(mq/sort ~sort))
               limit (conj `(mq/limit ~limit))
               skip (conj `(mq/skip ~skip)))))

(defmacro defcon [db coll & {:keys [prefix basename indexes updatable removable]
                             :or {prefix "" basename coll}}]
  (let [sym (s/replace (str prefix basename) #"\_+" "-")]
    `(do
       (defn ~(symbol (str sym "-db")) [] (ds/get-db ~db))
       (defn ~(symbol (str sym)) [& ~'args] (apply coerced-find (ds/get-db ~db) ~coll ~'args))
       (defn ~(symbol (str "count-" sym)) [& ~'args] (apply mc/count (ds/get-db ~db) ~coll ~'args))
       (defn ~(symbol (str "find-" sym)) [& ~'args] (apply mc/find-one-as-map (ds/get-db ~db) ~coll ~'args))
       (defn ~(symbol (str "sourced-" sym)) [& ~'args] (apply with-sources coerced-find (ds/get-db ~db) ~coll ~'args))
       (defn ~(symbol (str "bulk-write-" sym)) [& ~'args] (apply ds/bulk-write (ds/get-db ~db) ~coll ~'args))
       ~@(when updatable
           `[(defn ~(symbol (str "update-" sym)) [& ~'args] (apply mc/update (ds/get-db ~db) ~coll ~'args))
             (defn ~(symbol (str "update-" sym "-by-ids")) [& ~'args] (apply mc/update-by-ids (ds/get-db ~db) ~coll ~'args))
             (defn ~(symbol (str "update-" sym "-by-id")) [& ~'args] (apply mc/update-by-id (ds/get-db ~db) ~coll ~'args))])
       ~(when removable
          `(defn ~(symbol (str "remove-" sym)) [& ~'args] (apply mc/remove (ds/get-db ~db) ~coll ~'args))))))
