(ns soda.data.figi
  (:require [monger.collection :as mc]
            [datasources.core :as ds]))

(defn most-recent-per-figi [security-docs]
  (->> security-docs
       (sort-by (comp :date-of-applicability :meta) #(compare %2 %1))
       (partition-by (comp :date-of-applicability :meta))
       first
       (group-by :figi)
       (map (comp first (partial sort-by :_id #(compare %2 %1)) second))))

(defn query-norm-figi
  "Returns the most recent set of normalized figi docs for a security id."
  [query]
  (->> query
       (mc/find-maps (ds/get-db "soda-normalized") "figi")
       (group-by (fn [{cusip :cusip isin :isin {ticker :ticker} :exchange-specific}] (or cusip isin ticker)))
       (mapcat (comp most-recent-per-figi second))))
