(ns soda.data.implied
  (:require [datasources.core :as ds]
            [monger.collection :as mc]
            [soda.data.core :as data]))

(defn db [] (ds/get-db "implied_data"))
(defn sourced-data [& args] (apply data/with-sources mc/find-maps (db) "implied_data" args))
