(ns soda.data.agencies.ginnie-mae
  (:require [clj-http.client :as http]
            [net.cgrand.enlive-html :as html]
            [taoensso.timbre :as timbre])
  (:import (java.io StringReader)))

(def base-url "https://structuredginniemaes.ginnienet.com/RemicDB/")

(defn to-html-resource [response]
  (-> response
      :body
      (StringReader.)
      (html/html-resource)))

(defn get-form-params [response]
  (-> (to-html-resource response)
      (html/select [:input])
      (#(zipmap (map (fn [m] (get-in m [:attrs :name])) %)
                (map (fn [m] (get-in m [:attrs :value])) %)))))

(defn get-urls [cusip]
  (try
    (let [response (http/get base-url {:insecure? true})
          session-label "ASP.NET_SessionId"
          session-value (get-in response [:cookies "ASP.NET_SessionId" :value])
          form-params (assoc (get-form-params response) "SearchCriteria1:txtCusip" cusip)
          urls (-> (http/post base-url {:insecure?   true
                                        :headers     {:cookie (str session-label "=" session-value)}
                                        :form-params form-params})
                   (to-html-resource)
                   (html/select [[:a (html/attr-starts :id "SearchResults") (html/attr-ends :id "Hyperlink1")]]))]
      (when (not-empty urls)
        (->> urls
             (reduce (fn [m url]
                       (update m (first (:content url))
                               conj (str base-url (get-in url [:attrs :href]))))
                     {})
             (map (fn [[k v]] {:label k :urls v})))))
    (catch Exception e
      (timbre/warn e (str "Ginnie-mae url scraper failed"))
      nil)))
