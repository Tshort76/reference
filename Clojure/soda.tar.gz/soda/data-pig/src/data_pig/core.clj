(ns data-pig.core)

(defn -main []
  (println "Did you mean `lein test'?"))
