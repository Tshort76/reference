(defproject
  data-pig "0.2-SNAPSHOT"
  :description "data-pig: a project for testing (pigging) the data pipeline."
  :parent-project {:coords [com.clearwateranalytics/soda-meta-parent "0.2-SNAPSHOT"]
                   :inherit [:global-vars
                             :license
                             :managed-dependencies
                             :min-lein-version
                             :parent
                             :url]}
  :dependencies
  [[org.clojure/clojure]
   [environ]
   [clj-http]
   [org.clojure/data.json]
   [com.cognitect/transit-clj]
   [com.novemberain/monger]
   [com.taoensso/timbre]
   [metosin/scjsv]
   [cheshire]
   [clj-time]]

  :plugins
  [[lein-parent "0.3.4"]
   [lein-environ "1.1.0"]]

  :main data-pig.core

  ;; The following is used when the class path is too long (error 206 on Windows)
  :eval-in ~(if (= "Linux" (System/getProperty "os.name")) :subprocess :classloader)

  :profiles {:dev           [:project/dev :profiles/dev]
             :test          [:project/test :profiles/test]
             :project/dev   {}
             :project/test  {:dependencies   [[pjstadig/humane-test-output "0.8.3"]]
                             :injections     [(require 'pjstadig.humane-test-output)
                                              (pjstadig.humane-test-output/activate!)]}
             :profiles/dev  {}
             :profiles/test {}}

  :repositories
  [["releases" {:url "https://artifactory.arbfund.com/releases-group"}]
   ["snapshots" {:url "https://artifactory.arbfund.com/snapshots-group"}]])
