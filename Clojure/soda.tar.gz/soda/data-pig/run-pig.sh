
#don't care about checking for runnable-ness if we are skipping the deploy of latest
if [ "$skip_deploy" != "true" ]
then
    should_i_run=$(python should_i_run.py 2>&1)

    if [ "$should_i_run" = "False" ]
    then
        echo "No-op run - dependent projects are either running, or one or more of their last builds are in error."

        last_run_status=$(python last_run_status.py 2>&1)

        if [ "$last_run_status" != "SUCCESS" ]
        then
            #will report failure for both FAILURE and ABORTED, but not sure how to force an ABORTED status here...
            echo "Last run status was: $last_run_status."
            exit 1
        else
            exit 0
        fi
    fi

    if [ "$should_i_run" != "True" ]
    then
        echo "Error in checking dependent project run state. Please check the scripts."
        exit 1
    fi
fi

export mongo_host="dev-sodaqa-database-mongo-node1:27000"
export mongo_user_db="admin"
export mongo_password="soda"
export mongo_user_name="soda"
export soda_api_url="http://dev-sodaqa-intake-group1-app2:8084/soda-api/"
export soda_jerk_url="http://dev-sodaqa-intake-group1-app2:8084/soda-jerk-ws/"
export remote_pig="true"

echo "Build Number is: " $BUILD_NUMBER 

if [ "$skip_deploy" = "true" ]
then
    echo "Skipping deploy of latest soda deployables..."
else
    echo "Deploying latest code"
    response=$(curl --write-out %{http_code} -s -o /dev/null -X POST https://versionmanager.arbfund.com/jobs --data 'environment=soda-test&soda-jobs=latest&soda-jerk-ws=latest&soda-api=latest')

    if [ "$response" != "200" ]
    then
        echo "Failed to deploy latest apps via version manager. Response code: $response"
        exit 1
    fi

    echo "Sleeping 4 minutes for deploy"
    sleep 240
fi

echo "Starting test"

lein -U test
