#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import urllib, json

def get_last_run_status():
    master_response = urllib.urlopen("https://devbuild.arbfund.com/view/SODA/job/λsoda-test-jp/job/master/api/json")
    master_data = json.loads(master_response.read())
    build_url = master_data["builds"][1]["url"]
    build_response = urllib.urlopen(build_url + "/api/json")
    build_data = json.loads(build_response.read())
    return build_data["result"]

print get_last_run_status()
