#!/usr/bin/env python
import urllib, json

projects = ["soda-jerk-ws-jp", "soda-api-jp", "soda-jobs-jp"]

def ok_to_run(project_name):
    master_response = urllib.urlopen("https://devbuild.arbfund.com/view/SODA/job/" + project_name + "/job/master/api/json")
    master_data = json.loads(master_response.read())
    build_url = master_data["builds"][0]["url"]
    build_response = urllib.urlopen(build_url + "/api/json")
    build_data = json.loads(build_response.read())
    return not build_data["building"] and build_data["result"] == "SUCCESS"

def should_i_run():
    try:
        return str(reduce((lambda a, b: a and b), map(ok_to_run, projects)))
    except:
        return "Error"

print should_i_run()
