# Introduction to data-pig

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
