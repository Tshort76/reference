# data-pig

A Clojure library designed to ... well, that part is up to you.

## Usage

FIXME
This is a project meant to be soda's end to end test.

To run this project you will need to have the full stack of soda running
  - soda-jobs
  - soda-jerk-ws + figwheel
  - soda-api
  - a mongo instance
 and someday
  - soda_ml_retrieval_model
  - soda_ml_extraction_model
  - soda_ml_validation_model


Helpfull profile settings:

    {:mongo-host        "localhost"                     ;just to be sure you are running this locally!
     :remote-pig        false                           ;danger mode.  Please make sure you are only pointing to your local mongo collection
     :isolate-pig-tests ["name of test you want to run by it self"]}}}


Test definitions are located in resources/test_data.
They look like:

 {:name        "Name of test (used for building dependency tree)"
  :depends-on  ["specifies each test"
                "that this test needs"
                "to have run first"]
  :upload-args [["upload-file-name1" "mime/type1" "file-type1"]
                ["upload-file-name2" "mime/type2" "file-type2"]]
  :verify-args [{:cusip "somecusip" :schema "corp" :type :security}
                {:isin "isiniexpect" :schema "equity" :type :security}]
  :version     "1.XX"
  :cases       ["SODA-XXXX"]}

hacks:
   Some data might be a function of today's date so in data-pig.segments.temporal there is some code to
execute arbitrary code on specified keys.
See:
  "next-maturity-date" "#=(data-pig.segments.temporal/next-month-day 1 27)"


## License

Copyright © 2016 FIXME

Distributed under the Eclipse Public License either version 1.0 or (at
your option) any later version.
