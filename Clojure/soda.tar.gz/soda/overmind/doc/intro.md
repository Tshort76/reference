# Introduction to simple-mind

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
