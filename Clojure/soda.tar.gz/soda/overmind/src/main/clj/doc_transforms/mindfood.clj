(ns doc-transforms.mindfood
  (:require [clojure.spec.alpha :as spec]
            [enhanced-hickory.spec :as ehs]
            [clojure.pprint :refer [pprint]]))

(defn remove-zero-id
  "Mindfood contains 'constructed elements with 0_0_0 id to fill out tables, etc."
  [content]
  (remove (comp #{"0_0_0"} :id :attrs) content))

(defn get-dim [content]
  (let [good-ids (remove-zero-id content)]
    (if (empty? good-ids)
      [0 0 0 0 "0"]
      (let [min-x (apply min (map (comp :min-x :attrs) good-ids))
            min-y (apply min (map (comp :min-y :attrs) good-ids))
            max-x (apply max (map (comp :max-x :attrs) good-ids))
            max-y (apply max (map (comp :max-y :attrs) good-ids))
            page-number (str (get-in (first content) [:attrs :page-number]))]
        [min-x min-y max-x max-y page-number]))))

(defn build-element [tags tag content-func data]
  (let [content (map (partial content-func (concat tags [tag])) data)
        [min-x min-y max-x max-y page-number] (get-dim content)
        calc-min-x (if (>= 0 min-x)
                     0
                     (- min-x 1))
        calc-min-y (if (>= 0 min-y)
                     0
                     (- min-y 1))]
    {:type    :element
     :tag     tag
     :content content
     :tags    (vec (concat tags [tag]))
     :attrs   {:id          (str page-number "_" (int calc-min-x) "_" (int calc-min-y))
               :page-number page-number
               :min-x       calc-min-x
               :min-y       calc-min-y
               :max-x       max-x
               :max-y       max-y}}))

(defn enhik-word
  "Base form"
  [tags {:keys [text id y x width height page-number]}]
  {:type    :element
   :tag     :span
   :content [text]
   :token?  (not= "0_0_0" id)
   :tags    (vec (concat tags [:span]))
   :attrs   {:id          id
             :page-number (str page-number)
             :min-x       x
             :min-y       (- y height)
             :max-x       (+ x width)
             :max-y       y}})

(defn enhik-text [tags text]
  (build-element (concat tags [:div]) :div enhik-word (flatten (:vals text))))

(defn enhik-cell [tags cell]
  (let [td (build-element tags :td enhik-word cell)]
    td))

(defn enhik-row [tags row]
  (let [tr (build-element tags :tr enhik-cell row)]
    tr))

(defn enhik-table [tags table]
  (let [table (build-element tags :table enhik-row table)]
    table))

(defn enhik-mf-table [tags mf-table]
  (enhik-table tags (:vals mf-table)))

(defn enhik-component [tags component]
  (case (:type component)
    :text (enhik-text tags component)
    :table (enhik-mf-table tags component)))

(defn enhik-mindfood [mind-food]
  {:type    :document,
   :content [{:type    :element,
              :attrs   nil,
              :tag     :html,
              :content [{:type    :element,
                         :attrs   nil,
                         :tag     :body,
                         :content (map (partial enhik-component [:html :body]) mind-food)}]}]})

#_(comment
    (def omni-data (jp/query->omni-data {:md5 "befab2b7291b529f97df0b99f9a2910f"}))
    (def hik (enhik-mindfood (:mind-food omni-data)))
    (spec/valid? :enhanced-hickory/document hik))

