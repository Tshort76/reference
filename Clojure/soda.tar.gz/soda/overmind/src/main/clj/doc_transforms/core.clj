(ns doc-transforms.core
  (:require [doc-transforms.cache :as cache]
            [soda.data.file-system :as sdfs]
            [taoensso.tufte :refer [p]]
            [taoensso.timbre :as log]
            [clojure.string :as s]
            [taoensso.timbre :as timbre]
            [mind-food.core :as mf]
            [html.core :as h]
            [enhanced-hickory.core :as ehc]
            [enhanced-hickory.tokenvec :as eht]
            [html.utils :as hu]
            [doc-transforms.mindfood :as dtmf]
            [util.feature-flags :as ff]))

(defn get-file-class [file-class]
  (when (and file-class (ff/memoized-allowed-to? (keyword (str (name file-class) "-custom-context"))))
    file-class))

(def output-n-input->transform-defs
  "Map of output type -> map of input-type -> transformation definition"
  {:mind-food        {:html {:transform-type :mind-food
                             :transform-fn   (fn [is _] (h/html->mind-food is))}
                      :pdf  {:transform-type :mind-food
                             :transform-fn   (fn [is {:keys [first-page last-page file-class]}]
                                               (mf/pdf-form->mind-food
                                                 is {:page-bounds [(or first-page 0) (or last-page 100)]
                                                     :file-class  (get-file-class file-class)}))}}
   :pdf-blocks       {:pdf {:transform-type :pdf-blocks
                            :transform-fn   (fn [is & _]
                                              (mf/pdf->block-positions is))}}
   :enhanced-hickory {:html {:transform-type :enhanced-hickory
                             :transform-fn   (fn [is _] (-> is slurp hu/get-html ehc/html->enhik))}
                      :pdf  {:transform-type :enhanced-hickory
                             :transform-fn   (fn [is {:keys [first-page last-page file-class]}]
                                               (dtmf/enhik-mindfood
                                                 (mf/pdf-form->mind-food
                                                   is
                                                   {:page-bounds [(or first-page 0) (or last-page 100)]
                                                    :file-class  (get-file-class file-class)})))}}
   :tokenvec         {:enhik {:transform-type :tokenvec
                              :transform-fn   (fn [is _] (eht/enhik->tokenvecs is))}}})

(defn ->transform-defs
  "Gets the transformation specs for output-type and input-type pairs"
  [out in]
  (-> out
      output-n-input->transform-defs
      (get in)))

(defn input-type [{:keys [filename content-type file-type]}]
  (cond (or (and filename (s/ends-with? (s/lower-case filename) ".pdf"))
            (#{"application/pdf"} content-type)) :pdf
        (or (and filename (s/ends-with? (s/lower-case filename) ".html"))
            (#{:edgar-prospectus :edgar-10k :edgar-s4} (keyword file-type))) :html
        :else nil))

(defn- safe-transform [{:keys [transform-type transform-fn]}
                       {:keys [input-stream md5 file-type filename]}
                       args]
  (let [args (assoc args :file-class file-type)
        info (str "Applying a " transform-type " transformation to the file with md5: " md5
                  ", filename: " filename ", and args: " args)]
    (try
      (timbre/debug info)
      (transform-fn input-stream args)
      (catch Exception e
        (timbre/debug e (str "Exception when " info))))))


(defn file->transform
  ([output-type file] (file->transform output-type file nil))
  ([output-type file args] (file->transform output-type false file args))
  ([output-type replace-cached? file args]
   (if-let [{:keys [transform-type cache?] :as spec} (->transform-defs output-type (input-type file))]
     (if cache?
       (or (and (not replace-cached?)
                (cache/file->cached-transformation transform-type file))
           (let [transformation (safe-transform spec file args)]
             (cache/file->cache-transformation! transformation transform-type file)
             (cache/file->cached-transformation transform-type file)))
       (assoc (dissoc file :input-stream :file)
         transform-type
         (safe-transform spec file args)))
     (log/debug (format "No transformation definition matches filename=`%s', file-type=`%s'" (:filename file) (:file-type file))))))

(defn mongo->transform
  "Transforms mongo documents into the specified representation"
  [output-type {:keys [md5 filename]} & [{:keys [update-cache? first-page last-page]}]]
  (p ::mongo->transform
     (when-let [result (some->
                         (cond
                           md5 {:md5 md5}
                           filename {:filename filename}
                           :else nil)
                         sdfs/find-file)]
       (file->transform output-type update-cache? result {:first-page first-page :last-page last-page}))))

;Here for soda-jerk-ws & surveyor
(defn lazy-food [md5 & {:keys [first-page last-page] :as args}]
  (->> (mongo->transform :mind-food {:md5 md5} args)
       :mind-food
       (drop-while #(-> % :page-number (< (or first-page 0))))
       (take-while #(-> % :page-number (<= (or last-page 100))))))
