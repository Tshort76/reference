(ns doc-transforms.cache
  (:require [clojure.edn :as edn]
            [clojure.java.io :as io]
            [clojure.string :as s]
            [clojure.pprint :refer [pprint]]
            [soda.data.file-system :as sdfs]
            [taoensso.timbre :as timbre]
            [util.temp-file :as temp-file]))

(defn file->cache-transformation!
  "Transforms a file and caches the result in mongo."
  [transformation transform-type {:keys [filename md5] :as file}]
  (when (not-empty transformation)
    (temp-file/let-temp-file
      [tempfile "soda_" ".tmp"]
      (let [mf-filename (str (subs filename 0 (s/last-index-of filename ".")) "-transformed" ".edn")]
        (timbre/debug (str "Caching a " transform-type " transformation of the file with md5: " md5))
        (with-open [fh (io/writer tempfile)]
          (binding [*out* fh]
            (pr transformation)))
        (sdfs/add-file tempfile {:filename         mf-filename
                                 :transform-type   transform-type
                                 :transform-source (dissoc file :input-stream :file)})))))

(defn file->cached-transformation
  "Retrieves the specified transformation of the supplied file."
  [type {:keys [md5]}]
  (when-let [{:keys [input-stream transform-source]}
             (->> {:transform-type type :transform-source.md5 md5}
                  sdfs/find-files
                  (sort-by :_id)
                  last)]
    (timbre/debug (str "Fetching cached " type " transformation of md5: " md5))
    (assoc transform-source (keyword type) (-> input-stream slurp edn/read-string))))

(defn input-type [])