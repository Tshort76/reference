(ns doc-transforms.simple)
;   (:require [doc-transforms.core :as transform])
;   (:import (java.io File)))
;
; (defn convert->
;   "Open filename, convert it from to"
;   [filename from to]
;   (let [file (File. filename)
;         transform-def (transform/->transform-defs to from)]
;     (if (and transform-def (:transform-fn transform-def))
;       ((:transform-fn transform-def) file))))
