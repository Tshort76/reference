(ns utils.metrics)

(defn accuracy
  "Calculates the number of correct classifications divided by the number of instances"
  [confusion-matrix]
  (let [{:keys [tp fp fn tn]} confusion-matrix]
    (float (if (zero? (+ tp fp tn fn)) 0 (/ (+ tp tn) (+ tp fp tn fn))))))

(defn precision
  "Calculates the number of true positives divided by the number of predicted positives"
  [confusion-matrix]
  (let [{:keys [tp fp]} confusion-matrix]
    (float (if (zero? (+ tp fp)) 0 (/ tp (+ tp fp))))))

(defn recall
  "Calculates the number of true positives divided by the number of actual positives"
  [confusion-matrix]
  (let [{:keys [tp fn]} confusion-matrix]
    (float (if (zero? (+ tp fn)) 0 (/ tp (+ tp fn))))))

(defn compute-metrics
  "Returns a map of several metrics on a confusion matrix"
  [confusion-matrix]
  {:confusion-matrix confusion-matrix
   :accuracy         (accuracy confusion-matrix)
   :precision        (precision confusion-matrix)
   :recall           (recall confusion-matrix)})
