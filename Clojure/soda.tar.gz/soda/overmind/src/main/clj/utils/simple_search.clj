(ns utils.simple-search
  (:require [clojure.string :as str]
            [clojure.walk :as walk]
            [jaegers.utils :as ju]))

(defn word->coord [{:keys [page page-number x y id]}]
  (let [[page-id x-id y-id] (ju/id->vec id)]
    {:page-number (or page page-number page-id) :x (or x x-id) :y (or y y-id)}))

(defn clean-text [word]
  (some-> word
          (str/replace #"[^\x00-\x7F]" "")
          (str/replace #"^[\/\-]+" "")
          (str/replace #"[\/\-]+$" "")
          (str/replace #"[\[\]()\\+\"\.:;,_^|@*?]+" "")
          str/lower-case
          not-empty))

(defn update-result [query-string {[first-word & rest-words] :words :as result}]
  (when (-> first-word
            :text
            clean-text
            (= query-string))
    (-> result
        (update :matches (fnil conj []) first-word)
        (assoc :words rest-words))))

(defn find-next-word [results query-part]
  (cond
    (empty? results) []
    (nil? query-part) results
    (sequential? query-part) (reduce #(or (not-empty (find-next-word %1 %2)) (reduced [])) results query-part)
    (set? query-part) (mapcat (partial find-next-word results) query-part)
    (string? query-part) (keep (partial update-result query-part) results)
    :else []))

(defn first-if-only [lst]
  (if (= 1 (count lst))
    (first lst)
    lst))

(defn format-query-part [query-part]
  (cond
    (sequential? query-part) (->> query-part
                                  flatten
                                  first-if-only)
    (string? query-part) (->> (str/split query-part #"\s+")
                              (map clean-text)
                              first-if-only)
    (set? query-part) (first-if-only query-part)
    :else query-part))

(defn format-match [match]
  {:ids      (map :id match)
   :coords   (map word->coord match)
   :raw-text (->> match
                  (map :text)
                  (str/join " "))
   :text     (->> match
                  (map (comp clean-text :text))
                  (str/join " "))})

(defn find-words [search-query component]
  (->> component
       :vals
       flatten
       (iterate rest)
       (take-while seq)
       (mapcat #(find-next-word
                 [{:words %}]
                 search-query))
       (keep :matches)
       (map format-match)))


(defn query-search-components [search-query components]
  (mapcat
   (->> search-query
        (walk/postwalk format-query-part)
        (partial find-words))
   components))

(defn search-components [search-phrases components]
  (some->> components
           (query-search-components
            (->> search-phrases
                 flatten
                 (into #{})))
           seq
           (apply merge-with conj
             {:ids []
              :coords []
              :text []
              :raw-text []})))
