(ns utils.mind-food
  "Utilties to manipulate mind-food for various operations"
  (:require [clojure.set :as c-set]))


(defn component-any-id?
  "returns true if component contains any of the ids in the set. Used as training filter"
  [id-set component]
  (let [component-id-set (set (map :id (flatten (:vals component))))]
    (not (empty? (c-set/intersection id-set component-id-set)))))

(defn has-id? [id mind-food-units]
  ((into #{} (map :id mind-food-units)) id))


(defn id-surrounding-text [id component]
  (if (= (:type component) :text)
    (let [line (first (filter (partial has-id? id) (:vals component)))
          text (clojure.string/join " " (map :text line))
          ids (flatten (map :id line))]
      [text ids])
    (let [cell (first (filter (partial has-id? id) (mapcat identity (:vals component))))
          text (clojure.string/join " " (map :text cell))
          ids (flatten (map :id cell))]
      [text ids])))







(defn build-seq [seq-def]
  (take (second seq-def) (repeat (first seq-def))))

(defn build-string-map
  "Given a set of mind-food-units, returns a vector of
  ints where each int matches the location of a character in a string
  built from the mindfood units, and references the location of the mfu
  it came from   For example:
  mindfood [{'foo' ...} {'bar'...}]
  indexed-counts [ [0 3] [1 3]]
  with-spaces [ [0 3] [-1 1] [0 3] ]
  the-string [ 'foo bar']
  return  [ 'foo bar'  [ 0 0 0 -1 1 1 1]]
  Where the last most bit represents the mapping of the string back to the mindfood units.
  "
  [mind-food-units]
  (let [indexed-counts (map-indexed (fn [i d] [i (count (:text d))]) mind-food-units)
        with-spaces (interpose [-1 1] indexed-counts)
        the-string (clojure.string/join " " (map :text mind-food-units))]
    [the-string (vec (mapcat build-seq with-spaces))]))

(defn mfu-indexes
  "Pull out the object indexes referenced, drop the -1 space index"
  [string-map [start end value]]
  (filter (partial not= -1)
          (-> string-map
              (subvec start end)
              distinct)))
(defn re-pos
  "finds all the occurences of the given regular expression
   in the string, returning the start, stop and match group"
  [re s]
  (loop [m (re-matcher re (str s))
         res []]
    (if (.find m)
      (recur m (conj res [(.start m) (.end m) (.group m)]))
      res)))

(defn take-indexes
  "Given a set of indexes, pull the items indexed from the vector"
  [a-vector indexes]
  (map (fn [i] (nth a-vector i)) indexes))

(defn find-in-vals
  "The fundemental unit of mindfood is a dictionary containing
  one word, a usually a sequence of characters with no white space.
  This can make using regular expression very difficult to use, this
  function takes a regular expression and a seq of mindfood units"
  [regex mind-food-units]
  (let [[a-string, string-map] (build-string-map mind-food-units)
        found (re-pos regex a-string)
        mind-food-indexes (map (partial mfu-indexes string-map) found)]
    ;TODO This is assuming one match only, which may actually cripple our ability to find it in some cases.
    (when (not (empty? found))
      {:total-string a-string
       :matches      (map (fn [s mf] [(nth s 2) (flatten mf)])
                          found
                          (map (partial take-indexes (vec mind-food-units)) mind-food-indexes))})))

(defn find-in-cells
  "Given a mindfood table, and a regex, applies the regex to each cell in the table
   returns the coordinates of the first item of the cells which contain matches
  "
  [regex table]
  (let [cells (vec (mapcat identity (:vals table)))]
    (remove empty? (map (partial find-in-vals regex) cells))))

(defn find-in-rows
  "Given a mindfood table, and a regex, applies the regex to each row in the table
   returns the coordinates of the first item of the cells which contain matches
  "
  [regex table]
  (let [rows (vec (map (comp vec flatten) (:vals table)))]
    (remove empty? (map (partial find-in-vals regex) rows))))


(defn find-in-columns
  "Given a mindfood table, and a regex, applies the regex to each column in the table
   returns the coordinates of the first item of the cells which contain matches
  "
  [regex table]
  (let [transpose (apply map list (:vals table))
        columns (vec (map (comp vec flatten) transpose))]
    (remove empty? (map (partial find-in-vals regex) columns))))

(defn find-in-table [regex table]
  (or (seq (remove empty? (find-in-cells regex table)))
      (seq (remove empty? (find-in-columns regex table)))
      (seq (remove empty? (find-in-rows regex table)))))


(defn find-in-text
  "Given a mindfood text, and a regex, applies the regex to each line of text and
   returns the coordinates of the first item of the units which match.
  "
  [regex text]
  (let [vals (flatten (:vals text))]
    (find-in-vals regex vals)))


(defn find-in-component [regex component]
  (if (= :table (:type component))
    (find-in-table regex component)
    (find-in-text regex component)))

(defn find-in-mindfood [regex mind-food]
  (flatten (remove empty? (map (partial find-in-component regex) mind-food))))


(defn bc->sc [[t1 t2]]
  (and (= (select-keys t1 [:y :page-number :bold? :font])
          (select-keys t2 [:y :page-number :bold? :font]))  ;some values the same
       (and (:font-size t1) (:font-size t2)
            (> (:font-size t1) (:font-size t2)))            ;font size goes from big to small
       (or (= 1 (count (:text t1)))                         ;only one char in the capital.
           (and (= 2 count (:text t1)) (= "\"" (first (:text t1))))) ;"or"
       (< (- (:x t2) (+ (:x t1) (:width t1)))               ;gap between letters is less than
          (/ (:width t1) 2))))                              ;1/2 size of the first letter

(defn merge-bcsc
  [items]
  (if (= 2 (count items))
    (let [[t1 t2] items]
      (if (bc->sc [t1 t2])
        [{:text   (str (:text t1) (:text t2))
          :x      (:x t1)
          :y      (:y t1)
          :width  (+ (:width t1) (:width t2))
          :height (:height t1)
          :bold?  (:bold? t1)
          :font-size (:font-size t2)
          :id     (:id t1)
          :ids    [(:id t1) (:id t2)]}]

        [t1 t2]))
    items))

(defn merge-big-cap-small-cap
  "In some documents, instead of using uppercase and lowercase, there is a pattern of using all caps
  but changing font size on the first letter for emphasis.  Our current mindfood separates this out,
  which causes problems with using regular expressions."
  [seq]
  (let [first-merge (mapcat merge-bcsc (partition-all 2 2 seq))
        first-item (take 1 first-merge)
        second-merge (vec (mapcat merge-bcsc (partition-all 2 2 (drop 1 first-merge))))]

    (flatten [first-item second-merge])))

(defn text-clean-up [c]
  (let [rows (:vals c)
        cleaned (map merge-big-cap-small-cap rows)]
    (assoc c :vals cleaned)))

(defn cell-clean-up [cell]
  (let [cleaned (nth (iterate merge-big-cap-small-cap cell) 2)]
    cleaned))

(defn table-row-clean-up [row]
  (doall (map cell-clean-up row)))

(defn table-clean-up [t]
  (let [rows (:vals t)
        cleaned (map table-row-clean-up rows)]
    (assoc t :vals cleaned)))

(defn component-clean-up [c]
  (case (:type c)
    :text (text-clean-up c)
    :table (table-clean-up c)
    c))

(defn new-text-component [vals]
  {:x0          0.0
   :x1          0.0
   :y0          0.0
   :y1          0.0
   :page-number 0
   :type        :text
   :vals        vals})

(defn columns->text
  "Some of our algorithms are designed around looking at
  text as a :text component.  :Text is composed of [[token token token]]
  Whereas a table is composed of [[[token token][token]]]
  This function creates new text components based on the columns of the table.
  It doesn't create new ids, is mainly a helper for other functions.
  "
  [component]
  (if (= (:type component) :text)
    [component]
    (let [rows (:vals component)
          columns (apply mapv vector rows)
          components (vec (map new-text-component columns))]
      components)))




(defn ->text-component [c]
  (if (= (:type c) :text)
    c
    (merge c
           {:vals (map flatten (:vals c))
            :type :text})))

(defn merge-2components [c1 c2]
  (let [txt1 (->text-component c1)
        txt2 (->text-component c2)]
    (assoc txt1 :vals (concat (:vals txt1) (:vals txt2)))))

(defn merge-components [components]
  (when (seq components)
    (reduce merge-2components components)))

#_(comment
    (find-in-mindfood #".{3,30} plus \d.\d\d%" (:mind-food test-document)))
