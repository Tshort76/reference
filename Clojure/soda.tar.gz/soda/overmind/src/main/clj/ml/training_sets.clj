(ns ml.training-sets
  (:require
    [clj-ml.classifiers :as ml-class]
    [clj-ml.data :as ml-data]
    [clj-ml.io :as ml-io]
    [clojure.spec.alpha :as spec]
    [ml.classifiers :as mlc]
    [datasources.core :as ds]
    [doc-transforms.core :as dtc]
    [enhanced-hickory.tokenvec :as eht]
    [enhanced-hickory.util :as ehu]
    [jaegers.edgar.primer :as ep]
    [jaegers.utils :as ju]
    [jaegers.features.enfeature :as enfeature]
    [jaegers.md5-control-sets :as csets]
    [jaegers.mind-food-utils :as mfu]
    [jaegers.spec]
    [medley.core :refer [distinct-by find-first]]
    [ml.tokenizers :as tok]
    [monger.collection :as mc]
    [soda.data.core :refer [defcon]]
    [monger.operators :refer [$set]]
    [taoensso.timbre :as log])
  (:import [org.bson.types ObjectId]))

(defcon "training-sets" "feature-maps" :updatable true)

(defn reprocess-control-set
  [control-name train-set-name & {:keys [page-limit] :or {page-limit 3}}]
  (->> (csets/control-sets control-name)
       (distinct-by :md5)
       (pmap (fn [{:keys [filename md5]}]
               (some->>
                 {:md5 md5}
                 (dtc/mongo->transform :enhanced-hickory)
                 :enhanced-hickory
                 (ehu/filter-pages page-limit)
                 ep/enfeature-enhik
                 (map #(assoc % :descriptor-id train-set-name, :filename filename, :md5 md5))
                 (map #(dissoc % :indexes :string)))))
       (apply concat)))

(defn control-set->training-set
  ([control-name]
   (control-set->training-set (keyword control-name) (name control-name)))
  ([control-name train-set-name]
   (mc/insert (ds/get-db "training-sets") "features-descriptors"
              {:_id train-set-name, :jaeger train-set-name, :features-descriptor ep/simple-features-descriptor})
   (bulk-write-feature-maps (reprocess-control-set control-name train-set-name))))

(defn upsert-control-set-feature-maps
  ([control-name]
   (upsert-control-set-feature-maps (keyword control-name) (name control-name)))
  ([control-name train-set-name]
   (map
     (fn [feature-map]
       (if (not-empty (feature-maps (select-keys feature-map [:md5 :ids])))
         (update-feature-maps (select-keys feature-map [:md5 :ids]) {$set {:features (:features feature-map)}})
         (bulk-write-feature-maps [feature-map])))
     (reprocess-control-set control-name train-set-name))))

(defn keywordize-value [v]
  (cond
    (string? v) (keyword v)
    (boolean? v) (keyword (str v))
    :default v))

(defn feature-maps->training-set [jaeger-name feature-maps]
  (let [fd (some :features-descriptor feature-maps)]
    {:jaeger              jaeger-name
     :features-descriptor fd
     :feature-maps        (mapv #(dissoc % :features-descriptor) feature-maps)}))

(defn training-set->weka-data-set
  [{:keys [jaeger feature-maps features-descriptor] :as m}]
  {:pre [(spec/assert :training-set/training-set m)]}
  (let [fd (mfu/implicit->explicit-feature-descriptor features-descriptor)
        ks (conj (vec (remove #{:class} (keys fd))) :class)
        valid (->> feature-maps (filter :validated?) (map :features))]
    (-> (ml-data/make-dataset
          jaeger
          (vec (for [k ks :let [v (k fd)]] (if v {k (mapv keywordize-value v)} k)))
          (mapv (fn [fmap] (mapv (comp keywordize-value fmap) ks)) valid))
        (ml-data/dataset-set-class :class))))

(defn training-set->arff-file
  [training-set filename]
  {:pre [(spec/assert :training-set/training-set training-set)]}
  (ml-io/save-instances :arff filename (training-set->weka-data-set training-set)))

(defn training-set->decision-tree
  [training-set]
  {:pre [(spec/assert :training-set/training-set training-set)]}
  (let [ds (training-set->weka-data-set training-set)
        classifier (-> (ml-class/make-classifier :decision-tree :c45)
                       (ml-class/classifier-train ds))]
    (mlc/classfier->edn-tree classifier)))

(defn training-set->ensemble-trees
  [training-set & {:keys [num-trees num-features max-depth]}]
  {:pre [(spec/assert :training-set/training-set training-set)]}
  (let [ds (training-set->weka-data-set training-set)
        opts (cond-> {:parallelism           0              ; auto-detect cores
                      :calc-out-of-bag-error true
                      :print-classifiers     true}
                     num-trees (assoc :num-trees-in-forest num-trees)
                     num-features (assoc :num-features-to-consider num-features)
                     max-depth (assoc :depth max-depth))
        classifier (-> (ml-class/make-classifier :decision-tree :random-forest opts)
                       (ml-class/classifier-train ds))]
    (mlc/ensemble-classifier->edn-trees classifier)))

(defn training-set->classifier
  [training-set & {:keys [evaluate?] :or {evaluate? true}}]
  (let [ds (training-set->weka-data-set training-set)
        classifier (-> (ml-class/make-classifier :decision-tree :c45)
                       (ml-class/classifier-train ds))]
    (merge {:classify-fn (partial mlc/classify (mlc/classfier->edn-tree classifier))}
           (when (and evaluate? (-> training-set :feature-maps count (>= 10)))
             {:evaluation (ml-class/classifier-evaluate classifier :cross-validation ds 10)}))))

;; -----------------------------------------------------------------------------

(defn re-enfeature-feature-map
  "Re-enfeatures a single feature map.
   Do not use directly. Use re-enfeature-feature-maps or re-enfeature-training-set instead."
  [db dmap tvs {[[id]] :ids {klass :class} :features :as fmap}]
  (let [tv (find-first (fn [[_ toks]] (some (comp #{id} :id) toks)) tvs)
        value (enfeature/datom->dissection dmap {:token-id (ju/id->vec id)})]
    (-> (enfeature/enfeature-value db ep/features-descriptor dmap tv value)
        (merge (select-keys fmap [:_id :descriptor-id :md5 :filename :validated?]))
        (assoc-in [:features :class] klass))))

(defn re-enfeature-feature-maps
  "Re-enfeatures a collection of feature maps from a single document"
  [[{:keys [md5]} :as fmaps]]
  (let [enhik (->> {:md5 md5} (dtc/mongo->transform :enhanced-hickory) :enhanced-hickory)
        tvs (eht/enhik->tokenvecs enhik)
        db (enfeature/enhik->db tok/dissect-text enhik)
        dmap (enfeature/tvs->dissect-map tok/dissect-text tvs)]
    (if enhik
      (do (log/debug (format "Re-enfeaturing %d feature maps for md5 %s" (count fmaps) md5))
          (map (partial re-enfeature-feature-map db dmap tvs) fmaps))
      (log/debug (format "No enhanced-hickory for md5 %s!" md5)))))

(defn re-enfeature-training-set
  "Re-enfeatures all feature maps for the given training set"
  [set-name]
  (let [db (ds/get-db "training-sets")
        old-fmaps (->> (mc/find-maps db "feature-maps" {:descriptor-id set-name}) (group-by :md5) vals)
        new-fmaps (remove nil? (flatten (pmap re-enfeature-feature-maps old-fmaps)))]
    (when (seq new-fmaps)
      (mc/update-by-id db "features-descriptors" set-name
                       {:$set {:features-descriptor ep/simple-features-descriptor}})
      (run! (fn [{:keys [_id] :as m}] (mc/update-by-id db "feature-maps" _id m)) new-fmaps))))
