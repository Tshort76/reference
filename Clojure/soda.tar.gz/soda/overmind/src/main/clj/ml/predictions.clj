(ns ml.predictions
  (:require
    [clj-http.client :as http]
    [clojure.string :as string]
    [datascript.core :as d]
    [environ.core :refer [env]]
    [jaegers.features.context :as context]
    [jaegers.features.enfeature :as enfeature]
    [perseverance.core :as perseverance]
    [plumbing.core :refer [?>>]]
    [soda.core :refer [partition-when]]
    [soda.data.file-system :as sdfs]
    [surveyor-interop.ml.core :as siml]
    [taoensso.timbre :as timbre]
    [clojure.data.json :as json]
    [ml.restrictions :as restrictions])
  (:import [java.io FileNotFoundException IOException]))

(def ml-retrieval-address (or (env :ml-retrieval-address) "http://soda_ml_retrieval_model:8000/soda_ml_retrieval_model"))
(def ml-extraction-address (or (env :ml-extraction-address) "http://soda_ml_extraction_model:8000/soda_ml_extraction_model"))
(def ml-validation-address (or (env :ml-validation-address) "http://soda_ml_validation_model:8000/soda_ml_validation_model"))

(defn batch-prediction
  "Calls classify-batch endpoint at url with samples"
  [url samples & [opts]]
  (perseverance/retriable
    {:tag ::batch-prediction}
    (try (->> {:content-type :json, :form-params samples, :as :json}
              (http/post (str url "/classify-batch" (if (:full-output opts) "?full=true" "")))
              :body)
         (catch IOException e
           (throw (IOException. (format "Can't connect to %s: %s" url e))))
         (catch Exception e
           (timbre/debug (str "Can't connect to ML batch-prediction service."
                              "  URL: " url
                              ", Content Length: " (count (json/write-str samples))
                              ", Exception type: " (.getCanonicalName (.getClass e))))
           (throw e)))))

(defn new-value?
  "Returns true if token y starts a new value.

  Tokens are tagged using the Inside-Outside-Beginning (IOB) scheme. A b- tag
  marks the start of a new value, an i- tag marks the continuation of a value,
  and an o- tag marks a junk value."
  [x y]
  (let [[x-tag x-class] (string/split (name x) #"-")
        [y-tag y-class] (string/split (name y) #"-")]
    (or                                                     ; start of new value
      (= "b" y-tag)
      ; end of current value
      (and (= "i" x-tag) (not= "i" y-tag))
      ; both tags i, but diff class
      (and (= "i" x-tag y-tag) (not= x-class y-class))
      ; classes don't match
      (not= x-class y-class))))

(defn run-retrieval-prediction
  "Returns components that are predicted with greater than 50% probability to
  have at least one field of interest"
  [components]
  (let [source (-> components first :source)
        components (remove (partial restrictions/beyond-page-limit? source) components)               ;SODA-4520: add a page limit for tokens, given source
        {:keys [api-version model-version model-last-modified classes predictions]}
        (batch-prediction ml-retrieval-address components)]
    (for [[com preds] (map vector components predictions)
          :when (some #(> % 0.5) preds)
          :let [meta {:api-version             api-version
                      :model-version           model-version
                      :model-last-modified     model-last-modified
                      :component-id            (:component-id com)
                      :component-classes       classes
                      :component-probabilities preds}]]
      (assoc com :meta {:retrieval meta}))))

(defn run-extraction-prediction
  "Returns values extracted from components that are predicted to be of a
   value-type of interest"
  [components]
  (let [{:keys [api-version model-version model-last-modified predictions]} (batch-prediction ml-extraction-address components)
        results (mapv merge components predictions)]
    (for [{:keys [ids classes words probabilities meta]} results
          :let [result (map (comp (partial zipmap [:id :class :word :p]) vector) ids classes words probabilities)]
          value-toks (partition-when (fn [x y] (new-value? (:class x) (:class y))) result)
          :when (not-any? (comp #{"other"} :class) value-toks)
          :let [string (string/join " " (map :word value-toks))
                cls (-> value-toks first :class (string/split #"-" 2) last keyword)]]
      {:string   string
       :value    string
       :class    cls
       :source   (:source (first components))
       :ids      (vector (mapv :id value-toks))
       :features {:value-type cls}
       :meta     (merge meta {:extraction
                              {:api-version             api-version
                               :model-version           model-version
                               :model-last-modified     model-last-modified
                               :component-words         words
                               :component-classes       classes
                               :component-probabilities probabilities
                               :value-classes           (map :class value-toks)
                               :value-probabilities     (map :p value-toks)}})})))

; TODO deprecate top-level :probability key
(defn run-validation-prediction
  [values]
  (let [{:keys [api-version model-version model-last-modified predictions]} (batch-prediction ml-validation-address values)]
    (map (fn [value pred]
           (let [meta {:api-version         api-version
                       :model-version       model-version
                       :model-last-modified model-last-modified
                       :value-probability   (:probability pred)}]
             (-> (merge value pred)
                 (update :meta assoc :validation meta)
                 (assoc :class (keyword (:class pred))))))
         values predictions)))

(defn prediction-pipeline
  "Runs the deep learning prediction pipeline on enhik, returning a collection
  of maps representing predicted values"
  [db source & [{:keys [use-retrieval?]}]]
  (let [sort-fn (enfeature/token-sort-fn (d/pull db [:*] 1))]
    (->> (context/enhik-db->components db source {:sort-fn sort-fn})
         (?>> use-retrieval? run-retrieval-prediction)
         run-extraction-prediction
         (pmap (partial context/add-context db))
         run-validation-prediction)))

(defn prediction-pipeline-helper [{:keys [db file-type query]} opts]
  (if db
    (prediction-pipeline db (siml/file-type->source file-type) opts)
    (throw (FileNotFoundException. (str query)))))


(defn enhik->predictions [{:keys [file-type md5] :as enhik} & [opts]]
  (prediction-pipeline-helper {:db        (enfeature/file-transform->db enhik)
                               :file-type file-type
                               :query     {:md5 md5}} opts))

(defn prediction-pipeline-by-query
  "Runs the deep learning prediction pipeline on the document identified by query"
  [query & [opts]]
  (let [{:keys [file-type]} (sdfs/find-one-meta query)]
    (prediction-pipeline-helper {:db        (enfeature/query->db query)
                                 :file-type file-type
                                 :query     query} opts)))

(defn token-extractions
  "Format the data in a robert friendly form"
  [{:keys [ids words text classes full_output probabilities] :as component-results}]
  (let [base-component (dissoc component-results :ids :words :text :classes :full_output :probabilities)]
    (map (fn [id word class probability full_output]
           (assoc base-component
             :id id
             :component-text text ;just renaming text -> component-text
             :word word
             :class class
             :probability probability
             :extractions (mapv (fn [[k v]] {:type k :probability v}) full_output)))
         ids words classes probabilities full_output)))

(defn raw-extraction-by-query
  "Runs extraction raw."
  [query & [{:keys [use-retrieval?]}]]
  (let [{:keys [file-type]} (sdfs/find-one-meta query)]
    (if-let [db (enfeature/query->db query)]
      (let [sort-fn (enfeature/token-sort-fn (d/pull db [:*] 1))
            source (siml/file-type->source file-type)
            values (->> (context/enhik-db->components db source {:sort-fn sort-fn})
                        (?>> use-retrieval? run-retrieval-prediction))]
        (->> (batch-prediction ml-extraction-address values {:full-output true})
             :predictions
             (map merge values)
             (mapcat token-extractions)))
      (throw (FileNotFoundException. (str query))))))