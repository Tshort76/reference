(ns ml.restrictions)

(defmulti beyond-page-limit?
          "Returns true if a component is starts on a page after the limit for that source"
          (fn [source component] source))
(defmethod beyond-page-limit? :default [_ component] false)
(defmethod beyond-page-limit? :limited-partnership
  [_ component]
  (some->> component :component-id (re-find #"(\d+)_(.*)") second read-string (< 12)))
(defmethod beyond-page-limit? :emma
  [_ component]
  (some->> component :component-id (re-find #"(\d+)_(.*)") second read-string (< 10)))