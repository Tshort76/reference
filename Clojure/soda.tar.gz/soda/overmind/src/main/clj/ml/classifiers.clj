(ns ml.classifiers
  (:require [clojure.edn :as edn]
            [clojure.string :as cs]
            [clojure.walk :as walk]
            [clojure.zip :as zip]
            [soda.core :refer [ptransduce]]
            [taoensso.tufte :refer [defnp]])
  (:import (weka.classifiers.trees J48 RandomForest)))

(defn classfier->edn-tree
  "Convert a trained J48 classifier decision tree to valid edn.
  This can be further processed into a function."
  [^J48 classifier]
  (-> (.prefix classifier)
      (cs/replace #"/" " / ")
      (cs/replace #"([\w\-]+\??):" (fn [[_ x]] (str ":" x)))
      edn/read-string))

(defn- ensemble-lines->tree
  [lines]
  (letfn [(zip-up-n [loc n] (->> (zip/up loc) (iterate zip/up) (take (or n 1)) last))] 
    (loop [lines lines, last-depth -1, ztree (zip/xml-zip {:root true :content []})]
      (if-let [[depth node] (first lines)]
        (recur (rest lines)
               depth
               (cond-> ztree
                 (= depth last-depth) (-> (zip/insert-right node) zip/right)
                 (< depth last-depth) (-> (zip-up-n (- last-depth depth)) (zip/insert-right node) zip/right)
                 (> depth last-depth) (-> (zip/append-child node) zip/down)))
        (zip/root ztree)))))

(defn- ensemble-lines->edn
  [lines]
  (->> lines 
       ensemble-lines->tree
       (walk/postwalk
         (fn [{content :content :as node}]
           (if content
             (let [attr (-> content first :attr keyword)
                   edges (mapcat (juxt (comp symbol :pred) (comp edn/read-string :val)) content)
                   kids (map (fn [{klass :class contrib :contrib content :content}]
                               (if klass [(symbol klass) (symbol (cs/replace contrib "/" " / "))] content)) content)]
               (assoc node :content (vec (concat [attr] edges kids))))
             node)))
       :content))

(defn ensemble-classifier->edn-trees
  "Converts a trained RandomForest classifier to a vector of edn trees, one
   for each tree in the forest."
  [^RandomForest classifier]
  (let [xform (comp (take-while seq)
                    (map #(cs/split % #"\s+"))
                    (map (fn [toks] (cons (count (take-while #{"|"} toks)) (drop-while #{"|"} toks))))
                    (map (partial remove #{":"}))
                    (map (fn [[depth & toks]] [depth (zipmap [:attr :pred :val :class :contrib] toks)])))] 
    (->> (cs/split (str classifier) #"RandomTree\s*\n\s*==========\s*\n\n")
         rest
         (map cs/split-lines)
         (map (partial into [] xform)) 
         (mapv ensemble-lines->edn))))

(defn- auto-keyword [word]
  (if (or (symbol? word)
          (string? word))
    (keyword word)
    word))

(defn- contrib->vec [c] 
  (-> (str c) 
      (cs/replace #"[^\d./]" "") 
      (cs/split #"/") 
      (->> (mapv edn/read-string))))

(defn classify [classifier-tree m]
  (loop [[feature & r] classifier-tree p []]
    (if (symbol? feature)
      {:class (keyword feature) :contributions (contrib->vec (first r)) :decision-path p}
      (let [[c results] (split-at (* (/ (count r) 3) 2) r)
            ops (map (fn [[op v] result]
                       [((resolve op) (-> m feature auto-keyword) (auto-keyword v)) result [feature op v]])
                     (partition 2 c) results)
            [branch reason] (some (fn [[c r op]] (when c [r op])) ops)]
        (when (and branch reason)
          (recur branch (conj p reason)))))))

(defn- merge-classifications
  [m {[total wrong] :contributions klass :class}]
  (-> m
      (update-in [klass :total] (fnil + 0) (or total 0))
      (update-in [klass :wrong] (fnil + 0) (or wrong 0))))

(defnp classify-ensemble [classifier-trees fmap]
  (let [n (* 4 (.. Runtime getRuntime availableProcessors))]
    (some->> classifier-trees
             (ptransduce n (keep #(classify % fmap)) merge-classifications {})
             not-empty
             (apply max-key (comp :total val))
             ((fn [[klass {:keys [total wrong]}]] 
                {:class klass 
                 :contributions [total wrong] 
                 :confidence (double (/ (- total wrong) total))})))))
