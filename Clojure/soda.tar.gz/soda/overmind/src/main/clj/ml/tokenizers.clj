(ns ml.tokenizers
  (:require
    [jaegers.regisector :as rs]
    [soda-common.parsers :as parsers]
    [soda-common.regexes :as re]))

(def interesting-words
  (->> ["aggregate" "allocation" "amount" "annual" "annum" "authorized"
        "beginning" "benchmark"
        "call" "callable" "certificate" "commencing" "coupon" "cusip"
        "date" "delivery" "denomination" "due"
        "face" "first" "fixed" "frequency"
        "gross"
        "inception" "increment" "information" "initial" "interest" "issue"
        "mandatory" "maximum" "maturity" "minimum" "multiple"
        "note" "number"
        "offering" "offered" "option" "optional" "original"
        "par" "payment" "price" "pricing" "principal" "prospectus"
        "rate" "record" "redemption" "registration"
        "securities" "security" "settlement" "size" "spread" "state" "stated" "supplement"
        "tax" "term" "title" "total" "trade" "treasury"
        "yield"]
       (map (fn [w] {(keyword (str w "-word")) (re-pattern (str "(?i)(?:^|\\b)" w "(?:\\b|$)"))}))
       (into {})))

(def interesting-terms
  {:key-like          #"(\w+:)"
   :interest-rate     #"(?i)(coupon|((interest|coupon|annual) rate)|(fixed rate note)):?"
   :issue-date        #"(?i)(((original )?(issue|issuance|settle(ment)?) date)|(date of issue)):?"
   :maturity-date     #"(?i)((stated )?maturity( date)?|matur(e|ing|ities)):?"
   :principal-amount  #"(?i)((aggregate )?(principal|face) amount)( offered)?:?"
   :issue-price       #"(?i)(initial )?((price to public)|(issue price)|((public )?offering price)):?"
   :first-coupon-date #"(?i)(1\s?st |first )?(((interest )?pay(ment)?)|coupon) dates?:?"
   :call-option-date  #"(?i)(((optional )?redemption( information| provisions)?)):?"})

(def re-percent #"((?:\d|[1-9]\d|1\d{2})|(?:\.\d+)|(?:\d|[1-9]\d|1\d{2})\.\d+)\s?%")
(def re-money #"\$?(\d{1,3})(,\d{3})+(\.\d{1,2})?")
(def re-double #"(\d{1,3}\.\d{1,3})")

(def term-splits
  (let [split-def (fn [[kw re]] {:regex re :handler (fn [[s]] {:value s :features {:value-type kw :term? true}})})]
    (into (map split-def interesting-words) (map split-def interesting-terms))))

(def value-splits
  [{:regex re-percent :handler (fn [[s]] {:value (-> s parsers/parse first val double) :features {:value-type :percent}})}
   {:regex re/date :handler (fn [[s]] {:value (:date (parsers/parse s)) :features {:value-type :date}})}
   {:regex re-money :handler (fn [[s]] {:value (-> s parsers/parse first val double) :features {:value-type :dollars}})}
   {:regex re/four-digit-year :handler (fn [s] {:value (-> s parsers/parse first val) :features {:value-type :year}})}
   {:regex re/month-day :handler (fn [[s]] {:value s :features {:value-type :month-day}})}
   {:regex #"(?i)(date of delivery|delivery date|dated date)" :handler (fn [[s]] {:value s :features {:value-type :reference-date}})}
   {:regex re-double :handler (fn [[s]] {:value (Double/parseDouble s) :features {:value-type :number}})}])

(def split-set (reduce into [] [value-splits term-splits]))
(defn dissect-text [s] (rs/dissect s split-set))
