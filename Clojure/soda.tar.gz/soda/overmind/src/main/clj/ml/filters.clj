(ns ml.filters
  (:require [clojure.set :as set])
  (:import (weka.filters.unsupervised.attribute Normalize)))

(defn normalizer->edn
  [^Normalize normalizer attribute-names]
  (-> (bean normalizer)
      (select-keys [:scale :translation :minArray :maxArray])
      (set/rename-keys {:minArray :min-array :maxArray :max-array})
      (update :min-array vec)
      (update :max-array vec)
      (assoc :attributes (vec attribute-names))))

(defn normalize-value
  [value scale translation minval maxval] 
  (let [spread (- maxval minval)] 
    (->> (if (pos? spread) (/ (- value minval) spread) 0)
         (* scale)
         (+ translation))))

(defn normalize-feature-map
  [normalizer fmap]
  (let [{:keys [attributes scale translation min-array max-array]} normalizer]
    (reduce (fn [m i] 
              (let [attr (attributes i)
                    old-val (get-in m [:features attr])]
                (cond-> m
                  (number? old-val) 
                  (assoc-in [:features attr] (normalize-value old-val scale translation (min-array i) (max-array i)))))) 
            fmap (range (count attributes)))))

