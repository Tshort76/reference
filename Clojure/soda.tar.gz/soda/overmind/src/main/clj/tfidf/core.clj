(ns tfidf.core
  (:gen-class)
  (:require [clojure.string :as s]
            ; [datasources.core :as ds]
            ; [monger.collection :as mc]
            [soda-common.regexes :as regex]
            ; [doc-transforms.core :as dtc]
            [stemmer.snowball :as snowball]
            [clojure.java.io :as io]
            [clojure.edn :as edn]))

(def stemmer (snowball/stemmer :english))
(def punc-regex #"[\[\]\/()\\+\"\.:;,_^|@*\-?]+")
(def punc-regexy #"[\[\]()\\+\"\.:;,_^|@*?]+")
(def middle-dots-regex #".*\.{2,}.*")
(def money-regex #".*[$].*")
(def cusip-regex (regex/alts regex/cusip-3-like regex/cusip-6-like regex/cusip-9-like
                             regex/muni-cusip-6-like regex/muni-cusip-9-like))
(def alpha-num #".*[a-zA-Z].*\d.*|.*\d.*[a-zA-Z].*")
(def date-range #"\d{4}[-]\d{4}")
(def with-num #".*\d.*")

(def ignore-words #{"" "a" "and" "that" "have" "as" "in"
                    "the" "of" "at" "to" "too" "i" "it" "for"
                    "not" "on" "with" "do" "are"})

(defn norm-word
  [word]
  (let [stemmed (-> word
                    (s/replace #"[^\x00-\x7F]" "")
                    (s/replace (re-pattern (str "^" punc-regex)) "")
                    (s/replace (re-pattern (str punc-regex "$")) "")
                    (s/replace punc-regexy "") ;TL addition
                    s/trim stemmer)]
    (cond
      (re-matches regex/number-like stemmed) "number*"
      (re-matches regex/date stemmed) "date*"
      (re-matches date-range stemmed) "date-range*"
      (re-matches regex/percent-like stemmed) "percent*"
      (re-matches money-regex stemmed) "money*"
      (re-matches cusip-regex stemmed) "cusip*"
      (re-matches alpha-num stemmed) "alpha-num*"
      (re-matches with-num stemmed) "with-num*"
      (re-matches middle-dots-regex stemmed) ""
      :else (s/lower-case stemmed))))

; (defn query-essence [q compression]
;   (let [compression (if (> 2 compression) 2 compression)]
;     (->> (s/split q #" ") (map norm-word) (filter #(not (ignore-words %))) frequencies
;          (map (fn [[w c]] (repeat (int (/ c compression)) w))) flatten (s/join " "))))

;=========TF-IDF Implementation/
(defn calc-tf [word-freq max-freq]
  (+ 0.5 (* 0.5 (/ word-freq
                   max-freq))))

(defn calc-idf [word num-comps freqs]
  (some->> word freqs (/ num-comps) (Math/log10)))

(defn calc-vector-weights [doc num-comps freqs]
  (let [doc-freqs (frequencies (filter #(not (ignore-words (first %))) (map norm-word doc)))
        max-freq (second (last (sort-by second doc-freqs)))]
    (reduce
      (fn [vector-map [word freq]]
        (assoc vector-map word (* (calc-tf freq max-freq)
                                  (or (calc-idf word num-comps freqs) 0))))
      {}
      doc-freqs)))

(defn calc-euclidean-length [v]
  (Math/sqrt
    (reduce
      (fn [ret v]
        (+ ret (* v v)))
      0
      (vals v))))

(defn multiply-vectors [v1 v2]
  (reduce
    (fn [ret [w v]]
      (+ ret (* v (or (v2 w) 0))))
    0
    v1))


(defonce component-freqs (-> "tfidf/component_freqs.edn" io/resource slurp edn/read-string))

;(def components-inspected (:components-inspected (mc/find-one-as-map (ds/get-db "soda_configs") "overmind" {} [:components-inspected])))
(def components-inspected 11267348)

(defn calc-cosine-similarity [d q & [num-components freqs]]
  (let [n (or num-components components-inspected)
        freqs (or freqs component-freqs)
        v1 (calc-vector-weights q n freqs)
        v2 (calc-vector-weights d n freqs)
        x (* (calc-euclidean-length v1) (calc-euclidean-length v2))]
    (if (zero? x)
      x
      (/ (multiply-vectors v1 v2)
         x))))

; (defn pmap-indexed [f coll] (pmap f (range) coll))
;
; (defn transform-md-comp-to-text [mf-comp]
;   (->> mf-comp :vals (map (partial map :text)) flatten (filter (comp not nil?))))
;
; (defn most-similar-to [ref-string mind-food & [n]]
;   (let [mf-components (map (fn [comp]
;                              (let [id (:id (ffirst (:vals comp)))]
;                                (dissoc (assoc comp :id id
;                                                    :text (transform-md-comp-to-text comp)
;                                                    :page-number (or (:page-number comp) (if-let [page (not-empty (first (s/split (or id "") #"[_]")))]
;                                                                                           (Integer/parseInt page))))
;                                        :vals)))
;                            mind-food)
;         words-q (s/split ref-string #" ")
;         num-comps (:components-inspected (mc/find-one-as-map (ds/get-db "soda_configs") "overmind" {} [:components-inspected]))]
;     (->> mf-components
;          (pmap-indexed (fn [index {:keys [text] :as mf-comp}]
;                          (assoc mf-comp :index index
;                                         :text (s/join " " text)
;                                         :score (calc-cosine-similarity words-q (:text mf-comp) num-comps component-freqs))))
;          (sort-by (fn [{:keys [score]}] (* score -1.0)))
;          (take (or n 3)))))
;
; (defn get-mindfood [filename]
;   (:mind-food (dtc/mongo->transform :mind-food {:filename filename})))
;
; (defn query-top-n [query-doc filename & [n]]
;   (most-similar-to query-doc (get-mindfood filename) n))
