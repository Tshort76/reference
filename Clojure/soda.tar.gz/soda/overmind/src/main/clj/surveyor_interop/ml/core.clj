(ns surveyor-interop.ml.core
  (:require
    [datasources.core :as ds]
    [doc-transforms.core :as dtc]
    [jaegers.features.enfeature :as enfeature]))

(def training-db #(ds/get-db "training-sets"))
(def training-coll "candidates2")

(defn file-type->source [file-type]
  (case (keyword file-type)
    (:edgar-prospectus :edgar-corporate-action :edgar-s4) :edgar
    (:muni-jaeger) :emma
    (:canadian-analytics-data) :can-mbs
    (:blackrock-trade-ticket) :blackrock
    (:lp-general-partner-report) :limited-partnership
    ; else
    (keyword file-type)))
