(ns surveyor-interop.ml.seed-ml-questions
  (:require
    [clj-http.client :as http]
    [doc-transforms.core :as dtc]
    [environ.core :refer [env]]
    [jaegers.features.enfeature :as enfeature]
    [ml.predictions :as predictions]
    [surveyor-interop.core :as si]
    [surveyor-interop.enqueue-questions :as eq]
    [surveyor-interop.ml.core :as ml]
    [taoensso.timbre :as log]))

(defn seed-question!
  "Predicts values for the given Surveyor question id and caches the result as
  the default answer unless a cached answer already exists"
  [qid & [{:keys [use-all-components?] :or {use-all-components? false}}]]
  (letfn [(answer [qid] (:body (http/get (str si/base-url "api/answer/default/question-id/" qid) {:as :json})))
          (question [qid] (:body (http/get (str si/base-url "api/question-definition/question-id/" qid) {:as :json})))]
    (if-not (answer qid)
      (let [{:keys [params document]} (question qid)
            file-type (keyword (:file-type document))
            source (ml/file-type->source file-type)
            question-field? (set (map keyword (:fields params)))
            db (enfeature/query->db (select-keys document [:md5]))]
        (some->>
          (predictions/prediction-pipeline db source {:use-retrieval? (not use-all-components?)})
          ;; only keep fields that are in the question
          (filter (comp question-field? :class))
          ;; only keep fields with a correct value-type
          (filter (fn [{:keys [value-type class]}]
                    (= (keyword value-type) (get-in eq/file-type->fields [file-type class :field-type]))))
          ;; remove weak predictions
          (remove (comp #(< % 0.75) :probability))
          not-empty
          (map (fn [{:keys [ids string class]}]
                 {:ids (flatten ids), :text string, :class class, :groups []}))
          (si/seed-question! qid)))
      (log/info (str "A cached answer already exists for question-id " qid)))))

(defn seed-questions!
  "Predicts values for the Surveyor questions matching tags and caches each
  result as a default answer unless a cached answer already exists"
  [tags & [opts]]
  (->> {:as :json, :query-params {"tags" (distinct (cons "model-training" (map name tags)))}}
       (http/get (str si/base-url "api/question-definition"))
       :body
       (map :question-id)
       (pmap #(seed-question! % opts))
       dorun))
