(ns surveyor-interop.ml.enqueue-ml-questions
  (:require
    [clj-http.client :as http]
    [clj-time.core :as tm]
    [clj-time.coerce :as tmc]
    [clojure.core.memoize :as memo]
    [clojure.spec.alpha :as spec]
    [datasources.core :as ds]
    [environ.core :refer [env]]
    [monger.collection :as mc]
    [surveyor-interop.core :as si]
    [surveyor-interop.enqueue-questions :as questions]
    [surveyor-interop.ml.core :as ml]))

(spec/def ::max-files pos-int?)
(spec/def ::file-percent (spec/and float? pos?))
(spec/def ::window-days pos-int?)
(spec/def ::ask-options (spec/keys :req-un [::max-files ::file-percent ::window-days]))

(def hour-in-ms (* 60 60 1000))

(defn ask-options*
  "Returns the Surveyor question options for file-type"
  [file-type]
  (let [opts (mc/find-one-as-map (ds/get-db "soda_configs") "properties" {:type "surveyor-ask-options", :file-type file-type})
        parsed (spec/conform ::ask-options opts)]
    (if (= parsed ::spec/invalid)
      (throw (ex-info "Invalid ask-options" (spec/explain-data ::ask-options opts)))
      parsed)))

(def ask-options
  (memo/ttl ask-options* :ttl/threshold hour-in-ms))

(defn by-date-query
  [as-of-date opts]
  (let [from-date (tmc/to-date (tm/minus (tmc/to-date-time as-of-date)
                                         (tm/days (:window-days opts))))]
    {:effective-start-date {:$gte from-date :$lt as-of-date}}))

(defn known-truth-files
  "Returns the md5s of file-type for which truth data exists with an effective
  start date in the time window [as-of-date - window-days, as-of-date)"
  [file-type as-of-date opts]
  (let [source (ml/file-type->source file-type)]
    (->> (assoc (by-date-query as-of-date opts) :source source)
         (mc/distinct (ml/training-db) ml/training-coll :md5)
         set)))

(defn count-soda-files
  "Returns the number of SODA files of file-type with an effective start date in
  the time window [as-of-date - window-days, as-of-date)"
  [file-type as-of-date opts]
  (->> (assoc (by-date-query as-of-date opts) :file-type file-type)
       (mc/distinct (ds/get-db "soda-raw") "files-meta" :md5)
       count))

(defn sample-size
  "Returns the sample size of files to be randomly selected from SODA files"
  [file-type as-of-date truth-file-count opts]
  (let [{:keys [max-files file-percent]} opts
        soda-file-count (count-soda-files file-type as-of-date opts)]
    (-> (* soda-file-count file-percent)
        (min max-files)
        (- truth-file-count)
        int)))

(defn random-files
  "Retrieves n random files-meta entries matching query"
  [n query]
  (mc/aggregate
    (ds/get-db "soda-raw") "files-meta"
    [{:$match query}
     {:$sample {:size n}}
     {:$project {:_id 0, :md5 1, :file-type 1}}]
    :cursor 20))

(defn submit-question-batch!
  "Submits a batch of questions to Surveyor for files, a collection of maps
  containing at least :md5. Returns the newly created question-ids."
  [files]
  (let [{:keys [file-type]} (first files)]
    (->> {:form-params
          {:fields (keys (questions/file-type->fields (keyword file-type)))
           :documents files
           :tags [file-type :model-training]
           :number-of-answers 1}
          :content-type :json
          :as :json}
         (http/post (str si/base-url "api/question-definition/create-and-enqueue/class-trainer-batch"))
         :body
         (map :question-id))))

(defn bulk-ask-questions!
  "Enqueues a batch of questions in Surveyor for file-type.

  The exact files to be enqueued are determined using as-of-date as the end of
  the rolling time window, and the ask-options for file-type."
  [file-type as-of-date]
  (let [opts (ask-options file-type)
        known-md5s (known-truth-files file-type as-of-date opts)
        n (sample-size file-type as-of-date (count known-md5s) opts)
        query (assoc (by-date-query as-of-date opts), :file-type file-type, :md5 {:$nin known-md5s})]
    (when (pos? n)
      (submit-question-batch! (random-files n query)))))
