(ns surveyor-interop.core
  (:require
    [clj-http.client :as http]
    [environ.core :refer [env]]))

(def base-url (or (:surveyor-address env) "http://soda-surveyor:8084/surveyor/"))

(def default-question
  {:question-type "class-link-trainer"
   :number-of-answers 1
   :notify-soda-pipeline? false})

(defn enqueue-question!
  [question]
  (:body
    (http/post
      (str base-url "api/question-definition/create-and-enqueue")
      {:content-type :json
       :as :json
       :form-params (merge default-question question)})))

(defn re-ask-question!
  [qid & [no-seed-fields]]
  (:body
    (http/post
      (str base-url "api/question/re-ask/question-id/" qid)
      {:content-type :json
       :as :json
       :form-params {:params no-seed-fields}})))

;{"params": {
;    "fields-to-remove":["field-a"],
;    "fields-to-add":["field-b"],
;    "fields-to-rename":{
;      "field-c":"field-d"
;    }
;   }
;}
(defn alter-question!
  [qid changes]
  (:body
    (http/post
      (str base-url "api/question-definition/alter/question-id/" qid)
      {:content-type :json
       :as :json
       :form-params {:params changes}})))

(defn seed-question!
  [qid answers]
  (:body
    (http/post
      (str base-url "api/answer/default/question-id/" qid)
      {:content-type :json
       :as :json
       :form-params answers})))
