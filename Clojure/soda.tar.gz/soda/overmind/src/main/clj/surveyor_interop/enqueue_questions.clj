(ns surveyor-interop.enqueue-questions
  (:require [clj-http.client :as client]
            [clojure.string :as s]
            [environ.core :refer [env]]
            [non-soda-sources.sources :as non-soda]
            [surveyor-interop.core :as si]
            [surveyor-interop.ml.core :as smlc]))

; TODO move to surveyor-interop.core ns
(def file-type->fields
  (merge
    non-soda/non-soda-file-type->fields

    {:edgar-corporate-action
     {:stock-ratio             {:field-type :percent}
      :cash-ratio              {:field-type :dollars}
      :corporate-action-type   {:field-type :string}
      :taxability-section-type {:field-type :string}
      :taxable-gain-not-loss   {:field-type :taxability}
      :non-taxable             {:field-type :taxability}
      :fully-taxable           {:field-type :taxability}
      :involved-entity         {:field-type :entity}}

     :canadian-analytics-data
     {:first-coupon-date                                {:field-type :date}
      :interest-rate                                    {:field-type :percent}
      :issue-date                                       {:field-type :date}
      :maturity-date                                    {:field-type :date}
      :pool-number                                      {:field-type :identifier}
      :principal-amount                                 {:field-type :dollars}
      :principal-balance-due-5-months-prior-to-maturity {:field-type :dollars}
      :principal-balance-due-4-months-prior-to-maturity {:field-type :dollars}
      :principal-balance-due-3-months-prior-to-maturity {:field-type :dollars}
      :principal-balance-due-2-months-prior-to-maturity {:field-type :dollars}
      :principal-balance-due-1-months-prior-to-maturity {:field-type :dollars}
      :weighted-interest-adjustment-date                {:field-type :date}
      :weighted-average-remaining-amortization          {:field-type :number}
      :weighted-average-coupon                          {:field-type :percent}}

     :edgar-prospectus
     {:accrual-start-date {:field-type :date}
      :call-option-date   {:field-type :date}
      :cusip              {:field-type :identifier}
      :face-value         {:field-type :dollars}
      :first-coupon-date  {:field-type :date}
      :interest-rate      {:field-type :percent}
      :isin               {:field-type :identifier}
      :issue-date         {:field-type :date}
      :issue-price        {:field-type :percent}
      :maturity-date      {:field-type :date}
      :principal-amount   {:field-type :dollars}}

     :fhlmc-offerings
     {:issuer-name                           {:field-type :string}
      :senior-reference-tranches-description {:field-type :string}
      :first-coupon-date                     {:field-type :string}
      :series                                {:field-type :string}
      :issue-date                            {:field-type :string}
      :tranche                               {:field-type :string}
      :junior-reference-tranches-description {:field-type :string}
      :original-balance                      {:field-type :money}
      :accrual-tranches-description          {:field-type :string}
      :underwriters                          {:field-type :string :multi-value? true}
      :principal-only-tranche-description    {:field-type :string}
      :day-count                             {:field-type :string}
      :maturity-date                         {:field-type :string}
      :coupon-rate                           {:field-type :noisy-float}
      :floating-rate-floor                   {:field-type :noisy-float}
      :floating-rate-cap                     {:field-type :noisy-float}
      :cusip                                 {:field-type :string}
      :floating-rate-formula                 {:field-type :string}
      :day-of-month-for-coupon-payment       {:field-type :string}
      :notional-principal-amount-description {:field-type :string}
      :coupon-rate-type                      {:field-type :string}
      :interest-only-tranches-description    {:field-type :string}
      :fhlmc-program-name                    {:field-type :string}}

     :muni-jaeger
     {:accrual-start-date     {:field-type :date}
      :alias                  {:field-type :string}
      :call-option-date       {:field-type :date}
      :cusip                  {:field-type :identifier}
      :cusip-3                {:field-type :identifier}
      :cusip-6                {:field-type :identifier}
      :day-count              {:field-type :string}
      :face-value             {:field-type :dollars}
      :first-coupon-date      {:field-type :date}
      :interest-rate          {:field-type :percent}
      :isin                   {:field-type :identifier}
      :issue-date             {:field-type :date}
      :issue-description      {:field-type :string}
      :issue-price            {:field-type :percent}
      :issue-principal-amount {:field-type :dollars}
      :issue-yield            {:field-type :percent}
      :maturity-date          {:field-type :date}
      :principal-amount       {:field-type :dollars}}}))

(defn source-fields []
  (map (fn [[file-type fields]]
         {:source    (smlc/file-type->source file-type)
          :file-type file-type
          :fields    fields})
       file-type->fields))

(def field->display-name (comp (partial s/join " ") (partial map s/capitalize) #(s/split % #"-") name))
(def display-name->field (comp keyword s/lower-case #(s/replace % #"\s+" "-")))


(defmulti default-question
          "Returns the default question for a file, dispatching off of file-type"
          (fn [{:keys [file-type]} & _] (keyword file-type)))


(defmethod default-question :default [file-meta & [{:keys [tags]}]]
  {:params                {:fields (->> file-meta :file-type
                                        keyword
                                        file-type->fields
                                        keys)}
   :question-type         "class-link-trainer"
   :document              (select-keys file-meta [:md5 :file-type :filename])
   :notify-soda-pipeline? true
   :number-of-answers     1
   :tags                  (conj (or tags [])
                                (->> file-meta :file-type name))})


(defn ask-question [file-meta & [{:keys [question tags]}]]
  (when (or question (-> file-meta :file-type keyword file-type->fields))
    (client/post (str si/base-url "api/question-definition/create-and-enqueue")
                 {:form-params  (or question (default-question file-meta {:tags tags}))
                  :content-type :json})))
