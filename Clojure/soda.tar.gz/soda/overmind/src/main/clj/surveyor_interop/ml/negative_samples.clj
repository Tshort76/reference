(ns surveyor-interop.ml.negative-samples
  "Functions to generate negative truth samples for Surveyor results"
  (:require
    [clj-http.client :as http]
    [datascript.core :as d]
    [doc-transforms.core :as dtc]
    [environ.core :refer [env]]
    [jaegers.utils :as ju]
    [ml.predictions :as pred]
    [ml.tokenizers :as tok]
    [jaegers.features.context :as context]
    [jaegers.features.enfeature :as enfeature]
    [plumbing.core :refer [?>>]]
    [surveyor-interop.core :as si]
    [surveyor-interop.ml.core :as siml]
    [surveyor-interop.ml.process-results :refer [merge-answers merge-results]]
    [taoensso.timbre :as log])
  (:import [java.io FileNotFoundException]))

(defn id->component-id [db id]
  (some->>
    (ju/id->vec id)
    (d/datoms db :avet :token-id)
    first
    :e
    (d/pull db [:component-id])
    :component-id
    context/idvec->id))

(defn- seed-result!
  [result & [{:keys [use-all-components?] :or {use-all-components? false}}]]
  (let [{:keys [question-definition answer]} result
        {:keys [question-id document]} question-definition]
    (if-let [db (enfeature/query->db (select-keys document [:md5]))]
      (let [value-ids (set (mapcat :ids answer))
            value-comp-ids (set (map (partial id->component-id db) value-ids))
            neg-answer (->> (context/enhik-db->components db (siml/file-type->source (:file-type document)))
                            (?>> (not use-all-components?) pred/run-retrieval-prediction)
                            pred/run-extraction-prediction
                            ; filter out known truth values
                            (remove (comp (partial some value-ids) flatten :ids))
                            ; remove predictions in components without truth values
                            (?>> (not use-all-components?)
                                 (filter (comp value-comp-ids (partial id->component-id db) ffirst :ids)))
                            (map (fn [{:keys [string ids]}]
                                   {:text string, :ids (flatten ids), :class "other", :groups []})))
            new-answer (:answer (merge-answers [{:answer neg-answer} {:answer answer}]))]
        (when (seq new-answer)
          (si/re-ask-question! question-id)
          (si/alter-question! question-id {"fields-to-add" ["other"]})
          (si/seed-question! question-id new-answer)))
      (throw (FileNotFoundException. (str (select-keys document [:md5])))))))

(defn seed-question-with-negative-samples!
  "Generates negative training samples for the given Surveyor question, re-asks
  the question, and seeds it with the negatives samples. Only works for
  questions that have results."
  [qid & [opts]]
  (log/info "Seeding negative samples for question-id " qid)
  (let [result (:body (http/get (str si/base-url "api/results/question-id/" qid) {:as :json}))]
    (seed-result! result opts)))

(defn seed-questions-with-negative-samples!
  "Generates negative training samples for Surveyor questions matching tags,
  re-asks each question and seeds them with negative samples. Only works for
  questions that have results."
  [tags & [opts]]
  (->> {:as :json, :query-params {"tags" (distinct (cons "model-training" (map name tags)))}}
       (http/get (str si/base-url "api/results"))
       :body
       merge-results
       (pmap #(seed-result! % opts))
       dorun))
