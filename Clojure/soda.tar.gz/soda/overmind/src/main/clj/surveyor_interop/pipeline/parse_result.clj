(ns surveyor-interop.pipeline.parse-result
  (:require [soda.data.file-system :as sdfs]
            [monger.collection :as mc]
            [datasources.core :as ds]
            [soda.jobs.utils :as jutils]
            [soda.jobs.job-defs :as jdefs]
            [clojure.string :as s]
            [surveyor-interop.enqueue-questions :as eq]))

(defn clean-str [st]
  (some-> st (s/replace #"[.,'\"\(\)%]" "") s/trim))


(defn merge-vals [{:keys [multi-value?]} values]
  (if multi-value?
    (distinct (keep :text values))
    (->> values (map (comp clean-str :text)) (#(when (apply = %) (-> values first :text))))))

;TODO this will need to be more intelligent in the future
; maybe take the most frequent value (require some min number to agree)
; will have to handle stuff like   October 1 vs 10/1 .... maybe?
(defn extract-vals
  "Attempts to intelligently group {:keys [text class]} docs by class"
  [spec answers]
  (->> answers
       (group-by (comp :class))
       (map (fn [[class vals]]
              (let [field (eq/display-name->field class)]
                [field (merge-vals (get spec field) vals)])))
       (filter second)
       (into {})))


(defn reformat-surveyor [parse-spec {:keys [answer]}]
  (->> answer
       (mapcat (fn [{:keys [groups] :as doc}]
                 (if (seq groups)
                   (map #(assoc doc :group %) groups)
                   [(assoc doc :group 0)])))
       (group-by :group)
       (map (comp (partial extract-vals parse-spec) second))))


(defn surveyor-doc->raw-data [{{:keys [file-type] :as file-meta}        :file-meta
                               {:keys [_id] :as surveyor-doc} :surveyor-doc}]

  (map #(assoc % :meta (-> file-meta
                           (dissoc :byte-size :content-type :file-path
                                   :mime-type :uploader :input-stream :file :length)
                           (assoc :database "soda_surveyor" :collection "results"
                                  :_id _id :data-type file-type :source-type :judy)))
       (reformat-surveyor (eq/file-type->fields (keyword file-type)) surveyor-doc)))

(def parse-surveyor-answer
  {:load-fn    (fn [{{:keys [md5 question-id]} :job-def}]
                 {:file-meta    (sdfs/find-one-meta {:md5 md5})
                  :surveyor-doc (mc/find-map-by-id (ds/get-db "soda_surveyor") "results" question-id)})
   :process-fn surveyor-doc->raw-data
   :store-fn   (fn [docs] (-> (ds/bulk-write (ds/get-db "soda-raw") "data" docs) jutils/consec-ids->summary (assoc :db "soda-raw" :coll "data")))
   :enqueue-fn (fn [{:keys [bid priority]} ids-seq]
                 (jutils/enqueue-job (merge (jdefs/normalize (select-keys ids-seq [:min-id :max-id]))
                                            {:bid bid :priority priority})))})
