(ns surveyor-interop.ml.process-results
  "Functions to convert Surveyor results into training data"
  (:require
    [clj-http.client :as http]
    [clj-time.coerce :as tmc]
    [clj-time.core :as tm]
    [clojure.set :as set]
    [datasources.core :as ds]
    [doc-transforms.core :as dtc]
    [environ.core :refer [env]]
    [jaegers.edgar.primer :as primer]
    [jaegers.features.context :as context]
    [jaegers.features.enfeature :as enfeature]
    [ml.tokenizers :as tok]
    [monger.collection :as mc]
    [monger.result :as mr]
    [soda.data.file-system :as sdfs]
    [surveyor-interop.core :as si]
    [surveyor-interop.enqueue-questions :as questions]
    [surveyor-interop.ml.core :as ml]
    [taoensso.timbre :as log]))

(defn surveyor-result->truth-data
  "Converts a Surveyor result into truth data for machine learning models"
  [result]
  (let [{:keys [_id all-question-ids question-definition answer last-updated]} result
        {:keys [tags] {:keys [md5 file-type]} :document} question-definition
        {:keys [effective-start-date] :as file-meta} (sdfs/find-one-meta {:md5 md5})
        db (enfeature/query->db file-meta)]
    (when db
      (for [{:keys [ids text class groups]} answer
            :let [file-type (keyword file-type)
                  class (keyword class)
                  value-type (get-in questions/file-type->fields [file-type class :field-type])]
            :when (or value-type (#{:other} class))
            :let [m (context/add-context
                      db
                      {:md5 md5
                       :effective-start-date (or effective-start-date (tmc/to-date (tm/today-at 0 0)))
                       :source (ml/file-type->source file-type)
                       :ids ids
                       :tags tags
                       :question-id _id
                       :question-ids all-question-ids
                       :question-last-updated last-updated
                       :string text
                       :class class
                       :groups groups
                       :features {:value-type (or value-type :other)}})]
            :when m]
        m))))

(defn test-set?
  "Returns truthy if the result identified by question-id already is, or should be, part of the test set.

  :p - probability [0.0, 1.0] that result should be part of the test set if it isn't already (default 0.1)"
  [question-ids & [{:keys [p] :or {p 0.1}}]]
  (let [{:keys [tags] :as result} (mc/find-one-as-map (ml/training-db) ml/training-coll {:question-ids {"$in" question-ids}})]
    (if result
      (some (comp #{:test-set} keyword) tags)
      (<= (rand) p))))

(defn merge-answers
  "Merges Surveyor answers in results. Assumes results are ordered as for clojure.core/merge."
  [results]
  (let [question-ids (distinct (map :_id results))]
    (->>                                                    ; turn answer data into map indexed by ids
      (for [res results]
        (update res :answer #(reduce (fn [m ans] (assoc m (:ids ans) ans)) {} %)))
      ; merge answers from oldest to newest
      (reduce (fn [m x] (assoc (merge m x) :answer (merge (:answer m) (:answer x)))) {})
      ; turn merged answer data back into original format
      (#(update % :answer (comp vec vals)))
      (#(assoc % :all-question-ids question-ids)))))

(defn merge-results
  "Merges Surveyor results such that a single result is returned for each document"
  [results]
  (->> results
       (sort-by :last-updated)
       (group-by (comp :document :question-definition))
       vals
       (map merge-answers)))

(defn process-result!
  "Converts a Surveyor result into training data. Existing training data for
  the same question will be overwritten."
  [result]
  (let [{:keys [all-question-ids _id]} result
        all-question-ids (keep identity (if-not all-question-ids [_id] (into [] all-question-ids)))
        truth-data (cond->> (surveyor-result->truth-data result)
                            (test-set? all-question-ids) (map #(update % :tags conj :test-set)))]
    (if (seq truth-data)
      (do (when (seq all-question-ids)
            (let [n (.getN (mc/remove (ml/training-db) ml/training-coll {:question-id {:$in all-question-ids}}))]
              (log/debug (format "Removed %s existing truth data records for question-ids %s" n (str all-question-ids)))))
          (mc/insert-batch (ml/training-db) ml/training-coll truth-data)
          (log/debug (format "Inserted %s truth data records for question-id %s" (count truth-data) all-question-ids)))
      (log/info "No truth data generated for question-id" all-question-ids))))

(defn process-results!
  "Converts Surveyor results into training data.

  tags - list of tags that must all exist in question definition (in addition to :model-training)
  pred - predicate to filter Surveyor results on arbitrary conditions"
  [tags pred]
  (let [url (str si/base-url "api/results")
        params {:question-type "class-link-trainer", :tags (map name (conj tags :model-training))}
        results (:body (http/get url {:as :json, :query-params params}))]
    (doseq [result (merge-results results)
            :when (pred result)]
      (log/debug "Processing result for md5" (get-in result [:question-definition :document :md5]))
      (process-result! result))))

(defn new? [result]
  (let [{:keys [_id last-updated]} result
        {:keys [question-last-updated]} (mc/find-one-as-map (ml/training-db) ml/training-coll {:question-id _id})]
    (or (not question-last-updated)
        (tm/after? (tmc/from-string last-updated) (tmc/from-string question-last-updated)))))

(defn process-new-results!
  "Converts new or updated Surveyor results into training data"
  []
  (process-results! [] new?))
