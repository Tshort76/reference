(ns feature-lib.maturity-schedule
  (:require [clojure.spec.alpha :as s]
            [feature-lib.string :as fs]
            [feature-lib.core :refer [colspec]]))

;;Maturity schedule definitions
;;required
(s/def :maturity-schedule/cusip9s (colspec :header/cusip ::fs/cusip9))
(s/def :maturity-schedule/cusip6s (colspec :header/cusip ::fs/cusip6))
(s/def :maturity-schedule/cusip3s (colspec :header/cusip ::fs/cusip3))
;(s/def :maturity-schedule/cusips
;  (s/or :cusip9s :maturity-schedule/cusip9s :cusip6s :maturity-schedule/cusip6s :cusip3s :maturity-schedule/cusip3s))

;;required
(s/def :maturity-schedule/maturity-day (colspec ::fs/nontemporal ::fs/month-day))
(s/def :maturity-schedule/maturity-date (colspec ::fs/nontemporal ::fs/date))
(s/def :maturity-schedule/maturity-year (colspec ::fs/nontemporal ::fs/year))
(s/def :maturity-schedule/maturity-month-year (colspec ::fs/nontemporal ::fs/month-year))
(s/def :maturity-schedule/principal-amount (colspec :header/principal-amount ::fs/currency))
;;Varying
(s/def :maturity-schedule/interest-rate (colspec :header/interest-rate ::fs/percent))
;;Usually high - complements yield
(s/def :maturity-schedule/price (colspec :header/price ::fs/percent))
;;Usually low - complements price
(s/def :maturity-schedule/yield (colspec :header/yield ::fs/percent))
(s/def :maturity-schedule/interest-type (colspec :header/interest-type ::fs/interest-type))
(s/def :maturity-schedule/principal-type (colspec :header/principal-type ::fs/principal-type))
;(s/def ::fs/maturity-schedule/maturity-type ::fs/tbd)

; (def fields
;   #{:maturity-schedule/cusip9s
;     :maturity-schedule/cusip6s
;     :maturity-schedule/cusip3s
;     :maturity-schedule/maturity-day
;     :maturity-schedule/maturity-date
;     :maturity-schedule/maturity-month-year
;     :maturity-schedule/maturity-year
;     :maturity-schedule/principal-amount
;     :maturity-schedule/principal-type
;     :maturity-schedule/interest-rate
;     :maturity-schedule/interest-type
;     :maturity-schedule/price
;     :maturity-schedule/yield})
