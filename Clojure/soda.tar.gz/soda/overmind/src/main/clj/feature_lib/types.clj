(ns feature-lib.types)

;;Hierarchy of types
(derive ::double ::numeric)
(derive ::percent ::double)
(derive ::currency ::double)

(derive ::long ::numeric)
(derive ::year ::long)

(derive ::cusip-part ::string)
(derive ::cusip6 ::cusip-part)
(derive ::cusip3 ::cusip-part)
(derive ::cusip2 ::cusip3)
(derive ::cusip-checksum ::cusip3)
