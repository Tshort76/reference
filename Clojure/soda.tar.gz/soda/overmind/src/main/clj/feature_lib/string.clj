(ns feature-lib.string
  (:require [soda-common.regexes :as r]
            [clojure.spec.alpha :as s]
            [clojure.string :as cs]
            [clj-fuzzy.metrics :as fzy]
            [feature-lib.core :refer [or-spec]])) ;colspec]]))
            ; [clojure.spec.gen.alpha :as gen]))

;strawmen
(defn yield? [s]
  (let [n (-> s cs/upper-case (cs/replace #"\W" ""))]
    (or (cs/includes? n "YIELD")
        (>= (fzy/jaro-winkler n "YIELD") 0.85))))

(defn principal-amount? [s]
  (let [n (-> s cs/upper-case (cs/replace #"\W" ""))]
    (or (cs/includes? n "AMOUNT")
        (cs/includes? n "BALANCE"))))

(defn interest-rate? [s]
  (let [n (-> s cs/upper-case (cs/replace #"\W" ""))]
    (cs/includes? n "RATE")))

(defn interest-type? [s]
  (let [n (-> s cs/upper-case (cs/replace #"\W" ""))]
    (and (cs/includes? n "INTEREST") (cs/includes? n "TYPE"))))

(defn principal-type? [s]
  (let [n (-> s cs/upper-case (cs/replace #"\W" ""))]
    (and (cs/includes? n "PRINCIPAL") (cs/includes? n "TYPE"))))

(defn price? [s]
  (let [n (-> s cs/upper-case (cs/replace #"\W" ""))]
    (cs/includes? n "PRICE")))

(defn cusip? [s]
  (let [n (-> s cs/upper-case (cs/replace #"\W" ""))]
    (cs/includes? n "CUSIP")))

;;Column headers
(s/def :header/cusip cusip?)
(s/def :header/yield yield?)
(s/def :header/principal-amount principal-amount?)
(s/def :header/interest-rate interest-rate?)
(s/def :header/interest-type interest-type?)
(s/def :header/principal-type principal-type?)
(s/def :header/price price?)

;;Primitives
(s/def ::double (partial re-matches r/double-like))
(s/def ::long (partial re-matches r/long-like))
(s/def ::percent (partial re-matches r/percent-like))
(s/def ::currency (partial re-matches r/money-like))
(s/def ::cusip3 (partial re-matches r/cusip-3-like))
(s/def ::cusip6 (partial re-matches r/cusip-6-like))
(s/def ::cusip9 (partial re-matches r/cusip-9-like))

;;Various time combos
(s/def ::month (partial re-matches r/any-month))
(s/def ::month-day (partial re-matches r/month-day))
(s/def ::month-year (partial re-matches r/month-year))
(s/def ::year (partial re-matches r/four-digit-year))
(s/def ::date (partial re-matches r/date))
(s/def ::temporal (s/or :month ::month
                        :month-year ::month-year
                        :date ::date
                        :year ::year))
(s/def ::nontemporal #(#{:clojure.spec.alpha/invalid} (s/conform ::temporal %)))

(s/def ::interest-type #{"INV" "INV/IO" "FLT" "FIX" "FIX/IO" "FIX/Z" "PO" "T/IO" "NPR"})
(s/def ::principal-type #{"SEQ" "SEQ/AD" "NTL" "PT" "SUP" "PAC I" "PAC II"})
(s/def ::remic-class #{"PC" "CH" "CK" "CG" "PB" "CD" "CS" "CF" "CT" "CM" "CE" "CY" "CU" "CA" "PA" "CB" "CJ" "CL"})

(s/def ::string-column (s/every string? :kind vector?))
(s/def ::string-table (s/every ::string-column :kind vector?))
;(s/def ::string-table (s/and (s/every ::string-column :kind vector?) #(apply == (map count %))))
;(gen/sample (s/gen ::string-table))

;;Predicates for columnar data
;TODO - Add partial matches as a 3rd alt
(s/def ::double-column (s/+ ::double))
(s/def ::interest-type-column (s/+ ::interest-type))
(s/def ::principal-type-column (s/+ ::principal-type))
(s/def ::currency-column (or-spec ::currency))
(s/def ::percent-column (or-spec ::percent))
(s/def ::temporal-column (or-spec ::temporal))
(s/def ::remic-class-column (or-spec ::remic-class))
(s/def ::cusip-3-column (or-spec ::cusip3))
(s/def ::cusip-6-column (or-spec ::cusip6))
(s/def ::cusip-9-column (or-spec ::cusip9))
(s/def ::interest-type-column (or-spec ::interest-type))
(s/def ::principal-type-column (or-spec ::principal-type))

;;This one doesn't give the expected every/mostly result. Gotta think about it.
(s/def ::cusip-ids-column
  (s/or :cusip3s ::cusip-3-column :cusip6s ::cusip-6-column :cusip9s ::cusip-9-column))

;;;Maturity schedule definitions
;;;required
;(s/def :maturity-schedule/cusip9s (colspec :header/cusip ::cusip9))
;(s/def :maturity-schedule/cusip6s (colspec :header/cusip ::cusip6))
;(s/def :maturity-schedule/cusip3s (colspec :header/cusip ::cusip3))
;;(s/def :maturity-schedule/cusips
;;  (s/or :cusip9s :maturity-schedule/cusip9s :cusip6s :maturity-schedule/cusip6s :cusip3s :maturity-schedule/cusip3s))
;
;;;required
;(s/def :maturity-schedule/maturity-day (colspec ::nontemporal ::month-day))
;(s/def :maturity-schedule/maturity-date (colspec ::nontemporal ::date))
;(s/def :maturity-schedule/maturity-year (colspec ::nontemporal ::year))
;(s/def :maturity-schedule/principal-amount (colspec :header/principal-amount ::currency))
;;;Varying
;(s/def :maturity-schedule/interest-rate (colspec :header/interest-rate ::percent))
;;;Usually high - complements yield
;(s/def :maturity-schedule/price (colspec :header/price ::percent))
;;;Usually low - complements price
;(s/def :maturity-schedule/yield (colspec :header/yield ::percent))
;(s/def :maturity-schedule/interest-type (colspec :header/interest-type ::interest-type))
;(s/def :maturity-schedule/principal-type (colspec :header/principal-type ::principal-type))
;;(s/def ::maturity-schedule/maturity-type ::tbd)

(def specs (filter #(-> % namespace keyword #{:feature-lib.string}) (keys (s/registry))))

(defn +features [word]
  (let [x (some #(when (s/valid? % word) %) specs)]
    (conj (ancestors x) x)))

(defn ->feature-table [data]
  (clojure.walk/postwalk #(if (string? %) {:text % :features (+features %)} %) data))
