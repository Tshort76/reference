(ns feature-lib.core
  (:require [clojure.spec.alpha :as s]))

(defmacro mostly [spec]
  `(s/and
     (s/+ (s/or :match ~spec :no-match string?))
     #(let [{:keys [~'no-match ~'match]} (group-by first %)]
       (> (count ~'match) (count ~'no-match)))))

(defmacro or-spec [spec] `(s/or :every (s/+ ~spec) :mostly (mostly ~spec)))
; (defmacro alt-spec [spec] `(s/alt :every (s/+ ~spec) :mostly (mostly ~spec)))

(defmacro colspec [headerspec spec]
  `(s/or :definite (s/cat :header ~headerspec :values (s/+ ~spec))
         :mostly-definite (s/cat :header ~headerspec :values (mostly ~spec))
         :every (s/+ ~spec)
         :mostly (mostly ~spec)))
