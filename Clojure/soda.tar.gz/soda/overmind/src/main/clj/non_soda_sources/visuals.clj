(ns non-soda-sources.visuals
  (:require [clojure.data.json :as json]
            [mind-food.core :as mfc]
            [cheshire.core :as c]
            [clj-http.client :as http]
            [clojure.spec.alpha :as s]
            [environ.core :refer [env]]
            [taoensso.timbre :as timbre])
  (:import (java.io File)))


;ToDo consolidate color stuffs to one ns
(def colors
  ["#e6194B" "#3cb44b" "#ffe119" "#4363d8" "#f58231" "#911eb4" "#42d4f4" "#f032e6" "#bfef45" "#fabebe"
   "#469990" "#e6beff" "#9A6324" "#fffac8" "#800000" "#aaffc3" "#808000" "#ffd8b1" "#000075" "#a9a9a9"])


(defn hash-color [x]
  (-> (hash x)
      (mod (count colors))
      (#(get colors %))))


;todo this will probably have to change again with the extraction changes
;todo merge this with extract data?
(defn highlighted-url [extracted request]
  (->> extracted
       :raw-output
       (mapcat #(map (fn [m] (select-keys m [:ids :class :value])) %))
       (mapcat (fn [{:keys [ids class value]}]
                 (map (fn [id] {:i [id]
                                :c (hash-color class)
                                :t (str (name class) " = \"" value "\"")}) (flatten ids))))
       (assoc (dissoc request :file-type) :highlights)
       json/write-str
       (hash-map :headers {"Content-type" "application/json"} :body)
       (http/post (str surveyor-interop.core/base-url "api/view/cache"))
       :body
       json/read-str
       (#(get % "view-id"))
       ;todo change this line when we have surveyor-address
       (str (or (:surveyor-address env) "http://dev-soda-intake-group1-app1:8084/surveyor/") "answer-question#/custom-highlight?id=")
       ))


(defn coordinate? [x]
  (and (number? x) (>= x 0)))

(s/def ::page-number number?)
(s/def ::x0 coordinate?)
(s/def ::x1 coordinate?)
(s/def ::y0 coordinate?)
(s/def ::y1 coordinate?)

(s/def ::boundaries
  (s/coll-of (s/and (s/keys :req-un [::x0 ::x1 ::y0 ::y1 ::page-number])
                    (fn [{:keys [x0 x1 y0 y1]}]
                      (and (< y0 y1) (< x0 x1))))))

(defn parse-json-boundaries [json-str]
  (let [bounds (c/parse-string json-str keyword)]
    (if (s/valid? ::boundaries bounds)
      bounds
      (timbre/debug "Issue when parsing boundaries from json: " (s/explain ::boundaries bounds)))))

;Used for api endpoint
(defn annotated-doc [is bounds]
  (let [tempfile (doto (File/createTempFile "soda_" ".tmp") (.deleteOnExit))]
    (mfc/annotate {:input-stream is
                   :output-file  tempfile} bounds)
    tempfile))