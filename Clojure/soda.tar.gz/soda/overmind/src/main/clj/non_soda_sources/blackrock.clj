(ns non-soda-sources.blackrock
  (:require [non-soda-sources.utils :as nssu]
            [clojure.string :as cs]))

(def std-blackrock-bounds-anchors
  {:anchors-extractor (fn [predictions]
                        (->> (nssu/refined-instances predictions #{:counterparty-code}
                                                     {:bounding-box  {:x0 45 :x1 390 :y0 145 :y1 740}
                                                      :num-per-class 10 :file-type :blackrock-trade-ticket})
                             (sort-by :min-y)
                             (take 2)))
   :linking-bound-box {:x0 45 :x1 390 :y0 145 :y1 740}})


(def link-meta-by-trade-type
  {"SWAP/SWAP"      (assoc std-blackrock-bounds-anchors
                      :linkable-class-set #{:coupon
                                            :business-day-convention
                                            :index-definition
                                            :lookback
                                            :accrual-date
                                            :daycount-basis
                                            :business-days
                                            :first-swap-payment-date
                                            :first-reset-date
                                            :reset-frequency
                                            :accrual-date-adjusted
                                            :initial-coupon})

   "SWAP/TRSWAP"    (assoc std-blackrock-bounds-anchors
                      :linkable-class-set #{:payment-frequency
                                            :initial-index-level
                                            :coupon
                                            :unadjusted-first-reset-date
                                            :business-day-convention
                                            :index-definition
                                            :coupon-frequency
                                            :lookback
                                            :accrual-date
                                            :first-payment-date
                                            :first-period-end
                                            :daycount-basis
                                            :intial-coupon
                                            :unit-type
                                            :notional-amount
                                            :business-days
                                            :reset-delay
                                            :payment-delay
                                            :underlying-asset-definition
                                            :first-reset-date
                                            :number-of-units
                                            :reset-frequency
                                            :accrual-date-adjusted})

   "SYNTH/SWAPTION" (assoc std-blackrock-bounds-anchors
                      :linkable-class-set #{:accrual-date
                                            :accrual-date-adjusted
                                            :business-day-convention
                                            :business-days
                                            :coupon
                                            :coupon-frequency
                                            :daycount-basis
                                            :first-payment-date
                                            :first-period-end
                                            :first-reset-date
                                            :index-definition
                                            :initial-index-level
                                            :intial-coupon
                                            :lookback
                                            :notional-amount
                                            :number-of-units
                                            :payment-delay
                                            :payment-frequency
                                            :reset-delay
                                            :reset-frequency
                                            :unadjusted-first-reset-date
                                            :underlying-asset-definition
                                            :unit-type})

   "SYNTH/CAP"      (assoc std-blackrock-bounds-anchors
                      :linkable-class-set #{:accrual-date
                                            :accrual-date-adjusted
                                            :business-day-convention
                                            :business-days
                                            :cap-price
                                            :coupon
                                            :coupon-frequency
                                            :daycount-basis
                                            :first-payment-date
                                            :first-period-end
                                            :first-reset-date
                                            :index-definition
                                            :initial-index-level
                                            :intial-coupon
                                            :lookback
                                            :notional-amount
                                            :number-of-units
                                            :payment-delay
                                            :payment-frequency
                                            :premium-due
                                            :reset-delay
                                            :reset-frequency
                                            :strike
                                            :unadjusted-first-reset-date
                                            :underlying-asset-definition
                                            :unit-type})

   "SWAP/CDSWAP" (assoc std-blackrock-bounds-anchors
                   :linkable-class-set #{:coupon})})

(def white-list [:account-code :settle-date :swap-id :termination-date :trade-date :trade-number :trade-sub-type :trade-type :asset-id :version])
(defmulti white-list-fields :trade-type)
(defmethod white-list-fields :default [cleaned-output] cleaned-output)
(defmethod white-list-fields "CASH/COLLATERAL"
  [cleaned-output]
  (select-keys cleaned-output white-list))

(def subsections #{"General Use" "Bank Use" "Delivery Instructions" "Related Trades Information" "RelatedTrades Information" "Rollover Information" "Miscellaneous Information"})

(defn join-tokens [token-a {:keys [min-x max-x min-y max-y string value id ids] :as tok}]
  (let [delimiter (if ids "\n" " ")]
    (-> token-a
        (update :min-x #(min min-x %))
        (update :max-x #(max max-x %))
        (update :min-y #(min min-y %))
        (update :max-y #(max max-y %))
        (update :string #(if (empty? %) string (str % delimiter string)))
        (update :value #(if (empty? %) string (str % delimiter string)))
        ((if id #(update-in % [:ids 0] conj id) identity))
        ((if ids #(-> (update % :ids concat ids) (update :ids vec)) identity)))))

(defn context->line [enhanced-hickory]
  (->> enhanced-hickory
       (map (fn [{:keys [attrs content] :as token}]
              (-> (merge attrs token)
                  (dissoc :attrs)
                  (assoc :string (cs/join " " content) :value (cs/join " " content)))))
       (reduce join-tokens {:min-x 1000 :max-x 0 :min-y 1000 :max-y 0 :ids [[]] :value "" :string ""}) ))

(defn clean-n-keyword [string]
  (-> string (cs/replace #"\W" "-") cs/lower-case keyword))

(defn enhanced-hickory->line [context]
  (->> context
       (group-by (comp :min-y :attrs))
       vals
       (map context->line)
       (sort-by :min-y)
       (partition-by (comp subsections :string))
       (partition 2)
       (map (fn [[[{:keys [value]}] things]]
              {(clean-n-keyword value) things}))
       (apply merge)))

(defn clean [raw-output {:keys [bank-use general-use delivery-instructions miscellaneous-information] :as subsection-map}]
  (let [used-ids (->> (for [item raw-output token item] (:ids token)) flatten set)
        update-fn (fn [list-of-lines]
                    (when list-of-lines
                      (->> (remove (comp #(some used-ids (flatten %)) :ids) list-of-lines)
                           (remove (comp #(re-find #"^(?:----|Term Sheet)" %) :value))
                           (reduce join-tokens {:min-x 1000 :max-x 0 :min-y 1000 :max-y 0 :ids [] :value "" :string ""} ))))]
    (cond-> subsection-map
            bank-use (update :bank-use update-fn)
            general-use (update :general-use update-fn)
            delivery-instructions (update :delivery-instructions update-fn)
            miscellaneous-information (update :miscellaneous-information update-fn)
            true (select-keys [:bank-use :general-use :delivery-instructions :miscellaneous-information]))))

(defn post-process [enhik raw-output]
  (->> enhik
       :enhanced-hickory
       :content first
       :content first
       :content
       (map :content)
       (keep enhanced-hickory->line)
       first
       (clean raw-output)
       (map (fn [[class token]] (assoc token :class class)))))