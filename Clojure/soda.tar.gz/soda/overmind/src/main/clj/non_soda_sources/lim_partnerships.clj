(ns non-soda-sources.lim-partnerships
  (:require [doc-transforms.core :as dtc]
            [clojure.string :as s]
            [clojure.set :as st]
            [non-soda-sources.utils :as nssu]))

(defn relative-to
  "Returns the position of second box relative to the first box.  Result is a set that contains
  those of the 4 directions are applicable to the relationship. The empty set means that the boxes overlap."
  [{:keys [x0 x1 y0 y1]} {sx0 :x0 sx1 :x1 sy0 :y0 sy1 :y1}]
  (cond-> #{}
          (< sy1 y0) (conj :above)
          (> sy0 y1) (conj :below)
          (< sx1 x0) (conj :left)
          (> sx0 x1) (conj :right)))

(defn boundaries-of [block]
  (reduce (fn [{:keys [x0 x1 y0 y1]}
               {xw :x ww :width yw :y hw :height page :page-number}]
            {:x0          (min x0 xw)
             :x1          (max x1 (+ xw ww))
             :y0          (min y0 (- yw hw))
             :y1          (max y1 yw)
             :page-number page})
          {:x0 1000 :x1 0 :y0 1000 :y1 0} block))


(defn extract-label [amount {:keys [tokens]}]
  (when-let [label-tokens (seq (filter (fn [{:keys [y height]}]
                                         (empty? (relative-to amount (assoc amount :y0 (- y height) :y1 y)))) tokens))]
    (assoc (boundaries-of label-tokens) :tokens label-tokens)))


(defn label-left [blocks {:keys [x0 page-number] :as amount}]
  (some->> blocks
           (filter (fn [{:keys [features] :as block}]
                     (and
                       (= page-number (:page-number block))
                       (= #{:left} (relative-to amount block)) ;block is left
                       (pos? (:num-english-words features))))) ;label like
           seq
           (apply min-key #(- x0 (:x1 %)))
           (extract-label amount)))


(defn format-description [{:keys [tokens] :as desc}]
  (when desc (->> tokens (map :text) (s/join " "))))


(def buckets
  [{:class "realized-gain",               :re #"(?i)Distribution for Realized Gains"}
   {:class "distribution"                 :re #"(?i)distribution|return of capital|Accrual Adjustment"} ;todo handle closeout vs return of capital
   {:class "contribution"                 :re #"(?i)contribution"}
   {:class "unrealized-gain"              :re #"(?i)unrealized"}
   {:class "realized-gain",               :re #"(?i)gain|appreciation.*realized|appreciation ?/ ?\(?depreciation\)?"}
   {:class "uncategorized-expense",       :re #"(?i)management fee.*and|(?:and|before).*management fee"}
   {:class "management-fee",              :re #"(?i)management fee"}
   {:class "unfunded-capital-commitment", :re #"(?i)remaining commitment"}
   {:class "total-capital-commitment",    :re #"(?i)Capital Commitment"}
   {:class "total",                       :re #"(?i)total|net|aggregate|gross|life[ \-]to[ \-]date"}
   {:class "beginning-balance",           :re #"(?i)(?:opening|beginning) (?:balance|price)|Balance -? ?(?:beginning of period|brought forward)"}
   {:class "ending-balance",              :re #"(?i)(?:closing|ending) (?:price|balance)|Balance ?- ?End of Period"}
   {:class "market-value",                :re #"(?i)market value"}
   {:class "contribution"                 :re #"(?i)additions"} ;'additions' not 'total additions'

   ;{:class "", :re #"(?i)"}
   ;{:class "close-out",                   :re #"(?i)"}
   ;{:class "funded-capital-commitment",   :re #"(?i)"}
   ;{:class "uncategorized-income",        :re #"(?i)"}

   {:class "other", :re #"(?i).*"}
   ])


(defn deduce-class [blocks {:keys [raw-description value meta]}]
  (some (fn [{:keys [class re]}] (when (and raw-description (re-find re raw-description)) class)) buckets))

(defn ids->page-number [ids]
  (-> ids flatten first (s/split #"_") first Integer/parseInt))

(defn add-annotate-fields [{:keys [min-x min-y max-x max-y page-number ids] :as amt}]
  (assoc amt :x0 min-x :x1 max-x
             :y0 min-y :y1 max-y
             :page-number (or page-number (ids->page-number ids))))


(defn parse-transactions [md5 predictions]
  (let [max-page (some->> predictions (map (comp ids->page-number :ids)) not-empty (apply max))
        blocks (:pdf-blocks (dtc/mongo->transform :pdf-blocks {:md5 md5} {:first-page 0 :last-page (or max-page 999)}))]
    (->> (nssu/n-most-probable-instances 999 :amount predictions :lp-general-partner-report)
         (map (comp
                #(assoc % :class (deduce-class blocks %))
                #(assoc % :raw-description (format-description (get-in % [:meta :raw-description])))
                #(assoc-in % [:meta :raw-description] (label-left blocks %))
                add-annotate-fields)))))

(def colors
  ["#e6194B" "#3cb44b" "#ffe119" "#4363d8" "#f58231" "#911eb4" "#42d4f4" "#f032e6" "#bfef45" "#fabebe"
   "#469990" "#e6beff" "#9A6324" "#fffac8" "#800000" "#aaffc3" "#808000" "#ffd8b1" "#000075" "#a9a9a9"])


(def important-keys [:value :category :raw-description :hex-color :id
                     :x0 :x1 :y0 :y1 :page-number])

;Add :meta and :ids to the list for annotating descriptions
;(def important-keys [:value :category :raw-description :hex-color :id
;                     :x0 :x1 :y0 :y1 :page-number :meta :ids])

(defn format-output [data-points]
  (map (comp #(select-keys % important-keys)
             add-annotate-fields
             #(st/rename-keys % {:class :category})
             (fn [idx datapoint]
               (assoc datapoint :id idx :hex-color (colors (mod idx (count colors))))))
       (range) data-points))