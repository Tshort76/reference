(ns non-soda-sources.sources)

(def non-soda-file-type->fields
  {:blackrock-trade-ticket
   {;; common
    :account-code                      {:field-type :entity}
    :trade-currency                    {:field-type :currency}
    :settle-date                       {:field-type :date}
    :swap-id                           {:field-type :identifier}
    :trade-date                        {:field-type :date}
    :trade-factor                      {:field-type :percent}
    :trade-number                      {:field-type :number}
    :trade-price                       {:field-type :percent}
    :trade-sub-type                    {:field-type :trade-type}
    :trade-type                        {:field-type :trade-type}
    :version                           {:field-type :number}
    :clearing-party                    {:field-type :entity}
    :clearing-party-code               {:field-type :identifier}
    :clearing-counter-party            {:field-type :entity}
    :broker                            {:field-type :entity}
    :broker-code                       {:field-type :identifier}

    ;; interest-rate swap
    :accrual-date                      {:field-type :date}
    :accrual-date-adjusted             {:field-type :boolean}
    :business-day-convention           {:field-type :calendar-convention}
    :commission                        {:field-type :dollars}
    :coupon                            {:field-type :noisy-percent} ;contains percents, and floating rates ("CUSIP:123456789 +10 bps")
    :daycount-basis                    {:field-type :day-count}
    :final-reset-date                  {:field-type :date}
    :first-swap-payment-date           {:field-type :date}
    :index-definition                  {:field-type :index}
    :initial-coupon                    {:field-type :percent}
    :lookback                          {:field-type :duration}
    :net-money                         {:field-type :percent}
    :original-par                      {:field-type :dollars}
    :reset-frequency                   {:field-type :frequency}
    :termination-date                  {:field-type :date}
    :trade-interest                    {:field-type :percent}
    :trade-principal                   {:field-type :dollars}
    :unrounded-trade-price             {:field-type :percent}

    ;; tr swap
    :business-days                     {:field-type :enum}
    :convexity                         {:field-type :percent}
    :current-par                       {:field-type :number}
    :duration                          {:field-type :percent}
    :exchange-rate                     {:field-type :number}
    :first-payment-date                {:field-type :date}
    :first-period-end                  {:field-type :date}
    :first-reset-date                  {:field-type :date}
    :income-currency                   {:field-type :currency}
    :income-payment-percent            {:field-type :percent}
    :income-payment-type               {:field-type :enum}
    :initial-index-level               {:field-type :number}
    :optional-early-termination        {:field-type :enum}
    :net-cash-flow                     {:field-type :enum}
    :notional-amount                   {:field-type :dollars}
    :number-of-units                   {:field-type :number}
    :payment-delay                     {:field-type :duration}
    :payment-frequency                 {:field-type :frequency}
    :price-currency                    {:field-type :currency}
    :reset-delay                       {:field-type :duration}
    :trade-factor-date                 {:field-type :date}
    :unadjusted-first-reset-date       {:field-type :date}
    ;:underlying-asset-definition {:field-type } ; free text?
    :unit-type                         {:field-type :enum}
    :unwind                            {:field-type :percent}

    ;; fx swap
    :amount-in                         {:field-type :dollars}
    :amount-out                        {:field-type :dollars}
    :asset-id                          {:field-type :identifier}
    :counterparty                      {:field-type :entity}
    :counterparty-code                 {:field-type :identifier}
    :currency-in                       {:field-type :currency}
    :currency-out                      {:field-type :currency}
    :exchange-rate-currencies          {:field-type :ratio}
    :net-proceeds-amount               {:field-type :dollars}
    :net-proceeds-currency             {:field-type :currency}
    :net-proceeds-flow                 {:field-type :enum}
    :outright-exchange-rate            {:field-type :number}
    :spot-exchange-rate                {:field-type :number}
    :ticker                            {:field-type :ticker}

    ;; bnd
    :144a                              {:field-type :boolean}
    :amt                               {:field-type :boolean}
    :coupon-frequency                  {:field-type :frequency}
    :coupon-rate-type                  {:field-type :enum}
    :discretionary                     {:field-type :boolean}
    :erisa                             {:field-type :boolean}
    :first-coupon-date                 {:field-type :date}
    :isin                              {:field-type :identifier}
    :issue-date                        {:field-type :date}
    :liquid                            {:field-type :boolean}
    :mandatory-put                     {:field-type :boolean}
    :maturity-date                     {:field-type :date}
    :min-trade-increment               {:field-type :dollars}
    :min-trade-size                    {:field-type :dollars}
    :next-payment-date                 {:field-type :date}
    :notional                          {:field-type :boolean}
    :odd-first-payment                 {:field-type :boolean}
    :prepay                            {:field-type :number}
    :ratings-dbrs                      {:field-type :rating}
    :ratings-fitch                     {:field-type :rating}
    :ratings-moody                     {:field-type :rating}
    :ratings-naic                      {:field-type :rating}
    :ratings-snp                       {:field-type :rating}
    :release                           {:field-type :boolean}
    :reset-term                        {:field-type :frequency}
    :sector                            {:field-type :enum}
    :security-code                     {:field-type :identifier}
    :segregate                         {:field-type :boolean}
    :sic-code                          {:field-type :identifier}
    :trade-unrounded-price             {:field-type :number}
    :yield                             {:field-type :number}

    ;; options
    :contract-size                     {:field-type :number}
    :contracts                         {:field-type :number}
    :delivery-date                     {:field-type :date}
    :delivery-method                   {:field-type :enum}
    :discount                          {:field-type :percent}
    :exercise-style                    {:field-type :enum}
    :expiration-date                   {:field-type :date}
    :expiry-date                       {:field-type :date}
    :expiry-time                       {:field-type :time}
    :last-settle-date                  {:field-type :date}
    :option-type                       {:field-type :enum}
    :other-fees                        {:field-type :dollars}
    :osi                               {:field-type :identifier}
    :pc-early-redemption               {:field-type :enum}
    :premium                           {:field-type :dollars}
    :risk-country                      {:field-type :entity}
    :sedol                             {:field-type :identifier}
    :settle-type                       {:field-type :enum}
    :share-class                       {:field-type :acronym}
    :shares                            {:field-type :number}
    :stock-exchange                    {:field-type :entity}
    :strike                            {:field-type :number}
    :tba-id                            {:field-type :identifier}
    :underlying-asset-definition       {:field-type :string}
    :underlying-id                     {:field-type :identifier}
    :usd-amount                        {:field-type :dollars}
    :ytc                               {:field-type :percent}
    :strike-currencies                 {:field-type :ratio}
    :deliverable-currency              {:field-type :currency}

    ;cdswap
    :cds-description                   {:field-type :entity},
    :escrow                            {:field-type :boolean},
    :failure-to-pay                    {:field-type :boolean},
    :reference-obligation-identifier   {:field-type :identifier},
    :obligation-default                {:field-type :boolean},
    :reference-obligation-red          {:field-type :identifier},
    :underlying-guarantor              {:field-type :entity},
    :dispute-resolution                {:field-type :boolean},
    :repudiation-moratorium            {:field-type :boolean},
    :notice-of-physical-settlement     {:field-type :boolean},
    :original-issue-amount             {:field-type :dollars},
    :payment-requirement               {:field-type :boolean},
    :lin                               {:field-type :identifier},
    :relevant-secured-list             {:field-type :string},
    :reference-entity                  {:field-type :entity},
    :reference-entity-red              {:field-type :identifier},
    :credit-event-notice               {:field-type :boolean},
    :restructuring-maturity-limitation {:field-type :boolean},
    :physical-settlement-period        {:field-type :duration},
    :primary-obligor                   {:field-type :entity},
    :designated-priority               {:field-type :enum},
    :exclude-accrued-interest          {:field-type :boolean},
    :restructuring                     {:field-type :boolean},
    :restructuring-supplement          {:field-type :boolean},
    :reference-price                   {:field-type :number},
    :default-requirement               {:field-type :dollars},
    :grace-period-extension            {:field-type :duration},
    :underlying-asset-type             {:field-type :enum},
    :obligation-acceleration           {:field-type :boolean},
    :bankruptcy                        {:field-type :boolean},
    :settlement-method                 {:field-type :enum}

    ;synth/swaptions
    :option-buyer                      {:field-type :identifier}
    :option-seller                     {:field-type :identifier}
    :premium-due-on                    {:field-type :date}
    :swaption-price                    {:field-type :enum}
    :underlying-swap-tenor             {:field-type :duration}
    :underlying-index                  {:field-type :enum}
    :underlying-reference-entity       {:field-type :string}
    :underlying-effective-date         {:field-type :date}
    :underlying-termination-date       {:field-type :date}
    :annex-date                        {:field-type :date}
    :scheduled-termination-date        {:field-type :date}
    :premium-price                     {:field-type :percent}
    :effective-date                    {:field-type :date}

    ;loan/terms
    :performing                        {:field-type :boolean},
    :total-fees                        {:field-type :dollars},
    :issuer-country                    {:field-type :entity},
    :economic-benefit                  {:field-type :dollars},
    :facility                          {:field-type :identifier},
    :classification-cs                 {:field-type :string},
    :facility-floor                    {:field-type :percent},
    :ratings-snp-long                  {:field-type :rating},
    :global-facility-amount            {:field-type :dollars},
    :agent-bank                        {:field-type :entity},
    :covenant-type                     {:field-type :string},
    :amount-issued                     {:field-type :dollars},
    :lien                              {:field-type :enum},
    :bloom-id                          {:field-type :identifier},
    :covenants-number                  {:field-type :number},
    :structure                         {:field-type :enum},
    :cost-of-carry                     {:field-type :dollars},
    :aladdin-name                      {:field-type :entity},
    :delayed-compensation              {:field-type :dollars},
    :ratings-moody-long                {:field-type :rating},
    :loanx-id                          {:field-type :identifier},
    :classification-moody              {:field-type :string},
    :classification-snp                {:field-type :string}
    :spread                            {:field-type :percent},
    :ticketing-fee                     {:field-type :dollars},

    ;CASH/BB
    :rollover-asset-id                 {:field-type :identifier},
    :loan-currency                     {:field-type :currency},
    :interest-at-maturity              {:field-type :dollars},
    :rollover-security-id              {:field-type :identifier},
    :loan-rate                         {:field-type :percent},
    :rollover-factor                   {:field-type :percent},
    :rollover-issue                    {:field-type :string},
    :rollover-hc                       {:field-type :string},
    :maturity-currency                 {:field-type :currency},
    :loan-cash-flow                    {:field-type :enum},
    :rollover-qty                      {:field-type :number},
    :rollover-interest-at-maturity     {:field-type :dollars},
    :loan-amount                       {:field-type :dollars},
    :rollover-current-par              {:field-type :dollars},
    :maturity-cash-flow-date           {:field-type :date},
    :rollover-price                    {:field-type :number},
    :rollover-loan-principal-amount    {:field-type :dollars},
    :maturity-cash-flow                {:field-type :enum},
    :loan-cash-flow-date               {:field-type :date},
    :rollover-net-proceeds-at-maturity {:field-type :dollars},

    ;Related Trades
    :related-trades-trade-number       {:field-type :number, :array-group :related-trade},
    :related-trades-relation           {:field-type :enum, :array-group :related-trade},
    :related-trades-amount             {:field-type :number, :array-group :related-trade},
    :related-trades-gl                 {:field-type :number, :array-group :related-trade}

    ;bnd/corp
    :classification-barclays           {:field-type :string}
    :classification-barclays-code      {:field-type :string}
    }


   :lp-general-partner-report
   {:client-name                       {:field-type :entity}
    :investment-id                     {:field-type :entity}
    :notice-date                       {:field-type :date}
    :post-date                         {:field-type :date}
    :capital-call-due-date             {:field-type :date}
    :period-length                     {:field-type :frequency}
    :period-begin-date                 {:field-type :date}
    :period-end-date                   {:field-type :date}
    :amount                            {:field-type :dollars}
    ;:description                       {:field-type :string}
    }}
  )

