(ns non-soda-sources.core
  (:require [ml.predictions :as predictions]
            [non-soda-sources.linking :as link]
            [non-soda-sources.utils :as uns]
            [non-soda-sources.refine :as r]
            [non-soda-sources.array-grouping :as ag]
            [soda.data.file-system :as sdfs]
            [non-soda-sources.lim-partnerships :as lps]
            [non-soda-sources.blackrock :as blr]
            [plumbing.core :refer [fnk]]
            [plumbing.graph :as graph]
            [doc-transforms.core :as dtc]
            [non-soda-sources.visuals :as viz])
  (:import (java.util Date)))


(def base-extractor
  {:pdf                (fnk [md5] (sdfs/find-file {:md5 md5}))
   :enhik              (fnk [pdf] (dtc/file->transform :enhanced-hickory pdf {}))
   :raw-predictions    (fnk [enhik] (->> {:use-retrieval? false}
                                         (predictions/enhik->predictions enhik)
                                         (remove uns/indecipherable?)))

   :model-meta         (fnk [raw-predictions]
                         (some->> raw-predictions
                                  (some :meta)
                                  (map (fn [[k v]]
                                         [k (select-keys v [:api-version :model-version :model-last-modified])]))
                                  (filter (comp seq second))
                                  (into {})))

   :scoped-predictions (fnk [raw-predictions file-type]
                         (r/clean-n-scope {:file-type file-type} raw-predictions))

   :array-grouped      (fnk [scoped-predictions file-type] (ag/group-arrays file-type (:array-group-fields scoped-predictions)))

   :linked             (fnk [scoped-predictions file-type]
                         (link/link-predictions {:file-type file-type} scoped-predictions))

   :raw-output         (fnk [scoped-predictions array-grouped linked]
                         (map (partial concat (:doc-level-fields scoped-predictions) array-grouped) linked))})


(def blackrock-extractor
  {:post-processing-fields (fnk [enhik raw-output] (blr/post-process enhik raw-output))
   :output                 (fnk [post-processing-fields raw-output]
                             (map (comp (partial into {})
                                        (partial remove empty?)
                                        blr/white-list-fields
                                        uns/format-predictions
                                        (partial concat post-processing-fields)) raw-output))})


(def lp-extractor {:amounts (fnk [md5 raw-predictions] (lps/parse-transactions md5 raw-predictions))
                   :output  (fnk [raw-output amounts]
                              (->> raw-output
                                   first                    ;no groupings for LPs
                                   (concat amounts)
                                   lps/format-output))})


(def file-type->extractor
  {:blackrock-trade-ticket    (graph/lazy-compile (merge base-extractor blackrock-extractor))
   :lp-general-partner-report (graph/lazy-compile (merge base-extractor lp-extractor))})


(defn extract [{:keys [file-type] :as request}]
  ((file-type->extractor file-type) request))


(defn extract-data [{:keys [md5 file-type] :as request}]
  (let [{{:keys [filename]} :pdf data :output model-meta :model-meta} (extract request)]
    (cond-> {:data data
             :meta {:md5        md5
                    :file-type  file-type
                    :time-stamp (new Date)
                    :filename   filename
                    :models     model-meta}})))


(defn highlighted-url [request] (viz/highlighted-url (extract request) request))









;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; For description selection verification ;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(comment

  (require '[mind-food.core :as mfc])
  (require '[monger.collection :as mc])
  (require '[datasources.core :as ds])

  (def mdocs (mc/find-maps (ds/get-db "soda_surveyor") "results" {:question-definition.tags "lp-mvp"}))

  (def md5s (into #{} (map (comp :md5 :document :question-definition) mdocs)))


  (defn annotate-it [md5]
    (try
      (->> (extract-data {:md5 md5 :file-type :lp-general-partner-report})
           :data
           (mapcat (fn [{:keys [hex-color raw-description meta] :as datum}]
                     (vector (dissoc datum :meta)
                             (when raw-description
                               (assoc (dissoc (:raw-description meta) :tokens) :hex-color hex-color)))))
           (filter identity)
           (mfc/annotate {:pdf-url  (str "http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/overmind/original/?md5=" md5)
                          :out-file (str md5 "-annotated.pdf")})
           dorun)
      (catch Exception ex (println "EXCEPTION on md5 :" md5 "\n" ex))))


  (defn left-or-above [amt-id des-id]
    (let [id->coords (fn [id] (->> id (s/split #"_") (map #(Integer/parseInt %)) (zipmap [:page-number :x :y])))
          within-x? (fn [x a b] (< (Math/abs (- a b)) x))
          {:keys [x y page-number]} (id->coords amt-id)
          {dx :x dy :y dp :page-number} (id->coords des-id)]
      (and (= dp page-number)
           (or
             (and                                           ;to the left
               (within-x? 3 y dy)
               (< dx x))
             (and                                           ;above
               (within-x? 10 x dx)
               (< dy y))))))



  ;try to use surveyor results as oracle
  (def issues (->> mdocs
                   (filter (comp neg? (partial compare #inst"2019-01-07T00:14:00.867-00:00") :last-updated))
                   (filter (fn [{:keys [answer]}]
                             (let [amts (count (filter (comp #{"amount"} :class) answer))
                                   descs (count (filter (comp #{"description"} :class) answer))]
                               (and (pos? amts) (pos? descs) (< (- amts descs) 3)))))
                   (take 50)
                   (map (fn [{:keys [answer question-definition _id]}]
                          (let [md5 (get-in question-definition [:document :md5])
                                predictions (->> (extract-data {:md5 md5 :file-type :lp-general-partner-report})
                                                 :data)]
                            {:question-id   _id
                             :md5           md5
                             :descriptions  (filter (comp #{"description"} :class) answer)
                             :amounts       (filter (comp #{"amount"} :class) answer)
                             :a-predictions (->> predictions
                                                 (remove (comp #{:none} #(get % :raw-description :none)))
                                                 (map :ids)
                                                 flatten
                                                 (into #{}))
                             :d-predictions (->> predictions
                                                 (filter :raw-description)
                                                 (mapcat (comp (partial map :id) :tokens :raw-description :meta))
                                                 (into #{}))})))
                   (map (fn [{:keys [descriptions amounts d-predictions a-predictions md5] :as a}]
                          {:md5             md5
                           :missing-amounts (seq (remove #(some a-predictions (:ids %)) amounts))
                           :missing-desc    (seq (remove #(some d-predictions (:ids %)) descriptions))}))))



  ;use this to find issues
  (filter (fn [{:keys [missing-desc missing-amounts]}]
            (> (count missing-desc) (count missing-amounts))) issues)

  ;sample, annotate, inspect
  (->> md5s
       shuffle
       (take 30)
       (map annotate-it))

  )