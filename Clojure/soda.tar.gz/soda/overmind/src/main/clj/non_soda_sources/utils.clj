(ns non-soda-sources.utils
  (:require [non-soda-sources.sources :as srcs]
            [datasources.core :as ds]
            [monger.collection :as mc]
            [clojure.core.memoize :as memo])
  (:import (java.util Date)))

(defn in-box? [{:keys [x0 x1 y0 y1]} {:keys [min-x min-y max-x max-y]}]
  (not (or (< max-y y0)
           (> min-y y1)
           (< max-x x0)
           (> min-x x1))))

(defn indecipherable? [{:keys [value]}]
  (or
    (nil? value)
    (= "" value)
    (= "✔" value)))

(defn format-predictions
  "Expects a sequence of single class predictions and produces an user friendly map of terms -> values"
  [predictions]
  (->> predictions
       (map (juxt :class :value))
       (into {})))

(defn set-prob-threshold [file-type field value]
  (mc/upsert (ds/get-db "soda_configs") "properties"
             {:type "ml_confidence_thresholds" :file-type file-type}
             {"$push" {(str "field_thresholds" "." (name field)) {:effective-start-date (Date.) :threshold value}}}))

(defn prob-threshold* [file-type field]
  (or (some-> (mc/find-one-as-map (ds/get-db "soda_configs") "properties" ;look up in mongo
                                  {:type      "ml_confidence_thresholds"
                                   :file-type file-type})
              :field_thresholds
              (get field)
              ((partial sort-by :effective-start-date))
              last
              :threshold)
      (get-in srcs/non-soda-file-type->fields [file-type field :p-threshold]) ;look up in sources definition
      0.8))

(def five-min-in-ms (* 1000 60 5))

(def prob-threshold (memo/ttl prob-threshold* :ttl/threshold five-min-in-ms))

(defn n-most-probable-instances [n class predictions file-type]
  (some->> predictions
           (filter #(and (#{class} (:class %))
                         (> (:probability %) (prob-threshold file-type class))))
           not-empty
           (sort-by (comp (partial - 1.0) :probability))
           (take n)))

(defn refined-instances
  "Chooses the most probable <num-per-class> candidates from each class in <class-set>.  The
  candidate must fall within the region defined by <bounding box>"
  [raw-candidates class-set & [{:keys [bounding-box num-per-class file-type]}]]
  (let [legit-candidates (filter (every-pred (comp class-set :class)
                                             (partial in-box? (or bounding-box {:x0 0 :x1 9999 :y0 0 :y1 9999}))) raw-candidates)]
    (mapcat #(n-most-probable-instances num-per-class % legit-candidates file-type) class-set)))