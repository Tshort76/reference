(ns non-soda-sources.linking
  (:require [taoensso.timbre :as timbre]))

(defmulti link-predictions (fn [{:keys [file-type]} _] file-type))


(defn link-first-below
  "Links anchors to linkables according to the following criteria: A linkable
  belongs to the closest anchor above it."
  [all-anchors all-linkables]
  (let [below? (fn [{anchor-y :max-y} {cand-y :min-y}]
                 (> (+ cand-y 3) anchor-y))]
    (loop [anchors (reverse (sort-by :min-y all-anchors))   ;start with the lowest anchor and move up
           linkables all-linkables
           linked []]
      (if-let [anchor (first anchors)]
        (let [{members-raw true aliens false} (group-by (partial below? anchor) linkables)
              members (->> members-raw (group-by :class) (map (comp (partial apply min-key :min-y) second)))]
          (recur (rest anchors) aliens
                 (conj linked (conj members anchor))))
        linked))))


(def trade-type->link-fn {"SWAP/SWAP"   link-first-below
                          "SWAP/TRSWAP" link-first-below
                          "SYNTH/SWAPTION"  link-first-below
                          "SYNTH/CAP" link-first-below
                          "SWAP/CDSWAP" link-first-below})


;todo handle field value conflicts ...

(defmethod link-predictions :blackrock-trade-ticket
  [_ {:keys [anchors meta linkables]}]
  (let [{:keys [trade-type]} meta
        link-fn (trade-type->link-fn trade-type)]
    (or
      (if link-fn
        (if (seq anchors)
          (link-fn anchors linkables)
          (timbre/debug "No anchors found, only document level fields will be extracted."))
        (timbre/debug "No link function defined for trade type of: " trade-type ".  Only document level fields will be extracted."))
      [[]])))

(defmethod link-predictions :default [& _] [[]])
