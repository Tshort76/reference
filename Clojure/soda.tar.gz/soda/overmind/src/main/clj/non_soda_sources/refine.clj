(ns non-soda-sources.refine
  (:require [non-soda-sources.sources :as sm]
            [non-soda-sources.utils :as u]
            [non-soda-sources.blackrock :as br]
            [non-soda-sources.array-grouping :as ag]
            [clojure.string :as s]
            [taoensso.timbre :as timbre]))


(defmulti clean-n-scope "Builds sets of anchors, linkables, and doc-level fields from a set of predictions"
          (fn [{:keys [file-type]} _] file-type))





(defmethod clean-n-scope :blackrock-trade-ticket [_ predictions]
  (if-let [trade-type (some->> predictions
                                 (filter (fn [{:keys [class value probability]}]
                                           (and (= :trade-type class)
                                                (s/includes? value "/")
                                                (> probability 0.8))))
                                 not-empty
                                 (apply min-key :min-y)
                                 :value)]
    (let [{:keys [anchor-class-set linkable-class-set
                  linking-bound-box anchors-extractor]
           :or   {anchor-class-set   #{}
                  linkable-class-set #{}}} (br/link-meta-by-trade-type trade-type)
          anchors (cond
                    (seq anchor-class-set)
                    (u/refined-instances predictions anchor-class-set {:bounding-box  linking-bound-box
                                                                       :num-per-class 1
                                                                       :file-type :blackrock-trade-ticket})
                    anchors-extractor (anchors-extractor predictions)
                    :else [])]
      {:meta               {:trade-type trade-type}
       :anchors            anchors
       :linkables          (u/refined-instances predictions linkable-class-set {:bounding-box  linking-bound-box
                                                                                :num-per-class (count anchors)
                                                                                :file-type     :blackrock-trade-ticket})
       :array-group-fields (u/refined-instances predictions
                                                (->> sm/non-soda-file-type->fields
                                                     :blackrock-trade-ticket
                                                     keys
                                                     (filter (into #{} (keys (ag/array-groups :blackrock-trade-ticket))))
                                                     (into #{}))
                                                {:num-per-class 10 :file-type :blackrock-trade-ticket})
       :doc-level-fields   (u/refined-instances predictions
                                                (->> sm/non-soda-file-type->fields
                                                     :blackrock-trade-ticket
                                                     (keep (fn [[class field-info]] (when-not (:array-group field-info) class)))
                                                     (remove linkable-class-set)
                                                     (into #{}))
                                                {:num-per-class 1
                                                 :file-type     :blackrock-trade-ticket})})
    (timbre/debug "No trade type found in this document.")))


(defmethod clean-n-scope :lp-general-partner-report [_ predictions]
  {:doc-level-fields (u/refined-instances predictions
                                          (->> sm/non-soda-file-type->fields
                                               :lp-general-partner-report
                                               keys
                                               (remove #{:amount :description})
                                               (into #{})) {:num-per-class 1 :file-type :lp-general-partner-report})})


(defmethod clean-n-scope :default [{:keys [file-type]} predictions]
  {:doc-level-fields (u/refined-instances predictions
                                          (->> (get sm/non-soda-file-type->fields file-type)
                                               keys
                                               (into #{}))
                                          {:num-per-class 1})})
