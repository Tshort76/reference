(ns non-soda-sources.client-specific
  (:require [jaegers.features.context :as context]
            [jaegers.utils :as ju]
            [clojure.string :as cs]
            [jaegers.features.enfeature :as jfe]))


(defn ids->words
  "Given a list of ids return a list of ids"
  [db ids]
  (some->> ids
           (map ju/id->vec)
           (sort-by second)
           (sort-by last)
           (mapcat (partial context/hik-id->text db))))

(defn ids->text
  "Given a list of ids return a concatenated string of the associated text."
  [db ids]
  (->> (ids->words db ids)
       (cs/join " ")))

(defn recover-answer-text
  "Given some answers (with ids) add in the text associated with those ids."
  [db answers]
  (for [{:keys [ids class] :as answer} answers]
    (assoc answer :text (ids->text db ids))))

(defn recover-result-text
  "Takes an entry from the result collection and adds in the text based on the ids."
  [result & {:keys [db]}]
  (let [md5 (->> result :question-definition :document :md5)
        db (or db (jfe/query->db {:md5 md5}))]
    (update result :answer (partial recover-answer-text db))))

(defn recover-training-text
  "Takes an entry from the result collection and adds in the text based on the ids."
  [example & {:keys [db]}]
  (let [md5 (:md5 example)
        db (or db (jfe/query->db {:md5 md5}))]
    (into (sorted-map)
          (reduce (fn [example item]
                    (assoc example (keyword (str "words" item))
                                   (->> (str "ids" item)
                                        keyword
                                        example
                                        (ids->words db)
                                        (into []))))
                  example
                  ["-in-component"
                   "-before"
                   "-after"
                   "-in-row-before"
                   "-in-row-after"
                   "-in-col-above"
                   "-in-col-below"]))))


(comment
  (require '[soda.data.core :as sdc])

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;results;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
  (sdc/defcon "soda_surveyor" "results")
  (->> (results {:question-definition.tags "lp-mvp"})
       rand-nth
       recover-result-text)


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;candidate 2;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
  (sdc/defcon "training-sets" "candidates2")
  (->> (candidates2 {:tags "lp-mvp"})
       first
       recover-training-text
       )
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;notes;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
  ;answer-cache and question-queue don't know which document they point at.
  )