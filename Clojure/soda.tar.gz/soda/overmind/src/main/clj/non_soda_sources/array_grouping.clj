(ns non-soda-sources.array-grouping
  (:require [non-soda-sources.sources :as sm]))

(defn group-key->entry [group-key] (-> group-key name (str "-entry") keyword))
(defn group-key->array [group-key] (-> group-key name (str "-list") keyword))

(defn array-groups [file-type]
  (->> sm/non-soda-file-type->fields
       file-type
       (keep (fn [[class {grouping :array-group}]] (if grouping {class grouping})))
       (apply merge)))

(defn merge-group [group-key blocks]                   ;todo make this a multimethod for other groupings
  (->> (sort-by :min-x blocks)
       (reduce (fn [accumulator
                    {:keys [min-x max-x min-y max-y ids class value string] :as block}]
                 (-> accumulator
                     (update :min-x #(min min-x %))
                     (update :max-x #(max max-x %))
                     (update :min-y #(min min-y %))
                     (update :max-y #(max max-y %))
                     (update :string str " " string)
                     (update :value merge {class value})
                     (update-in [:ids 0] #(vec (concat % (mapcat identity ids))))
                     (update :fields conj block)))
               {:class group-key :min-x 1000 :max-x 0  :min-y 1000 :max-y 0 :ids [[]] :value {} :string ""} )))

(defn concat-entries [group-key entries]
  (if (> 1 (count entries))
    []
    (reduce (fn [accumulator
                 {:keys [min-x max-x min-y max-y ids class value string] :as block}]
              (-> accumulator
                  (update :min-x #(min min-x %))
                  (update :max-x #(max max-x %))
                  (update :min-y #(min min-y %))
                  (update :max-y #(max max-y %))
                  (update :string str ", " string)
                  (update :value conj value)
                  (update :ids concat ids)
                  (update :fields conj block)))
            {:class group-key :min-x 1000 :max-x 0 :min-y 1000 :max-y 0 :ids [] :value [] :string ""}
            entries)))


(defmulti group-arrays (fn [file-type _] file-type))
(defmethod group-arrays :default [file-type array-predictions] array-predictions)
(defmethod group-arrays :blackrock-trade-ticket [file-type array-predictions]
  (some->> array-predictions
           (group-by (comp (array-groups file-type) :class))
           (map (fn [[group-key predictions]]                   ;todo handle grouping smarter.
                  (->> (group-by :min-y predictions)            ;todo use geometric linker ???
                       vals
                       (map (partial merge-group (group-key->entry group-key)))
                       (concat-entries (group-key->array group-key)))))))

(comment
  (map (fn [[md5 file-type]]
         (->> (non-soda-sources.core/extract {:md5 md5 :file-type file-type})
              ;:scoped-predictions
              ;:array-group-fields
              ;:data
              ;(map (fn [entry] (select-keys entry [:related-trade-list])))

              :output
              ))
       [
        ;["1a89f11ee176bc195b1198d038521425" :blackrock-trade-ticket]
        ;["c3b1f2ff3fbccc421f5fec59fc35d019" :blackrock-trade-ticket]
        ;;["003f45ac4a056c24f92039ecef25ab8f" :blackrock-trade-ticket] ;as of 4/1 no related trade info is found.
        ;["28df22e000d678576e08b79169e18c74" :blackrock-trade-ticket]
        ;["1ea30aa1e4d8ac41485e38a42cde0c10" :blackrock-trade-ticket]
        ;["1b9966f25058867d43970335340dff37" :blackrock-trade-ticket]

        ["e879f128e696e4cf3c4559bbba2b9af7" :blackrock-trade-ticket]


        ]))