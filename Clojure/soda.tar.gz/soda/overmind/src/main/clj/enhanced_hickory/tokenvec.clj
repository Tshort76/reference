(ns enhanced-hickory.tokenvec
  (:require
    [clojure.walk :as walk]
    [tokenvec.core :as tv]))

(def block-level-tags
  #{:address :blockquote :dd :div :dl :fieldset :form :h1 :h2 :h3 :h4 :h5
    :li :main :nav :noscript :ol :p :pre :table :tfoot :ul
    ; pseudo-block-level tags
    :body :document :html :page :tbody :td :th :thead :tr})

(defn block-tokenvec [content]
  (->> content
       (reduce (fn [coll v] (if (map? v) (conj coll v) (into coll v))) [])
       (partition-by (comp some? :tokenvec))
       (mapcat (fn [part]
                 (if (-> part first :tokenvec some?)
                   part
                   (->> part
                        (filter (every-pred :id :text))
                        (remove (comp #{" "} :text))
                        (tv/tokens->tokenvec)
                        (hash-map :tokenvec)
                        vector))))))

(defn- extract-tokenvecs [hik]
  (->> hik flatten (keep :tokenvec)))

(defn enhik->tokenvecs [enhik]
  (->> enhik
       (walk/postwalk
         (fn [h]
           (if (map? h)
             (let [{:keys [attrs tag content token?]} h]
               (cond
                 ; transform tokens
                 token?
                 (assoc attrs :text (first content))
                 ;{:id (:id attrs) :text (first content)}

                 ; filter empty/self-closing elements and squash nested non-block-level tags
                 (and (contains? h :content) (not (block-level-tags tag)))
                 (when (seq content) (flatten content))

                 ; transform block-level elements into tokenvecs
                 (and (contains? h :content) (block-level-tags tag))
                 (block-tokenvec content)
                 ; (->> content
                 ;      (reduce (fn [coll v] (if (map? v) (conj coll v) (into coll v))) [])
                 ;      (partition-by (juxt map? :tokenvec))
                 ;      (map (fn [part] (if (every? (every-pred :id :text) part)
                 ;                        {:tokenvec (tv/tokens->tokenvec (remove (comp #{" "} :text) part))}
                 ;                        part))))

                 :else h))
             h)))
       block-tokenvec
       extract-tokenvecs))
