(ns enhanced-hickory.util
  (:require
    [clojure.string :as cs]
    [clojure.walk :as walk]
    [clojure.zip :as zip]
    [hickory.select :as hs]
    [hickory.zip :as hz]
    [html.data :as hd]
    [soda.core :as soda]))

(defn- prewalk-zip*
  [f loc]
  (if (zip/end? loc)
    (zip/root loc)
    #(prewalk-zip* f (zip/next (f loc)))))

(defn prewalk-zip
  "Performs a depth-first, pre-order traversal of zipper, applying f to every node visited"
  [f loc]
  (trampoline prewalk-zip* f loc))

; TODO try to use trampoline to avoid stack consumption
(defn postwalk-zip
  "Performs a depth-first, post-order traversal of zipper, applying f to every node visited"
  [f [_ path :as loc]]
  (let [loc (if-some [loc (zip/down loc)]
              (loop [loc loc]
                (let [loc (postwalk-zip f loc)]
                  (if-some [loc (zip/right loc)]
                    (recur loc)
                    (zip/up loc))))
              loc)]
    (cond-> (f loc) (nil? path) zip/root)))

(defn remove-pred
  "Removes all elements matching selector-fn"
  [selector-fn enhik]
  (loop [zip (hz/hickory-zip enhik)
         nxt (hs/select-next-loc selector-fn zip)]
    (if nxt
      (let [new-zip (zip/remove nxt)]
        (recur new-zip (hs/select-next-loc selector-fn new-zip)))
      (zip/root zip))))

(defn filter-pages
  "Removes all elements after max-page"
  [max-page enhik]
  (remove-pred (hs/follow (hs/attr :page-number #(some-> % soda/parse-long (> max-page)))) enhik))

(defn add-attr [existing attr-name attr-value]
  (let [new-attr (str (name attr-name) ":" (name attr-value) ";")]
    (cond
      (or (= existing ";") (empty? existing)) new-attr
      (cs/ends-with? existing ";") (str existing new-attr)
      :default (str existing ";" new-attr))))

(defn add-highlights [enhik ids & {:keys [color] :or {color :yellow}}]
  (let [loc (hz/hickory-zip enhik)]
    (->> ids
         (reduce (fn [loc id]
                   (-> (hs/select-next-loc (hs/id id) loc)
                       (zip/edit update-in [:attrs :style] #(add-attr % :background-color color))
                       zip/root
                       hz/hickory-zip))
                 loc)
         zip/root)))

(defn add-tooltips [enhik ids tooltip-text]
  (let [loc (hz/hickory-zip enhik)]
    (->> ids
         (reduce (fn [loc id]
                   (-> (hs/select-next-loc (hs/id id) loc)
                       (zip/edit assoc-in [:attrs :title] tooltip-text)
                       zip/root
                       hz/hickory-zip))
                 loc)
         zip/root)))

(defn add-highlight-groups [enhik seqs-of-ids & {:keys [colors]}]
  (if (empty? seqs-of-ids)
    enhik
    (reduce
      (fn [h [ids color]] (add-highlights h ids :color color))
      enhik
      (map
        vector
        seqs-of-ids
        (or colors (map :keyword-name (hd/create-color-spread (count seqs-of-ids))))))))

(defn stringify-attr-vals [enhik]
  (letfn [(stringify-vals [m] (zipmap (keys m) (map str (vals m))))]
    (walk/prewalk
      (fn [x]
        (cond-> x
          (and (map? x) (:attrs x)) (update :attrs stringify-vals)))
      enhik)))
