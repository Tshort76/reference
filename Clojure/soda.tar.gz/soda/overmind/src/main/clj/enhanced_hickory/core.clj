(ns enhanced-hickory.core
  (:require
    [clojure.edn :as edn]
    [clojure.pprint :as pp]
    [clojure.spec.alpha :as spec]
    [clojure.string :as cs]
    [clojure.walk :as walk]
    [clojure.zip :as zip]
    [enhanced-hickory.spec]
    [enhanced-hickory.util :as ehu]
    [hickory.convert :as hcv]
    [hickory.core :as hc]
    [hickory.render :as hrend]
    [hickory.select :as hs]
    [hickory.zip :as hz]
    [html.data :as hd]
    [html.flying-saucer :as flying-saucer]
    [html.utils :as hu]
    [soda.core :as soda]
    [taoensso.tufte :refer [defnp]]))

(defnp add-ids
  "Adds a unique id attribute to all elements starting at <body>"
  ([m]
   (add-ids identity [] [] m))
  ([{:keys [html-ids?]} m]
   (add-ids (if html-ids?
              (partial str "id")
              identity)
            [] [] m))
  ([id-fn id tags {:keys [tag type content] :as m}]
   (if (string? m)
     m
     (case type
       :document (update m :content #(mapv (partial add-ids id-fn id tags) %))
       :comment m
       (case tag
         :head m
         (let [new-content (vec (map-indexed (fn [i v] (add-ids id-fn (conj id i) (conj tags tag) v))
                                             content))]
           (cond-> (assoc m :content new-content)
                   ;Adding the tag path is mainly for debugging.
                   (seq tags) (assoc :tags (conj tags tag))
                   (and (seq new-content)
                        (seq id)) (assoc-in [:attrs :id] (id-fn (cs/join "_" id))))))))))

(defn- tokenize-content
  [coll v]
  (if (string? v)
    (let [xform (comp (remove empty?)
                      (map (fn [w] {:type :element, :tag :span, :content [w], :token? true}))
                      (interpose {:type :element, :tag :span, :content [" "], :token? true}))
          toks (into [] xform (cs/split v #"[\t\n\p{Z}]"))] ;; note: this regex does *NOT* catch "\r"
      (cond-> coll (seq toks) (into toks)))
    (conj coll v)))

(defn- clean-header
  [coll v]
  (if (string? v)
    (into coll (remove empty? (cs/split v #"[\t\n\p{Z}]"))) ;; note: this regex does *NOT* catch "\r"
    (conj coll v)))

(defnp sanitize-attrs
  "Removes any non-standard attribute from the node at loc"
  [{:keys [attrs] :as m}]
  (cond-> m
    (some? attrs) (update :attrs select-keys hd/attrs)))

(defnp add-token-tags
  "Splits string content of the node at loc by whitespace, converting each token
   and interposed space into span elements"
  [{:keys [tag type content] :as m}]
  (if (string? m)
    m
    (cond
      (= type :comment) m
      (= tag :head) m
      :else (sanitize-attrs (update m :content (fn [c] (->> c
                                                            (map add-token-tags)
                                                            (reduce tokenize-content []))))))))

(defnp add-page-number
  "Adds page number as an attribute to the node at loc when (pred node) is true.
   page is an atom holding the current page number, and is incremented after
   visiting an element with a page-break-before or page-break-after style
   attribute."
  ([page loc]
   (add-page-number page identity loc))
  ([page pred loc]
   (if (zip/branch? loc)
     (let [{{:keys [id style]} :attrs :as node} (zip/node loc)
           new-loc (cond-> loc (pred node) (zip/edit assoc-in [:attrs :page-number] (-> page deref str)))]
       (when (or (hu/get-style :page-break-before style)
                 (hu/get-style :page-break-after style))
         (swap! page inc))
       new-loc)
     loc)))

(defnp add-coords
  "Adds geometric coordinates from id->coords as attributes to the node at loc"
  [id->coords loc]
  (if (zip/branch? loc)
    (if-let [coords (-> loc zip/node :attrs :id id->coords)]
      (zip/edit loc update :attrs merge coords)
      loc)
    loc))

(defnp filter-by-page
  "Removes the node at loc if its page number is greater than max-page"
  [max-page loc]
  (let [prune? (and (zip/branch? loc)
                    (some-> loc zip/node :attrs :page-number soda/parse-long (> max-page)))]
    (cond-> loc prune? zip/remove)))

;; -----------------------------------------------------------------------------

(defn- prune-hik
  "Removes all elements from hik after max-page"
  [max-page hik]
  (->> hik
       hz/hickory-zip
       (ehu/prewalk-zip
         (comp (partial filter-by-page max-page)
               (partial add-page-number (atom 1))))))

(defn- decorate-hik
  "Adds geometric attributes to every element of hik under <body> and before max-page"
  [id->coords max-page hik]
  (->> hik
       hz/hickory-zip
       (ehu/prewalk-zip
         (comp (partial add-coords id->coords)
               (partial filter-by-page max-page)
               (partial add-page-number (atom 1) (comp :id :attrs))))))

(defn html->enhik
  [html & {:keys [max-page only-ids?] :as opts}]
  (let [enhik (->> html hc/parse hc/as-hickory
                   (prune-hik (or max-page 20))
                   add-token-tags
                   (add-ids opts))]
    (if only-ids?
      enhik
      (-> enhik
          flying-saucer/hickory-to-xhtml
          flying-saucer/make-coords-map
          (decorate-hik (or max-page 20) enhik)))))



(defn empty-string? [s]
  (and (string? s)
       (re-matches #"[\t\n\r\s\p{Z}]*" s)))

(defn empty-content? [content]
  (every? empty-string? content))

(defnp remove-junk-tags [{:keys [tag type content] :as m}]
  (cond
    (or (empty-string? m)
        (= :comment type)) nil
    (string? m) m
    (= tag :head) m
    :else (let [new-content (vec (keep remove-junk-tags content))]
            (if (and (= tag :span)
                     (empty-content? new-content))
              " "
              (assoc m :content new-content)))))

(defn add-component-labels [{:keys [tag type] :as enhik}]
  (cond
    (= :body tag) (update enhik :content (partial mapv (fn [c] (assoc-in c [:attrs :class] "component"))))
    (or (= :document type)
        (= :html tag)) (update enhik :content (partial mapv add-component-labels))
    :else enhik))


(defn add-filename [{:keys [tag type] :as enhik} filename]
  (cond
    (= :head tag)
    (update enhik :content (fn [cnt] (->> cnt
                                          (remove #(= :title (:tag %)))
                                          (into [{:type :element, :tag :title, :content [filename]}]))))

    (or (= :document type)
        (= :html tag))
    (update enhik :content (partial mapv #(add-filename % filename)))

    :else enhik))


(defn add-meta-data [{:keys [tag type] :as enhik} meta]
  (cond
    (= :head tag)
    (update enhik :content (fn [cnt] (->> cnt
                                          (remove #(= :title (:tag %)))
                                          (into [{:type :element, :tag :title, :content [(:filename meta)]}]))))

    (= :body tag)
    (update enhik :content (partial into [{:type :element, :tag :div, :content
                                           [(pr-str (select-keys meta [:file-type :filename :md5 :edgar :mime-type]))]}]))

    (or (= :document type)
        (= :html tag))
    (update enhik :content (partial mapv #(add-meta-data % meta)))

    :else enhik))


(defnp enhik->html [enhik]
  (-> enhik
      add-component-labels
      remove-junk-tags
      ehu/stringify-attr-vals
      hrend/hickory-to-html))

(defnp enhik->enhiccup [enhik]
  (hcv/hickory-to-hiccup enhik))
