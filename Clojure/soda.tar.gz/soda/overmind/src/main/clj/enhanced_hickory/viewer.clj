(ns enhanced-hickory.viewer
  ; (:require [html.viewer :as hv]
  ;           [enhanced-hickory.core :as enhik]
  ;           [clojure.string :as cs]
  ;           [clojure.edn :as edn])
  ; (:import (javax.swing JFrame JComponent JScrollPane)
  ;          (java.awt BorderLayout Graphics2D Color Dimension Font RenderingHints Component)
  ;          (java.awt.geom Rectangle2D$Double AffineTransform)
  ;          (java.io File))
           )

; (defn ^Component component [enhik]
;   (hv/component (enhik/enhik->html enhik)))

; (defn view [enhik]
;  (hv/view (enhik/enhik->html enhik)))

; (defn parse-font-size [{:keys [font]}]
;   (some->>
;     font
;     (re-seq #"(\d+)pt")
;     first second edn/read-string))

; (defn bold? [{:keys [font]}] (some-> font cs/lower-case (cs/includes? "bold")))
; (defn italic? [{:keys [font]}] (some-> font cs/lower-case (cs/includes? "italic")))

; (defn parse-style [style]
;   (into {} (map
;     (fn [s] (let [[k v] (cs/split s #":")]
;               (when v [(keyword (cs/trim k)) (cs/trim v)])))
;     (cs/split (or style "") #";"))))

; (defn font [{:keys [font] :as style :or {font "Arial 10pt"}}]
;   (Font.
;     font
;     (cond-> Font/PLAIN (bold? style) (+ Font/BOLD) (italic? style) (+ Font/ITALIC))
;     (or (parse-font-size style) 10)))

; (defn render-contents [^Graphics2D g {:keys [type tag content token? tags attrs]}]
;   (doseq [c content]
;     (cond
;       (string? c) (let [{:keys [style min-x max-x min-y max-y]} attrs]
;                     (doto g
;                       (.setPaint Color/RED)
;                       (.draw (Rectangle2D$Double. min-x min-y (- max-x min-x) (- max-y min-y)))
;                       (.setPaint Color/BLACK)
;                       ;(.setFont (font (parse-style style)))
;                       (.drawString ^String c ^double min-x ^double max-y)))
;       (map? c) (render-contents g c))))

; (defn render-enhik [^Graphics2D g enhik]
;   (.setPaint g Color/WHITE)
;   (doseq [page (range 2)]
;     (.fill g (Rectangle2D$Double. 0 (* page 800) 600 800)))
;   (.setPaint g Color/BLACK)
;   (doseq [page (range 2)]
;     (.draw g (Rectangle2D$Double. 0 (* page 800) 600 800)))
;   (render-contents g enhik))

;We may also want to pass in the component
; (defn render [^Graphics2D g mind-food]
;   (doto g
;     (.setRenderingHint RenderingHints/KEY_TEXT_ANTIALIASING RenderingHints/VALUE_TEXT_ANTIALIAS_ON)
;     (.setPaint Color/BLACK)
;     (render-enhik mind-food)))

; (defn ^Component geometric-component [enhik]
;   (JScrollPane.
;     (doto
;       (proxy [JComponent] []
;         (paint [g] (render g enhik)))
;       (.setPreferredSize (Dimension. 800 (-> 2 (* 800)))))))

; (defn geometric-view [enhik]
;   (let [state (atom {})]                                    ;currently does nothing
;     (doto (JFrame. "Enhanced Hickory Geometric Viewer")
;       (.setSize 800 900)
;       (.setLayout (BorderLayout.))
;       ;(.add (JToolBar.) BorderLayout/BEFORE_FIRST_LINE)
;       (.add (geometric-component enhik) BorderLayout/CENTER)
;       (.setVisible true))))
