(ns jaegers.edgar.primer
  (:require
    [clj-http.client :as http]
    [clojure.data.json :as json]
    [clojure.pprint :as pp]
    [clojure.string :as string]
    [environ.core :refer [env]]
    [medley.core :refer [map-vals]]
    [taoensso.tufte :refer [defnp]]
    [soda-common.parsers :as scp]
    [soda-common.regexes :as re]
    [jaegers.edgar.classifiers.asset-class :as asset-class]
    [jaegers.edgar.classifiers.candidates :as candidates]
    [jaegers.edgar.cusips :as cusips]
    [jaegers.features.enfeature :as enfeature]
    [jaegers.features.context :as context]
    [jaegers.hickory-utils :as hu]
    [enhanced-hickory.util :as ehu]
    [jaegers.mind-food-utils :as mfu]
    [jaegers.regisector :as rs]
    [jaegers.tokenvec-solver :as solver]
    [html.utils :as html]
    [ml.predictions :as predictions]
    [ml.tokenizers :as tok]
    [perseverance.core :as perseverance]
    [plumbing.core :refer [?>>]]
    [soda.data.file-system :as sdfs]
    [edgar.tfidf-enfeaturing :as tfidf-enf]
    [soda.core :refer [partition-when]]
    [surveyor-interop.ml.core :as siml]
    [taoensso.timbre :as log]
    [util.feature-flags :as ff]))

(def provides
  {:accrual-start-date :date
   :face-value         :dollars
   :first-coupon-date  :date
   :interest-rate      :percent
   :issue-date         :date
   :issue-price        :percent
   :maturity-date      :date
   :principal-amount   :dollars
   :call-option-date   :date})

(def features-descriptor
  (merge
    {:class               {:options [:accrual-start-date
                                     :face-value
                                     :first-coupon-date
                                     :interest-rate
                                     :issue-date
                                     :issue-price
                                     :maturity-date
                                     :other
                                     :principal-amount
                                     :call-option-date]
                           :default :other}
     :value-type          {:options [:date :percent :dollars :number :year :month-day :reference-date]}
     ; general features
     :page-number         {:options :implicit}
     :vert-alignment      {:options hu/vert-align-values}
     :horiz-alignment     {:options hu/horiz-align-values}
     :words-in-block      {:options :implicit}
     ; value features
     :magnitude           {:options :implicit}
     :multiple-of-1000?   {:options [:true :false] :default false}
     :precision           {:options :implicit}
     ; table features
     :table-nest-depth    {:options :implicit}
     :col-count           {:options :implicit}
     :row-count           {:options :implicit}
     :words-in-table      {:options :implicit}
     ; table cell features
     :words-in-row        {:options :implicit}
     :words-in-col        {:options :implicit}
     :words-in-row-before {:options :implicit}
     :words-in-row-after  {:options :implicit}
     :words-in-col-above  {:options :implicit}
     :words-in-col-below  {:options :implicit}
     :first-column?       {:options [:true :false] :default false}
     :last-column?        {:options [:true :false] :default false}
     :first-row?          {:options [:true :false] :default false}
     :last-row?           {:options [:true :false] :default false}}
    ; word/value features
    (->> (for [term (concat (map key tok/interesting-words) [:date :percent :dollars :number])
               sfx ["-terms-before" "-terms-after" "-terms-in-row-before" "-terms-in-row-after" "-terms-in-col-above" "-terms-in-col-below"]]
           {(keyword (str (name term) sfx)) {:options :implicit :default 0}})
         (apply merge))
    ; term (keyword) features
    (->> (for [term (map key tok/interesting-terms)
               sfx ["-terms-before" "-terms-in-row-before" "-terms-in-col-above" "-terms-in-nearest-row-label"]]
           {(keyword (str (name term) sfx)) {:options :implicit :default 0}})
         (apply merge))))

(def simple-features-descriptor
  (map-vals (fn [{:keys [options] :as m}]
              (if (#{:implicit} options) :implicit m))
            features-descriptor))

(def candidate-xform
  "Filters results from prediction pipeline"
  (comp (remove (comp #{:other} :class))
        (filter (comp #(> % 0.75) :probability))
        (filter #(= (provides (:class %)) (keyword (:value-type %))))
        (keep (fn [{:keys [probability] :as m}]
                (-> (select-keys m [:value :ids :class :value-type])
                    (assoc :classifier-results {:confidence probability, :contributions [1 1]})
                    (update :value (fn [s] (let [[{:keys [value]}] (tok/dissect-text s)] (or value s)))))))
        (filter :value)))

(defn predict-candidates
  "Runs the deep learning prediction pipeline on enhik, returning candidates
  grouped by class name"
  [enhik source]
  (let [db (enfeature/enhik->db tok/dissect-text enhik)]
    (->> (perseverance/retry
           {:strategy (perseverance/progressive-retry-strategy :max-count 5)}
           (predictions/prediction-pipeline db source {:use-retrieval? true}))
         (sequence candidate-xform)
         (group-by :class))))

(defn enfeature-enhik
  ([enhik]
   (enfeature-enhik enhik 10))
  ([enhik max-pages]
   (let [db (enfeature/enhik->db tok/dissect-text enhik)]
     (some->>
       enhik
       (?>> (pos? max-pages) (ehu/filter-pages max-pages))
       mfu/enhik->sentence-tokenvecs
       (enfeature/enfeature-tokenvecs db features-descriptor tok/dissect-text)))))

(def xform
  (comp (map #(assoc % :class (-> % :classifier-results :class)))
        (filter #(= (provides (:class %)) (get-in % [:features :value-type])))
        (map #(dissoc % :string :sentence :indexes :features))
        (filter (comp provides :class))))

(defn classify-candidates
  ([enhanced-hickory normalizer classifier]
   (if (ff/allowed-to? :use-deep-learning-candidates)
     (predict-candidates enhanced-hickory :edgar)
     (some->> enhanced-hickory
              enfeature-enhik
              (map normalizer)
              (apply solver/classify-featuremaps classifier)
              (sequence xform)
              (group-by :class))))
  ([{:keys [enhanced-hickory] :as omni-data}]
   (let [[normalizer classifier] (candidates/select-model omni-data)]
     (classify-candidates enhanced-hickory normalizer classifier))))

; (defn classify-candidates-noisy
;   [{enhik :enhanced-hickory :as omni-data}]
;   (let [[normalizer classifier] (candidates/select-model omni-data)
;         xform (comp (map #(assoc % :class (-> % :classifier-results :class)))
;                     (filter #(= (provides (:class %)) (get-in % [:features :value-type])))
;                     (map #(dissoc % :string :sentence :indexes :features))
;                     (filter (comp provides :class)))]
;     (some->> enhik
;              (ec/filter-pages 10)
;              mfu/enhik->sentence-tokenvecs
;              (enfeature/enfeature-tokenvecs enhik features-descriptor tok/dissect-text)
;              (map normalizer)
;              (apply solver/classify-featuremaps classifier)
;              ;(sequence xform)
;              (group-by :class))))

; (defn ->candidates
;   "Convenience function for classifying candidates in enhik using the model
;    specified by asset-class. asset-class is in #{:abs :cmo :corp :equity} and
;    defaults to :corp."
;   [enhik & [asset-class]]
;   (classify-candidates
;     {:enhanced-hickory enhik
;      :asset-class      (or asset-class :corp)
;      :cusip-docs       (cusips/enhik->cusip-docs enhik)}))

(defn classify-html-asset
  [html]
  (let [[binary-tfidf binary-classifier] (:binary asset-class/models)
        [multiclass-tfidf multiclass-classifier] (:multiclass asset-class/models)]
    (or (-> html (tfidf-enf/enfeature-tfidf binary-tfidf) binary-classifier :class #{:corp})
        (-> html (tfidf-enf/enfeature-tfidf multiclass-tfidf) multiclass-classifier :class))))

(defn classify-asset-class
  [query]
  (classify-html-asset (-> query sdfs/find-file :input-stream slurp html/html-contents)))
