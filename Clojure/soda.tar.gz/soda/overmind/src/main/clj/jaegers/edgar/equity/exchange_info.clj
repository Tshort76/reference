(ns jaegers.edgar.equity.exchange-info
  (:require [clojure.string :as str]
            [medley.core :as med]
            [jaegers.edgar.equity.exchange-mapping :as ex-map]
            [jaegers.edgar.equity.header-scraper :as head]
            [plumbing.core :refer [defnk]]))

(defn re-pattern-extended
  ([s]
   (clojure.core/re-pattern s))
  ([s & rst]
   (clojure.core/re-pattern (apply str s rst))))

(defn remove-filler-from-end [strs]
  (->> strs
       reverse
       (drop-while (partial re-find #"^[^A-Z]|^[Tt]he$"))
       reverse))

(defn clean-exchange-words [words]
  (->> words
       (map #(str/replace % #"[\W]" ""))
       (drop-while (partial re-find #"^[^A-Z]|^[Tt]he$"))
       (take-while (partial re-find #"^[A-Z]|^(?:the|of|and|or|market)$"))
       remove-filler-from-end
       (str/join " ")
       ex-map/exchange->mic))

; (defn clean-exchanges [text]
;   (when (string? text)
;     (->> (str/split text #"[(),]")
;          (map #(str/split (str/trim %) #"\s+"))
;          (keep clean-exchange-words)
;          seq)))

(defn clean-exchange [text]
  (when (string? text)
    (-> text
        str/trim
        (str/split #"\s+")
        clean-exchange-words)))



(def symbol-re
  #"(?:[sS]ymbol|[tT]icker)")

(def class-re
  #"(?:[Cc]lass|CLASS) ([A-Z](?:-\d)?)\b") ;; apparently "class V" is a thing

(def trade-re
  #"(?:trad(?:e[sd]?|ing)(?: \w+)?? (?:on|through)|quoted on|reported on|listed on)")

(def date-re
  #"(?:(Jan)|(Feb)|(Mar)|(Apr)|(May)|(Jun)|(Jul)|(Aug)|(Sep)|(Oct)|(Nov)|(Dec))[a-z]*\s?(\d)?(\d)[\s,]{1,3}(\d{4})")

(def otc-re
  #"[oO]ver[ -][tT]he[ -][cC]ounter")

(def exchange-n-ticker
  #"\((NYSE|NASDAQ) ?: ?([A-Z]{1,6})\)")


(defn class-fn [s]
  (when-let [[_ class] (re-find class-re s)]
    [{:share-class {:share-class class
                    :class-phrase s}}]))

(defn make-exchange [raw-exchange]
  (when-let [{:keys [mic exchange-name score orig iso-country-code exchange-code]}
             (clean-exchange raw-exchange)]
    {:exchange (med/assoc-some
                {}
                :exchange exchange-name
                :mic mic
                :exchange-code exchange-code
                :exchange-lookup-score score
                :exchange-lookup orig
                :country-of-issue iso-country-code)}))

(defn exchange-n-ticker-fn [s]
  (when-let [[_ exchange ticker] (re-find exchange-n-ticker s)]
    (some-> exchange
            make-exchange
            (assoc-in [:exchange :exchange-phrase] s)
            (assoc :ticker {:ticker ticker
                            :ticker-phrase s})
            vector)))

(def *exchange-fn-re
  (re-pattern-extended trade-re #"\s(.*)"))

(defn exchange-fn [s]
  (or (exchange-n-ticker-fn s)
      (some-> (re-matches *exchange-fn-re s)
              second
              make-exchange
              (assoc-in [:exchange :exchange-phrase] s)
              vector)
      (when (re-find otc-re s)
        [{:exchange {:exchange "over-the-counter"}}])))

(def *ticker-fn-re
  (re-pattern-extended symbol-re #"[^;)]{1,5}?\b([A-Z](?:[A-Z./-]{0,5}[A-Z])?)(?:,?[^\w);.]{1,5}([A-Z](?:[A-Z.\/-]{0,5}[A-Z])))?(?:[^\w);.]{1,5}and[^\w);.]{1,5}([A-Z](?:[A-Z./-]{0,5}[A-Z])?))?\b.*"))

(defn ticker-fn [s]
  (when-let [results (keep identity (rest (re-matches *ticker-fn-re s)))]
    (map (fn [ticker] {:ticker {:ticker ticker
                                :ticker-phrase s}}) results)))

(def splitter-regex
  (re-pattern-extended "(?=" date-re "|" symbol-re "|" class-re "|" exchange-n-ticker "|" trade-re "|" otc-re ")"))

(defn distinct-filter [key results]
  (->> results
       (map #(select-keys % [key]))
       (filter seq)
       (med/distinct-by (comp key key))))

(defn mash-lists [lists]
  (->> lists
       (keep first)
       ((fn [x]
          (when (seq x)
            [(reduce merge x)])))))

(defn distinct-exchange [exchanges]
  (med/distinct-by (juxt (comp :ticker :ticker)
                         (comp :exchange :exchange)
                         (comp :share-class :share-class))
                   exchanges))

(defn get-singles [docs]
  (->> docs
       (remove second)
       (group-by ffirst)
       vals
       (map distinct-exchange)
       (remove second)
       (map first)))

(defn mash-singles-2 [results]
  (let [singles (get-singles results)
        singles-values (apply merge singles)
        tuples (remove (set singles) results)]
    (reduce (fn [tuples [k v]]
              (let [{:keys [out inserted?] :as r}
                    (reduce (fn [{:keys [out inserted?] :as r} tuple]
                              (let [t-val (get tuple k)]
                                {:out (conj out (cond-> tuple (nil? t-val) (assoc k v)))
                                 :inserted? (or inserted? ({v true nil true} t-val))}))
                            {:out [] :inserted? false}
                            tuples)]
                (cond-> out
                        (not inserted?) (conj {k v}))))
            tuples
            singles-values)))

(defn mash-filter [docs]
  (->> docs
       (filter (some-fn :ticker :exchange :share-class))
       distinct-exchange))

(defn mash-singles [docs]
  (let [filtered (mash-filter docs)
        tickers (distinct-filter :ticker filtered)
        exchanges (distinct-filter :exchange filtered)
        classes (distinct-filter :share-class filtered)]
    (if (>= 1 (count tickers)
            (count exchanges)
            (count classes))
      (mash-lists [tickers exchanges classes])
      (mash-singles-2 filtered))))

(defn mash-only-singles [docs]
  (let [filtered (mash-filter docs)]
    (if (not (some second filtered))
      (->> filtered
           (group-by ffirst)
           vals
           (map distinct-exchange)
           (group-by count)
           ((fn [m]
              (let [add-single (->> (get m 1)
                                    (map first)
                                    (apply merge)
                                    repeat
                                    (partial apply mapv merge))]
                (mapcat add-single
                        (or (vals (dissoc m 1))
                            (when (seq (get m 1))
                              [[[{}]]]))))))
           vec)
      filtered)))

(defn process-exchange-group [sections]
  (mapcat (some-fn class-fn exchange-fn ticker-fn)
          sections))

(defn final-merge [results]
  (map (fn [x]
         (apply merge (vals x)))
       results))

(defn special-distinct
  "remove any duplicate single results without touching the multi-results"
  [results]
  (let [{keepers true
         singles false} (group-by #(> (count %) 1)
                                  results)
        res-set (->> keepers
                     (mapcat (partial map (fn [[k v]]
                                            {k ((some-fn :ticker :exchange :share-class) v)})))
                     (into #{}))]
    (->> singles
         final-merge
         (reduce (fn [s x]
                   (let [res-key (select-keys x [:ticker :exchange :share-class])]
                     (if (res-set res-key)
                       s
                       (-> (update s :set conj res-key)
                           (update :keep conj x)))))
                 {:set res-set
                  :keep (final-merge keepers)})
         :keep)))

(def end-sentence-re
  #"(?<=[.]\"?)\s(?=[A-Z])")

; http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/overmind/food/raw?md5=cbf28548d2d0b37eae01d82f2548c06a
; "Class A and Class B (prior to June 12, 2017)" - only class b is bad

; http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/overmind/food/raw?md5=e496fa806d1b2d10a64e1502c98e2744
; "to September 13"
(def old-re
  #"(?i)(?:prior|until|from( the period)? (?:[ADFJMNOS][a-z]{2,10} \d{1,2},? )?\d{4}|previously|initially|subsequently|have applied|for an?( [a-z]+)? period)")

(defn remove-units [exchange-specific]
  (let [possible-unit (into #{} (keep #(some->> % :ticker (re-find #".*[UW]$" ) drop-last (apply str)) exchange-specific))
        units (into #{} (mapcat (fn [base-ticker] [(str base-ticker "U")
                                                   (str base-ticker "W")]) (keep (comp possible-unit :ticker) exchange-specific)))]
    (remove (comp units :ticker) exchange-specific)))

(defn process-section [section]
  (->> (str/split section end-sentence-re)
       (remove (partial re-find old-re))
       (map #(str/split % splitter-regex))
       (mapcat (comp mash-only-singles process-exchange-group))
       mash-singles ;; last-ditch merge attempt
       (filter :ticker) ;; exchanges by themselves are usually wrong
       special-distinct
       remove-units))

(defn clean-html-text [text]
  (-> text
      (str/replace #"<[^>]+>" "")
      (str/replace #"&#?\w+;" " ")
      (str/replace #"[\s\n\r]+" " ")
      str/trim))

(defn sub-sections [texts]
  (loop [sections []
         texts texts]
    (if (seq texts)
      (let [[section texts] (->> texts
                                 (drop-while (complement (partial re-find #"^(?i)item\.? 5|MARKET FOR REGISTRANT.?S COMMON EQUITY, RELATED STOCKHOLDER MATTERS AND ISSUER PURCHASES OF EQUITY SECURITIES")))
                                 (split-with (complement (partial re-find #"^(?i)item\.? [0-46-9]"))))]
        (recur (conj sections section)
          (rest texts)))
      sections)))

(defn find-exchange-info [raw-text]
  (when raw-text
    (->> (str/split raw-text #"(?i)</?(?:p|div|table|hr|h\d)(?:\s[^>]+)?>")
         (map clean-html-text)
         (remove (partial = ""))
         sub-sections
         flatten
         (map process-section)
         (filter seq)
         first)))


;; exchange-info and header-info merge logic

(defn eq-or-nil? [a b]
  (or (nil? a)
      (nil? b)
      (< 0.7 (clj-fuzzy.jaro-winkler/jaro-winkler a b))))

(defn match-info [exchange-info header-info]
  (or
    (->> (for [h header-info]
           (if-let [ex (->> exchange-info
                            (filter (fn [x] (and (eq-or-nil? (:exchange h) (:exchange x))
                                                 (eq-or-nil? (:share-class h) (:share-class x)))))
                            (filter :ticker)
                            first)]
             (merge ex h)
             h))
         ; (filter :exchange)
         seq)
    exchange-info))
  ; (cond
  ;   (= 1 (count exchange-info)
  ;        (count header-info))
  ;   [(merge (first header-info) (first exchange-info))]
  ;
  ;   ;; TODO: add sophisticated matching algorithms
  ;
  ;   ; (and (seq exchange-info) ;; only for debugging/testing stuff
  ;   ;      (seq header-info))
  ;   ; {:head header-info :exch exchange-info}
  ;
  ;   :else (or (seq exchange-info)
  ;             (seq header-info))))

(defn omni-find-info [raw-text]
  (match-info (find-exchange-info raw-text)
              (head/find-10k-header-info raw-text)))


;we now use exchange-specific for the number of securities in the document
;todo sort out exchange-specific based on which security (primary exchange ticker?)
(defnk exchange-specific [raw]
  (omni-find-info (:ten-k raw)))


(defn format-output [output]
  {:class  :exchange-specific
   :jaeger :exchange-specific
   :value  output})

(defnk exchange-specific* [cusips exchange-specific]
  (->> exchange-specific
       (group-by (juxt :ticker :share-class))
       vals
       (mapv format-output)
       (zipmap cusips)))


;; TODO: debug this:
; http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/overmind/food/raw?md5=d4a27ad71164cb0fe92a011488ce4ede
; http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/overmind/food/raw?md5=fe197dd035029e0fdbbf07ce1cc06fb1
