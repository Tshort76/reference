(ns jaegers.muni.issue-principal-amount
  (:require [doc-transforms.core :as dtc]
            [clojure.string :as cs]
            [utils.simple-search :as ss]
            [monger.collection :as mc]
            [datasources.core :as ds]
            [taoensso.timbre :as timbre]
            [plumbing.core :refer [defnk]]))

(def money-regex #"\$\s*[,\d]{5,}")

(defn parse-double [double-str]
  (try
    (-> (re-find money-regex double-str)
        (cs/replace #"[%$,]|[.]$" "")
        (Double/parseDouble))
    (catch Exception e (do (timbre/warn (str "Issue Principal Amount JAEGER Parse Failure: " double-str "\n" (.getMessage e))) nil))))

(defn format-issue-principal-amount [number-vals]
  (when (not-empty number-vals)
    {:value  (reduce + (map :principal-amount number-vals))
     :ids    [(mapv :id number-vals)]
     :coords [(mapv ss/word->coord number-vals)]
     :jaeger :issue-principal-amount
     :class  :issue-principal-amount}))

(defn get-issue-principal-amount [tokens]
  (let [number-vals (sort-by :principal-amount
                             (map (comp #(assoc % :principal-amount (parse-double (:text %))) first)
                                  (vals (group-by :text tokens))))
        largest-val (last number-vals)
        rest-vals (butlast number-vals)]
    (if (= (:principal-amount largest-val) (reduce + (keep :principal-amount rest-vals)))
      [largest-val]
      number-vals)))

(defn mind-food->issue-principal-amount [mind-food]
  (let [bold-comps (->> mind-food
                        (take-while #(<= (:page-number %) 1))
                        (keep (comp not-empty (partial filter #(and (re-find money-regex (:text %)) (:bold? %)))
                                    flatten :vals)))
        largest-font-size (apply max (or (not-empty (map #(:font-size % 10) (flatten bold-comps))) [0]))
        select-comps (map (partial filter #(>= (:font-size % 10) (- largest-font-size 2))) bold-comps)]
    (format-issue-principal-amount
      (->> select-comps
           (map get-issue-principal-amount)
           flatten
           get-issue-principal-amount))))

(defnk issue-principal-amount* [mind-food cusips*]
  (zipmap
    (keys cusips*)
    (repeat (mind-food->issue-principal-amount mind-food))))

(comment

  (def get-mf
    (memoize
      (fn [md5]
        (dtc/mongo->transform :mind-food {:md5 md5}))))

  ;my test set
  (mind-food->issue-principal-amount (get-mf "c977649f8046628ae4e0630545801086"))
  (mind-food->issue-principal-amount (get-mf "a09d91303e254a838584fa06a35dc618"))
  (mind-food->issue-principal-amount (get-mf "b6e830ef4a2268660e12a5bf6cd11821"))
  (mind-food->issue-principal-amount (get-mf "9978c0e86044a56b980b9f8b2a6fa0e4"))
  (mind-food->issue-principal-amount (get-mf "0bb19d1658e3b32f2acc646ab2471d33"))
  (mind-food->issue-principal-amount (get-mf "ed411c0a1e1fa8eb76e35d0f720d0237"))
  (mind-food->issue-principal-amount (get-mf "240e33f625669648a1e1c20528b88e39"))
  (mind-food->issue-principal-amount (get-mf "85d78628a8e2ccc57c513a9e443f4abb"))
  (mind-food->issue-principal-amount (get-mf "0d84f7d0e4b5927674580c858d9becf3"))
  (mind-food->issue-principal-amount (get-mf "1c2570164a9afddcf6937f3855b57f5d"))

  ;SODA-1779
  (mind-food->issue-principal-amount (get-mf "07a16e46544cdadaaddc13a97f1b852e")) ;3.9195E7
  (mind-food->issue-principal-amount (get-mf "c4e017d55c5faf57874f1872670f3772")) ;1.718E7
  (mind-food->issue-principal-amount (get-mf "85d78628a8e2ccc57c513a9e443f4abb")) ;4.35E7
  (mind-food->issue-principal-amount (get-mf "d996bb1bd8e9c70107e88a8612b88bb1")) ;3.015E7
  (mind-food->issue-principal-amount (get-mf "9152c6c8809467db542446e8a92d4c17")) ;3.476E7

  ;SODA-1780
  (mind-food->issue-principal-amount (get-mf "5f7277aa3f20f07de615cf3701f0d68a"))

  ;SODA-1781
  (mind-food->issue-principal-amount (get-mf "7383f960cd428f5cc3bb5f8e32a32e1a")) ;1.2885E7
  (mind-food->issue-principal-amount (get-mf "4bdb4255f26d84ea24630c1591388fd8")) ;2.1194E8
  (mind-food->issue-principal-amount (get-mf "af7b263d34cf1901b5f206de61469a34")) ;4.2315E7
  (mind-food->issue-principal-amount (get-mf "3cd33bed7f2269126ed72bef850de2ea")) ;9.1195E7

  (do
    (require 'jaegers.md5-control-sets)
    (mc/remove (ds/get-db "mekadragon") "issue-principal-amount" {})
    (process-issue-principal-amount {:md5 {:$in jaegers.md5-control-sets/kilo-of-happiness}})))
