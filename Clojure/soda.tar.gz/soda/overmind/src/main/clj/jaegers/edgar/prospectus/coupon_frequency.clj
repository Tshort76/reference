(ns jaegers.edgar.prospectus.coupon-frequency
  (:require [clojure.string :as str]
            [clojure.pprint :refer [pprint]]
            [edgar.geometric-combo-linker :as gcl]
            [edgar.linker-chunker :as chunk]
            [jaegers.mind-food-utils :as mfu]
            [jaegers.regisector :as rs]
            [medley.core :as med]
            [plumbing.core :refer [defnk]]
            [tokenvec.core :as tv]))

(defn safe-min
  ([] nil)
  ([a] a)
  ([a b & args] (apply min a b args)))

(defn safe-max
  ([] nil)
  ([a] a)
  ([a b & args] (apply max a b args)))

(defn add-coords [m objects]
  (assoc m :min-x (apply safe-min (keep :min-x objects))
         :max-x (apply safe-max (keep :max-x objects))
         :min-y (apply safe-min (keep :min-y objects))
         :max-y (apply safe-max (keep :max-y objects))))

(defn format-index-values [sentence tokenvec {:keys [indexes value]}]
  (let [tokens (tv/unique-tokens tokenvec indexes)]
    (add-coords
     {:value value
      :text  sentence
      :class :coupon-frequency
      :jaeger :coupon-frequency
      :ids   [(mapv :id tokens)]}
     tokens)))

(defn add-overmind-details [details results]
  (mapv #(assoc % :overmind-details details) results))

(defn rate-matches [[sentence tokenvec]] ; frequency|
  (when (re-find #"(?i)interest payment|interest periods|pay interest|interest on the notes (will be paid|is payable)"
                 sentence)
    (->> (rs/dissect sentence
                     [{:regex #"(?i)(?<! [^x] )semi.?annually"
                       :handler (fn [v] {:value "Semi-annually"})}
                      {:regex #"(?i)(?<! [^x] )(quarterly|annually|weekly|monthly|daily)"
                       :handler (fn [v] {:value (str/capitalize (second v))})}
                      {:regex #"(?i)each month"
                       :handler (fn [v] {:value "Monthly"})}])
         (map (partial format-index-values sentence tokenvec))
         (add-overmind-details {:method :loose-rate-matches}))))

(defn maturity-matches [[sentence tokenvec]]
  (->> (rs/dissect sentence
                   [{:regex #"(?i)(?:will|do) not (?:bear|pay) interest|no interest payments|will bear no interest" ;payment at maturity
                     :handler (fn [_] {:value "At Maturity"})}])
       (map (partial format-index-values sentence tokenvec))
       (add-overmind-details {:method :loose-maturity-matches})))

(defn merge-matches [matches]
  (when-let [value (->> (keep :value matches)
                        distinct
                        count
                        {1 "Annually"
                         2 "Semi-annually"
                         4 "Quarterly"
                         12 "Monthly"})]
    (add-coords
     {:value value
      :text  (-> matches first :text)
      :class :coupon-frequency
      :ids   [(vec (apply concat (mapcat :ids matches)))]}
     matches)))

(defn safe-vector [x]
  (if x [x] []))

(defn process-month-results [sentence tokenvec results]
  (when (seq results)
    (->> results
         (drop-while (fn [x] (not= :begin (:value x))))
         (remove (fn [x] (= :begin (:value x))))
         (take-while (fn [x] (not= :end (:value x))))
         (map (partial format-index-values sentence tokenvec))
         merge-matches
         safe-vector)))

(defn month-matches [regex [sentence tokenvec]]
  (->> (rs/dissect sentence
                   [{:regex #"\(.*?\)"
                     :handler (fn [v] {:value nil})}
                    {:regex regex
                     :handler (fn [v] {:value :begin})}
                    {:regex #"January|February|March|April|May|June|July|August|September|October|November|December"
                     :handler (fn [v] {:value v})}
                    {:regex #"(?i)commenc|begin|initial|start|first"
                     :handler (fn [v] {:value :end})}])
       (filter :value)
       (process-month-results sentence tokenvec)))

(defn loose-month-matches [tokenvec]
  (->> tokenvec
       (month-matches #"(?i)interest on the notes (will be paid|is payable)|pay interest")
       (add-overmind-details {:method :loose-month-matches})))

(defn strict-month-matches [tokenvec]
  (->> tokenvec
       (month-matches #"(?i)pay(?:ment) dates")
       (add-overmind-details {:method :strict-month-matches})))

(defn tokenvec-apply [func tokenvec]
  (seq (mapcat func tokenvec)))

(defn find-coupon-frequency [enhik]
  (let [tokenvec (->> enhik
                      mfu/enhik->row-and-sentence-tokenvec
                      (med/distinct-by second))]
    (or (tokenvec-apply strict-month-matches tokenvec)
        (tokenvec-apply rate-matches tokenvec)
        (tokenvec-apply loose-month-matches tokenvec)
        (tokenvec-apply maturity-matches tokenvec))))

(defn resolve-fn [cusip-docs candidates ids->coords]
  (cond
    (= 1 (count (distinct (map :value candidates))))
    (zipmap cusip-docs (repeat (first candidates)))

    (<= 1 (count cusip-docs) (count candidates))
    (gcl/solve-for-edgar :coupon-frequency cusip-docs
                         {:coupon-frequency candidates}
                         ids->coords)

    :else
    (zipmap cusip-docs (repeat nil))))

(defnk coupon-frequency* [cusips ids->coords enhanced-hickory]
  (let [candidates (find-coupon-frequency enhanced-hickory)]
    (chunk/form-cusip-groups
     resolve-fn cusips candidates ids->coords)))
