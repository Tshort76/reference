(ns jaegers.features.enfeature
  (:require
    [clojure.pprint :as pp]
    [clojure.string :as string]
    [clojure.zip :as zip]
    [datascript.core :as d]
    [doc-transforms.core :as dtc]
    [enhanced-hickory.tokenvec :as eht]
    [hickory.select :as hs]
    [jaegers.features.queries :as q]
    [jaegers.hickory-utils :as hu]
    [jaegers.utils :as ju]
    [medley.core :refer [assoc-some distinct-by find-first map-keys map-vals]]
    [ml.tokenizers :as tok]
    [pdf-transforms-core.tokens.core :as pdf-tokens]
    [plumbing.core :refer [for-map]]
    [soda.core :refer [ptransduce] :as soda]
    [taoensso.tufte :refer [defnp]]
    [tokenvec.core :as tv]))

(def num-threads (* 2 (.. Runtime getRuntime availableProcessors)))

(defn loc->id-vec [loc] (some-> loc zip/node :attrs :id ju/id->vec))

(defmulti token-sort-fn
  "Given a file metadata map, dispatches on input-type to return a token sorting function"
  dtc/input-type)
(defmethod token-sort-fn :default [_] (partial sort-by (juxt :min-y :min-x :token-id)))
(defmethod token-sort-fn :pdf [_] pdf-tokens/sort-tokens)

(def schema
  {:token-id {:db/unique :db.unique/identity}
   :block-id {:db/cardinality :db.cardinality/one, :db/index true}
   :cell-id {:db/cardinality :db.cardinality/one, :db/index true}
   :row-id {:db/cardinality :db.cardinality/one, :db/index true}
   :table-id {:db/cardinality :db.cardinality/one, :db/index true}
   :component-id {:db/cardinality :db.cardinality/one, :db/index true}
   :column {:db/cardinality :db.cardinality/one, :db/index true}})

(defnp token->datom
  "Given a zip-loc from enhanced-hickory, returns a map of basic feature data
   intended for use as a datom.

   Computationally intensive features are implemented as lazy functions so they
   are only computed on demand, and are cached."
  [file-meta loc]
  (let [{:keys [file-type filename content-type md5]} file-meta
        {:keys [min-x min-y max-x max-y page-number]} (->> loc zip/node :attrs)
        text (->> loc zip/node :content first (#(string/replace % #"[\r\n\p{Z}]+" "")) not-empty)
        component (hu/parent-pred hu/body-child? loc)
        block (hu/parent-pred hu/block-level? loc)
        cell (hu/parent-pred hu/td? loc)
        row (hu/parent-pred hu/tr? loc)
        table (hu/parent-pred hu/table? loc)
        column (hs/count-until #(hs/left-pred % hu/td?) cell nil?)]
    (when-let [id (loc->id-vec loc)]
      (-> {:token-id id}
          (assoc-some
            :file-type file-type
            :filename filename
            :content-type content-type
            :md5 md5
            :dissect-fn (memoize #(some-> text tok/dissect-text first))
            :text text
            :page-number (soda/parse-long page-number)
            :horiz-alignment-fn (memoize #(hu/horiz-alignment loc))
            :vert-alignment-fn (memoize #(hu/vert-alignment loc))
            :component-id (loc->id-vec component)
            :block-id (loc->id-vec block)
            :cell-id (loc->id-vec cell)
            :row-id (loc->id-vec row))
          (cond->
            (and max-y min-y) (assoc :max-y max-y :min-y min-y :y min-y :height (- max-y min-y))
            (and max-x min-x) (assoc :max-x max-x :min-x min-x :x min-x :width (- max-x min-x))
            table (assoc-some :table-id (loc->id-vec table) :column column))))))

(defn datom->dissection
  "Returns the dissection for the given datom from dissect-map"
  [dissect-map {:keys [token-id]}]
  (let [id (string/join "_" token-id)
        f (get dissect-map id)]
    (when f
      (find-first (fn [{:keys [ids]}] (ids id)) (f)))))

(defn datoms-around
  "Splits datoms at ids, returning a vector of [all-datoms datoms-preceding datoms-following]"
  [datoms ids & [{:keys [sort-fn] :or {sort-fn (partial sort-by :db/id)}}]]
  (let [in-ids? (set ids)]
    (->> datoms
         sort-fn
         (partition-by (comp #(<= (apply min ids) % (apply max ids)) :db/id))
         (map (partial remove (comp in-ids? :db/id)))
         ((juxt first last))
         (cons datoms))))

(defn datoms-around-cell
  "Like datoms-around, but also removes datoms in the same cell-id"
  [datoms id cell-id & [{:keys [sort-fn] :or {sort-fn (partial sort-by :db/id)}}]]
  (->> datoms
       sort-fn
       (split-with (comp (complement #{id}) :db/id))
       (map (partial remove (comp #{cell-id} :cell-id)))
       (cons datoms)))

(defn eids-around
  "Like datoms-around, but only returns entity ids instead of complete datoms"
  [datoms ids & [opts]]
  (map (partial map :db/id) (datoms-around datoms ids opts)))

(defn eids-around-cell
  "Like datoms-around-cell, but only returns entity ids instead of complete datoms"
  [datoms id cell-id & [opts]]
  (map (partial map :db/id) (datoms-around-cell datoms id cell-id opts)))

(defn word-count-query
  "Returns the number of words matched by the given datascript query or sequence of datoms"
  ([db datoms]
   (->> datoms (d/pull-many db [:text]) (keep :text) count))
  ([db query {:keys [:db/id]}]
   (word-count-query db (d/q query db id))))

(defn term-count-query
  "Returns a frequency map of terms matched by the given datascript query or sequence of datoms"
  ([db datoms filter-fn dissect-map suffix]
   (->> datoms
        (d/pull-many db [:token-id :cell-id :row-id :text :features])
        filter-fn
        (map (partial datom->dissection dissect-map))
        distinct
        (keep (comp :value-type :features))
        frequencies
        (map-keys #(keyword (str (name %) (or suffix ""))))))
  ([db query filter-fn dissect-map suffix {:keys [:db/id]}]
   (term-count-query db (d/q query db id) filter-fn dissect-map suffix)))

(defn value-features
  [db _ [{:keys [dissect-fn page-number vert-alignment-fn horiz-alignment-fn]}]]
  (let [{:keys [string value features]} (dissect-fn)]
    {:page-number (or page-number 0)
     :vert-alignment (vert-alignment-fn)
     :horiz-alignment (horiz-alignment-fn)
     :magnitude (or (when (number? value) (hu/magnitude value)) 0)
     :precision (or (when (-> features :value-type #{:double :percent}) (hu/precision string)) 0)
     :multiple-of-1000? (boolean (when (number? value) (hu/multiple-of? value 1000)))}))

(defn block-features
  [db dissect-map [{:keys [:db/id text]} :as datoms]]
  (let [block-datoms (map (partial hash-map :db/id) (d/q q/block-toks db id))
        [all before after] (eids-around block-datoms (map :db/id datoms))]
    (merge
      {:words-in-block (or (word-count-query db all) 0)
       :words-before (or (word-count-query db before) 0)
       :words-after (or (word-count-query db after) 0)}
      (term-count-query db all identity dissect-map "-terms-in-block")
      (term-count-query db before identity dissect-map "-terms-before")
      (term-count-query db after identity dissect-map "-terms-after"))))

(defn table-features
  [db _ [{:keys [:db/id cell-id] :as datom}]]
  (when cell-id
    (let [[col _ max-col] (d/q q/column-indexes db id)]
      {:row-count (count (d/q q/row-ids db id))
       :col-count (or max-col 0)
       :first-column? (= col 1)
       :last-column? (and col (= col max-col))
       :words-in-table (or (word-count-query db q/table-cells datom) 0)
       ; TODO
       :table-nest-depth 1})))

(defn row-features
  [db dissect-map [{:keys [:db/id cell-id] :as datom}]]
  (when cell-id
    (let [row-datoms (d/pull-many db [:db/id :cell-id :text] (d/q q/row-cells db id))
          [all before after] (eids-around-cell row-datoms id cell-id)
          row-label (fn [xs] (->> xs (sort-by :row-id #(compare %2 %1)) (partition-by :row-id) first))]
      (merge
        {:words-in-row (or (word-count-query db all) 0)
         :words-in-row-before (or (word-count-query db before) 0)
         :words-in-row-after (or (word-count-query db after) 0)}
        (term-count-query db before identity dissect-map "-terms-in-row-before")
        (term-count-query db after identity dissect-map "-terms-in-row-after")
        (term-count-query db q/nearest-row-labels row-label dissect-map "-terms-in-nearest-row-label" datom)))))

(defn col-features
  [db dissect-map [{:keys [:db/id cell-id] :as datom}]]
  (when cell-id
    (let [col-datoms (d/pull-many db [:db/id :cell-id] (d/q q/column-cells db id))
          [all above below] (eids-around-cell col-datoms id cell-id)
          above-count (or (word-count-query db above) 0)
          below-count (or (word-count-query db below) 0)]
      (merge
        {:words-in-col (or (word-count-query db all) 0)
         :words-in-col-above above-count
         :words-in-col-below below-count
         :first-row? (zero? above-count)
         :last-row? (zero? below-count)}
        (term-count-query db above identity dissect-map "-terms-in-col-above")
        (term-count-query db below identity dissect-map "-terms-in-col-below")))))

(def feature-fns [value-features block-features table-features row-features col-features])

(defnp enhik->db
  "Creates a datascript db from tokens in enhik"
  [dissect-fn enhik]
  (let [xform (comp (filter (comp :token? zip/node)) (keep (partial token->datom {})))]
    (->> (hs/select-locs hs/element enhik)
         (ptransduce num-threads xform conj [])
         (d/db-with (d/empty-db schema)))))

(defn file-transform->db [{:keys [enhanced-hickory] :as file-meta}]
  (when enhanced-hickory
    (let [xform (comp (filter (comp :token? zip/node)) (keep (partial token->datom file-meta)))]
      (->> (hs/select-locs hs/element enhanced-hickory)
           (ptransduce num-threads xform conj [])
           (d/db-with (d/empty-db schema))))))

(defn query->db
  "Creates a datascript db based on the document identified by query"
  ([query]
   (file-transform->db (dtc/mongo->transform :enhanced-hickory query)))
  ([_ query]
   (query->db query)))

(defn default-feature [m]
  (cond
    (contains? m :default) (:default m)
    (-> m :options #{:implicit}) 0))

(defn enfeature-value
  [db fdesc dissect-map [s toks] v]
  (let [ids (some->> v :indexes (tv/unique-tokens toks) (keep :id) vec)
        datoms (keep (fn [id] (d/entity db [:token-id (ju/id->vec id)])) ids)]
    (when (and ids datoms)
      (-> (assoc v :sentence s :ids [ids])
          (update :features (partial apply merge) (map (fn [f] (f db dissect-map datoms)) feature-fns))
          ; add defaults for missing features
          (update :features (partial merge (map-vals default-feature fdesc)))
          ; remove features the model isn't aware of
          (update :features select-keys (keys fdesc))))))

(defn enfeature-tokenvec
  [db fdesc dissect-fn dissect-map [s :as tv]]
  (->> (dissect-fn s)
       (remove (some-fn nil? (comp :term? :features)))
       (keep (partial enfeature-value db fdesc dissect-map tv))
       seq))

(defn dissect-sentence
  [s toks dissect-fn]
  (for [{:keys [indexes] :as d} (dissect-fn s)
        :when indexes]
    (assoc d :ids (set (map :id (tv/unique-tokens toks indexes))))))

(defnp tvs->dissect-map
  "Returns a map of id to lazy dissection fn"
  [dissect-fn tvs]
  (for-map
    [[s toks] tvs
     :let [f (memoize #(dissect-sentence s toks dissect-fn))]
     {:keys [id]} (distinct-by :id toks)
     :when id]
    id f))

(defn enfeature-tokenvecs
  [db fdesc dissect-fn tvs]
  (let [dissect-map (tvs->dissect-map dissect-fn tvs)
        xform (mapcat (partial enfeature-tokenvec db fdesc dissect-fn dissect-map))]
    (ptransduce num-threads xform conj [] tvs)))

(defn enfeature-value-by-ids
  "Enfeatures the value(s) in enhik given by ids"
  [enhik db fdesc dissect-fn & ids]
  (let [select-fn (apply hs/or (map (partial hs/id) ids))
        tvs (eht/enhik->tokenvecs (hs/select select-fn enhik))]
    (when enhik
      (enfeature-tokenvecs db fdesc dissect-fn tvs))))
