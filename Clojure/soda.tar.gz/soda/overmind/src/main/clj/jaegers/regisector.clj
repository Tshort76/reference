(ns jaegers.regisector
  (:require [clojure.string :as cs]
            [taoensso.tufte :refer [defnp]]
            [taoensso.timbre :as timbre]
            [clojure.pprint :as pp]))

(defn result-string [s] (cond-> s (coll? s) first))
(def rgx-count (comp count result-string))
(defn default-string-parser [s]
  (cond-> s ((complement string?) s) first))

(defnp create-match
  [a {:keys [handler parser value-type] :as m :or {parser default-string-parser}}]
  (cond
    (and handler parser value-type)
    (do
      (timbre/warn (into m {:reason :overspecified-splitter :using (select-keys m [:parser :value-type])}))
      {:value (parser a) :features {:value-type value-type}})
    (and parser value-type)
    {:value (parser a) :features {:value-type value-type}}
    handler (handler a)))

(defnp rgx-split [s {:keys [regex handler validator parser value-type] :as m}]
  (loop [[f & r] (cs/split s regex) [a & b] (re-seq regex s) res []]
    (if (or f a)
      (recur r b
             (try (cond-> res
                          f (conj f)
                          a (conj (assoc (create-match a m)
                                    :count (rgx-count a)
                                    :string (result-string a))))
                  ;Any exceptions thrown while parsing/handling token should be treated as if token were never matched
                  (catch Exception e
                    (timbre/debug (str "Exception while attempting to parse matched value: "
                                       (with-out-str (pp/pprint s))
                                       ", with matcher: " (with-out-str (pp/pprint m))))
                    res)))
      res)))

(defnp reindex [s]
  (loop [[{:keys [count] :as f} & r] s start 0 res []]
    (if-some [u (some-> f (dissoc :count) (assoc :indexes [start (+ start count)]))]
      (recur r (+ start count) (conj res u))
      res)))

(defnp rgx-seqsplit [r s] (->> s (map #(cond-> % (string? %) (rgx-split r))) flatten))

;(defnp re-string [start-string {:keys [indexes] :as m}]
;  (assoc m :sentence start-string :fragment (apply subs start-string indexes)))

(def leftover-splits
  [{:regex #"\W+" :handler (constantly {:other-type :nonwords})}
   {:regex #".+" :handler (fn [s] {:other-type :dregs :value s})}])

(defn dissect [start-string regexes]
  (loop [feature-strings [start-string]
         [r & rs] (into (vec regexes) leftover-splits)]
    (if r
      (recur (rgx-seqsplit r feature-strings) rs)
      (->> feature-strings
           (remove empty?)
           reindex
           (remove :other-type)
           (mapv (fn [{:keys [value value-type] :as m}] (if value m value-type)))))))
