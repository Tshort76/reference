(ns jaegers.edgar.prospectus.debt-level
  (:require [plumbing.core :refer [defnk]]))

(defn jaeger-form [value ids]
  {:jaeger ::debt-level :value value :ids ids :class :debt-level})

(defn issue-desc->debt-level [issue-desc]
  (if (and issue-desc (re-find #"(?i)subordinated" issue-desc))
    :Subordinated
    :Senior))

(defnk debt-level* [issue-description*]
  (zipmap
   (keys issue-description*)
   (map (fn [{:keys [value ids]}]
          (jaeger-form (issue-desc->debt-level value) ids))
        (vals issue-description*))))
