(ns jaegers.edgar.prospectus.security-alias
  (:require
    [plumbing.core :refer [defnk]]
    [clojure.string :as cs]))

;todo do a better job at aliasing
;case1: dealing with fixed vs floating in a alias
;case2: dealing with things like 'Series A Bonds'

(def alias-re #"(?i)(?:notes|bonds) due \d{4}|\d{4} (?:notes|bonds)")
(def months "(?:jan|january|feb|february|mar|march|apr|april|may|jun|june|jul|july|aug|august|sep|september|oct|october|nov|november|dec|december)")

(def parse-alias-re (re-pattern (str "(?i)(notes|bonds|series),? (?:series .,? )?due " months "? ?(?:\\d{1,2},? )?(\\d{4})|(\\d{4}) (notes|bonds|series)")))

(defn parse-alias [s]
  (some->> (re-find parse-alias-re s)
           (map #(if (= "" %) nil %))
           ((fn [[_ type1 date1 date2 type2]]
              (let [type (or type1 type2 "")
                    date (or date1 date2 "")]
                (cs/lower-case (str date " " type)))))))

(defn parse-quotes [s]
  (some->> (re-find #"(?i)(?:&#147|\u0093|\")(.*?)(?:\u0094|&#148|\")" s)
           second
           cs/trim
           cs/lower-case))

(defn jaeger-form [value ids]
  {:jaeger ::security-alias :value value :ids ids :class :security-alias})

(defn issue-desc->alias [issue-desc]
  (if-let [in-quotes (parse-quotes issue-desc)]
       in-quotes
       (if-let [alias (parse-alias issue-desc)] alias)))

(defnk security-alias* [issue-description*]
  (let [documents (zipmap (keys issue-description*)
                          (map (fn [{:keys [value ids]}]
                                 (jaeger-form (issue-desc->alias (or value "")) ids))
                               (vals issue-description*)))]
    (into {} (filter (comp :value second) documents))))
