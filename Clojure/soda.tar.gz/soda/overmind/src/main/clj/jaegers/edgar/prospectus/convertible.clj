(ns jaegers.edgar.prospectus.convertible
  (:require
            [clojure.spec.alpha :as s]
            [jaegers.edgar.tokens :as ec]
            [jaegers.jaeger-primer :as primer]
            [jaegers.core :as jcr]
            [plumbing.core :refer [defnk]]))

(defn get-candidates [enhik]
  (not-empty
    (ec/token-regex
      (filter #(and (not-empty (:text %)) (not-empty (:id %)))
              (ec/extract-tokens enhik))
      #"(?i)exchange (right|period)")))

(defnk convertible* [enhanced-hickory issue-description*]
  (let [candidates (get-candidates enhanced-hickory)]
    (zipmap
      (keys issue-description*)
      (map
        (fn [{:keys [value]}] {:value (boolean (or (some->> value (re-find #"(?i)convertible|exchangeable")) candidates))
                               :jaeger ::convertible
                               :class :convertible})
        (vals issue-description*)))))