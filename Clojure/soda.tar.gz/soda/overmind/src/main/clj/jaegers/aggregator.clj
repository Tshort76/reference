(ns jaegers.aggregator
  (:require
    [clojure.pprint :refer [pprint]]
    [jaegers.jaeger-primer :as jp]
    [jaegers.muni.core :as jmc]
    [jaegers.edgar.prospectus.core :as jec]
    [jaegers.edgar.entity.core :as edgar-entity]
    [jaegers.edgar.equity.core :as edgar-equity]
    [taoensso.timbre :as timbre]
    [jaegers.cusip-linking.core :as clc]))

(defmulti accrete (fn [omni & _] (-> omni :file-type keyword)))

(defmethod accrete :edgar-prospectus [omni-data & jaegers]
  (let [docs (if jaegers
               (jec/execute-lazy-jaeger omni-data jaegers)
               (jec/execute-parallel-jaeger omni-data))]
    (cond-> []
      (seq docs) (conj {:jaeger-docs docs,
                        :meta {:data-type :edgar-prospectus,
                               :tags ["edgar"]}}))))

(defn process-edgar-entity-equity [omni-data jaegers]
  (let [entity-docs (if jaegers
                      (edgar-entity/execute-lazy-jaeger omni-data jaegers)
                      (edgar-entity/execute-parallel-jaeger omni-data))
        equity-docs (if jaegers
                      (edgar-equity/execute-lazy-jaeger omni-data jaegers)
                      (edgar-equity/execute-parallel-jaeger omni-data))]
    (cond-> []
      (seq entity-docs) (conj {:jaeger-docs entity-docs,
                               :meta {:data-type (-> omni-data :file-type keyword)
                                      :tags ["edgar" "entity"]}})
      (seq equity-docs) (conj {:jaeger-docs equity-docs,
                               :meta {:data-type :edgar-equity,
                                      :tags ["edgar" "equity"]}}))))

(defmethod accrete :edgar-10k [omni-data & jaegers]
  (process-edgar-entity-equity omni-data jaegers))

(defmethod accrete :edgar-20f [omni-data & jaegers]
  (process-edgar-entity-equity omni-data jaegers))

(defmethod accrete :muni-jaeger [omni-data & jaegers]
  (let [docs (if jaegers
               (jmc/execute-lazy-jaeger omni-data jaegers)
               (jmc/execute-parallel-jaeger omni-data))]
    (cond-> []
      (seq docs) (conj {:jaeger-docs docs,
                        :meta {:data-type :muni-jaeger,
                               :tags ["us-muni"]}}))))

(defmethod accrete :default [omni-data & _]
  (timbre/warn "Unknown accreting filetype: " (:file-type omni-data)))

(defn unstructured-files-types []
  (->> (methods accrete)
       keys
       (remove (partial = :default))
       (apply sorted-set)))
;; -----------------------------------------------------------------------------

;These are the two sources of pain and suffering in the system.
;Mephistopheles
(defn md5->security-docs [md5 & rst]
  (apply accrete (jp/query->omni-data {:md5 md5}) rst))

;Mephistopheles jr.
(defn md5->cusip-linked-docs [md5 data-type]
  (->> (accrete (jp/query->omni-data {:md5 md5}))
       (mapcat :jaeger-docs)
       (map #(hash-map :jaeger-doc %
                       :meta {:data-type data-type}))
       clc/handle-cusipless))
