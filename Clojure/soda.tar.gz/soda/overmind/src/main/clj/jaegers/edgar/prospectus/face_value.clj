(ns jaegers.edgar.prospectus.face-value
  (:require
    [clojure.spec.alpha :as s]
    [jaegers.spec]
    [jaegers.edgar.cluster :as c]
    [plumbing.core :refer [fnk defnk]]
    [clojure.pprint :as pp]))

(def default {:jaeger ::face-value :value 1000.0})

;; However, it seems we always end up with $1000.
(defn face-value-fn [{:keys [face-value]} cusips]
  (let [clusters (->> face-value (map #(assoc % :jaeger ::face-value)) c/cluster-fields)
        fvfn (if (seq clusters) (partial c/merge-doc clusters [:face-value]) #(assoc % :face-value default))]
    (mapv fvfn cusips)))
