(ns jaegers.edgar.entity.subsidiaries
  (:require
    [edgar.subsidiaries :as sub]
    [plumbing.core :refer [defnk]]))

(def cik-path [:filer 0 :company-data 0 :central-index-key 0])
(def org-path [:filer 0 :company-data 0 :company-conformed-name 0])

(defn subsidiaries [enhik org]
  (some->>
    enhik
    sub/enhik->subsidiaries
    (remove (comp #{(sub/normalize-name org)} sub/normalize-name :name))))

(defnk subsidiaries* [enhanced-hickory header]
  (hash-map
    {:cik {:class :cik, :value (get-in header cik-path)}}
    {:class :subsidiaries,
     :value (subsidiaries (:submission enhanced-hickory)
                          (get-in header org-path))}))

(defnk entity-name* [header]
  (hash-map
    {:cik {:class :cik, :value (get-in header cik-path)}}
    {:class :entity-name, :value (get-in header org-path)}))
