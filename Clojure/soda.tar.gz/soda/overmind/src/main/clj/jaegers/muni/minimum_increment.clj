(ns jaegers.muni.minimum-increment
  (:require [utils.simple-search :as simple-search]
            [clojure.string :as cs]
            [simple-mind.parse-objects-utils :as pou]
            [plumbing.core :refer [defnk]]
            [jaegers.jaeger-primer :as primer]
            [tfidf.core :as tfidf]
            [jaegers.mind-food-utils :as mfu]))

(def money-like #"\$[\d,]+")
(def pattern (re-pattern (format "(?i)%1$s \\D{0,100}integral multiples?( of {10})|(whole|integral) multiples? of %1$s|integrals? of %1$s|(denominations?|principal amounts?).{0,10} %1$s .{0,10}(and (equal multiples?|integrals?) of %1$s|(or|and) .{0,10}(integral|multiples?) .{0,10}thereof)" money-like)))

(def minimum-increment-ref-paragraphs
  (mapv #(cs/split % #"\s")
        ["Denominations $5,000 or any integral multiple thereof"
         "$5,000 of principal due on a specific maturity date or integral multiples thereof"
         "Individual purchases may be made in the principal amount of $1,000 integrals"
         "in denominations of $5,000 of principal or any integral multiple thereof"
         "issued in denominations of $5,000 principal amount or maturity value as applicable or any integral multiple thereof"
         "Initial Denominations Multiples of $5,000."
         "purchased in amounts of $5,000 of principal due on a specific maturity date or integral multiples thereof"
         "in the amount of $1,000 or any integral multiple there of with a minimum purchase of $5,000 required"
         "Denomination $5,000 or integral multiples thereof."
         "in amounts of $5,000 of principal due on a specific maturity date or integral multiples thereof"]))

(defn minimum-increment-language? [s]
  (->> minimum-increment-ref-paragraphs
       (map (partial tfidf/calc-cosine-similarity s))
       (some (partial < 0.6))))

(defn parse-minimum-increment [text]
  (some-> (last (re-seq money-like text))
          (cs/replace #"[^\d]" "")
          (Integer/parseInt)))

(defn cleanup-objs [objs]
  (->> objs
       (group-by :text)
       vals
       (map first)
       (remove nil?)))

(defn create-jaeger [{text :text objs :objs}]
  (when (and (not (cs/blank? text)) (not-empty objs))
    (when-let [value (parse-minimum-increment text)]
      {:value  value
       :text   text
       :ids    [(mapv :id objs)]
       :coords [(mapv simple-search/word->coord objs)]
       :jaeger :minimum-increment
       :class  :minimum-increment})))

(defn tfidf-find-minimum-increment [mindfood]
  (some->> (mfu/mind-food->sentence-tokenvecs mindfood)
           (map (fn [[text objs]] {:text text :objs (cleanup-objs objs)}))
           (filter (comp minimum-increment-language? #(cs/split (:text %) #"\s")))
           not-empty
           (map create-jaeger)))

(defn mind-food->minimum-increment [mind-food]
  (when (not-empty mind-food)
    (not-empty
      (keep create-jaeger
            (pou/rematch-in pattern [:text] (flatten (map :vals mind-food)))))))

(defnk minimum-increment* [mind-food cusips*]
  (let [mis (or (mind-food->minimum-increment mind-food)
                (tfidf-find-minimum-increment mind-food))]
    (zipmap
      (keys cusips*)
      (if (= (count mis) (count cusips*)) mis (repeat (first mis))))))

(comment
  (def memoized-query-omni-data
    (memoize (fn [q] (primer/query->omni-data q))))

  (keep (juxt :cusip-9 :minimum-increment)
        (run-all {:md5 "a00c959d6f1fe4de0e5f33f090f54938"})))
