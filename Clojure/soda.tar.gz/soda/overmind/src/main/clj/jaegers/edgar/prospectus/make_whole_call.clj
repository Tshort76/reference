(ns jaegers.edgar.prospectus.make-whole-call
  (:require
    [clojure.spec.alpha :as spec]
    [edgar.geometric-combo-linker :as gcl]
    [jaegers.mind-food-utils :as mfu]
    [jaegers.regisector :as rs]
    [jaegers.core :as jcr]
    [jaegers.jaeger-primer :as primer]
    [plumbing.core :refer [defnk]]
    [clojure.pprint :as pp]
    [tokenvec.core :as tv]))

(defn tokenvec->matches
  [[sentence tokenvec]]
  (let [results (rs/dissect
                  sentence
                  [{:regex   #"(?i)(?:make[-\s]?whole|at any time|redemption.*?(?:\bt\b|treasury)|discount rate)"
                    :handler (fn [v] {:value v})}
                   {:regex   #"(\d+(?:\.\d+)?)\s*(basis|points|bps|%(?!.{0,20}principal amount))"
                    :handler (fn [v] {:value v})}])]
    (when (some (comp string? :value) results)
      (->> results
           (remove (comp string? :value))
           ((fn [rs]                                        ;; we shouldn't get a mix of basis-points and percents
              (if (some (comp (every-pred (partial not= "%") some?)
                              last
                              :value)
                        rs)
                (remove (comp (partial = "%") last :value) rs)
                rs)))
           (map (fn [{[_ value type] :value :keys [indexes]}]
                  {:value (cond-> (Double/parseDouble value)
                                  (= "%" type) (* 100))
                   :text  sentence
                   :class :make-whole-call-spread
                   :jaeger :make-whole-call-spread
                   :ids   [(mapv :id (tv/unique-tokens tokenvec indexes))]}))
           vec))))

(defn find-spreads [enhik]
  (mapcat tokenvec->matches (mfu/enhik->row-tokenvec enhik)))

(defnk make-whole-call-spread* [enhanced-hickory cusips ids->coords coupon-rate-type*]
  (let [fixed-cusips (keys (filter (fn [[_ {:keys [value]}]] (#{:Fixed} value)) coupon-rate-type*))
        spreads (find-spreads enhanced-hickory)]
    (cond
      (<= 1 (count cusips) (count spreads))
      (gcl/solve-for-edgar :make-whole-call-spread cusips {:make-whole-call-spread spreads} ids->coords)

      (<= 1 (count fixed-cusips) (count spreads))
      (gcl/solve-for-edgar :make-whole-call-spread fixed-cusips {:make-whole-call-spread spreads} ids->coords))))

;; -----------------------------------------------------------------------------

(comment
  (def test-md5s
    (map first
         [["359904d962cf5e64e58a4aa5d2c36265" "0001193125-10-151251.txt"]
          ["55c1222a19de4122ddc28d9d8020b4c6" "0001193125-12-047107.txt"]
          ["0213e1a64d68a434bd773411b9514a38" "0000004904-11-000007.txt"]
          ["b2d11b2f098cd2f0ae195c18884ef84b" "0001104659-15-001892.txt"]
          ["0c04782408da36deac1e13f8e6e01d99" "0001104659-16-134159.txt"]
          ["5a0af710365e54226f93c75a44d1afc1" "0001193125-16-794686.txt"]
          ["156f4009c95b5f54ce81a8ae0e53088d" "0000891092-12-004478.txt"]
          ["44a7a182fdbd221f1f12ac632d83e077" "0001193125-12-034543.txt"]
          ["4532432a60c7183fa1c6021f245e1790" "0001193125-12-485934.txt"]
          ["2d1fddbc7f7088d1964ed5f4c98dbf65" "0001104659-14-016480.txt"]]))

  (def test2-md5s
    (map first
         [["fbf1e7361c0a7b29a40564124092a634" "0000903423-16-001315.txt"]]))

  (def memoized-query-omni-data
    (memoize (fn [q] (primer/query->omni-data q))))

  (run-all {:md5 (first test-md5s)}))
