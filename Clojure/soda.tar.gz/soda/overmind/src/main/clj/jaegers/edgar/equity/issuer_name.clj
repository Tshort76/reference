(ns jaegers.edgar.equity.issuer-name
  (:require [plumbing.core :refer [defnk]]))


(defn jaeger-form [issuer-name]
  (when issuer-name
    {:overmind-details {:method :header}
     :class            :issuer-name
     :value            issuer-name}))

;todo confirm this is a good idea.
(defnk issuer-name* [cusips header]
  (when header
    (let [issuer-name (->> header :filer (some :company-data) (some :company-conformed-name) first jaeger-form)]
      (zipmap cusips (repeat issuer-name)))))