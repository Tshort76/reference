(ns jaegers.muni.candidate-linker-utils
  (:require [clj-time.core :as t]
            [clj-time.coerce :as co]
            [clojure.pprint :as pp]))

(defn ps [something]
  (with-out-str (pp/pprint something)))

(defn correct-msrb-filter
  "When trying to determine correctness, we sometimes need to filter
  out bad msrb data"
  [docs]
  (filter
    (fn [d]
      (and
        (d :maturity-principal-amount)
        (d :initial-offering-price)
        (#{"Underwritten"} (d :security-status)))
      ) docs))

(defn correct-cusip-doc-filter
  "This represents the minimum amount of ifnromation we'd expect a cusip doc to have"
  [docs]
  (filter
    (fn [[k d]]
      (and
        (d :principal-amount)
        (d :interest-rate))) docs))


(defn normalize-solution [[cusip values]]
  {cusip
   {:cusip-9          (get-in values [:cusip-9 :value])
    :maturity-date    (get-in values [:maturity-date :value])
    :principal-amount (get-in values [:principal-amount :value])
    :interest-rate    (get-in values [:interest-rate :value])
    :maturity-year    (get-in values [:maturity-year :value])
    }})

(defn normalize-supplement [supplement]
  {(:cusip-9 supplement)
   {:cusip-9          (:cusip-9 supplement)
    :maturity-date    (:maturity-date supplement)
    :maturity-year    (t/year (co/from-date (:maturity-date supplement)))
    :principal-amount (:maturity-principal-amount supplement)
    :interest-rate    (:interest-rate supplement)
    }})

(defn gb [loc coll] (get-in coll loc))



(defn score-helper [key m1 m2]
  ; (debug (ps [key m1 m2]))
  (if (= (key m1) (key m2)) 1 0))

(defn score-by-cusip [solution supplement]
  (let [score (+ (score-helper :principal-amount solution supplement)
                 (score-helper :interest-rate solution supplement)
                 (if (zero? (score-helper :maturity-date solution supplement))
                   (score-helper :maturity-year solution supplement)
                   (score-helper :maturity-date solution supplement)))
        ]
    [score 3]))

;this could be more accurate using a bag of values from the
;candidates and function to allow "minus" from the bag.
(defn score-by-principal-amount [candidates supplements]
  (let [c-set (into #{} (map :value (:principal-amount candidates)))
        s-set (into #{} (map :maturity-principal-amount supplements))
        diff (clojure.set/difference s-set c-set)
        ]

    ; (clojure.pprint/pprint c-set)
    ; (clojure.pprint/pprint s-set)
    [(- (count s-set) (count diff)) (count s-set)]))



(defn pmapcat [fnk col]
  (reduce concat (pmap fnk col)))





