(ns jaegers.muni.date-of-applicability
  (:require [util.date-time :as dt]
            [clj-time.coerce :as tc]))

(defn- parse [t]
  (cond
    (string? t) (dt/date->yyyy-mm-dd (.toDate (tc/from-string t)))
    (inst? t) (dt/date->yyyy-mm-dd t)
    :else nil))

(defn- get-val [m]
  (parse (first (keep (comp not-empty :value) (vals m)))))

(defn choose [cusips
              submission-transaction-date-time
              official-stated-dated-date
              date-of-delivery
              issue-dated-date]
  (let [value (some get-val [submission-transaction-date-time
                             official-stated-dated-date
                             date-of-delivery
                             issue-dated-date])]
    (zipmap (keys cusips) (repeat {:jaeger :date-of-applicability
                                   :class  :date-of-applicability
                                   :value value}))))
