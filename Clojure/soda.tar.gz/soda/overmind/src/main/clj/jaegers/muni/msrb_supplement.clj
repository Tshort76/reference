(ns jaegers.muni.msrb-supplement
  (:require [plumbing.core :refer [defnk]]
            [clojure.set :as cset]))

(defn normalize [{meta :meta :as doc}]
  (->> (cset/rename-keys (dissoc doc :meta)
                         {:issuer-state                         :state-code
                          :initial-offering-yield               :yield
                          :initial-offering-price               :price
                          ;:security-dated-date       :issue-date ;TODO:not sure about this one
                          :maturity-principal-amount            :principal-amount
                          :original-cusip9-of-refunded-security :cusip-9})
       (map (fn [[k v]] {k {:value v :jaeger :msrb :meta meta}}))
       (apply merge)))

(defn get-msrb [msrb-supplemental-data cusips-jaeger]
  (let [msrb-data (mapv normalize msrb-supplemental-data)
        cusip9->msrb-doc (->> msrb-data
                              (map (juxt #(get-in % [:cusip-9 :value]) identity))
                              (into {}))
        cusip9->msrb-cusip9 (->> msrb-data
                                 (map (juxt #(get-in % [:cusip-9 :value]) #(select-keys % [:cusip-9])))
                                 (into {}))
        cusip9->cusips (->> (keys cusips-jaeger)
                            (map (juxt #(get-in % [:cusip-9 :value]) identity))
                            (into {}))
        all-cusips (map (fn [[cusip doc]]
                          (or (cusip9->cusips cusip) doc)) cusip9->msrb-cusip9)]
    (zipmap
      all-cusips
      (map #(cusip9->msrb-doc (get-in % [:cusip-9 :value])) all-cusips))))

(defnk msrb [msrb-supplemental-data cusips-jaeger]
  (get-msrb msrb-supplemental-data cusips-jaeger))
