(ns jaegers.edgar.prospectus.collateral-type
  (:require [plumbing.core :refer [defnk]]))

(defn issue-desc->collateral-type [issue-desc ids]
  (when issue-desc
    (when-let [c-type (cond
                        (re-find #"(?i)first mortgage" issue-desc) :first-mortgage
                        (re-find #"(?i)collateral trust" issue-desc) :collateral-trust
                        :else nil)]
      {:jaeger ::collateral-type
       :value c-type
       :ids ids
       :class :collateral-type})))

(defnk collateral-type* [issue-description*]
  (zipmap
   (keys issue-description*)
   (map (fn [{:keys [value ids]}]
          (issue-desc->collateral-type value ids))
        (vals issue-description*))))


(defnk is-secured* [collateral-type*]
  (zipmap
   (keys collateral-type*)
   (map (fn [{:keys [value]}]
          {:jaeger ::collateral-type
           :value (if value
                    :secured
                    :unsecured)
           :class :is-secured})
        (vals collateral-type*))))
