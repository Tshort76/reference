(ns jaegers.muni.single-bond
  (:require [clojure.string :as cs]
            [utils.simple-search :as ss]
            [simple-mind.parse-objects-utils :as pou]
            [jaegers.utils :as util]
            [clj-time.coerce :as tc]
            [clj-time.format :as f]
            [jaegers.muni.cusips :as uc]
            [taoensso.timbre :as timbre]
            [plumbing.core :refer [defnk]]
            [clojure.spec.alpha :as s]))

(def percent-like #"\d\d?\.\d\d%")
(def maturity-like #"(?i)(due:?|maturity:?|mature:?).{1,10}((?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|(?:nov|dec)(?:ember)?) [0-9]{1,2}[,]{0,1} [0-9]{4})")
(def maturity-like-backup #"(?i)due:?|maturity:?|mature:?")
(def date-like #"(?i)((?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|(?:nov|dec)(?:ember)?) [0-9]{1,2}[,]{0,1} [0-9]{4})")

(defn find-closest-match [match-token tokens]
  (when (and match-token (not-empty tokens))
    (apply min-key :dist
           (map
             (fn [token]
               (let [token (if (:coords token) (merge (first (:coords token)) token) token)]
                 (assoc token :dist (util/euclid-dist match-token token))))
             tokens))))

(defn parse-date [{:keys [objs text] :as token}]
  (when token
    (try (let [parsed-date (f/parse (f/formatter "MMM dd yyyy") (cs/replace text #"[,.]" ""))]
           {:value  (tc/to-date parsed-date)
            :coords (mapv ss/word->coord objs)
            :ids    (mapv :id objs)
            :jaeger :single-bond})
         (catch Exception e (do (timbre/warn (str "Single Bond JAEGER Parse Failure: " text "\n" (.getMessage e))) nil)))))

(defn parse-double [double-str]
  (try
    (some-> double-str
            (cs/replace #"[%$,]|[.]$" "")
            (Double/parseDouble))
    (catch Exception e (do (timbre/warn (str "Single Bond JAEGER Parse Failure: " double-str "\n" (.getMessage e))) nil))))

(parse-double nil)

(defn format-token [parse-fn token]
  (when token
    {:value  (parse-fn (:text token))
     :coords [(ss/word->coord token)]
     :ids    [[(:id token)]]
     :jaeger :single-bond}))

(defn format-date [token]
  (when token
    {:value  (:value token)
     :coords (:coords token)
     :ids    [(:ids token)]
     :jaeger :single-bond}))

(defn valid-insertion? [cusip-doc bond key]
  (and (not (get cusip-doc key))
       (get bond key)))

; (defn merge-docs [cusip-doc bond]
;   (cond-> cusip-doc
;           (valid-insertion? cusip-doc bond :principal-amount)
;           (assoc :principal-amount (:principal-amount bond))
;
;           (valid-insertion? cusip-doc bond :interest-rate)
;           (assoc :interest-rate (:interest-rate bond))
;
;           (valid-insertion? cusip-doc bond :maturity-date)
;           (assoc :maturity-date (:maturity-date bond))))

(defn mind-food->single-bond [mind-food]
  (when (= 1 (count (uc/find-cusips (filter (comp #(<= % 3) :page-number) mind-food))))
    (let [first-page-vals (flatten (map (comp flatten :vals) (filter (comp #(= % 1) :page-number) mind-food)))
          principal-amount (first (filter #(re-find #"\$[,\d]+" (:text %)) first-page-vals))
          interest-rates (filter #(re-find percent-like (:text %)) first-page-vals)
          interest-rate-val (first (filter #(re-find #"(?i)interest|coupon" (:text %)) first-page-vals))
          maturity-val (or (first (:objs (first (pou/rematch-in maturity-like [:text] first-page-vals :group 1))))
                           (first (:objs (first (pou/rematch-in maturity-like-backup [:text] first-page-vals)))))
          dates (keep parse-date (pou/rematch-in date-like [:text] first-page-vals :group 1))
          pa (format-token parse-double principal-amount)
          ir (format-token parse-double (find-closest-match interest-rate-val interest-rates))
          md (format-date (find-closest-match maturity-val dates))]
      (cond-> []
              pa (conj {:principal-amount pa})
              ir (conj {:interest-rate ir})
              md (conj {:maturity-date md})))))

(defnk single-bond [mind-food cusips*]
  (zipmap
    (keys cusips*)
    (repeat (apply merge (mind-food->single-bond mind-food)))))

(comment
  (mind-food->single-bond (first (mf/mind-food {:md5 "073450276a3ad003527730c0674cda1c"})))
  (mind-food->single-bond (first (mf/mind-food {:md5 "33224ed0ead65359e9f9b1deccb50b51"})))
  (mind-food->single-bond (first (mf/mind-food {:md5 "7ef4f5929a298bab0eaf9ae92201c955"})))
  (mind-food->single-bond (first (mf/mind-food {:md5 "11d2aba5e5b6de69b16e4ca58f58653c"})))
  ;TODO: This one has key -value problems, they're mixed weirdly
  (mind-food->single-bond (first (mf/mind-food {:md5 "53f01d90d3ec633b905df3814aeae2ef"})))
  (mind-food->single-bond (first (mf/mind-food {:md5 "05c642fdbfdef9c4467235387261ed5a"})))
  (mind-food->single-bond (first (mf/mind-food {:md5 "f6e2fcc2504f943afd9613a042ee5d84"})))
  (mind-food->single-bond (first (mf/mind-food {:md5 "60c6ad675562b6f0b13f87c966bfe7ed"})))
  (filter (comp #(= % 1) :page-number) (:mind-food (first (mf/mind-food {:md5 "cf5c3c07776032039bf3f69631485001"}))))
  (->> (mf/mind-food {:md5 "33224ed0ead65359e9f9b1deccb50b51"}) first :mind-food (take 10)))
