(ns jaegers.cusip-linking.identifier-derivation
  (:require [soda-common.cusip :as cusip]))

(def isin-re (re-pattern (str "US(" cusip/cusip-6 cusip/cusip-3 ").")))

(defn isin->cusip [isin-string]
  (when isin-string
    (second (re-find isin-re isin-string))))

; (defn jaeger-isin->cusip
;   [{{:keys [isin]} :jaeger-doc :as doc}]
;   (let [c (-> (update isin :value isin->cusip) (assoc :overmind-details {:method "isin-to-cusip-derivation"}))]
;     (when (:value c)
;       (assoc-in doc [:jaeger-doc :cusip-9] c))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;in case we decide to plumb this for add identifier job;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;(defnk isin-from-cusip [isin cusip]
;       (when (not cusip)
;         {:cusip (isin->cusip isin)
;          :confidence 100.0})); or whatever metric we want to use for this step.
