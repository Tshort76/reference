(ns jaegers.muni.make-whole-call
  (:require
    [plumbing.core :refer [defnk]]
    [utils.mind-food :as utils.mind-food]
    [utils.simple-search :as search]))

"at a redemption price equal to 100% of the principal amount of the bonds or portions thereof to be redeemed accrued interest to the date of redemption"
"a price of 100% of the principal amount being redeemed plus accrued interest to the date of redemption"

(def make-whole-call-re #"(?i)price.{0,10}100%.{0,10}principal amount.{0,50}redeemed.{0,50}date of redemption")

(defn ->jaeger-form [{:keys [ids coords]}]
  (when (boolean (not-empty (flatten ids)))
    {:value  true
     :ids    ids
     :coords coords
     :class  :make-whole-call
     :jaeger :make-whole-call}))

(defn simple-find [mind-food]
  (->> mind-food
       (search/search-components ["make-whole"])
       not-empty
       ->jaeger-form))

(defn regex-find [mind-food]
  (let [objs (some->> (utils.mind-food/find-in-mindfood make-whole-call-re mind-food)
                      first :matches first second)]
    (->jaeger-form {:ids (some-> (keep :id objs) vector) :coords (keep utils.simple-search/word->coord objs)})))

(defn mind-food->make-whole-call [mind-food]
  (some identity (vector (simple-find mind-food) (regex-find mind-food))))

(defnk make-whole-call* [mind-food cusips*]
  (zipmap
    (keys cusips*)
    (repeat (mind-food->make-whole-call mind-food))
    #_(jutil/assoc-nearest-series*
      (vals series*)
      #(-> % :coords flatten first)
      (mind-food->make-whole-call mind-food))))