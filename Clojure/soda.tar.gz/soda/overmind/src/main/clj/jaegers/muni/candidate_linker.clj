(ns jaegers.muni.candidate-linker
  (:require [clojure.math.combinatorics :as combinatorics]
            [edgar.link-geometries :as elg]
            [taoensso.timbre :refer [debug]]
            [loom.graph]
            [loom.alg]
            [jaegers.muni.candidate-linker-utils :refer :all]
            [plumbing.core :refer [defnk]]))

(defn get-coords
  "This does some conversions to allow for different pages."
  [candidate]
  (let [prime-coord (get-in candidate [0 0])
        page-offset (* 1000 (- (:page-number prime-coord) 1))]
    [(:x prime-coord) (+ page-offset (:y prime-coord))]))

(defn distance
  "Use euclidean, we are measuring distance on the page"
  [[x1 y1 p1 t1] [x2 y2 p2 t2]]
  (let [d1 (* (- x1 x2) 0.1)                                ;apply a tranform to to x distance.
        d2 (- y1 y2)]
    (Math/sqrt (+ (* d1 d1) (* d2 d2)))))

(defn find-closest [point targets]
  (first (sort-by first (map (juxt (partial distance point) identity) targets))))

(defn make-line [[x1 y1 p1 t1] [x2 y2 p2 t2]]
  (let [rise (- y2 y1)                                      ;nothing complicated needed
        run (- x2 x1)]
    [run rise]))

(defn generate-point [[x1 y1 p1 t1] [run rise]]
  [(+ x1 run) (+ y1 rise) p1 :point])

; all sources are linked.
; not enough targets.  (do we allow subsets of linking)
(defn linker [sources targets prime target]
  (let [line (make-line prime target)
        clean-targets (remove #{target} (into #{} targets))
        tolerance 10]
    (loop [links [[prime target]]
           target-set (remove #{target} clean-targets)
           source-list sources]
      (cond
        (empty? source-list) links                          ;Done!
        (empty? target-set) links                           ;couldn't match 'em all
        :else (let [current-source (first source-list)      ;;default
                    target-point (generate-point current-source line)
                    [closest-distance closest-target] (find-closest target-point target-set)]
                (if (> closest-distance tolerance)          ;can't do it
                  nil
                  (recur (concat links [[current-source closest-target]]) ;matched this one, continue on.
                         (remove #{closest-target} target-set)
                         (rest source-list))))))))

(defn link-em
  "finds a set of links where all sources are connected to targets."
  [sources targets]
  (let [sorted-targets (sort-by (fn [[x y p & r]] [p y x]) targets)
        sorted-sources (sort-by (fn [[x y p & r]] [p y x]) sources)
        primer (first sorted-sources)]
    (some (partial linker (rest sorted-sources) sorted-targets primer) sorted-targets)))

(defn point-in-key? [[x y p t] [p2 y1 y2]]
  (<= (dec y1) y (inc y2)))

;take-while would be better
(defn get-key [c-keys point]
  (first (filter (partial point-in-key? point) c-keys)))

(defn id->page
  "ugh--this sucks, we should be using the page number as part of
  coordinates"
  [id]
  (Integer. ^String (first (clojure.string/split id #"_"))))

(defn cusip->point-form [c]
  [(Math/round ^double (get-in c [:cusip-3 :coords :min-x]))
   (Math/round ^double (get-in c [:cusip-3 :coords :min-y]))
   (id->page (first (first (get-in c [:cusip-3 :ids]))))
   c])

(defn can->point-form [can]
  (if can
    [(Math/round ^double (get-in can [:coords :max-x] 0))
     (Math/round ^double (get-in can [:coords :min-y] 0))
     (id->page (first (flatten (:ids can))))
     can]
    [0 0 0 nil]))

(defn make-key [d]
  (if (nil? d)
    [-1 -1 -1]
    [(:page-number d)
     (int (:y0 d))
     (int (:y1 d))]))

(defn merge-component-keys
  "if the compoenent keys overlap in the y dimension
  then we go ahead and merge them, otherwise no"
  [[k1 k2]]
  (if nil? k2)
  [k1]
  (let [[[k1p k1y1 k1y2] [k2p k2y1 k2y2]] (sort [k1 k2])]
    (if (and (= k1p k2p)                                    ;;same page
             (> k1y2 k2y1))                                 ;;there is overlap
      [[k1p (min k1y1 k2y1) (max k1y2 k2y2)]]
      [k1 k2])))

(defn key-merger [c-keys]
  (->> c-keys
       (partition-all 2)
       (mapcat merge-component-keys)
       (remove nil?)))

(defn key-merger-2-step
  "We apply the merge, then skip one and apply it again"
  [c-keys]
  (let [merge-one (key-merger c-keys)
        merge-two (concat [(first merge-one)] (key-merger (rest merge-one)))]
    merge-two))

(defn merge-keys
  "This looks icky, but what it does is keep applying the key-merger-2-step until nothing changes (a=b)
  TODO clean this up. couldn't I just use a some on the partition-2 with 1 step, always finding and
  applying the first one?"
  [c-keys]
  (second
    (first
      (filter
        (fn [[a b]] (= a b))
        (partition 2 1 (iterate key-merger-2-step (sort (distinct c-keys))))))))

(defn by-component [mind-food page points]
  (let [components-on-page (filter (comp #{page} :page-number) mind-food)
        c-keys (merge-keys (map make-key components-on-page))]
    (group-by (partial get-key c-keys) points)))

(defn by-page-comp [mind-food points]
  (let [by-page (group-by (fn [p] (nth p 2)) points)
        by-comp (into {} (map (fn [[k v]] (by-component mind-food k v)) by-page))]
    by-comp))

(defn link-field-type-to-cusips
  "sources are already grouped by [page-number y0 y1] of the components to which they belong"
  [mind-food sources solution-nodes]
  (let [candidates (by-page-comp mind-food (map can->point-form solution-nodes))] ;do the same for candidates
    (mapcat (fn [[k v]] (link-em v (get candidates k))) sources)))

(defn link->cusip-doc
  "currently relies on source being a cusip"
  [[source target]]
  (let [s-data (nth source 3)
        t-data (nth target 3)]
    [s-data t-data]))

(defn decorate-links [links cusip-docs]
  (let [look-up (group-by (fn [d] (get-in d [:cusip-3 :value])) cusip-docs)]
    (map (fn [[[x y p d] t]]
           [[x y p (conj (first (get look-up (get-in d [:cusip-3 :value]))) d)] t]) links)))

(defn too-many-ids?
  "We never expect a cusip-3 to appear more than 2 times in a document
  This means we top out at 4 ids (it can have more 1+2 twice)"
  [cusip-doc]
  (< 4 (count (get-in cusip-doc [:cusip-3 :ids]))))

(defn clean-point [[_ _ page m]]
  {:class (:class m)
   :value (:value m)
   :id    (first (flatten (:ids m)))
   :page  page})

(defn clean-pair [[a b]]
  [(clean-point a) (clean-point b)])

(defn link-candidates-to-candidates
  "Given mind-food and its enhik form, and a set of base candidates, will try to link the base
  candidates to the target set of candidates, such that all links are approx the same"
  ([mind-food enhik source-candidates target-candidates]
   (let [ids->coords (elg/create-ids->geometries-map (elg/create-geometry-maps enhik))
         ids->muni-geom (partial elg/add-muni-doc-geom ids->coords)
         s (doall (map can->point-form
                       (:t (elg/create-solution-nodes {:t source-candidates} ids->muni-geom))))
         t (doall (map can->point-form
                       (:t (elg/create-solution-nodes {:t target-candidates} ids->muni-geom))))
         sources (by-page-comp mind-food s)
         targets (by-page-comp mind-food t)
         ;Build the common set of sections that contain both sources and targets.
         joint-keys (clojure.set/intersection (into #{} (keys sources)) (into #{} (keys targets)))]
     (doall (mapcat (fn [k] (link-em (sources k) (targets k))) joint-keys))))

  ([mind-food enhik candidates]
   (let [cusip-3s (map (fn [c] (assoc c :class :cusip-3)) (map :cusip-3 (:cusips candidates)))
         candidates (assoc candidates :cusip-3 cusip-3s)
         candidate-classes (disj (into #{} (keys candidates)) :cusips)
         class-pairs (combinatorics/combinations candidate-classes 2)
         links (mapcat (fn [[c1 c2]] (link-candidates-to-candidates mind-food enhik
                                                                    (candidates c1)
                                                                    (candidates c2))) class-pairs)]
     (apply loom.graph/graph (map clean-pair links))))

  ([omni-doc]
   (let [mind-food (:mind-food omni-doc)
         enhik (:enhanced-hickory omni-doc)
         candidates (:candidates omni-doc)]
     (link-candidates-to-candidates mind-food enhik candidates))))

;TODO Parts of this function are a big ball of mud.  It needs to be very clear what
;each thing does, with good documentation.
(defn link-candidates-to-cusips
  "Given an omni-doc uses the :candidates map and :mind-food to produce a set of cusip docs that
  contain linked candidates. These can set to the ordinary cusip docs, or they can used to augment
  the msrb cusip docs"
  ([mind-food all-candidates enhik]
   (let [cusip-docs (map (fn [d] (select-keys d [:cusip-3]))
                         (remove too-many-ids? (all-candidates :cusips)))
         candidates (dissoc all-candidates :cusips)
         ids->coords (elg/create-ids->geometries-map (elg/create-geometry-maps enhik))
         ids->muni-geom (partial elg/add-muni-doc-geom ids->coords)
         ids->geom (partial elg/add-jaeger-doc-geom ids->coords)
         s (map cusip->point-form (elg/create-muni-security-nodes cusip-docs ids->muni-geom))
         c (elg/create-solution-nodes candidates ids->geom)
         sources (by-page-comp mind-food s)
         links (doall (mapcat (fn [[k v]] (link-field-type-to-cusips mind-food sources v)) c))
         d-links (decorate-links links (all-candidates :cusips))
         points (concat (map (comp :cusip-3 last) s) (flatten (map second c)))]
     [(into {} (map (fn [[k v]] [(get-in k [:cusip-9 :value])
                                 (conj (into {} (map (juxt :class identity) (map second v))) k)])
                    (group-by first (map link->cusip-doc d-links)))) points]))

  ([omni-doc]
   (link-candidates-to-cusips (:mind-food omni-doc)
                              (:candidates omni-doc)
                              (:enhanced-hickory omni-doc))))

(defn decorate-key [msrb-xml pdf-linked field]
  (if (= (:value (field msrb-xml)) (:value (field pdf-linked)))
    {field (merge (field msrb-xml) (field pdf-linked) {:jaeger :candidate-linker})}
    {field (field msrb-xml)}))

(defn decorate-document
  "Given cusip docs created by the msrb, takes those and decorates the data in them using the
  candidate to cusip linker."
  [msrb-xml pdf-linked]
  (apply merge (map (partial decorate-key msrb-xml pdf-linked) (keys msrb-xml))))

(defn find-full-cusip-key [cusip-docs cusip-9]
  (first (filter (comp #{cusip-9} :value :cusip-9) (keys cusip-docs))))

(defn pass-through [mind-food candidates msrb enhanced-hickory]
  (let [[cusip-docs _] (link-candidates-to-cusips mind-food candidates enhanced-hickory)]
    (into {} (map (fn [c] (let [k (find-full-cusip-key msrb c)]
                            {k (decorate-document (msrb k) (cusip-docs c))}))
                  (keys cusip-docs)))))

(defnk full-links [mind-food candidates enhanced-hickory]
  (loom.alg/connected-components
    (link-candidates-to-candidates mind-food enhanced-hickory candidates)))

(defnk candidate-linker* [mind-food candidates msrb enhanced-hickory]
  (pass-through mind-food candidates msrb enhanced-hickory))
