(ns jaegers.edgar.equity.primary-exchange
  (:require [plumbing.core :refer [defnk]]
            [medley.core :as med]))


(defn pull-from-existing [value-fn class method info]
  (med/map-vals (fn [x]
                  {:class class
                   :overmind-details {:method method}
                   :value (value-fn x)})
                info))

(defn field-from-list [field x]
  (some field (:value x)))

(defn pull-from-exchange-info [field class info]
  (pull-from-existing (partial field-from-list field) class :exchange-info info))

(defnk country-of-issue* [exchange-specific*]
  (pull-from-exchange-info :country-of-issue :country-of-issue exchange-specific*))

(defnk primary-exchange* [exchange-specific*]
  (pull-from-exchange-info :exchange :primary-exchange exchange-specific*))

(defnk primary-mic* [exchange-specific*]
  (pull-from-exchange-info :mic :primary-exchange-mic exchange-specific*))


(defn get-ticker [ex-map shares-map filename-ticker]
  (cond
    (some (partial field-from-list :ticker) (vals ex-map))
    (pull-from-exchange-info :ticker :ticker ex-map)

    (some :ticker (vals shares-map))
    (pull-from-existing :ticker :ticker :shares-info shares-map)

    filename-ticker
    (pull-from-existing
     (constantly filename-ticker)
     :ticker :filename-ticker
     (if (seq ex-map)
       ex-map shares-map))))

(defnk primary-ticker* [exchange-specific* shares-outstanding* filename-ticker]
  (get-ticker exchange-specific* shares-outstanding* filename-ticker))
