(ns jaegers.edgar.classifiers.cusip-match
  (:require
    [clojure.data.json :as json]
    [clojure.edn :as edn]
    [clojure.java.io :as io]
    [clojure.pprint :as pp]
    [clojure.walk :as walk]
    [plumbing.core :refer [for-map]]
    [simple-mind.naive-bayes.core :as nb]))

(def edgar-prospectus-model (-> "jaegers/edgar_cusip_match_bayes.edn" io/resource slurp edn/read-string))
(def edgar-equity-model (-> "jaegers/edgar_equity_cusip_match_bayes.edn" io/resource slurp edn/read-string))

(def feature-fields
  {:edgar-prospectus
   #{:coupon-frequency
     :coupon-rate
     :dated-date
     :first-coupon-date
     :maturity-date
     :offering-amount
     :offering-amount-code
     :rate-type
     :where-traded}
   :edgar-equity
   #{:ticker-symbol
     :currency-code
     :issuer-name
     :where-traded
     :figi-data
     :new-indicator}})

(defn matched-fields->feature-map [data-type fields]
  (for-map
    [ff (data-type feature-fields)
     :let [v (ff fields)
           v (if v v :nothing-to-match)]]
    (keyword (str (name v) "-" (name ff)))
    1))

;; -----------------------------------------------------------------------------

(defn stats-cache [cset]
  (->> (name cset)
       (str "http://dev-soda-intake-group1-app1:8084/soda_jerk_ws/api/cusip-matching/data-for-valentines-tree?control-name=")
       slurp
       json/read-str
       walk/keywordize-keys))

(defn stats->feature-maps [cset data-type]
  (->> (stats-cache cset)
       (map :cusip-docs)
       flatten
       (remove :missing)
       (map (fn [{:keys [correct cusip-matched-on possible-cusips]}]
              (if correct
                (cons (-> (matched-fields->feature-map data-type cusip-matched-on)
                          (assoc :class :true))
                      (map #(-> (:cusip-matched-on %)
                                ((fn [doc] (matched-fields->feature-map data-type doc)))
                                (assoc :class :false)) possible-cusips))
                (-> (matched-fields->feature-map data-type cusip-matched-on)
                    (assoc :class :false)))
              ))
       flatten
       ))

(defn train-model
  [control-name data-type]
  (reduce
    (fn [m {:keys [class] :as fmap}] (nb/train m class (dissoc fmap :class)))
    {} (stats->feature-maps control-name data-type)))

(defn test-model
  "Returns the percentage of validation samples for which the classifier's prediction was correct"
  [model control-name data-type]
  (->> (stats->feature-maps control-name data-type)
       (map (fn [{:keys [class] :as fmap}]
              (= class (nb/classify-multinomial model (dissoc fmap :class)))))
       frequencies
       ((fn [m] (double (/ (get m true) (+ (get m true) (get m false))))))))

(defn split-train-test
  [control-name data-type]
  (let [stats (shuffle (stats->feature-maps control-name data-type))
        training-set (take (* (count stats) 0.75) stats)
        test-set (drop (* (count stats) 0.75) stats)
        model (reduce
                (fn [m {:keys [class] :as fmap}] (nb/train m class (dissoc fmap :class)))
                {} training-set)
        test-results (->> test-set
                          (map (fn [{:keys [class] :as fmap}]
                                 (= class (nb/classify-multinomial model (dissoc fmap :class)))))
                          frequencies
                          ((fn [m] (double (/ (get m true) (+ (get m true) (get m false)))))))]
    (do
      (spit (str (name control-name) ".edn") model)
      test-results)))

#_(def edgar-prospectus-model (train-model :edgar-multi-600))
#_(test-model edgar-prospectus-model :edgar-multi-1000-full)
#_(def edgar-equity-model (train-model :edgar-equity-multi-300))
#_(test-model edgar-equity-model :edgar-equity-multi-300)
#_(split-train-test :edgar-equity-multi-300 :edgar-equity)
