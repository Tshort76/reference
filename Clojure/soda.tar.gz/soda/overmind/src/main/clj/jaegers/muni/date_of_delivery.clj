(ns jaegers.muni.date-of-delivery
  (:require [clojure.string :as cs]
            [clojure.core.match :refer [match]]
            [jaegers.mind-food-utils :as mfu]
            [clojure.java.io :as io]
            [instaparse.core :as insta]
            [soda-common.parsers :as scp]
            [plumbing.core :refer [defnk]]
            [jaegers.jaeger-primer :as primer]
            [util.date-time :as date-time]))

(def first-coupon-date-terms #{"commencing" "beginning" "initially" "payable" "payment date" "paid" "interest[^s]"})
(def official-statement-terms #{"official statement" "dated:"})
(def legal-terms #{"amend(?:ed)?" "ordinance" "persuant" "lease" "city" "project" "agreement" "voters" "pursuant"})
(def other-dirty-words #{"compound" "convert" "priced" "redemption"})
(def dirty-word-filter
  (->> [first-coupon-date-terms official-statement-terms legal-terms other-dirty-words]
       (reduce into)
       (cs/join "|")
       (str "(?i)")
       re-pattern))

(def date-of-delivery-terms
  #{"(?i)deliver(?:y|ed)?" "available" "expected" "settlement" "date" "dated" "on or about" "dtc"
    "certificates" "bonds" "issue" "facilities" "depository trust company" "closing"})

(def terms (->> date-of-delivery-terms
                (cs/join "|")
                (str "(?i)")
                re-pattern))

(def parse-tree
  (let [[_ & r] (->> "soda_common/parsers.bnf" io/resource slurp cs/split-lines)
        [a & b] (->> "jaegers/date_of_delivery.bnf" io/resource slurp cs/split-lines)]
    (insta/parser (cs/join "\n" [a (cs/join "\n" r) (cs/join "\n" b)]))))

(def txmap
  (letfn [(f [k v m] {k {:value v :indexes (mfu/insta-indexes m) :class :date-of-delivery :jaeger :date-of-delivery}})]
    (into scp/txmap
          {:S (fn [& res]
                (first (map (fn [{:keys [date] :as m}] (f :date-of-delivery date m)) res)))})))

(def parse-tree->value (partial insta/transform txmap))

(defn parse [s] (->> s parse-tree parse-tree->value))

(defn process-tokenvec [[sentence _ :as tv]]
  (when-let [soln (parse sentence)]
    (zipmap (keys soln) (map #(mfu/add-token-data % tv) (vals soln)))))

(defn detect-delivery-dates [mind-food]
  (some->> mind-food
           ;Increasing the page count seems to help for first coupon date, but that's it.
           (filter (fn [{:keys [page-number]}] (<= page-number 2)))
           mfu/mind-food->sentence-tokenvecs
           (remove (comp #(and (re-seq dirty-word-filter %)
                               (not (re-seq #"(?i)date of delivery" %))) first))
           (map (fn [[sentence toks]]
                  [sentence toks (->> sentence (re-seq terms) distinct count)]))
           (filter (comp pos? peek))
           (sort-by peek #(compare %2 %1))))

(defn select-only-singly-dated [sentence-tokenvecs]
  (some->> sentence-tokenvecs (map (comp process-tokenvec pop)) (filter identity)))

(defn within-posting-date? [posting-date]
  (fn [candidate]
    (let [cand-date (get-in candidate [:date-of-delivery :value])]
      (if (and (inst? posting-date) (inst? cand-date))
        (and
          (.after cand-date (date-time/dec-month posting-date))
          (.before cand-date (date-time/inc-month posting-date)))
        true))))

(defn select-best-date [candidates]
  (some->> candidates
           (take 1)
           not-empty
           (mapv #(assoc-in % [:date-of-delivery :jaeger] :date-of-delivery))))

(defn mind-food->date-of-delivery [posting-date mind-food]
  (some->> mind-food
           detect-delivery-dates
           select-only-singly-dated
           (filter (within-posting-date? posting-date))
           select-best-date))

(defnk date-of-delivery* [msrb mind-food cusips*]
  (let [posting-date (some-> (first (vals msrb)) (get-in [:submission-transaction-date-time :value])
                             date-time/->Date)]
    (zipmap (keys cusips*) (repeat (:date-of-delivery (first (mind-food->date-of-delivery posting-date mind-food)))))))

(comment
  (require 'jaegers.muni.msrb-supplement
           'jaegers.muni.cusips)

  (def memoized-query-omni-data
    (memoize (fn [q] (primer/query->omni-data q))))

  (keep (juxt :cusip-9 :date-of-delivery)
        (run-all {:md5 "6949c67460c6bdd733c502348d18936d"})))
