(ns jaegers.edgar.equity.shares-outstanding
  (:require [medley.core :as med]
            [plumbing.core :refer [defnk]]))

(defn score-match [a b]
  (reduce (fn [r [ax bx]]
            (cond
              (or (nil? ax) (nil? bx)) r
              (= ax bx) (inc r)
              :else (reduced nil)))
          0
          (map vector a b)))

(defn safe-max-key [k l]
  (when (seq l)
    (apply max-key k l)))

(defn match-xbrl [xbrl ex-info fields]
  (let [fields-fn (apply juxt fields)
        score-fn (partial score-match (fields-fn ex-info))]
    (->> xbrl
         (map (juxt (comp score-fn fields-fn)
                    identity))
         (filter first)
         (safe-max-key first)
         second)))

(defn clean-xbrl [xbrl] ;; attempt to remove the "summary" shares-outstanding lists
  (cond->> xbrl
           (some :share-class xbrl) (filter :share-class)
           (some :ticker xbrl) (filter :ticker)))

(defn pick-xbrl [xbrl ex-info]
  (when-let [xbrl (seq (clean-xbrl xbrl))]
    (if (seq ex-info)
      (match-xbrl xbrl ex-info [:share-class :ticker])
      (first xbrl))))

(defn clean-exchange-info [{ex-info :value}]
  (med/assoc-some
    {}
    :ticker (some :ticker ex-info)
    :share-class (some :share-class ex-info)))

(defn data-format [data]
  (assoc (dissoc data :shares-outstanding)
         :class :shares-outstanding
         :overmind-details {:method :xbrl}
         :value (:shares-outstanding data)))

(defn process-shares-outstanding [xbrl-info cusips exchange-info]
  (if (seq exchange-info)
    (med/map-vals (comp data-format
                        (partial pick-xbrl xbrl-info)
                        clean-exchange-info)
                  exchange-info)
    (zipmap cusips (cycle (map data-format xbrl-info)))))

(defnk shares-outstanding* [xbrl-info cusips exchange-specific*]
  (process-shares-outstanding xbrl-info cusips exchange-specific*))
