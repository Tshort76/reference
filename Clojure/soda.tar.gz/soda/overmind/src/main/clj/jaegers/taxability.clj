(ns jaegers.taxability
  (:require [html.utils :as html]
            [edgar.tfidf-enfeaturing :as tfidf-enf]
            [simple-mind.naive-bayes.core :as nb]
            [clojure.java.io :as io]
            [clojure.edn :as edn]))

(defn- load-resource
  "Loads a resource file given its path"
  [path]
  (-> path
      io/resource
      slurp
      edn/read-string))

(def naive-bayes-resource
  (load-resource "jaegers/edgar_taxability_naive_bayes.edn"))

(def tfidf-resource
  (load-resource "jaegers/edgar_taxability_binary_tfidf.edn"))

(defn process-taxability-status?
  "Determines if we should process taxability status on the raw text of a document"
  [raw-text]
  (when raw-text
    (let [tfidfs (-> raw-text
                     html/get-html
                     (tfidf-enf/enfeature-tfidf tfidf-resource))]
      (= :process (nb/classify naive-bayes-resource tfidfs)))))
