(ns jaegers.cusip-linking.stats
  (:require [soda.data.core :as sdc]
            [jaegers.md5-control-sets :as controls]
            [jaegers.cusip-linking.core :as clc]))

(sdc/defcon "soda" "cusip-db")
(sdc/defcon "soda-normalized" "figi")
(sdc/defcon "soda-raw" "jaegers")

(defn get-truth-data [test-set]
  (->> test-set
       (group-by :md5)
       (map (fn [[md5 entry]] {md5 (mapv #(hash-map :value (:cusip %) :truth true) entry)}))
       (apply merge)))

(defn importance [{:keys [correct missing incorrect duplicates]}]
  (cond->  0
           correct    (- 2)
           missing    (- 1)
           duplicates (+ 0.5)))

(defn flatten-cusip-doc [{:keys [meta overmind-details] :as doc}]
  (-> (assoc doc :cusip-matched-on (:cusip-matched-on meta))
      (assoc :method (:method overmind-details))
      (assoc :probability (:probability meta))
      (dissoc :meta)
      (dissoc :overmind-details)
      (clojure.set/rename-keys {:value :cusip})))

(defn fill-in-cusip-db
  "Take a simplified cusip-doc and add cusip-matching-record for cusip-db of that cusip"
  [cusip-doc]
  (let [important-key-map (apply merge (vals clc/important-key-map))
        cusip (:cusip cusip-doc)
        ticker (:ticker cusip-doc)
        cusip-db-entry
        (if cusip (-> (cusip-db {:cusip cusip})
                      (#(apply merge %))
                      (select-keys (vals important-key-map))))
        figi-data
        (when (and cusip )
          (-> (figi {:cusip cusip})
              (#(apply merge %))
              (clojure.set/rename-keys (:figi clc/important-key-map))
              (select-keys (vals important-key-map))))]
    (reduce (fn [cd [k v]] (assoc-in cd [:cusip-match-record k :cusip-db-value] v))
            cusip-doc (merge figi-data cusip-db-entry))))

(defn truth-merge [truth result]
    (->> (concat truth result)
         (group-by :value)
         (map (fn [[cusip info]]
                 (let [t (some :truth info)
                       n (count (remove :truth info))]
                   (cond->> info
                            (and t (< 0 n))  (map #(assoc % :correct true))
                            (and t (< 0 n))  (remove :truth)
                            (and t (= 0 n))  (map #(assoc % :missing true))
                            (< 1 n)          (map #(assoc % :duplicates true))
                            (not t)          (map #(assoc % :incorrect true))
                            true             (map flatten-cusip-doc )))))
         flatten
         (map fill-in-cusip-db)
         (sort-by :value)
         (sort-by importance)
         (into [])))

(defn get-info [jaeger-docs]
  (mapv (fn [{:keys [jaeger-doc meta]}]
          (let [seeding-text (:seeding-text (:cusip-linking meta))
                possible-cusips (:possible-cusips (:cusip-linking meta))
                ciks (or (seq (keep :cik (:value (:filers jaeger-doc))))
                         (seq [(:value (:cik jaeger-doc))]))
                norm-jaeger-doc (clc/jaeger-doc->cusip-db-form (:data-type meta) jaeger-doc :full? true)
                cusip-match-record (apply merge (map (fn [[k v]] (hash-map k {:jaeger-value v})) norm-jaeger-doc))]
            (cond-> (assoc (:cusip-9 jaeger-doc) :cusip-match-record cusip-match-record)
                    possible-cusips (assoc  :text seeding-text :possible-cusips possible-cusips)
                    (seq ciks)      (assoc  :ciks ciks))))
        jaeger-docs))

(defn reform-jaeger-docs [md5s]
  (let [extras (apply merge (map hash-map md5s (repeat [])))]
    (->> (jaegers {:meta.outdated? {"$exists" false}
                   "$or" (mapv hash-map (repeat :meta.md5) md5s)
                   :meta.data-type {"$nin" ["edgar-20f" "edgar-10k"]}})
         (map #(assoc-in % [:meta :raw] nil) )
         (group-by (comp :md5 :meta))
         (mapv (fn [[md5 jaeger-docs]] {md5 (get-info jaeger-docs)}))
         (apply merge)
         (merge extras))))

(defn form-stats
  "takes a truth-set and a jaeger-result set merges them then derives stats"
  [[_ truth] [md5 result]]
  (let [docs (truth-merge truth result)
        expected-num (count truth)
        actual-num (count result)
        linked-num (count (filter :value result))
        incorrect-num (count (filter :incorrect docs))
        precision (cond
                    (every? #(or (:correct %) (nil? (:cusip %))) docs) :correct
                    (some #(and (:incorrect %) (:cusip %)) docs) :incorrect
                    :default :partial-correct)              ;if it's not incorrect it's partially-correct
        link-noise   (cond
                       (< expected-num linked-num) :more-noise
                       (> expected-num linked-num) :less-noise
                       (= expected-num linked-num) :correct-noise)
        jaeger-noise (cond
                       (< expected-num actual-num) :more-noise
                       (> expected-num actual-num) :less-noise
                       (= expected-num actual-num) :correct-noise)]
    {:md5                      md5
     :expected-num-securities  expected-num
     :actual-num-securities    actual-num
     :incorrect-num-securities incorrect-num
     :precision                precision
     :link-noise               link-noise
     :jaeger-noise             jaeger-noise
     :noise                    jaeger-noise
     :cusip-docs               docs}))

(defn statistical-data [training-set-name]
  (let [training-set (training-set-name controls/control-sets)
        truths (sort-by first (get-truth-data training-set))
        results (sort-by first (reform-jaeger-docs (mapv first truths)))]
    (mapv form-stats truths results)))



