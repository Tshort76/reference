(ns jaegers.edgar.common-code
  (:require
    [clojure.pprint :as pp]
    [edgar.basic-features :as enf]
    [jaegers.mind-food-utils :as mfu]
    [tokenvec.core :as tv]))

(defn common-code-like? [{f :features}]
  (and (-> f :value-type #{:cusip :cusip-like})
       (-> f :term? not)))

(def features->common-codes
  (partial enf/features->candidates :common-code #{:common-code} common-code-like?))

(defn enhik->common-codes [enhik]
  (some->> 
    enhik
    mfu/enhik->sentence-tokenvecs
    (tv/tokenvecs->basic-features enf/dissect-text)
    (enf/group-by-row enhik)
    (mapcat features->common-codes)
    (map #(assoc % :jaeger ::common-code))))
