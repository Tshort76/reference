(ns jaegers.edgar.prospectus.issue-date
  (:require
    [edgar.basic-features :as enf]
    [medley.core :refer [find-first]]
    [plumbing.core :refer [defnk]]))

; TODO sorting heuristic:
; month & day of maturity-date should match that of issue-date

(def re-indicator #"(will|are expected to) (deliver|(be issued( on)?)|(settle on( or about)?))")
(def value-splits [(enf/value :issue-date-indicator re-indicator)])

(defn jaegerize [m method]
  (assoc m :class :issue-date :jaeger ::issue-date :overmind-details {:method method}))

(defn issue-date-like? [{:keys [features value]}]
  (and (-> features :value-type #{:date})
       (inst? value)))

(defn features->issue-date
  [features]
  (some->>
    features
    (drop-while (complement (comp #{:issue-date :issue-date-indicator} :value-type :features)))
    rest
    (remove (comp #{:issue-date :year-offset :colon} :value-type :features))
    first
    (#(when (issue-date-like? %) (jaegerize % :basic-features)))))

(def sort-fn
  (juxt
    (comp (partial * -1) :confidence :classifier-results)
    (comp (partial * -1) first :contributions :classifier-results)))

(defn best-from-classifier
  [{:keys [issue-date]}]
  (some->
    issue-date
    (->> (sort-by sort-fn))
    first
    (jaegerize :classifier)))

(defn earliest-date [candidates]
  (when (seq candidates)
    (apply min-key (fn [{v :value}] (.getTime v)) candidates)))

(defn find-solution [candidates features]
  (or (earliest-date (keep features->issue-date features))
      (best-from-classifier candidates)))

(defnk issue-date* [enhanced-hickory tokenvecs candidates cusips]
  (let [features (enf/tokenvecs->row-features enhanced-hickory tokenvecs value-splits)]
    (when-let [soln (find-solution candidates features)]
      (zipmap cusips (repeat soln)))))
