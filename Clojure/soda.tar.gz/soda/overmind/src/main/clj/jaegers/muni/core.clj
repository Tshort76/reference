(ns jaegers.muni.core
  (:require
    [jaegers.muni
     [bond-lines :as bond-lines]
     [capital-appreciation :as capital-appreciation]
     [chronos :as chronos]
     [coupon-frequency :as coupon-frequency]
     [coupon-rate-type :as coupon-rate-type]
     [cusips :as cusips]
     [day-count :as day-count]
     [first-coupon-date :as first-coupon-date]
     [issue-principal-amount :as issue-principal-amount]
     [make-whole-call :as make-whole-call]
     [mandatory-redemption-schedule :as mandatory-redemption-schedule]
     [mandatory-redemption-bond-selection :as mandatory-redemption-bond-selection]
     [msrb-supplement :as msrb]
     [optional-redemption-schedule :as optional-redemption-schedule]
     [put-date :as put-date]
     [revenue-source :as revenue-source]
     [revenue-type :as revenue-type]
     [series :as series]
     [single-bond :as single-bond]
     [state-code :as state-code]
     [tax-exemption :as tax-exemption]
     [alternative-minimum-tax-item :as alternative-minimum-tax-item]
     [floating-rate :as floating-rate]
     [minimum-increment :as minimum-increment]
     [is-note :as is-note]
     [date-of-delivery :as date-of-delivery]
     [accrual-start-date :as accrual-start-date]
     [guarantor :as guarantor]
     [candidate-linker :as candidate-linker]
     [date-of-applicability :as date-of-applicability]]
    [jaegers.md5-control-sets :refer [control-sets]]
    [plumbing.graph :as graph]
    [plumbing.core :refer [fnk defnk ?>]]
    [clojure.string :as cs]
    [clojure.pprint :refer [pprint]]))


(defmacro aggregate-field [field-name jaegers]
  `(fnk ~jaegers
     (zipmap (keys (first ~jaegers))
             (map (fn [jaegers-vals#]
                    (some-> (some #(get % ~field-name) jaegers-vals#)
                            (assoc :class ~field-name)))
                  (apply map vector
                         (map vals ~jaegers))))))

;(macroexpand-1 '(aggregate-field :maturity-date [msrb bond-lines single-bond]))

(def jaeger-graph
  {:msrb                                   msrb/msrb
   :chronos                                chronos/chronos
   :bond-lines                             bond-lines/bond-lines
   :single-bond                            single-bond/single-bond
   :tax-exemption                          tax-exemption/tax-exemption
   :linked-candidates                      candidate-linker/candidate-linker*
   :linked-floating-rate                   floating-rate/linked-floating-rate
   :floating-rate-details                  floating-rate/floating-rate-details
   :full-links                             candidate-linker/full-links
   :cusips-jaeger                          cusips/cusips*
   :cusips*                                (fnk [msrb]
                                             (zipmap (keys msrb) (keys msrb)))
   :submission-transaction-date-time       (aggregate-field :submission-transaction-date-time [msrb])
   :issuer-name*                           (aggregate-field :issuer-name [msrb])
   :issue-description*                     (aggregate-field :issue-description [msrb])
   :maturity-date*                         (aggregate-field :maturity-date [linked-candidates msrb bond-lines single-bond chronos])
   :interest-rate*                         (aggregate-field :interest-rate [linked-candidates msrb bond-lines single-bond])
   :yield*                                 (aggregate-field :yield [linked-candidates msrb bond-lines])
   :price*                                 (aggregate-field :price [linked-candidates msrb bond-lines])
   :principal-amount*                      (aggregate-field :principal-amount [msrb])
   :state-code                             (aggregate-field :state-code [msrb])
   :official-stated-dated-date*            (aggregate-field :official-statement-dated-date [chronos])
   :issue-dated-date*                      (aggregate-field :issue-dated-date [msrb chronos])
   :chronos-date-of-delivery               (aggregate-field :date-of-delivery [chronos])
   :extended-issue-description             (fnk [issuer-name* issue-description*]
                                             (zipmap (keys issuer-name*)
                                                     (map #(str (:value %1) " " (:value %2))
                                                          (vals issuer-name*)
                                                          (vals issue-description*))))
   :revenue-type*                          revenue-type/revenue-type*
   :revenue-source*                        revenue-source/revenue-source*
   :coupon-rate-type*                      coupon-rate-type/coupon-rate-type*
   :coupon-frequency*                      coupon-frequency/coupon-frequency*
   :first-coupon-date*                     first-coupon-date/first-coupon-date*
   :is-note*                               is-note/is-note
   :capital-appreciation*                  capital-appreciation/capital-appreciation*
   :series*                                series/series*
   :state-code*                            state-code/state-code*
   :date-of-delivery-jaeger                date-of-delivery/date-of-delivery*
   :date-of-delivery*                      (fnk [chronos-date-of-delivery date-of-delivery-jaeger]
                                             (zipmap
                                               (keys date-of-delivery-jaeger)
                                               (map #(or %1 %2)
                                                    (vals date-of-delivery-jaeger)
                                                    (vals chronos-date-of-delivery))))
   :day-count*                             day-count/day-count*
   :issue-principal-amount*                issue-principal-amount/issue-principal-amount*
   :mandatory-redemption-paydown-schedule* mandatory-redemption-schedule/mandatory-redemption-schedule*
   :optional-redemption-schedule           optional-redemption-schedule/optional-redemption-schedule*
   :optional-redemption-paydown-schedule*  (aggregate-field :optional-redemption-paydown-schedule [optional-redemption-schedule])
   :optional-redemption-date-freedom*      (aggregate-field :optional-redemption-date-freedom [optional-redemption-schedule])
   :put-date*                              put-date/put-date*
   :make-whole-call*                       make-whole-call/make-whole-call*
   :minimum-increment*                     minimum-increment/minimum-increment*
   :accrual-start-date*                    accrual-start-date/accrual-start-date*
   :federal-tax-exempt*                    (aggregate-field :federal-tax-exempt [tax-exemption])
   :state-tax-exempt*                      (aggregate-field :state-tax-exempt [tax-exemption])
   :qualified-tax-exempt-obligation*       (aggregate-field :qualified-tax-exempt-obligation [tax-exemption])
   :alternative-minimum-tax-item*          alternative-minimum-tax-item/alternative-minimum-tax-item*
   :floating-rate-index*                   (aggregate-field :floating-rate-index [floating-rate-details])
   :floating-rate-spread*                  (aggregate-field :floating-rate-spread [floating-rate-details])
   :floating-rate-multiplier*              (aggregate-field :floating-rate-multiplier [floating-rate-details])
   :mandatory-redemption-bond-selection*   mandatory-redemption-bond-selection/mandatory-redemption-bond-selection*
   :guarantor*                             guarantor/guarantor*
   :date-of-applicability*                 (fnk [cusips*
                                                 submission-transaction-date-time
                                                 official-stated-dated-date*
                                                 date-of-delivery*
                                                 issue-dated-date*]
                                             (date-of-applicability/choose
                                               cusips*
                                               submission-transaction-date-time
                                               official-stated-dated-date*
                                               date-of-delivery*
                                               issue-dated-date*))})


; (def profiled-jaeger (graph/compile (graph/profiled :profile-data jaeger-graph)))
; (def jaeger (graph/compile jaeger-graph))
(def par-jaeger (graph/par-compile jaeger-graph))
(def lazy-jaeger (graph/lazy-compile jaeger-graph))

(defn smash [[security fields]]
  (reduce
    (fn [s [_ {:keys [class value jaeger] :as m}]]
      (cond-> s (and class (some? value) (not= :msrb (keyword jaeger))) (assoc class m)))
    security
    fields))

(defn big-merge [m]
  (->> m
       (keep (fn [[k v]] (when (-> k name (cs/ends-with? "*")) v)))
       (mapcat seq)
       (group-by #(select-keys (first %) [:cusip-9]))
       (map smash)))

(defn safe-execute-jaeger
  [jaeger-method {:keys [mind-food] :as omni-doc} & [jaegers]]
  (when mind-food
    (some-> omni-doc jaeger-method (?> (seq jaegers) (select-keys jaegers)) big-merge)))

; (def execute-jaeger (partial safe-execute-jaeger jaeger))
(def execute-parallel-jaeger (partial safe-execute-jaeger par-jaeger))
(def execute-lazy-jaeger (partial safe-execute-jaeger lazy-jaeger))

(comment
  (def memoized-query-omni-data
    (memoize (fn [q] (jaegers.jaeger-primer/query->omni-data q))))

  (def badies [["7db624060fb350b44c813e9f9a49c062" "646140BG7"]
               ["d44c255895aff6d5e70b6bb868d3e8cf" "13063CHG8"]
               ["efcf66dcaccbfbb5a4bc11bb950f30a7" "93978HRL1"]
               ["7eb2de3f89e512cbe5dea50e78d702bd" "13063DAF5"]])

  (execute-lazy-jaeger (memoized-query-omni-data {:md5 "666b53869dc40564f2910ae5d04e6690"}) [:floating-rate-index*])
  (map (fn [[md5 cusip]]
         (filter
           (fn [{{cusip9 :value} :cusip-9}] (= cusip9 cusip))
           (execute-lazy-jaeger (memoized-query-omni-data {:md5 md5}) [:floating-rate-index*])))
       badies)

  (time
    (count
      ;todo: this never finishes...why?
      (map #(jaegers.soda-pipe/write-jaeger-finds
              (jaegers.soda-pipe/md5->security-docs % :starting-jaeger :day-count* :memoize-omni? true))
           (map :md5 (control-sets :july-msrb))))))
