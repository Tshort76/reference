(ns jaegers.jaeger-primer
  (:require [doc-transforms.core :as dtc]
            [edgar.html-utils :as ehu]
            [edgar.header-data :as hd]
            [html.utils :as hu]
            [jaegers.edgar.common-code :as common-code]
            [jaegers.edgar.cusips :as cusips]
            [jaegers.edgar.equity.edgar-xbrl :as xbrl]
            [jaegers.edgar.equity.filename-ticker :as file-ticker]
            [jaegers.muni.cusips :as muni-cusips]
            [jaegers.edgar.primer :as ep]
            [jaegers.muni.primer :as jmp]
            [jaegers.uncertainty :as uncertain]
            [doc-transforms.mindfood :as dtmf]
            [soda.data.file-system :as sdfs]
            [soda.data.core :as sdc]
            [taoensso.timbre :as timbre]
            [taoensso.tufte :refer [p]]
            [soda.core :refer [p->]]
            [clojure.java.io :as io]
    ; [doc-transforms.simple :as simple]
            [clojure.instant :refer [read-instant-date]]
            [plumbing.core :refer [fnk defnk]]
            [util.feature-flags :as ff]
            [jaegers.features.enfeature :as enf]
            [medley.core :refer [assoc-some]]))

(sdc/defcon "soda-raw" "supplemental")
;(sdc/defcon "soda-raw" "omni-cache")

(defn- latest-by-id [maps]
  (reduce (fn [{id1 :_id :as x1} {id2 :_id :as x2}]
            (if (pos? (compare id2 id1))
              x2 x1))
          (first maps)
          (rest maps)))

(defn md5->supplemental-data [md5]
  (if-let [data (->> {:meta.linked-pdf.md5 md5}
                     supplemental
                     (mapcat (fn [{:keys [securities _id] :as doc}]
                               (if securities
                                 (map #(assoc % :_id _id) securities)
                                 (vector (assoc doc :_id _id)))))
                     (group-by #(or (:cusip-9 %) (:original-cusip9-of-refunded-security %) ((juxt (comp :md5 :meta) :ticker) %)))
                     (map (comp
                            (fn [{id :_id :as m}]
                              (-> m
                                  (dissoc :_id)
                                  (assoc :meta {:_id        id
                                                :database   "soda-raw"
                                                :collection "supplemental"})))
                            latest-by-id
                            second))
                     seq)]
    data
    (timbre/info (str "No supplemental data available for md5 " md5 "."))))

;Section for running files directly
;this is primarily used for development
;and testing
;****************************************************
; (defn data->omni-data
;   "Yea!  Let's take it to the next level!"
;   [enhanced-hickory asset-class]
;   (let [pre-doc {:enhanced-hickory enhanced-hickory
;                  :cusip-docs       (cusips/enhik->cusip-docs enhanced-hickory)
;                  :asset-class      asset-class}]
;     (assoc pre-doc :candidates (ep/classify-candidates pre-doc))))

; (defn file->omni-data [filename asset-class]
;   (let [enhanced-hickory (simple/convert-> filename :html :enhik)]
;     (data->omni-data enhanced-hickory asset-class)))

;example
;(file->omni-data "C:/temp/5491fbce794b076d7ce615fd50e72920_0001104659-08-004348.html" :corp)

;Section for hitting files in our storage system
;****************************************************************
;(def primer-graph
;  {:model       jecc/select-model-2
;   :header      (fnk [query] (hd/scrape-file-header-data query))
;   :asset-class (fnk [query] (ep/classify-asset-class query))
;   :cusip-docs  (fnk [enhanced-hickory] (cusips/enhik->cusip-docs enhanced-hickory))
;   :candidates  (fnk [enhanced-hickory model]
;                  (let [{:keys [normalizer classifier]} model]
;                    (ep/classify-candidates enhanced-hickory normalizer classifier)))})

(defn remove-common-codes
  "Removes from cusip-docs any element with a cusip-9 matching a common code in common-code-docs"
  [cusip-docs common-code-docs]
  (let [ccs (set (map :value common-code-docs))]
    (remove (comp ccs :value :cusip-9) cusip-docs)))

(def treasury-cusip-6s
  #{"912793" "912794" "912795" "912796" "912800" "912803" "912810" "912820" "912827" "912828"})

(defn remove-blacklisted-cusips [cusip-docs]
  (remove (fn [{{v :value} :cusip-6}] (treasury-cusip-6s v)) cusip-docs))

(defn has-underlying-cusips? [cusip-docs]
  (some->> cusip-docs
           seq
           (keep #(some-> % :cusip-9 :value (subs 0 6)))
           (apply not=)))

(defmulti query->omni-data
          "Takes a query that specifies a single mongo file and
          returns the omni-data for that file."
          (p :query->omni-data-dispatch
             #(-> % (doto prn) sdfs/find-one-meta (doto prn) :file-type keyword (doto prn))))

(defmethod query->omni-data :edgar-prospectus [query]
  (let [{:keys [input-stream] :as file} (sdfs/find-file query)
        file-contents (slurp input-stream)
        {:keys [uncertainty-flags] :as flagged-file} (uncertain/categorize-file file file-contents)]
    (if uncertainty-flags
      (uncertain/->record-file! flagged-file)
      (let [{:keys [enhanced-hickory] :as omni-data} (dtc/mongo->transform :enhanced-hickory query)
            common-code-docs (common-code/enhik->common-codes enhanced-hickory)
            cusip-docs (-> (cusips/enhik->cusip-docs enhanced-hickory)
                           (remove-common-codes common-code-docs)
                           remove-blacklisted-cusips)]
        (-> omni-data
            (assoc :header (hd/scrape-file-header-data query))
            (assoc :asset-class (ep/classify-asset-class query))
            (assoc :common-code-docs common-code-docs)
            (assoc :cusip-docs (if (has-underlying-cusips? cusip-docs)
                                 (do
                                   (timbre/info {:bounced-cusips (mapv (comp :value :cusip-9) cusip-docs)
                                                 :reason         :likely-underlying-cusips})
                                   [])
                                 cusip-docs))
            ;TODO change below to using feature-flags map loaded during jaeger-job load step
            (assoc :cusip-matching-allowed? (ff/memoized-allowed-to? :cusip-matching :cusip-link-edgar-prospectus))
            ((fn [{:keys [cusip-docs cusip-matching-allowed?] :as m}]
               (if (or (seq cusip-docs) cusip-matching-allowed?)
                 (assoc m :candidates (ep/classify-candidates m))
                 (do
                   (timbre/info {:candidates :not-computed :reason :no-cusips})
                   (assoc m :candidates nil))))))))))

(defmethod query->omni-data :edgar-s4 [query]
  (let [{:keys [input-stream] :as file} (sdfs/find-file query)
        file-contents (slurp input-stream)
        omni-data (dtc/mongo->transform :enhanced-hickory query)]
    (-> omni-data
        (assoc :header (hd/raw-doc->file-header-data file-contents))
        (assoc :raw-file-contents file-contents)
        (assoc :query-db (enf/file-transform->db omni-data)))))

(defn edgar-section-omni-data [query]
  (let [omni-data (sdfs/find-file query)
        [sections xbrl ticker] (-> omni-data :input-stream slurp
                                   ((juxt ehu/submission-section-enhiks
                                          xbrl/parse-tenk
                                          file-ticker/find-filename-ticker)))
        enhik (->> sections
                   (keep :enhanced-hickory)
                   (reduce merge))
        raw (->> sections
                 (keep :raw)
                 (reduce merge))
        tenq (md5->supplemental-data (:md5 query))]
    (-> omni-data
        (dissoc :input-stream :file)
        (assoc-in [:meta :audit] (map :meta tenq))
        (assoc :enhanced-hickory enhik
               :filename-ticker ticker
               :xbrl xbrl
               :raw raw
               :supplemental tenq
               :cusip-linking-allowed? (ff/memoized-allowed-to? :cusip-matching :cusip-link-edgar-equity)
               :header (hd/scrape-file-header-data query)))))

(defmethod query->omni-data :edgar-10k [query]
  (edgar-section-omni-data query))

(defmethod query->omni-data :edgar-20f [query]
  (edgar-section-omni-data query))


(defmethod query->omni-data :muni-jaeger [query]
  (let [{:keys [md5] :as omni-data} (dtc/mongo->transform :mind-food query)
        e-hik (dtmf/enhik-mindfood (:mind-food omni-data))]
    (-> omni-data
        (assoc :msrb-supplemental-data (md5->supplemental-data md5))
        (assoc :enhanced-hickory e-hik)
        (assoc :candidates (jmp/->candidates e-hik :muni))
        (jmp/->extra-candidates)
        (assoc-in [:candidates :cusips] (muni-cusips/mind-food->cusips (:mind-food omni-data))))))

(defmethod query->omni-data :default [_] {})

; matt's instructions
; you need to add the new value-thing that you want to classify into the value-splits vector and give it a unique value-type in its handler function 1:16 PM
;and add that value-type to the features-descriptor under [:value-type ptions]

#_(defn query->omni-data [q]
    (if-let [omni-data (first (omni-cache q))]
      (do (timbre/info "Grabbing cached omni-data " q)
          omni-data)
      (let [omni-data (query->omni-data q)]
        (try
          (bulk-write-omni-cache [omni-data])
          (catch Exception _ (timbre/info "Unable to cache omni-data " q)))
        omni-data)))


;; debug stuff
#_(defn query->sections-print [query]
   (some-> query
           sdfs/find-file
           :input-stream
           slurp
           ehu/print-submission-sections))
