(ns jaegers.edgar.equity.share-class
  (:require [medley.core :as med]
            [plumbing.core :refer [defnk]]))

(defn jaeger-form [exchanges]
  (when-let [class (->> exchanges :value (some :share-class))]
    {:value class
     :overmind-details {:method :exchange-specific}
     :class :share-class}))

(defnk share-class* [exchange-specific*]
  (med/map-vals jaeger-form exchange-specific*))

(defn xbrl->remaining-share-classes [xbrl-info share-class]
  (some->> (keep :share-class xbrl-info)
           ;(remove #{(:value share-class) "Undefined"})
           seq
           (hash-map :overmind-details {:method :share-class}
                     :class :other-share-classes
                     :value)))

(defnk other-share-classes* [share-class* xbrl-info]
  (med/map-vals (partial xbrl->remaining-share-classes xbrl-info) share-class*))
