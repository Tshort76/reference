(ns jaegers.edgar.classifiers.cusip
  (:require
    [clj-ml.filters :as ml-filt]
    [clojure.edn :as edn]
    [clojure.java.io :as io]
    [ml.classifiers :as mlc]
    [ml.filters :as mlf]))

(def rf-trees 25)
(def rf-attrs 
  [:first-terms-in-col-below
   :beginning-terms-in-col-above
   :note-terms-before
   :words-in-row-after
   :cusip-terms-after
   :cusip-terms-before
   :words-in-table
   :first-column?
   :col-count
   :words-in-block
   :words-in-col-above
   :last-column?
   :class])
(def norm-scale 1000)

(def rf-file "jaegers/edgar_cusip_random_forest.edn")
(def dataset-file "jaegers/edgar_cusip_dataset.arff")
(def normalizer-file "jaegers/edgar_cusip_normalizer.edn")

(def normalize-filter (-> normalizer-file io/resource slurp edn/read-string))
(def normalizer (partial mlf/normalize-feature-map normalize-filter))

(def random-forest (-> rf-file io/resource slurp edn/read-string))
(def classifier (partial mlc/classify-ensemble random-forest))

;; -----------------------------------------------------------------------------

;; Run this to recreate the dataset file, normalize filter, and decision trees for the classifier
(comment
  (do
    (require '[clj-ml.data :as ml-data])
    (require '[clj-ml.io :as ml-io])
    (require '[jaegers.edgar.classifiers.candidates :as jec])
    (require '[ml.training-sets :as training-sets])
    (require '[jaegers.trainer :as trainer])

    (let [train-set (-> (trainer/get-training-set :edgar-cusip-filter {:validated? true})
                        (update :features-descriptor #(select-keys % rf-attrs))
                        (update :feature-maps (fn [fmaps] 
                                                (map (fn [fmap] 
                                                       (update fmap :features #(select-keys % rf-attrs))) fmaps))))
          {:keys [dataset normalizer]} (-> train-set 
                                           training-sets/training-set->weka-data-set 
                                           (#(jec/normalize-dataset % :scale norm-scale)))
          feature-maps (map (fn [m] {:features m :validated? true}) (ml-data/dataset-as-maps dataset))
          random-forest (training-sets/training-set->ensemble-trees 
                          (assoc train-set :feature-maps feature-maps)
                          :num-trees rf-trees)
          norm-filter (dmf/normalizer->edn normalizer (ml-data/attribute-names dataset))]
      (ml-io/save-instances :arff (str "resources/" dataset-file) dataset)
      (spit (str "resources/" rf-file) (pr-str random-forest))
      (spit (str "resources/" normalizer-file) (pr-str norm-filter)))))
