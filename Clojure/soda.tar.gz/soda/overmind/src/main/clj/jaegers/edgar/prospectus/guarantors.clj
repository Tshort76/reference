(ns jaegers.edgar.prospectus.guarantors
  (:require
    [clojure.spec.alpha :as s]
    [jaegers.edgar.linking :as lnk]
    [jaegers.hickory-utils :as hu]
    [enhanced-hickory.core :as ehc]
    [clojure.string :as string]
    [jaegers.mind-food-utils :as mfu]
    [jaegers.regisector :as rs]
    [edgar.link-geometries :as lg]
    [clojure.string :as cs]
    [edgar.table-utils :as tu]
    [hickory.select :as hs]
    [clojure.zip :as zip]
    [medley.core :as med]
    [medley.core :as medley]
    [plumbing.core :refer [fnk defnk]]
    [tokenvec.core :as tv]))


;todo make this better with: https://en.wikipedia.org/wiki/List_of_business_entities
(def company-sufex (str " (?:inc\\.?|corp\\\\.?|incorporated|corporation" ;US
                        "|l\\.?p\\.?|limited partnership |limited company"
                        "|l\\.?l\\.?c\\.?|limited liabilty"
                        "|l\\.?t\\.?d\\.?|limited"
                        "|p\\.?l\\.?c\\.?"
                        "|co\\.?|company,? l\\.?l\\.?c\\.?|company,? inc\\.?|company"
                        "|holdings(?: s\\.?a\\.?)|group"
                        "|S\\.? de R\\.?L\\.? de C\\.?V\\.?" ;mexico
                        "|s\\.?a\\.? de C\\.?V\\.?"         ;also mexico
                        "|s\\.?a\\.?"
                        "|b\\.?v\\.?"
                        "|S\\.?R\\.?L\\.?"
                        "|a\\.?s\\."
                        "|n\\.?v\\.?"                       ;dutch
                        "|a\\.?g\\.?)"                      ;German
                        "(?![A-z])"))
(def company-stop-prefix (re-pattern (str "(?: ?/ | each of | and by )")))

; (def company-sufex-re (re-pattern company-sufex))
(def company-re (re-pattern (str "(?i)(?! ?/ ).{3,50}?(?<! and by)" company-sufex)))

(def not-before "(?<!not |not be | or )")
(def must-start-with "(?i:guaranteed by|guarantor:|guarantors:|guarantor)")
(def not-between (str "(?!(?i)"
                      " of | us | as | at | to | in | is | and | any | has | have | meets | each | shall "
                      "|s|\u0092s|,| ?\u0094|.{0,3}?\\)| will | would | announce| files | with | can "
                      "|or otherwise| acquired a majority"
                      "| the United States and do| a parent company,| a member firm| credit ratings| ratings| a firm| the guarantor| general partner of"
                      ")"))
(def capture-group "( *.{3,40})")
(def must-end-with "(?:(?i)(?:,?)( will guarantee|will fully and unconditionally guarantee))")
(def guarantors-regex (re-pattern (str "(?:" not-before must-start-with not-between capture-group "|" capture-group must-end-with ")")))

(def table-regex #"((?i)guarantor:|guarantors:)(?!.+)")
(def table-filter-regex #"^((?!:).)*$")

(defn trim-front [str re] (if (re-seq re str)
                            (second (cs/split str re))
                            str))

(defn trim-parens [string] (-> string (cs/split #"\(") first (trim-front company-stop-prefix) cs/trim (cs/replace #"^(/ *|, *|and *|; *)" "")))

(defn first-capture [possibilities] (some->> (remove nil? possibilities)
                                             (keep #(first (re-seq company-re %)))
                                             (keep trim-parens)
                                             (apply vector)))


(defn tokenvec->matches
  [regex [sentence tokenvec]]
  (let [matches (rs/dissect sentence [{:regex regex :handler (fn [[_ & v]] {:value v})}])]
    (map (fn [{:keys [value indexes]}]
           (let [v (first-capture value)]
             (if (not (empty? v))
               {:value v
                :id    [(mapv :id (tv/unique-tokens tokenvec indexes))]})))
         matches)))

(defn find-guarantors
  "looks for tokenvecs in which a sentence indicates the guarantor."
  [enhik]
  (->> enhik
       mfu/enhik->sentence-tokenvecs
       (mapcat #(tokenvec->matches guarantors-regex %))
       (remove nil?)))


(defn enhick->table-node [enhanced-hickory]
  (some->> enhanced-hickory
           mfu/enhik->sentence-tokenvecs
           (map (fn [[sentence tokenvecs]] (vector (second (re-find table-regex sentence)) (:id (first tokenvecs)))))
           (remove (comp nil? first))
           (map #(hu/id->loc enhanced-hickory (second %)))
           (keep #(hs/up-pred % (hs/tag :tr)))
           (map zip/node)))


(defn find-in-row [enhanced-hickory]
  "looks for a tokenvec with some variant of 'guarantor:', looks at the row it appears in, ignores sentences"
  (doall (some->> enhanced-hickory
                  enhick->table-node
                  (mapcat mfu/enhik->sentence-tokenvecs)
                  (remove (fn [[sentence _]] (re-find guarantors-regex sentence))) ;don't bother with something find-guarantors does
                  (remove (fn [[sentence _]] (re-find #"(?i)\:" sentence)))
                  (mapcat (fn [[sentence tokenvecs]] (map #(if % (vector % tokenvecs))
                                                          (if (> 4 (count (cs/split sentence #" ")))
                                                            [sentence]
                                                            (re-seq company-re sentence)))))
                  (map (fn [[sentence tokenvecs]] [(trim-parens sentence) tokenvecs]))
                  (filter (comp pos? count first))
                  (map (fn [[sentence tokenvecs]] (vector sentence (mapv :id (tv/unique-tokens tokenvecs [0 (count sentence)])))))
                  (filter (fn [[sentence _]] (re-find table-filter-regex sentence)))
                  (#(if (empty? %) nil %))
                  (map (fn [[sentence ids]] (hash-map :value sentence :id ids)))
                  (medley/distinct-by :value)
                  (#(hash-map :value (mapv :value %) :id (mapv :id %)))
                  list)))


(defnk guarantors* [enhanced-hickory cusips]
  (let [cusip-6-count (->> cusips flatten (map #(:value (:cusip-6 %))) (remove nil?) (into #{}) count)
        table-guarantors (find-in-row enhanced-hickory)
        sentence-guarantors (find-guarantors enhanced-hickory)
        [f & r] (med/distinct-by :value (concat table-guarantors sentence-guarantors))
        g (select-keys f [:value :id])]
    (zipmap
      cusips
      (repeat (cond-> g
                      (not-empty g) (into {:jaeger ::guarantors :class :guarantors})
                      (seq r) (assoc :other-values r))))))





;(def md5-samples
;  [;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;   ;not in table
;   ;"df0a877b369aa332233fdcec9c4d4938"
;   ;"6328e512505e88d3e2f65793f2c97546"
;   ;"f564564c1387ce62fe2bf7e0c6ebfc66"
;
;   "a8574e2ca80591cbeeb7f1f450a463c1"
;   "fd9afb67768ef46f26a830551c286a83"
;   "29e96a7d2b62d361ad9c6ac809d2ce6a"
;   "f179660c283cc19d7c15d54c5f41fdc5"
;   "0a9f53bb3a47b0381f046c77f2e2d20d"
;
;   "185b01e040451ccdd09e3bc4b94027bd"
;   "5914baf84066c050c6a9b05c2026689e"
;   "cca61042335d20b35acaa9cbe1b6981f"
;   "c94a9eb15fb418d5c7abebfb9692be57"
;   "cffe5ad40673b0237d367fff1ecd4ec6"
;   "f3316fdecc1c31e855f94f3f8ba343b2"
;
;   ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;   ;missing another guarantor
;   "cd0d236914e7d52beae30b9a8e12bbf8"                       ;should be :["Historic TW Inc." "Home Box Office, Inc." "Turner Broadcasting System, Inc."]
;   "dbdec0f6e0821a66188d31114ab097ab"                       ;should be :["Historic TW Inc." "Home Box Office, Inc." "Turner Broadcasting System, Inc."]
;   ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;   ;seperated by comma
;   "9aba4764ceb07798f714bc942e09e2d6"
;   "0b3420954d0441f122cde9cb44e5ba84"
;   "047cd2829890aef928c223c4671499db"                       ;company name split to new row
;   "c174800d9cb768530cfd6c18b771daa2"                       ;should be: ["IntercontinentalExchange, Inc." "Baseball Merger Sub, LLC"
;   ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;   ;unnesicary parens (like this)
;   "af51b9aa654d369603586265483b17f5"
;   ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;   ;'and'
;   "227f0ab6600fe1642e9d137c50646851"
;   ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;   ;deals with the issuer
;   "55c83d8c632ec03e14145af22a1683d1"
;   "530ae96c10a6bf81a00df26322b028d9"                       ;guarantor->issuer.  Should be: ["Omega Healthcare Investors, Inc."]
;   "a95bc91b63d04fe842a3731a15d463c0"                       ;guarantor->issuer.  Should be: bear sterns or jpmorgan. Not: the company
;   ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;   ;table with sentence
;   "33f63b5f38c39cc47c7c886a937ed248"                       ;should be: ["Bai Brands LLC"]
;   ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;   ;needs cleaning
;   "08a31cd953cdd39de07927e61ce23e05"                       ;should be:["Santa Fe Natural Tobacco Company, Inc." "R. J. Reynolds Tobacco Company" "R. J. Reynolds Tobacco Co." "Reynolds Finance Company" "Reynolds Innovations Inc." "Conwood Holdings, Inc." "American Snuff Company, LLC" "Rosswil LLC" "R.J. Reynolds Tobacco Holdings, Inc." "R. J. Reynolds Global Products, Inc." "RAI Services Company"]
;   "2d75536be5d4c0299ff167892cff38b3"
;   "3c90a97ad7394f296671bb0176f6f2c2"                       ;CBS Operations Inc.
;   ])
;
;(def soda-2989
;  ["5609f32faa5fcd46fa7448ec8ac8b20a"
;   "3c90a97ad7394f296671bb0176f6f2c2"
;   "883e21f46eef9def0ecdbd0afff1dfcb"
;   "33f63b5f38c39cc47c7c886a937ed248"
;   "ad02ac225ca028aa29a032a31aa2eaf6"
;   "b07fb43cd28778a2ed58308353458b7a"
;   "317cf15d5ee48721984e248e56597627"
;   "a5d338961d7e04a92c20468e05a4f845"
;   "ffa7dc645e2b3bb65718791e9ba18c3c"
;   "d9e50b1d7de9fdbad1c985ff8b921d8c"
;   "715e9a64ad6cc8a79b2b11ade127904f"
;   "a95bc91b63d04fe842a3731a15d463c0"])
;
;(def sample-docs
;  (map #(->> {:md5 %}
;             jaegers.jaeger-primer/query->omni-data)
;       soda-2989))
;
;(map #(->> sample-docs
;           jaegers.edgar.prospectus.core/lazy-jaeger
;           :guarantors*
;           vals
;           first
;           :value))
