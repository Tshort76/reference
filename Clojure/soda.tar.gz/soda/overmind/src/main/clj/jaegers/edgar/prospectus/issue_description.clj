(ns jaegers.edgar.prospectus.issue-description
  (:require
    [clojure.edn :as edn]
    [clojure.java.io :as io]
    [clojure.pprint :as pp]
    [clojure.spec.alpha :as s]
    [clojure.string :as string]
    [edgar.geometric-combo-linker :as gcl]
    [enhanced-hickory.tokenvec :as eht]
    [jaegers.core :as jcr]
    [medley.core :refer [find-first]]
    [plumbing.core :refer [defnk]]
    [simple-mind.naive-bayes.core :as nb]
    [simple-mind.naive-bayes.util :as nbu]
    [simple-mind.naive-bayes.normalize :as nbn]
    [clojure.string :as cs]
    [clojure.set :as set]
    [jaegers.hickory-utils :as hu]
    [soda.core :as soda]
    [tokenvec.core :as tv]
    [jaegers.regisector :as rs]))

(def months "(?:jan|january|feb|february|mar|march|apr|april|may|jun|june|jul|july|aug|august|sep|september|oct|october|nov|november|dec|december)")
(def due-regex (re-pattern (str "(?i)due " months "? ?(?:\\d{1,2},? )?(\\d{4}|\\d\\d \\d\\d)(?: \\(.{10,25}\\))?")))

(def n-grams (range 3 10))
(def min-probability -20.0)
(def model (->> "jaegers/edgar_issue_description_bayes.edn" io/resource slurp edn/read-string))

(def remove-pattern
  "Pattern to filter out obviously bogus sentences"
  (let [exprs #{"l[.]?l[.]?c"
                "inc(orporated)?"
                "co(rp)?"
                "for"
                "retire"
                "per"
                "maturity"
                "holdings"}
        groups (string/join "|" (map #(str "(" % ")") exprs))]
    (re-pattern (str "(?i)(?:^|\\b)(?:" groups ")(?:\\b|$)"))))

(defn bogus-row-ids
  "looks for rows that issue descriptions should not appear on and return their row id and min-y"
  [features enhik]
  (->> (filter #(or (and (some (fn [feat] (->> feat :features :value-type #{:benchmark})) %)
                         (some (fn [feat] (->> feat :features :value-type #{:treasury})) %)
                         (some (fn [feat] (->> feat :features :value-type #{:colon})) %))
                    (and (some (fn [feat] (->> feat :features :value-type #{:colon})) %)
                         (some (fn [feat] (->> feat :features :value-type #{:offerings :offering})) %)
                         (some (fn [feat] (->> feat :features :value-type #{:concurrent})) %))) features)
       (map first)
      (map (juxt (comp (partial hu/id->row-id enhik) ffirst :ids) :min-y))))

(defn splitter [[s tvs]]
  (let [indexes (->> (rs/dissect s [{:regex due-regex :handler (fn [[_ & v]] {:value v})}])
                     (map :indexes)
                     (cons [0 0])
                     (partition 2 1)
                     (map (fn [[[_ b] [_ e]]] (vector b e))))

        split (map #(vector %1 %2)
                   (map (fn [[b e]] (subs s b e)) indexes)
                   (map #(tv/unique-tokens tvs %) indexes))]
     (if (and (seq indexes)) split [[s tvs]])))

(defn fix-multi-issue-desc [candidates]
  (for [x (map splitter candidates) y x] y))

(defn count-words [s]
  (-> s
      (string/replace #"[^a-zA-Z0-9\s\,\$\%\.\\\/]" "")
      (string/split #"\s")
      count))

(defn has-keywords? [s]
  (some #{"senior" "subordin" "conting" "float" "fix" "rate" "__year__" "__money__" "__percent__"}
        (some-> s nbu/->words nbn/normalize-words set)))

(defn has-rate-type-keywords? [s]
  (some #{"float" "fix" "__percent__"}
        (some-> s nbu/->words nbn/normalize-words set)))

(defn sanitize [s]
  (apply str (string/split s #"(?i)(^terms (of|applicable to) (the )?)" 2)))

(defn same-row?
  "takes a sentence-tokenvec and sees if it's in the same row-id or min-y"
  [enhik sentence-tv row-id]
  (let [s-tv (->> sentence-tv second ((juxt (partial some (comp (partial hu/id->row-id enhik) :id)) :min-y)))]
    (or (and (first s-tv) (first row-id) (= (first s-tv) (first row-id)))
        (and (second s-tv) (second row-id) (= (second s-tv) (second row-id))))))

(defn find-candidates [features enhik]
  (->> enhik
       eht/enhik->tokenvecs
       (take-while #(->> % first (re-find #"(?i)capitalization") not))
       (remove #(some (partial same-row? enhik %) features))
       (filter (comp #(>= 20 % 3) count-words first))
       (remove (fn [[s]] (or (re-find remove-pattern s) (re-find #"([.]$)|(:.+)" s))))
       (filter (comp has-keywords? first))
       fix-multi-issue-desc
       (map (fn [[s toks]]
              {:ids [(distinct (keep :id toks))]
               :class :issue-description
               :jaeger :issue-description
               :value (sanitize s)}))))

(defn string->bag-of-words [n-grams s]
  (apply merge (map #(nb/->bag-of-words (nbu/->words s) :n %) n-grams)))

(defn issue-description? [{v :value :as m}]
  (let [[[c p]] (nb/classify model (string->bag-of-words n-grams v) true)]
    (when (and (#{:issue-description} c) (> p min-probability))
      (assoc m :probability p))))
(defn find-issue-descriptions [features enhik]
  (let [features (bogus-row-ids features enhik)]
    (->> enhik
         (find-candidates features)
         (keep issue-description?))))

(defn best-candidate [cands]
  (let [cs (sort-by :probability > cands)]
    (or (find-first (comp has-rate-type-keywords? :value) cs)
        (first cs))))

; TODO add some secondary (basic-feature-based) search techniques
;
; under "Title of Each Class of Securities Offered"
; d8f793ffc7c253c99c56bbea764b1cf9
;
; checkbox!
; 6e6eb56e463917731cdbb5d8538cd175


(defnk issue-description* [enhanced-hickory cusips ids->coords row-sorted-features]
  (let [issue-descriptions (find-issue-descriptions row-sorted-features enhanced-hickory)]
    (cond
      (and (= 1 (count cusips)) (pos? (count issue-descriptions)))
      (zipmap cusips (repeat (best-candidate issue-descriptions)))

      (<= 1 (count cusips) (count issue-descriptions))
      (gcl/solve-for-edgar :issue-description cusips {:issue-description issue-descriptions} ids->coords))))


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;deduping stuff;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(def months "(?:jan|january|feb|february|mar|march|apr|april|may|jun|june|jul|july|aug|august|sep|september|oct|october|nov|november|dec|december)")

(defn cannon->str [cannon]
  (cs/join " " (filter identity cannon)))
(defn remove-spaces [s]
  (if s (cs/replace s #" " "") s))
(defn normalize-percents [s]
  (->> (re-find #"(?:(\d+\.? ?\d*)|(\d{0,2}) (\d+) ?/ ?(\d{1,4})) ?%" s)
       ((fn [[_ percent whole num denom]]
          (cond percent (soda/parse-double (remove-spaces percent))
                (and whole num denom) (+ (soda/parse-double whole)
                                         (/ (soda/parse-double num)
                                            (soda/parse-double denom))))))))

(defn cannonical-issue-description [issue-description]
  (->> [
        (second (re-find #"(\$\d{1,3}(?:,?\d{3})+) " issue-description)) ;principal
        (normalize-percents issue-description)
        (cond                                               ;rate-type
          (second (re-find #"(?i)(fixed|\d{1,4} ?%)" issue-description)) "fixed-rate"
          (second (re-find #"(?i)float" issue-description)) "floating-rate")
        (second (re-find #"(?i)(secured|unsecured)" issue-description)) ;secured
        (second (re-find #"(?i)(guaranteed|unguaranteed)" issue-description)) ;guaranteed
        (remove-spaces (second (re-find #"(?i)(s ?enior|j ?unior)" issue-description))) ;debt-level
        (remove-spaces (second (re-find #"(?i)(n ?otes|b ?onds|d ?ebentures|c ?ertificates)" issue-description))) ;type
        (first (re-find #"(?i)series ([A-Z])" issue-description)) ;series
        (first (re-find #"(?i)(class [A-Z])" issue-description))
        (remove-spaces (second (re-find due-regex issue-description)))]

       (map #(if % (cs/lower-case %)))))

(defn compare-issue-descriptions [x y]
  (->> (map #(or (nil? %1) (nil? %2) (= %1 %2)) x y)
       (every? true?)))

(defn sort-cannonical [issue-descriptions]
  (->> issue-descriptions
       (sort-by #(if (:probability %) (:probability %) Double/NEGATIVE_INFINITY) >)
       (sort-by (comp count (partial keep identity) :cannonical) >)))

(defn dedup-issue-desc [issue-descriptions]
  (->> (let [coll (->> (map #(assoc % :cannonical (cannonical-issue-description (:value %))) issue-descriptions)
                       sort-cannonical)]
         (loop [ret [] x (first coll) xs (rest coll)]
           (if x
             (let [matching (into #{} (filter (comp (partial compare-issue-descriptions (:cannonical x)) :cannonical) xs))
                   remaining (->> (set/difference (into #{} xs) matching) sort-cannonical)]
               (recur (conj ret (assoc x :duplicates matching)) (first remaining) (rest remaining)))
             ret)))
       (map (fn [{:keys [cannonical duplicates] :as entry}] (->> (map :cannonical duplicates)
                                                                 (cons cannonical)
                                                                 (apply map (fn [& xs] (some identity xs)))
                                                                 (#(assoc entry :cannonical (cannon->str %))))))))


;; -----------------------------------------------------------------------------

;; code to generate a training set
(comment
  (require 'jaegers.md5-control-sets
           '[soda.data.core :refer [defcon]]
           '[datasources.core :as ds]
           '[doc-transforms.core :as dtc]
           '[monger.collection :as mc])
  (import '[org.bson.types ObjectId])
  (defcon "training-sets" "features-descriptors")
  (defcon "training-sets" "feature-maps")

  (defn write-features-descriptor []
    (mc/insert (ds/get-db "training-sets") "features-descriptors"
               {:_id :edgar-issue-description2 :jaeger :edgar-issue-description2 :features-descriptor {:class {:options [:issue-description :other]}}}))

  (defn write-feature-maps []
    (->> (jaegers.md5-control-sets/control-sets :edgar-multi-600)
         (group-by :md5)
         (map (comp first second))
         (pmap
           (fn [{:keys [md5 filename]}]
             (some->> {:md5 md5}
                      (dtc/mongo->transform :enhanced-hickory)
                      :enhanced-hickory
                      not-empty
                      (enhanced-hickory.core/filter-pages 1)
                      find-candidates
                      (remove (comp (partial re-find remove-pattern) :value))
                      (map #(-> (dissoc % :class)
                                (assoc :descriptor-id :edgar-issue-description2 :filename filename :md5 md5)))
                      bulk-write-feature-maps)))))

  ;; generate the model from the training data
  (defn get-model [n-grams train-set]
    (let [{:strs [issue-description other]} (group-by (comp :class :features) train-set)]
      (reduce (fn [m n] (-> (nbu/train-all m :issue-description (map :value issue-description) :n n)
                            (nbu/train-all :other (map :value other) :n n)))
              {} n-grams)))

  #_(let [train-set (feature-maps {:descriptor-id :edgar-issue-description2 :validated? true})
          model (get-model n-grams train-set)]
      (spit "/tmp/edgar_issue_description_bayes.edn" model))


  (def memoized-query-omni-data
    (memoize (fn [q] (jaegers.jaeger-primer/query->omni-data q))))


  #_(run-all {:filename "0001193125-15-285301.txt"})
  #_(run-all {:filename "0001214659-14-006983.txt"})
  #_(run-all {:filename "0000891092-13-002523.txt"})
  #_(run-all {:filename "0000950103-15-006623.txt"}))
