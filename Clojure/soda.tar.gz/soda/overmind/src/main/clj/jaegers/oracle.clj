(ns jaegers.oracle
  (:require [clojure.set :as set]
            [clojure.string :as str]
            [environ.core :refer [env]]
            [medley.core :refer [map-vals filter-vals]]
            [yesql.core :refer [defqueries]]
            [clojure.instant :refer [read-instant-date]]
            [datasources.core :as ds]
            [monger.collection :as mc]
            [soda.core :as basic]
            [clojure.java.io :as io]
            [jaegers.edgar.equity.exchange-mapping :as exm]))

(defn dissoc-nil [m]
  (dissoc m nil))

(defn mekadragon [] (ds/get-db "mekadragon"))

(def oracle-collection "oracle_cache")

;; ORACLE LOGIC ;;

(def db-spec {:classname "net.sourceforge.jtds.jdbc.Driver",
              :subprotocol "jtds:sqlserver",
              :subname (str "//" (:soda-sql-db env "soda-db") ":1433"),
              :user "soda",
              :password (:datasources-soda-password env "soda")})

; (defn get-oracle-query-names
;   "Fetch the query fn names from a sql file."
;   [filename]
;   (filter #(str/starts-with? % "-- name:") (str/split-lines (slurp (io/resource filename)))))

(defqueries "sql/oracle.sql" {:connection db-spec})
;(get-oracle-query-names "sql/oracle.sql")
;  ("-- name: munis->lm-main"
;   "-- name: munis->lm-mrs"
;   "-- name: munis->lm-ors"
;   "-- name: edgar->lm-cos"
;   "-- name: edgar->lm-main"
;   "-- name: edgar->cusip-db"
;   "-- name: usbank->newcmo")

(defqueries "sql/cusip_db.sql" {:connection db-spec})
;(get-oracle-query-names "sql/cusip_db.sql")
 ; ("-- name: cusip6-2-sum->series-name"
 ;  "-- name: cusips->series-name")

(defn clean-emma-names [emma-map]
  (reduce
   (fn [result [dirty-name v]]
     (assoc result (-> dirty-name
                       name
                       (str/replace-first "emma-" "")
                       keyword) v))
   {} emma-map))

(defn format-emma-schedule [schedule]
  (->> schedule
       (keep (basic/comp->
              (set/rename-keys
               {:optional-redemption-paydown-schedule.date :date
                :optional-redemption-paydown-schedule.price :price
                :mandatory-redemption-paydown-schedule.date :date
                :mandatory-redemption-paydown-schedule.amount :amount})
              (select-keys [:date :price :amount])
              not-empty))
       not-empty))

(defn format-edgar-schedule [schedule]
  (when-let [schedule (not-empty
                        (keep (comp
                                (fn [{date :effective-date :as m}] (when date (update m :effective-date read-instant-date)))
                                #(not-empty
                                   (select-keys
                                     (set/rename-keys
                                       %
                                       {:call-option-schedule.date  :effective-date
                                        :call-option-schedule.price :price})
                                     [:effective-date :price])))
                              schedule))]
    (if (every? #(== 100 (:price %)) schedule)
      [(first schedule)]
      schedule)))

; (defn series-name-query [cusip]
;   (when (= 9 (count cusip))
;     {:cusip6 (subs cusip 0 6)
;      :cusip2 (subs cusip 6 8)
;      :checksum (subs cusip 8 9)}))

(defn clean-due-date [doc]
  (-> doc
      (dissoc :due-date.day-of-month :due-date.month-of-year :due-date.year)
      (assoc-in [:due-date :day-of-month] (:due-date.day-of-month doc))
      (assoc-in [:due-date :month-of-year] (:due-date.month-of-year doc))
      (assoc-in [:due-date :year] (:due-date.year doc))))

(defn clean-emma-doc [doc]
  (some-> doc
          (dissoc :_id :url :emma-long-description :emma-short-description)
          clean-emma-names
          (set/rename-keys {:coupon-rate :interest-rate
                            :dated-date :issue-dated-date
                            :cusip-9 :cusip})
          (assoc :emma? true)))

(defn clean-bigdec [doc]
  (map-vals #(cond-> % (decimal? %) double) doc))

(defn cusips->emma-cache [cusips]
  (->> (mc/find-maps (mekadragon) "emma-security-data-cache" {:cusip-9 {:$in cusips}})
       (map clean-emma-doc)))

(defn format-emma-schedule-data [data & ors?]
  (let [sched-key (if ors? :optional-redemption-paydown-schedule
                           :mandatory-redemption-paydown-schedule)]
    (->> data
         (group-by :cusip)
         dissoc-nil
         (map (fn [[cusip schedule]]
                (when cusip
                  {:cusip cusip
                   sched-key (format-emma-schedule schedule)}))))))

(defn format-edgar-schedule-data [data]
  (->> data
       (group-by :cusip)
       dissoc-nil
       (map (fn [[cusip schedule]]
              (when cusip
                {:cusip    cusip
                 :call-option-schedule (format-edgar-schedule schedule)})))))

(defn- select-keys+ [doc keys]
  (filter-vals some? (select-keys doc keys)))

(defn- update-select [main-doc main-key s-doc s-keys]
  (update main-doc main-key
          (fnil conj []) (select-keys+ s-doc s-keys)))

(defn- update-double [doc fields]
  (reduce (fn [d f] (update d f (fn [x] (when x (double x)))))
          doc fields))

(defn format-newcmo-data [data]
  (->> data
       (map #(update-double % [:factor
                               :accrued-interest-amount
                               :distributed-interest-amount
                               :interest-shortfall-amount
                               :coupon-rate
                               :distributed-principal-amount
                               :ending-balance]))
       (group-by :cusip)
       dissoc-nil
       vals
       (map (partial reduce
              (fn [main doc]
                (-> main
                    (merge (select-keys+ doc [:cusip
                                              :tranche
                                              :original-balance
                                              :ending-balance]))
                    (update-select :interest-distributions
                                   doc [:accrued-interest-amount
                                        :distributed-interest-amount
                                        :interest-shortfall-amount
                                        :begin-date])
                    (update-select :principal-distributions
                                   doc [:distributed-principal-amount
                                        :principal-realized-loss-amount
                                        :begin-date])
                    (update-select :coupon-rates
                                   doc [:coupon-rate
                                        :begin-date])
                    (update-select :factors
                                   doc [:factor
                                        :begin-date])))
              {}))))

(defn clean-nils [data]
  (cond
    (sequential? data) (seq (keep clean-nils data))
    (map? data) (->> data
                     (map-vals clean-nils)
                     (filter-vals some?)
                     not-empty)
    :else data))

(defn merge-and-write [lm-muni-partition]
  (->> lm-muni-partition
       (map :cusip)
       cusips->emma-cache
       (concat lm-muni-partition)
       (group-by :cusip)
       dissoc-nil
       (map (comp
              (partial hash-map :source "lm" :data)
              #(dissoc % :emma?)
              (partial apply merge)
              (partial sort-by :emma?)
              second))
       clean-nils
       (ds/bulk-write (mekadragon) oracle-collection)))

(defn mic->exchange-name [mic]
  (->> exm/mapping
       (filter (comp #{mic} :mic))
       first
       :exchange-name))
(defn name->share-class [sc]
  (when sc (second (re-find #"(?i:class|cl) (\w+)" sc))))

(defn format-edgar-data [data]
  (->> data
       (map #(update % :primary-exchange mic->exchange-name))
       (map #(update % :share-class name->share-class))))

(defn refresh-cache []
  (mc/remove (mekadragon) oracle-collection {:source "lm"})
  (let [lm-muni-data (map clean-due-date (munis->lm-main))
        lm-ors-data (format-emma-schedule-data (munis->lm-ors) true)
        lm-mrs-data (format-emma-schedule-data (munis->lm-mrs))
        lm-cos-data (format-edgar-schedule-data (edgar->lm-cos))
        lm-edgar-data (format-edgar-data (edgar->lm-main))
        cusipdb-data (map clean-bigdec (edgar->cusip-db))
        newcmo-data (format-newcmo-data (usbank->newcmo))]
    (->> (concat newcmo-data cusipdb-data lm-ors-data lm-mrs-data lm-edgar-data lm-cos-data lm-muni-data)
         (group-by :cusip)
         dissoc-nil
         (map (comp (partial apply merge) second))
         (partition-all 200)
         (map merge-and-write))))


(defn add-validation
  ([cusip field-map]
   (mc/upsert (mekadragon) oracle-collection {:data.cusip cusip
                                              :source "notary"}
              {:$set (reduce (fn [m [f v]]
                               (assoc m (str "data." (name f)) v))
                             {:data.cusip cusip
                              :source "notary"}
                             field-map)}))
  ([cusip field value]
   (mc/upsert (mekadragon) oracle-collection {:data.cusip cusip
                                              :source "notary"}
              {:$set {:data.cusip cusip
                      :source "notary"
                      (str "data." (name field)) value}})))

(defn cusips->oracle-data [cusips]
  (when (seq cusips)
    (->> {:source {:$in ["notary" "lm"]}
          :data.cusip {:$in cusips}}
         (mc/find-maps (mekadragon) oracle-collection)
         (map #(dissoc % :_id)))))
