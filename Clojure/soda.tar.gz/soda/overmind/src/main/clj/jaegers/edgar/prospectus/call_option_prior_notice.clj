(ns jaegers.edgar.prospectus.call-option-prior-notice
  (:require [jaegers.edgar.tokens :as ec]
            [jaegers.jaeger-primer :as primer]
            [jaegers.core :as jcr]
            [simple-mind.parse-objects-utils :as pou]
            [clojure.string :as cs]
            [plumbing.core :refer [defnk]]
            [duckling.core :as p]))

(when-not *compile-files*
  (p/load! {:languages ["en"]}))

(def stop-words-re #"(upon at least \d+|prior (written )?notice|days notice|calendar days notice)")
(def prior-notice-re (re-pattern (str #"(?i)Redemption.{0,500}" stop-words-re)))

(defn normalize-text [text] (cs/replace text #"[^a-zA-Z0-9:]" ""))

(defn get-candidates [enhik]
  (->> (filter #(and (not-empty (:text %)) (not-empty (:id %))) (ec/extract-tokens enhik))
       (pou/rematch-in prior-notice-re [:text])
       (map (comp (partial map #(update % :text normalize-text)) :objs))))

(defn classify-candidates [cands]
  (keep
    (fn [cand]
      (let [{:keys [ids text]} (first (ec/token-regex cand (re-pattern (str #"(?i).{0,40}" stop-words-re))))]
        (when-let [value (some->> (p/parse :en$core text [:number])
                                  (map (comp :value :value))
                                  (filter #(<= % 180))
                                  seq
                                  (apply min))]
          {:value  value
           :text   text
           :ids    [ids]
           :jaeger ::call-option-prior-notice
           :class  :call-option-prior-notice
           :type   :call-option-prior-notice})))
    cands))

(defnk call-option-prior-notice* [enhanced-hickory cusips call-option-date*]
  (when call-option-date*
    (when-let [cand (first (classify-candidates (get-candidates enhanced-hickory)))]
      (zipmap cusips (repeat cand)))))

(comment
  (def memoized-query-omni-data
    (memoize (fn [q] (primer/query->omni-data q))))

  (run-all {:filename "0001193125-16-680788.txt"})
  (run-all {:md5 "f1b8295a8786b91d02719e117a1308f6"})
  )
