(ns jaegers.utils
  (:require [clojure.core.reducers :as r]
            [clojure.string :as cs]
            [soda.core :as soda]))

(def max-height 800)                                        ; max height of a PDF page, in points

(defn mostly? [pred threshold vals]
  (let [total-c (count vals)
        match (count (filter pred vals))]
    (>= (/ match total-c) threshold)))

(defn unpack-key-fn [k]
  (fn [agg-obj]
    (-> agg-obj
        (into (k agg-obj))
        (dissoc k))))

; (defn unpack-keys [keys objects]
;   (map (apply comp (map unpack-key-fn keys)) objects))

(defn id->vec [id]
  (when id
    (mapv soda/parse-long (cs/split id #"_"))))

(defn id-cmp
  "Compares two ids in vector form."
  [v1 v2]
  (or (some #{-1 1} (map compare v1 v2)) (compare v1 v2)))

(defn sort-ids
  "Sorts a collection of string ids."
  [ids]
  (sort-by id->vec id-cmp ids))

(defn precedes?
  "Returns true if coord a precedes coord b."
  [a b]
  (neg? (compare ((juxt :page-number :y :x) a)
                 ((juxt :page-number :y :x) b))))

(defn euclid-dist
  "Calculates the Euclidean (straight-line) distance between two coords."
  [{x0 :x y0 :y p0 :page-number}
   {x1 :x y1 :y p1 :page-number}]
  (let [p-gap (- p1 p0)
        a (- x0 x1)
        b (if (zero? p-gap)
            (- y0 y1)
            (+ y1 (- (* max-height p-gap) y0)))]
    (Math/sqrt (+ (* a a) (* b b)))))

(defn manhattan-dist
  [{x0 :x y0 :y p0 :page-number}
   {x1 :x y1 :y p1 :page-number}]
  (reduce + (map (comp #(Math/abs ^double %) -) [x0 y0 (* p0 max-height)] [x1 y1 (* p1 max-height)])))

(defn token-dist
  "Calculates the number of tokens between two coords in mindfood."
  [mindfood {pa :page-number :as a} {pb :page-number :as b}]
  (letfn [(tok->coord [x] (select-keys x [:page-number :y :x]))]
    (let [xf (comp (drop-while #(not= a (tok->coord %)))
                   (take-while #(not= b (tok->coord %))))]
      (->> mindfood
           (r/map :vals)
           (r/remove nil?)
           r/flatten
           (r/filter (comp (into #{} (range pa (inc pb))) :page-number))
           r/foldcat
           (into [] xf)
           count))))

; (defn find-nearest-series
;   "Generic nearest series algorithm.
;   kw is name of value to be returned.
;   get-value-fn is a function that takes the jaeger and returns the value"
;   [series jaegers kw get-value-fn & [insert-on-fail?]]
;   (reduce (fn [coll jaeger]
;             (let [cacoord (-> (get-value-fn jaeger) :coords flatten first)
;                   matches (for [{{:keys [coords] :as srs} :series} series
;                                 scoords (flatten coords)
;                                 :when (precedes? scoords cacoord)]
;                             {:series srs
;                              :dist   (euclid-dist cacoord scoords)
;                              kw      (kw jaeger)})]
;               (if (seq matches)
;                 (conj coll (dissoc (apply min-key :dist matches) :dist))
;                 (if insert-on-fail?
;                   (conj coll jaeger)
;                   coll))))
;           [] jaegers))

(defn <-nearest-attribute [attributes coordinate dist-fn]
  (when (seq attributes)
    (let [distance-from-coordinate
          (fn [{:keys [coords value]}]
            (or (some->> (flatten coords)
                         (filter #(precedes? % coordinate))
                         not-empty
                         (apply min-key (partial dist-fn coordinate))
                         (dist-fn coordinate))
                Double/NaN))]
      (apply min-key distance-from-coordinate attributes))))

(defn assoc-nearest-series
  [agg-docs <-comparison-coord jaeger-results & {:keys [dist-fn] :or {dist-fn euclid-dist}}]
  (let [series (some->> (keep :series agg-docs) not-empty (into #{}))]
    (map #(assoc % :series (<-nearest-attribute series (<-comparison-coord %) dist-fn)) jaeger-results)))

(defn assoc-nearest-series*
  [series <-comparison-coord jaeger-results & {:keys [dist-fn] :or {dist-fn euclid-dist}}]
  (let [unique-series (some->> series not-empty (into #{}))
        serie->jr (reduce (fn [ret jr]
                            (if-let [serie (<-nearest-attribute unique-series (<-comparison-coord jr) dist-fn)]
                              (assoc ret serie jr)
                              ret))
                          {}
                          jaeger-results)]
    (map serie->jr series)))

(defn map-vals [f m]
  (zipmap (keys m)
          (map f (vals m))))

(defn aggregate-by-series [agg-docs jaeger-results]
  (let [maps (->> jaeger-results
                  (filter :series)
                  (group-by (comp :value :series))
                  (map-vals first))]
    (map #(->> % :series :value maps (merge %)) agg-docs)))

(defn aggregate-by-cusip [cusip-docs jaeger-results provides]
  (let [found jaeger-results
        m (into (group-by (comp :value :cusip-9) found) (group-by (comp :value :cusip-3) found))
        c (zipmap (keys m) (map #(-> % first) (vals m)))]
    (mapv (fn [{{c9 :value} :cusip-9 {c3 :value} :cusip-3 :as doc}]
            (-> (or (and c9 (get c c9)) (and c3 (get c c3)) {})
                (select-keys provides)
                (#(merge doc %)))) cusip-docs)))

; (defn capitalize-words [s]
;   (->> (cs/split (str s) #"\s")
;        (map cs/capitalize)
;        (cs/join " ")))
