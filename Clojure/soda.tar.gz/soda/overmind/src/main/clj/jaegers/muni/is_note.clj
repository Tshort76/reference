(ns jaegers.muni.is-note
  (:require [clj-time.core :as time]
            [clj-time.coerce :as time.coerce]
            [plumbing.core :refer [defnk]]))

(defn find-note [{md :value} {idd :value} {issue-desc :value}]
  (when (and md idd issue-desc
             (time/after? (time/plus (time.coerce/from-date md) (time/days 400))
                          (time.coerce/from-date idd))
             (re-find #"(?i)notes" issue-desc))
    {:jaeger :is-note :value true}))

(defnk is-note [maturity-date* issue-dated-date* issue-description*]
  (zipmap
    (keys maturity-date*)
    (map find-note (vals maturity-date*) (vals issue-dated-date*) (vals issue-description*))))
