(ns jaegers.edgar.prospectus.rate-multiplier
  (:require [plumbing.core :refer [defnk]]
            [edgar.geometric-combo-linker :as gcl]
            [jaegers.mind-food-utils :as mfu]
            [jaegers.regisector :as rs]
            [tokenvec.core :as tv]))

(defn safe-min
  ([] nil)
  ([a] a)
  ([a b & args] (apply min a b args)))

(defn safe-max
  ([] nil)
  ([a] a)
  ([a b & args] (apply max a b args)))

(defn add-coords [m objects]
  (assoc m :min-x (apply safe-min (keep :min-x objects))
         :max-x (apply safe-max (keep :max-x objects))
         :min-y (apply safe-min (keep :min-y objects))
         :max-y (apply safe-max (keep :max-y objects))))

(defn format-matches [sentence tokenvec {:keys [indexes value]}]
  (let [tokens (tv/unique-tokens tokenvec indexes)]
    (add-coords
     {:value value
      :text  sentence
      :class :multiplier
      :ids   [(mapv :id tokens)]}
     tokens)))

(defn mult-matches [[sentence tokenvec]]
  (->> (rs/dissect sentence
                   [{:regex #"(?i)(?:(?<!spread ?)multiplier|leverage factor|product) .{0,20}?(\d+(?:\.\d+)?)(%)?(?![-\d.]|\s?cms)"
                     :handler (fn [[_ v p]] {:value (cond-> (Double/parseDouble v)
                                                            p (/ 100))})}])
       (mapv (partial format-matches sentence tokenvec))))

(defn find-multiplier [enhik]
  (let [tokenvec (mfu/enhik->row-and-sentence-tokenvec enhik)]
    (seq (mapcat mult-matches tokenvec))))

(defnk multiplier* [coupon-rate-type* ids->coords enhanced-hickory]
  (let [cusips (keys (filter (fn [[_ {:keys [value]}]]
                               (#{:Floating :Fixed-to-float :Float-to-fixed} value))
                             coupon-rate-type*))
        candidates (find-multiplier enhanced-hickory)]
    (if (<= 1 (count cusips) (count candidates))
      (gcl/solve-for-edgar :multiplier cusips
                           {:multiplier (mapv #(assoc % :class :multiplier)
                                                       candidates)}
                           ids->coords)
      (zipmap cusips (repeat nil)))))
