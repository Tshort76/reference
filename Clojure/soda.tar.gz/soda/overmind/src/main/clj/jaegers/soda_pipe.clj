(ns jaegers.soda-pipe
  (:require [jaegers.aggregator :as ja]
            [jaegers.conflicts :as con]
            [jaegers.uncertainty :as d]
            [jaegers.core :as jc]
            [jaegers.md5-control-sets :as cs]
            [soda.data.file-system :as sdfs]
            [soda.jobs.job-defs :as jdefs]
            [soda.jobs.utils :as jutils]
            [soda.data.core :refer [defcon]]
            [taoensso.timbre :as timbre]
            [jaegers.ml-pipe :as ml-pipe]))

(defcon "soda-raw" "jaegers" :updatable true)
(defcon "soda-raw" "data" :basename "raw-data")

(defn *query->jaeger-data [{:keys [cusips md5s] :as query}]
  (letfn [(args->match-clause [{cusips :cusips md5s :md5s}]
            (cond-> {:meta.outdated? nil}
                    md5s (assoc :meta.md5 {:$in md5s})
                    cusips (assoc :jaeger-doc.cusip-9.value {:$in cusips})
                    (not cusips) (assoc :jaeger-doc.cusip-9 {:$ne nil})))]
    (jaegers (if (or cusips md5s) (args->match-clause query) query))))

(defn mind-food->jaeger-db-docs [{:keys [starter mind-food]}]
  (let [jaeger-docs (if starter
                      (ja/accrete mind-food starter)
                      (ja/accrete mind-food))
        ml-jaeger-docs (ml-pipe/accrete mind-food)]
    (->> (concat jaeger-docs ml-jaeger-docs)
         (mapcat #(jc/->jaeger-db-form mind-food % "jaeger-aggregator"))
         (#(do (if (empty? %) (timbre/info (str "No jaeger data to write for " (:md5 mind-food))))
               %)))))

; (defn md5->security-docs
;   "Get the mind-food for a given md5 and run the jaegers on it. The output format is compatible with
;   soda-raw entity maps."
;   [md5 & {starter :starting-jaeger}]
;   (timbre/info "This function should never, ever be called in production. It should only be used for debugging.
;   Any function that touches the db mid-pipe is evil.")
;   (if-let [mind-food (jp/query->omni-data {:md5 md5})]
;     (mind-food->jaeger-db-docs {:mind-food mind-food :starter starter})
;     (do
;       (timbre/warn {:message (str "No security data was produced for " md5 ".")
;                     :form    (str "(jp/query->omni-data {:md5 " md5 "})")})
;       [])))

;This is bad mojo that needs to be kicked from the pipe.
(defn write-jaeger-finds [docs]
  (let [md5s (mapv (comp :md5 :meta) docs)]
    (update-jaegers {:meta.md5 {:$in md5s}} {:$set {:meta.outdated? true}} {:multi true})
    (bulk-write-jaegers docs)))

(defn run-jaegers-on-omnis [omnis]
  (some->> omnis
           (pmap (fn [omni]
                   (timbre/debug (str "processing md5: " (:md5 omni)))
                   (mind-food->jaeger-db-docs {:mind-food omni})))
           flatten (filter identity) seq))

(defn securities->mongo [omnis]
  (let [chunks (partition-all 50 (into #{} omnis))]
    (map (fn [chunk batch-num]
           (timbre/debug (str "processing batch: " batch-num " of " (count chunks)))
           (run-jaegers-on-omnis chunk))
         chunks
         (iterate inc 1))))

(defn submit-prospectuses [entity-maps]
  (when (seq entity-maps)
    (->> entity-maps
         bulk-write-raw-data
         (#(hash-map :min-id (first %) :max-id (last %)))
         jdefs/normalize
         jutils/enqueue-job)))

(defn ->jaeger-db->ecs-form [query]
  (->> query
       *query->jaeger-data
       d/remove-n-record-doubtfuls!
       (remove con/conflicted-doc?)
       (map jc/jaeger-db-form->ecs)))

(defn bulk-jaeger-db->soda-api [cusips]
  (->> (partition-all 200 cusips)
       (pmap (fn [x] (->> {:cusips x}
                          ->jaeger-db->ecs-form
                          submit-prospectuses)))))

;;;;    STUFF FOR SODA JOBS     ;;;;

(defn jaegerize [m]
  (mind-food->jaeger-db-docs m))

; (defn jaegers->soda-raw [query bid]
;   (let [ids (some->> query
;                      ->jaeger-db->ecs-form
;                      not-empty
;                      bulk-write-raw-data)
;         {:keys [min max]} (jutils/ids->range ids)]
;     (when ids
;       (-> (jdefs/normalize {:min-id min :max-id max})
;           (assoc :bid bid)
;           jutils/enqueue-job))
;     ids))

;;;;;; SOME HELPER FUNCTIONS

; (defn write-data [control-set & {->api? :->api?}]
;   (let [cs (get cs/control-sets (keyword control-set))]
;     (dorun (securities->mongo (->> cs (map :md5) set)))
;     (when ->api?
;       (dorun (bulk-jaeger-db->soda-api (map :cusip cs))))))

(defn outdate-jaegers
  "Meant for outdating all jaeger-docs to be run.  Expects a training-set."
  [docs]
  (let [md5s (mapv :md5 docs)]
    (update-jaegers {:meta.md5 {:$in md5s}} {:$set {:meta.outdated? true}} {:multi true})))

(defn write-data-via-queue [control-set & {:keys [starting-jaeger ->api? priority out-date? run-cusipless?]}]
  (let [cs (->> control-set
                keyword
                cs/control-sets
                (group-by :md5)
                (map (comp first second)))
        file-type (cs/set->file-type control-set)]
    (do (if out-date? (outdate-jaegers cs))
        (->> cs
           (map #(-> %
                     (assoc :file-type file-type
                            :starting-jaeger starting-jaeger
                            :->api? ->api?
                            :run-cusipless? run-cusipless?)
                     jdefs/jaegerize
                     (assoc :priority priority)
                     jutils/enqueue-job))
           doall))))

(defn write-md5-via-queue [md5 & {:keys [starting-jaeger ->api? priority out-date? run-cusipless?]}]
  (do (if out-date? (outdate-jaegers [:md5 md5]))
    (some-> {:md5 md5}
            sdfs/find-one-meta
            (assoc :starting-jaeger starting-jaeger
                   :->api? ->api?
                   :run-cusipless? run-cusipless?)
            jdefs/jaegerize
            (assoc :priority priority)
            jutils/enqueue-job)))

(comment

  (write-data :thrifty-30
              :->api? true)


  ;Added a new function that allows an optional argument to pipe data into the api after generating jaegers
  (write-data :kilo-of-happiness)
  (write-data :century-of-fun)
  (write-data :frolicsome-500)
  (write-data :flamboyant-500)
  (write-data :flippant-500)
  (write-data :serendipitous-7k))
