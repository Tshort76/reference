(ns jaegers.edgar.entity.core
  (:require
    [plumbing.graph :as graph]
    [jaegers.edgar.prospectus.core :as jec]
    [jaegers.edgar.entity
     [subsidiaries :as subsidiaries]]))

(def jaeger-graph
  {:entity-name* subsidiaries/entity-name*
   :subsidiaries* subsidiaries/subsidiaries*})

; (def profiled-jaeger (graph/compile (graph/profiled :profile-data jaeger-graph)))
; (def jaeger (graph/compile jaeger-graph))
(def par-jaeger (graph/par-compile jaeger-graph))
(def lazy-jaeger (graph/lazy-compile jaeger-graph))

; (def execute-jaeger (partial jec/safe-execute-jaeger jaeger))
(def execute-parallel-jaeger (partial jec/safe-execute-jaeger par-jaeger))
(def execute-lazy-jaeger (partial jec/safe-execute-jaeger lazy-jaeger))
