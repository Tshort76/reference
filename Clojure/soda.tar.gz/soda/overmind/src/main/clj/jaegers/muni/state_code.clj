(ns jaegers.muni.state-code
  (:require [clojure.string :as cs]
            [soda-common.regexes :as scr]
            [soda-common.state-data :as sd]
            [jaegers.spec]
            [jaegers.mind-food-utils :as mfu]
            [plumbing.core :refer [defnk]]))

(defn sanitize [word] (cs/upper-case (cs/replace word #"\W+" "")))

(defn mind-food->all-state-codes [mind-food]
  (let [unigrams (mfu/terms mind-food :sanitizer sanitize)
        bigrams (mfu/n-grams 2 unigrams)
        trigrams (mfu/n-grams 3 unigrams)
        occurences (filter #(re-matches scr/state-names (first %)) (concat unigrams bigrams trigrams))
        m (->> occurences (group-by first))]
    (zipmap (keys m) (map (fn [v] {:count (count v) :ids (vec (mapv second v))}) (vals m)))))

(defn mind-food->state-code [mind-food]
  (let [[state-name {:keys [ids]}]
        (some->> mind-food mind-food->all-state-codes not-empty (apply max-key (fn [[_ {:keys [count]}]] count)))
        m (zipmap (map cs/upper-case (keys sd/name->code)) (vals sd/name->code))]
    (when state-name [{:state-code {:value  (m state-name)
                                    :ids    ids
                                    :class  :state-code
                                    :jaeger :state-code}}])))

(defnk state-code* [mind-food state-code]
  (if (some identity (vals state-code))
    state-code
    (zipmap (keys state-code) (repeat (:state-code (first (mind-food->state-code mind-food)))))))

;(process-state-code {:md5 "a6df0ac30829ff023a75e311d668dc38"})
;(find-state-code {:meta.md5 "ede32f3f68d274a1ddf19d55d1134977"})
;(macroexpand
;  '(jc/defjaeger
;  :state-code
;  :fields [:state-code]))

;(:meta (find-mindfood {:md5 "05b091aa23db946f531a20ee15eb72e0"}))
;(batch-process-state-code :partition-size 10 :num-partitions 2)

;;Odd cases
; d96253e1fbb0c317d6704996cc0b31d6 - District of Columbia - Now works
; a6df0ac30829ff023a75e311d668dc38 - text is all weird
; 05b091aa23db946f531a20ee15eb72e0 - No states listed

;(hunt {:query           {:md5 "a6df0ac30829ff023a75e311d668dc38"}
;       :jaeger-function mind-food->state-code
;       :skip-when-exists-in find-state-code
;       :format :jaeger-db})

;(->> {:md5 "d96253e1fbb0c317d6704996cc0b31d6"}
;     find-mindfood
;     mind-food->state-code
;     (s/valid? :jaeger/docs))
;
;(->> {:md5 "a6df0ac30829ff023a75e311d668dc38"}
;     find-mindfood
;     :mind-food
;     mind-food->state-code
;     )
;
;(->> {:md5 "05b091aa23db946f531a20ee15eb72e0"}
;     find-mindfood
;     :mind-food
;     mind-food->state-code)

;(process {:query {:md5 "2be6cfc93dd515f0fe0080dcbab30949"}})
;
;(->> (hunt {:query {:md5 {:$in ["2be6cfc93dd515f0fe0080dcbab30949"
;                                "432bd45ce8cd17ee1f5d2d176cd98321"
;                                "f85c5d9736c193154d530b4ca9342459"]}}
;            :jaeger-function mind-food->state-code
;            :format          :jaeger-db
;            ;:skip-when-exists-in find-state-code
;            :username        "mekadragon"})
;     (#(archive % ->state-code :state-code))
;     ;count
;     )
;(mark-processed "2be6cfc93dd515f0fe0080dcbab30949" :state-code)

;(->> (jc/md5s)
;     (take 1000)
;     (map process)
;     (reduce +))



;(->> (hunt {:query           {}
;            :jaeger-function mind-food->state-code
;            :format          :jaeger-db
;            :username        "mekadragon"})
;     (take 1)
;     ;(#(archive % ->state-codes))
;     )
