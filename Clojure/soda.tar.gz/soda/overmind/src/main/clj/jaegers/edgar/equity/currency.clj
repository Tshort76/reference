(ns jaegers.edgar.equity.currency
  (:require
    [plumbing.core :refer [defnk]]
    [clojure.set :as set]
    [clojure.string :as string]
    [soda.core :refer :all]))

(def dollar "\\u0024|&#x0{0,2}24;|&#36;|\\$")
(def peso "\\WPs\\.\\W|\\Wpeso\\W|\\u20b1|&#8369")

(def peso-relations [#{:peso} #{:PHP :MXN :COP :CLP :ARS :UYU :IDR}])
(defn country-codify [code]
  (apply str (map #(format % code)
                  ["\\W%s\\W|" "^%s\\W|" "\\W%s$|" "^%s$|"])))
(def symbols
  [; US dollar
   {:class :USD :re (str "(?:^|[^CNDAR]|\\WUSD\\W)" dollar)}
   ; British pound
   {:class :GBP :re "\\u00a3|&#x0{0,2}a3;|&#163;|&pound;"}
   ; Euro
   {:class :EUR :re "\\u20ac|&#x20ac;|&#8364;|&euro;|&#128;|\\x80"}
   ; Canadian dollar
   {:class :CAD :re (str "(?:(?:CDN|CAD)\\s?(?:" dollar "|\\d))|C" dollar)}
   ; Australian dollar
   {:class :AUD :re (str "(?:A|(?:AUD\\s?))" dollar)}
   ; Brazilian real
   {:class :BRL :re (str "R" dollar)}
   ; Japanese yen
   {:class :JPY :re (str "¥|&#165|\\u00a5")}
   ;general peso
   {:class :peso :re peso}
   ;Philipino Peso
   {:class :PHP :re (str (country-codify "PHP") "Philippine pesos?|Philippine")}
   ;Mexico Peso
   {:class :MXN :re (str (country-codify "MXN") "Mexican Pesos?")}
   ;Colombia Peso
   {:class :COP :re (str (country-codify "COP") "Colombian Pesos?")} ;not sure if 'Ps.' refers to pesos in general
   ;Chilean Peso
   {:class :CLP :re (str (country-codify "CLP") "Chilean Pesos?")}
   ;Argentina Peso
   {:class :ARS :re (str (country-codify "ARS") "Argentine Pesos?")}
   ;Uraquay Peso
   {:class :UYU :re (str (country-codify "UYU") "Uruguayan Pesos?")}
   ;Indonesian rupiah
   {:class :IDR :re (str (country-codify "IDR") (country-codify "Rp") "Rupiah")}])

(defn group [regex] (str "(" regex ")"))
(defn alts [regexes] (re-pattern (str "(?i)" (string/join "|" (map group regexes)))))
(def regex (alts (map :re symbols)))


(defn merge-common->specific
  "Adds generic currency class with each more specific currency classes
  ie. :peso -> :PHP :MXN :COP :CLP :ARS :UYU"
  [[general specific] matches]
  (let [parent (set/intersection specific (into #{} (map :value matches)))
        new-peso (for [value parent
                       match (filter (comp general :value) matches)]
                   (assoc match :value value))]
    (concat (remove (comp general :value) matches) new-peso)))

(defn get-most-frequent-currency
  "Returns the most frequently seen currency in matches, a collection of
   regisector results. Ties are broken in favor of non-USD currencies."
  [matches]
  (->> matches
       (group-by :value)
       vals
       (sort-by (juxt count (comp (complement #{:USD}) :value first)) #(compare %2 %1))
       first
       ((fn [vs] {:value (-> vs first :value) :ids (vec (merge-with conj (mapcat :ids vs)))}))))

(defn form-jaeger [{:keys [value ids]}]
  {:value value
   ;:ids ids
   :class :currency
   :overmind-details {:method :most-common}})

(defn classify [s]
  (if s
    (if-let [s (re-find regex s)]
      {:value (:class (get symbols (some-index identity s)))})))

(defn find-par-values-raw
  [raw]
  (some->> (:ten-k raw)
           (re-seq #">([^<>]+)<" )
           (map second)
           (filter #(re-seq #"(?i)par value" %))))

(defnk currency* [cusips raw]
  (let [par-values (find-par-values-raw raw)
        currency (some->> (keep classify par-values)
                          (merge-common->specific peso-relations)
                          get-most-frequent-currency
                          form-jaeger)]
    (zipmap cusips (repeat currency))))