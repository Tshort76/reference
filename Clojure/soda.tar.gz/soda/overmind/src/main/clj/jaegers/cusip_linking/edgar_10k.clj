(ns jaegers.cusip-linking.edgar-10k
  (:require [jaegers.cusip-linking.cik :as cik]
            [soda-common.isin :as isin]
            [jaegers.cusip-linking.common :as common]
            [taoensso.timbre :as timbre]
            [jaegers.edgar.classifiers.cusip-match :as cm]
            [simple-mind.naive-bayes.core :as nb]
            [jaegers.edgar.equity.core :as jeec]
            [clojure.string :as cs]
            [clojure.tools.trace :refer :all]
            [medley.core :as medley]
            [util.feature-flags :as ff]
            [clj-fuzzy.jaro-winkler :refer [jaro-winkler]]
            [soda.data.core :as sdc]))

(sdc/defcon "soda" "edgar-termination")

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;matching stuff;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defmethod common/flag-other-matches :edgar-equity
  [_ cusip-doc jaeger-doc]
  (let [figi-data (:figi-data cusip-doc)]
    (cond-> []
            (not (#{"NOT AVAILABLE" "NOT APPLICABLE"} (:where-traded cusip-doc))) (conj {:where-traded :matched})
            (if (seq (:figi-data cusip-doc)) :match) (conj {:figi-data :matched})
            (some->> cusip-doc :cusip-issue-description (re-find #"(?i)\bcom new\b")) (conj {:new-indicator :matched})
            (some->> cusip-doc :cusip-issue-description (#(and (re-find #"(?i)\bcom\b" %)
                                                               (not (re-find #"(?i)\bcom new\b" %))))) (conj {:new-indicator :not-matched})

            (<= 0.80 (jaro-winkler (some-> figi-data :name cs/lower-case)
                                   (some-> jaeger-doc :issuer-name first cs/lower-case)))
            (conj {:issuer-name :matched}))))
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;normalizing stuff;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defmulti normalize->cusip-db (fn [k v] k))
(defmethod normalize->cusip-db :default [k v] {k [v]})
(defmethod normalize->cusip-db :currency [k v]
  {k [(name v)]})

(defmethod normalize->cusip-db :ticker [k v]
  {k (cik/expand-ticker v)})


(defn normalize-field [[k v]]
  (let [norm (normalize->cusip-db k v)]
    (if (every? nil? (vals norm))
      (do (timbre/info (str "Could not normalize to cusip-db form: " k " (" norm ")"))
          {k []})
      norm)))

(defmethod common/normalize-doc :edgar-equity
  [_ simplified-jaeger-doc]
  (->> (map normalize-field simplified-jaeger-doc)
       (apply merge)))

(defmethod common/cusip-selecting-short :edgar-equity [_ cusips]
  (if (= 1 (count cusips))
    (first cusips)))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;cik stuff;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defmethod common/field-filter-fn :edgar-equity [_ _] true) ;no field-filter

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;entry point;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defmethod common/execute-cusipless-jaeger :edgar-equity [data-type omni-data]
  (->> (jeec/execute-jaeger omni-data)
       (map #(hash-map :jaeger-doc %, :meta {:data-type :edgar-equity, :tags ["edgar" "equity"]}))))

;todo once we identify features for this data-type, we should add a real classifier.
;(defmethod common/classify-match :edgar-equity
;  [_ m] (assoc-in m [:meta :probability] {:match -100.0 :not-match -100.0 :class :match}))
(defmethod common/classify-match :edgar-equity
  [_ {{:keys [cusip-matched-on]} :meta :as m}]
  (let [fmap (cm/matched-fields->feature-map :edgar-equity cusip-matched-on)
        {t :true f :false} (apply hash-map (flatten (nb/classify-multinomial cm/edgar-equity-model fmap :verbose? true)))]
    (assoc-in m [:meta :probability] {:match t :not-match f :class (if (< f t) :match :not-match)})))

;todo 10k and 10q filetype can default to exchange code US but 20f will need to rely on exchange
(defmethod common/additional-cusips :edgar-equity
  [data-type jaeger-doc]
  (let [ticker (->> jaeger-doc :ticker :value vector)]
    (->> (cik/tickers->cusip-db-docs ticker {:field-filter :edgar-equity :cfi-code #"E[^P]..|CI...|CB..." :description-removal-regex #"CTF DEPS"})
         (medley/distinct-by :cusip))))

(defmethod common/find-possible-cusips :edgar-equity
  [jaeger-docs]
  (let [first-cusip (:value (:cusip-9 (:jaeger-doc (first jaeger-docs))))]
    (if (and first-cusip (re-find #"fakecusip\d{1,2}" first-cusip))
      (let [ciks (vector (:value (:cik (:jaeger-doc (first jaeger-docs)))))
            possible-cusips (distinct (cik/ciks->cusips ciks :field-filter :edgar-equity :cfi-code #"E[^P].." :description-removal-regex #"CTF DEPS"))]
        possible-cusips)
      [])))


(defn check-12-15
  "checks the 12-15 collection to find out if the security has been terminated"
  [{{:keys [share-class] :as doc} :jaeger-doc}]
  (if-let [cik (some->> doc :cik :value common/cik-sanitize->long str (hash-map :meta.edgar.cik))]
    (->> (edgar-termination cik)
         (some #(= (:share-class %) (:value share-class)))
         not)
    true))

(defmethod common/cusip-link-needed? :edgar-equity [doc]
  (and (-> doc :jaeger-doc :ticker :value)                  ;to not cusip link when no ticker is present in an equity
       (check-12-15 doc)
       (or (ff/memoized-allowed-to? :edgar-equity-multi-share-class)
           (-> doc :jaeger-doc :other-share-classes :value count zero?))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;isin stuff;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


(defmethod common/isin-follow-up :edgar-equity [_ jaeger-doc best-match]
  (when-let [coi (->> jaeger-doc :country-of-issue :value #{"US"})]
    {:value            (isin/cusip->isin coi (:cusip best-match))
     :class            :isin
     :overmind-details {:method :cusip-linking}}))