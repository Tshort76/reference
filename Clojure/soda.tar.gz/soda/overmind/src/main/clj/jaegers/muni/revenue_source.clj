(ns jaegers.muni.revenue-source
  (:require
    [clojure.edn :as edn]
    [clojure.java.io :as io]
    [clojure.string :as string]
    [simple-mind.naive-bayes.core :as nb]
    [simple-mind.naive-bayes.normalize :refer :all]
    [simple-mind.naive-bayes.util :as nbu]
    [plumbing.core :refer [defnk]]))

(def n-grams [1 2 3 ])
(def bayes-model (memoize #(-> "jaegers/revenue_source_bayes3.edn" io/resource slurp edn/read-string)))
;(def bayes-model  #(-> "jaegers/revenue_source_bayes2.edn" io/resource slurp edn/read-string))
(defn class->string [c]
  (when (not= c :bayes/unclassified)
    (->> (string/split (name c) #"-")
         (map string/capitalize)
         (string/join " "))))

;
;(def revenue-source-normalizer (comp norm-empty norm-stems norm-small-words norm-numbers norm-money norm-percents norm-cusip9s norm-months norm-years norm-states norm-stopwords norm-case))

(defn revenue-source-normalizer [words]
  (-> words
      norm-case
      norm-chars
      norm-small-words
      norm-stopwords
      norm-empty
    ))


(defn ->bag-of-words-multi
  [words n-grams]
  (reduce (fn [m n] (merge m (nb/->bag-of-words words :n n :normalize-fn revenue-source-normalizer))) {} n-grams))

(defn as-jaeger
  [value details]
  {:value value :overmind-details details :jaeger :revenue-source :class :revenue-source})

(def patterns
  [["Building"       #"(?i)lease|rent|construction"]
   ["Education"      #"(?i)higher ed|univ|student|college|pub sch|edl|sch"]
   ["Health"         #"(?i)hospital|health|health care|healthcare|med|medicine|residential care"]
   ["Housing"        #"(?i)hsg|housing|mtg|mortgage|single family|multi family|residential"]
   ["Utility"        #"(?i)pwr|swr|wtr|elec|wastewtr|util|wastewater|sewer|trns|utl|solid waste|water|gas"]
   ["Transportation" #"(?i)transn|transit|transportation|arpt|airport|hwy|rr|railroad|port|dock|highway"]
   ["Tax Revenue"    #"(?i)tax revenue"]])

(defn solve-by-bayes [model solve-fn text]
  (let [bag-of-words (some-> text nbu/->words (->bag-of-words-multi n-grams))
        ps (solve-fn model bag-of-words true)
        ;ps (nb/get-probs-with-classes  class-counts bayes-model bag-of-words)
        ;_ (clojure.pprint/pprint ps)
        ]  ;(bayes-model)
    (as-jaeger (class->string (if (empty? ps) "None" (ffirst ps))) {:method :bayes :n-grams bag-of-words :probabilities (into {} ps)})))
    ;(as-jaeger  (if (empty? ps) "None" (ffirst ps)) {:method :bayes :n-grams bag-of-words :probabilities (into {} ps)})))

(defn tag-by-re [text]
  (some (fn [[k v]] (when (re-find v text) k)) patterns))

(defn solve-by-regular [model solve-fn text]
  (let [c (or (tag-by-re text) "Other")]
    (as-jaeger c {:method :regex})))


; (defn solve-regular-first [model solve-fn text]
;   (if-let [c (solve-by-regular model solve-fn text)]
;     (solve-by-bayes model solve-fn text)))

; (defn solve-bayes-first [model solve-fn text]
;   (let [result (solve-by-bayes model solve-fn text)
;         re-tag  (tag-by-re text)]
;     (if (and re-tag (= (:value result) "Other"))
;       (as-jaeger re-tag {:method :regex})
;        result)))

(defn solve [text]
  (solve-by-bayes (bayes-model) nb/classify-multinomial text))

(defn find-revenue-source
  [revenue-type text]
  (if (= revenue-type "Revenue")
    (solve text)
     {:value "General Obligation"
      :method :default
      })
  )

(defnk revenue-source* [extended-issue-description revenue-type*]
  (zipmap (keys revenue-type*)
          (map find-revenue-source (map :value (vals revenue-type*)) (vals extended-issue-description))))


;; -----------------------------------------------------------------------------

;; Code to re-build the Bayesian classifier model
#_(do
    (def raw-data { :nz ["foo foo bar blarg blarg"
                         "foo bar wibble wibble"
                         "foo blarg blarg blarg blarg wibble"
                         "foo blarg wibble"
                         "foo foo bar blarg blarg blarg"
                         "foo wibble wibble"
                         "blarg wibble wibble"
                         "foo wibble wibble"]
                   :mit ["foo bar baz quux quux"
                         "foo foo foo bar baz"
                         "foo foo bar baz baz quux"
                         "foo foo foo bar bar baz quux"
                         "foo foo foo foo bar bar baz"
                         "foo bar"
                         "foo foo foo bar baz"
                         "foo foo foo foo bar baz quux"
                         "shot-key shot-key"]
                   :brown ["foo bar bar snork snork"
                           "foo foo foo bar bar bar bar snork snork snork"
                           "foo bar baz snork"
                           "foo foo bar snork snork snork"
                           "foo foo foo snork snork snork"
                           "foo bar snork snork snork snork"
                           "foo foo bar snork snork snork snork"
                           "foo foo foo bar snork snork snork"
                           "foo bar baz snork"
                           "shot-key shot-key"]}        )

    (defn calculate-accuracy-clazz [data meta-fn s-fn model clazz]
      (let [ nice-clazz (class->string clazz)
            results  (frequencies (pmap (comp :value (partial meta-fn model s-fn)) (clazz data)))]
        ;(clojure.pprint/pprint [results  clazz])
        [(get results nice-clazz 0.0) (count (clazz data)) nice-clazz (int (float (* 100(/ (get results nice-clazz 0.0) (count (clazz data)))))) results]
        ))

    (defn calculate-accuracy [data meta-fn s-fn model]
      (let [ results  (map (partial calculate-accuracy-clazz data meta-fn s-fn model) (keys data))
            total-correct (reduce + (map first results))
            total (reduce + (map second results))]
        [results total-correct total (int (float (* 100(/ total-correct total))))]))


    (get-in (mc/find-one (ds/get-db "soda-raw") "jaegers" {"jaeger-doc.cusip-9.value" "484350KG7"}) ["meta" "md5"])
    (require '[jaegers.jaeger-primer :as jp])
    (require '[utils.mind-food :as umf])

    (defn get-page-1-text [mind-food]
      (let [chopped (take-while #(< (:page-number %) 6) mind-food)
            fixed (mapcat umf/columns->text chopped)
            ;cleaned (map umf/component-clean-up fixed)
            all-vals (nth (iterate umf/merge-big-cap-small-cap (flatten (map :vals fixed))) 2)]
        (clojure.string/join " " (map :text all-vals))))


    (defn convert-data-to-samples [data allow-duplicates]
      (let [converted (map (juxt :issuer-name :issue-description :soda-revenue-source) data)
            ready (if allow-duplicates
                    converted
                    (seq (set converted)))
            smashed (map (fn [[a b c]] [(str a " " b) c]) ready)
            by-tag (group-by second smashed)
            cleaned-up (into {} (map (fn[[k v]] {(keyword (cs/lower-case k)) (map first v) }) by-tag))
            ]
         cleaned-up))

    (defn add-jaeger-output [datom]
      (if-let [output (:value (solve (str (:issuer-name datom) " " (:issue-description datom))))]
        (assoc datom :jaeger-tag (cs/replace output " " "-"))
        (assoc datom :jaeger-tag "Other")))
      ;(assoc datom :jaeger-tag (cs/replace (:value (solve (str (:issuer-name datom) " " (:issue-description datom)))) " " "-")))


    (defn score-it [score datom]
      (let [confusion-key (keyword (str (:soda-revenue-source datom)"->" (:jaeger-tag datom)))
            right (if (= (:soda-revenue-source datom) (:jaeger-tag datom)) 1 0)
            wrong (if (= right 1) 0 1)
            ]
        (conj score
              { confusion-key (+ (get score confusion-key 0) 1)
                :right (+ (get score :right 0) right)
                :wrong (+ (get score :wrong 0) wrong)
                :total (+ (get score :total 0) 1)
               })))

    (defn correct-percent [score]
      (int (float (* 100(/ (:right score) (:total score))))))

    (defn calculate-accuracy [data clazz]
      (let [clazz-key (keyword (clojure.string/lower-case clazz))
            results  (frequencies (map (comp :value solve-by-bayes) (clazz-key data)))
            ]
        [(int (float (* 100(/ (get results clazz) (count (clazz-key data)))))) results]
      ))

    (defn write-first-page [md5]
      (let [ mind-food (try (:mind-food (jp/query->omni-data {:md5 md5}))
                            (catch Exception e (str "caught exception: " (.getMessage e)) nil))
             text (when mind-food (get-page-1-text mind-food))
             file-path (str "d:\\revenue-source-t-pages\\" md5 ".txt")
            ]
        (if text
          (do
          (spit file-path text)
          (println (str "wrote " file-path)))
          (println (str "Nothing to write for md5:" md5)))
        ))

    (def samples (some-> "jaegers/revenue_source_trainset.edn" io/resource slurp edn/read-string))

    (defn build-model [samples]
      (->> samples
           (reduce-kv
             (fn [model klass sams]
               (reduce
                 (fn [m n]
                   (nbu/train-all m klass sams :n n :normalize-fn revenue-source-normalizer)) model n-grams)) {})))

    (spit "/tmp/revenue_source_bayes.edn"
          (with-out-str (clojure.pprint/pprint (build-model samples))))
    )
