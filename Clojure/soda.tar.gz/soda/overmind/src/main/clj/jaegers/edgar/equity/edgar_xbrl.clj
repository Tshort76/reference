(ns jaegers.edgar.equity.edgar-xbrl
  (:require
    [clojure.data.xml :as xml]
    [clojure.data.zip :as dzip]
    [clojure.data.zip.xml :as zxml]
    [clojure.string :as string]
    [clojure.pprint :refer [pprint]]
    [clojure.zip :as zip]
    [edgar.html-utils :as ehu]
    [html.utils :as hu]
    [medley.core :refer [assoc-some]]
    [plumbing.core :refer [for-map]]
    [taoensso.timbre :as log]
    [util.date-time :as time]
    [soda.core :as soda]))

(defn parse-date [date-str]
  (when (string? date-str)
    (->> (string/trim date-str)
         (re-matches #"\d{4}-\d{2}-\d{2}")
         time/yyyy-mm-dd->date)))


(defn tag-re
  "Like clojure.data.zip.xml/tag=, but matches a node when its tag matches
   pattern re"
  [re]
  (let [f #(some->> % zip/node :tag name (re-find re))]
    (fn [loc]
      (or (f loc)
          (filter #(and (zip/branch? %) (f %)) (dzip/children-auto loc))))))

; (defn attr-re
;   "Like clojure.data.zip.xml/attr=, but matches a node when it has an attribute
;    named attr whose value matches pattern re"
;   [attr re]
;   (fn [loc] (when (some->> loc zip/node :attrs attr (re-find re)) loc)))

(defn get-in-xml
  "Like get-in, but for xml zippers"
  [loc ks]
  (let [node (reduce (fn [l k] (when l (zxml/xml1-> l (zxml/tag= k)))) loc ks)]
    (some-> node zxml/text)))

(defn parse-xbrl
  "Transforms XBRL submission sections by adding an :xml key with the parsed xml data.
   Intended as an xform-fn for edgar.html-utils/submission-sections."
  [{:keys [section contents] :as m}]
  (cond-> m
    (#{"EX-101.INS"} section)
    (assoc :xml (some-> contents hu/xml-contents xml/parse-str))))

(defn xbrl-zip
  "Given a string representing an Edgar filing, returns an XML zipper over the
   XBRL content"
  [text]
  (->> (ehu/submission-sections text :xform-fn parse-xbrl)
       (some :xml)
       zip/xml-zip))

;; -----------------------------------------------------------------------------

(defn tenk->contexts
  "Returns a map from context ID to context data"
  [root-loc]
  (for-map [loc (zxml/xml-> root-loc (tag-re #"(?i)^context$"))]
    (-> loc zip/node :attrs :id)
    (assoc-some {}
      :entity-id (soda/parse-long (get-in-xml loc [:entity :identifier]))
      :share-class (some->> (get-in-xml loc [:entity :segment :explicitMember])
                            (re-matches #".*(?:Common|Capital)Class\w+Member.*"))
      :period-instant (parse-date (get-in-xml loc [:period :instant])))))

(defn tenk->shares
  "Returns a list of maps representing shares outstanding data"
  [root-loc contexts]
  (for [loc (zxml/xml-> root-loc (tag-re #"(?i)^(Entity)?(?:Common|Capital)StockSharesOutstanding$"))
        :let [{{:keys [contextRef]} :attrs} (zip/node loc)]]
    (merge {:shares-outstanding (soda/parse-long (zxml/text loc))}
           (get contexts contextRef))))

(defn tenk->tickers
  "Returns a map from share-class to trading-symbol"
  [root-loc contexts]
  (for-map
    [loc (zxml/xml-> root-loc (tag-re #"(?i)^TradingSymbol$"))
     :let [{{:keys [contextRef]} :attrs} (zip/node loc)]]
    (-> contextRef contexts :share-class)
    (some-> loc zxml/text string/upper-case)))

(defn select-ticker
  [share-class-count ticker-count tickers share-class]
  (cond
    (and (= 1 ticker-count)
         (<= share-class-count 1))
    (val (first tickers))

    :else
    (get tickers share-class)))

(defn parse-tenk [text]
  (try
    (let [root (xbrl-zip text)
          contexts (tenk->contexts root)
          tickers (tenk->tickers root contexts)
          sc-count (->> contexts vals (keep :share-class) distinct count)
          tk-count (-> tickers vals distinct count)]
      (for [{:keys [share-class] :as shares} (distinct (tenk->shares root contexts))
            :let [ticker (select-ticker sc-count tk-count tickers share-class)]]
        (assoc-some shares :trading-symbol ticker)))
    (catch Exception e
      (log/info "Can't parse XBRL:" (.getMessage e)))))

(defn unmarshal [input-stream]
  (parse-tenk (slurp input-stream)))
