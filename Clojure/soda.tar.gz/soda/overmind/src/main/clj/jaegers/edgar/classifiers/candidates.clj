(ns jaegers.edgar.classifiers.candidates
  (:require
    [clojure.edn :as edn]
    [clojure.java.io :as io]
    [clj-ml.filters :as ml-filt]
    [ml.classifiers :as mlc]
    [ml.filters :as mlf]
    [taoensso.timbre :as log]
    [plumbing.core :refer [defnk]]))

(def load-resource (comp edn/read-string slurp io/resource))
(def ->normalizer #(partial mlf/normalize-feature-map (load-resource %)))
(def ->ensemble-classifier #(partial mlc/classify-ensemble (load-resource %)))
(def ->classifier #(partial mlc/classify (load-resource %)))

(def models
  {[:corp :single-security] [(->normalizer "jaegers/edgar_candidates_corp_single_normalizer.edn")
                             (->ensemble-classifier "jaegers/edgar_candidates_corp_single_random_forest.edn")]
   [:corp :multi-security]  [(->normalizer "jaegers/edgar_candidates_corp_multi_normalizer.edn")
                             (->ensemble-classifier "jaegers/edgar_candidates_corp_multi_random_forest.edn")]
   [:muni :multi-security]  [identity
                             (->classifier "jaegers/new-muni-data-least-sampled-tree.edn")]
   [:muni :single-security] [identity
                             (->classifier "jaegers/new-muni-data-least-sampled-tree.edn")]})

(defn cardinality [cusip-docs] (if (> (count cusip-docs) 1) :multi-security :single-security))

(defn select-model
  "Selects the appropriate machine learning model (normalizer + classifer) to
   classify candidate fields for the document defined by omni-data."
  [{:keys [asset-class cusip-docs]}]
  (or (models [asset-class (cardinality cusip-docs)])
      (do (log/info (format "Using default candidate model for [%s %s]" asset-class (cardinality cusip-docs)))
          (models [:corp :single-security]))))

(defnk select-model-2 [asset-class cusip-docs]
  (select-model {:asset-class asset-class :cusip-docs cusip-docs}))

;; Helper fns ------------------------------------------------------------------

(defn normalize-dataset
  [ds & {:keys [scale translation] :or {scale 1.0 translation 0}}]
  {:pre [(instance? weka.core.Instances ds)]}
  (let [filt (ml-filt/make-filter :normalize {:dataset-format ds :scale scale :translation translation})]
    {:dataset    (ml-filt/filter-apply filt ds)
     :normalizer filt}))

;; -----------------------------------------------------------------------------

;; Run this to recreate the dataset file, normalize filter, and decision trees for the classifier
(comment
  (do
    (require '[clj-ml.data :as ml-data])
    (require '[clj-ml.io :as ml-io])
    (require '[ml.training-sets :as training-sets])
    (require '[jaegers.trainer :as trainer])

    (def classes
      #{:accrual-start-date :call-option-date :face-value :first-coupon-date :interest-rate
        :issue-date :issue-price :maturity-date :other :principal-amount})

    (defn handle-unknown-classes [train-set]
      (update train-set
              :feature-maps
              (fn [fmaps] (map (fn [fmap] (update-in fmap [:features :class] #(if-not (contains? classes (keyword %)) :other (keyword %)))) fmaps))))

    (def corp-single-config
      {:rf-trees        500
       :rf-feats        60
       :rf-depth        20
       :rf-file         "jaegers/edgar_candidates_corp_single_random_forest.edn"
       :dataset-file    "jaegers/edgar_candidates_corp_single_dataset.arff"
       :normalizer-file "jaegers/edgar_candidates_corp_single_normalizer.edn"
       :train-set       (let [set1 (handle-unknown-classes (trainer/get-training-set :edgar-triumphant-2900 {:validated? true}))
                              set2 (handle-unknown-classes (trainer/get-training-set :edgar-scsf-393 {:validated? true}))]
                          (update set1 :feature-maps into (:feature-maps set2)))})

    (def corp-multi-config
      {:rf-trees        500
       :rf-feats        60
       :rf-depth        20
       :rf-file         "jaegers/edgar_candidates_corp_multi_random_forest.edn"
       :dataset-file    "jaegers/edgar_candidates_corp_multi_dataset.arff"
       :normalizer-file "jaegers/edgar_candidates_corp_multi_normalizer.edn"
       :train-set       (handle-unknown-classes (trainer/get-training-set :edgar-multi-600 {:validated? true}))})

    (def path "src/main/resources/")

    (defn generate-model-files
      [{:keys [rf-trees rf-feats rf-depth rf-file dataset-file normalizer-file train-set]}]
      (let [{:keys [dataset normalizer]} (-> train-set training-sets/training-set->weka-data-set normalize-dataset)
            feature-maps (map (fn [m] {:features m :validated? true :value nil :ids nil :md5 ""}) (ml-data/dataset-as-maps dataset))
            random-forest (training-sets/training-set->ensemble-trees
                            (assoc train-set :feature-maps feature-maps)
                            :num-trees rf-trees
                            :num-features rf-feats
                            :max-depth rf-depth)
            norm-filter (dmf/normalizer->edn normalizer (ml-data/attribute-names dataset))]
        (ml-io/save-instances :arff (str path dataset-file) dataset)
        (spit (str path rf-file) (pr-str random-forest))
        (spit (str path normalizer-file) (pr-str norm-filter))))))

;; Hyperparameter evaluation
(comment
  (do
    (require '[clj-ml.io :refer [load-instances]])
    (require '[clj-ml.data :refer [dataset-set-class]])
    (require '[clj-ml.classifiers :refer [make-classifier classifier-train classifier-evaluate]])

    (defn eval-hyperparameters []
      (let [ds (-> (load-instances :arff (str "resources/" dataset-file)) (dataset-set-class :class))]
        (doall
          (->> (for [num-trees [10 100 200 500]
                     num-feats [0 10 30 60]
                     max-depth [0 10 20 50]
                     :let [opts {:num-trees-in-forest num-trees :num-features-to-consider num-feats :depth max-depth :parallelism 2}
                           model (-> (make-classifier :decision-tree :random-forest opts) (classifier-train ds))]]
                 (do
                   (println (format "trees=%d, feats=%d, depth=%d" num-trees num-feats max-depth))
                   (assoc (select-keys (classifier-evaluate model :cross-validation ds 10)
                                       [:percentage-incorrect :f-measure :true-positive-rate :false-positive-rate :error-rate])
                     :num-trees num-trees
                     :num-feats num-feats
                     :max-depth max-depth)))
               (apply min-key :error-rate)))))))
