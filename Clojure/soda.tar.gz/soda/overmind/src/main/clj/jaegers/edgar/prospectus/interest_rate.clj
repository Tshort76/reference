(ns jaegers.edgar.prospectus.interest-rate
  (:require
    [clojure.pprint :as pp]
    [edgar.basic-features :as enf]
    [edgar.geometric-combo-linker :as gcl]
    [jaegers.edgar.linking :as lnk]
    [medley.core :refer [find-first]]
    [plumbing.core :refer [defnk]]))

; TODO consider :number value-type too?
(defn interest-rate-like? 
  [{:keys [features string value]}]
  (and (-> features :value-type #{:percent})
       (number? value)
       (<= -10 value 25)))

(def features->interest-rate
  (partial enf/features->candidates :interest-rate #{:interest-rate} interest-rate-like?))

(defn link-best-single [enhanced-hickory cusips cands]
  (let [[{:keys [candidate]}] (lnk/link-by-score enhanced-hickory (vec cusips) cands lnk/euclidean-distance)]
    (zipmap cusips (repeat candidate))))

(defnk interest-rate*
  [enhanced-hickory candidates cusips coupon-rate-type* row-sorted-features col-sorted-features ids->coords]
  (let [cusips (keys (filter (complement (comp #{:Floating} :value val)) coupon-rate-type*))
        cands [(:interest-rate candidates)
               (mapcat features->interest-rate row-sorted-features)
               (mapcat features->interest-rate col-sorted-features)]
        first-cands (find-first (comp pos? count) cands)
        linkable-cands (find-first #(<= 2 (count cusips) (count %)) cands)]
    (cond
      (and (= 1 (count cusips)) first-cands)
      (link-best-single enhanced-hickory cusips first-cands)

      (seq linkable-cands)
      (gcl/solve-for-edgar :interest-rate cusips {:interest-rate linkable-cands} ids->coords))))
