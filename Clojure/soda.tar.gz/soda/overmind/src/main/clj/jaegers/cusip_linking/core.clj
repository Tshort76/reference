(ns jaegers.cusip-linking.core
  (:require
    [clojure.set :as set]
    [jaegers.cusip-linking.common :as common]
    [jaegers.cusip-linking.edgar-prospectus]
    [jaegers.cusip-linking.edgar-10k]
    [clojure.tools.trace :refer :all]
    [util.feature-flags :as ff]
    [medley.core :as medley]))
    ; [jaegers.cusip-linking.identifier-derivation :as id]))

(def important-key-map
  {:edgar-prospectus {:interest-rate        :coupon-rate,
                      :coupon-frequency     :coupon-frequency,
                      :first-coupon-date    :first-coupon-date,
                      :issue-date           :dated-date,
                      :maturity-date        :maturity-date,
                      :coupon-rate-type     :rate-type
                      :principal-amount     :offering-amount
                      :offering-amount-code :offering-amount-code
                      :offering-amount      :offering-amount}
   :edgar-10k        {:ticker :ticker-symbol}
   :figi             {:name :issuer-name}
   :edgar-equity     {:ticker :ticker-symbol
                      :currency :currency-code
                      :issuer-name :issuer-name}})
(def min-probs
  {:edgar-prospectus -45.2
   :edgar-equity -20})
(def cusip-db-keys [:offering-amount-code :offering-amount])

;; initially set very low, adjust as needed
(defn min-probability? [data-type]
  (every-pred
    (comp #{:match}  :class :probability :meta)
    (comp #(> % (data-type min-probs)) :match :probability :meta)))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;ciq->cusip-6->cusip;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn evaluate-matches [data-type jaeger-doc cusip-doc]
  (let [matches (keep (fn [k] (let [v (k jaeger-doc)]
                                {k
                                 (if (and (seq v) (k cusip-doc))
                                   (if (some #(= % (k cusip-doc)) v) :matched :not-matched)
                                   (cond
                                     (seq v) :cusip-only
                                     (k cusip-doc) :jaeger-only
                                     :default :nothing))})) (distinct (vals (data-type important-key-map))))
        other-flags (common/flag-other-matches data-type cusip-doc jaeger-doc)]
     (assoc cusip-doc :meta {:cusip-matched-on (apply merge (concat matches other-flags))})))

(defn match-to-doc
  "Takes a list of likely cusip-docs and finds the one(s) that best match to the jaeger-doc."
  [data-type cusip-docs jaeger-doc]
  (->> cusip-docs
       (map (partial evaluate-matches data-type jaeger-doc))
       (map (partial common/classify-match data-type))
       (sort-by (comp :match :probability :meta) >)))

(defn simplify-jaeger-doc
  "Condenses a jaeger-doc for easier readability"
  [jaeger-doc]
  (->> (map (juxt first (comp :value second)) jaeger-doc)
       (filter (comp not nil? second))
       (into {})))

(defn jaeger-doc->cusip-db-form
  "Takes a jaeger-doc and normalizes it to cusip-db form."
  [data-type jaeger-doc & {:keys [full?]}]
  (-> (common/normalize-doc data-type (simplify-jaeger-doc jaeger-doc))
      (select-keys (keys (data-type important-key-map)))
      (set/rename-keys (data-type important-key-map))))

(defn format-other-matches
  [all-matches]
  (mapv (fn [{cusip :cusip, {:keys [cusip-matched-on probability]} :meta}]
          {:cusip cusip
           :cusip-matched-on cusip-matched-on
           :probability probability})
        all-matches))

(defn match->cusip-doc
  [{:keys [cusip-9]} {:keys [cusip meta]} [_ & all-matches]]
  {:value cusip
   :text (:text cusip-9)
   :cannonical (:cannonical cusip-9)
   :ids (:ids cusip-9)
   :meta meta
   :overmind-details {:method :cusipless-doc}
   :possible-cusips (format-other-matches (take 10 all-matches))})

(defn clean-n-match
  "Takes a full jaeger-doc and possible cusip-docs and attempts to find the best match.
  Sanitizes cusip-9 field if it can't."
  [data-type cusip-docs {:keys [jaeger-doc meta] :as original-doc}]
  (let [cdb-jaeger-doc (jaeger-doc->cusip-db-form data-type jaeger-doc)
        matches (match-to-doc data-type cusip-docs cdb-jaeger-doc)
        additional-matches (match-to-doc data-type (common/additional-cusips data-type jaeger-doc) cdb-jaeger-doc)
        all-matches (sort-by (comp :match :probability :meta) > (medley/distinct-by :cusip (concat matches additional-matches)))
        best-match (or (common/cusip-selecting-short original-doc additional-matches)
                       (common/cusip-selecting-short original-doc matches)
                       (first (filter (min-probability? data-type) all-matches)))]
    (-> (if best-match
          {:jaeger-doc (medley/assoc-some jaeger-doc :cusip-9 (match->cusip-doc jaeger-doc best-match all-matches)
                                                     :isin (common/isin-follow-up data-type jaeger-doc best-match))
           :meta       (assoc meta :cusip-linking (select-keys (:meta best-match) [:cusip-matched-on :probability]))}
          {:jaeger-doc (dissoc jaeger-doc :cusip-9)
           :meta       (assoc-in meta [:cusip-linking :possible-cusips] (format-other-matches (take 10 all-matches)))})
        (assoc-in [:meta :cusip-linking :attempted] true)
        (assoc-in [:meta :cusip-linking :seeding-text] (-> jaeger-doc :cusip-9 :text)))))

;these are for our endpoints
(def find-possible-cusips-support (keys (methods common/find-possible-cusips)))
(def field-filter-fn-support (keys (methods common/field-filter-fn)))

(defn has-fake-cusip?
  "determines if a jaeger-doc has a 'fake cusip' (a marking indicating we might want to link it to a cusip)"
  [jaeger-doc]
  (let [cusip (-> jaeger-doc :jaeger-doc :cusip-9 :value)]
    (and cusip (re-find #"fakecusip" cusip))))

(defn link-needed
  "Pass through for cusip-link-needed, provides basic functionality for all data-types"
  [jaeger-doc]
  (and (ff/memoized-allowed-to? (->> jaeger-doc :meta :data-type name (str "cusip-link-") keyword))
       (has-fake-cusip? jaeger-doc)
       (common/cusip-link-needed? jaeger-doc)))

;todo add logic to stop the use of the same cusip between jaeger-docs in the same job.
(defn attempt-cusip-linking [[data-type jaeger-docs]]
  (let [no-linking (remove link-needed jaeger-docs)
        need-linking (filter link-needed jaeger-docs)]
    (if (seq need-linking)
      (let [possible-cusips (common/find-possible-cusips need-linking)]
        (concat (common/cusip-6-check (map #(clean-n-match data-type possible-cusips %) need-linking))
                (map #(if (has-fake-cusip? %) (update-in % [:jaeger-doc] dissoc :cusip-9) %) no-linking)))
      (map #(if (has-fake-cusip? %) (update-in % [:jaeger-doc] dissoc :cusip-9) %) jaeger-docs))))


;; used in pipeline.jobs.parse-file for edgar-10k docs and in pipeline.jobs.jaegers
(defn handle-cusipless [jaeger-docs]
  (if (ff/memoized-allowed-to? :cusip-matching)
    (->> (group-by (comp :data-type :meta) jaeger-docs)
         (map attempt-cusip-linking)
         flatten)
    jaeger-docs))
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;Sand-box-stuff;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn derive-cusips [query data-type & {:keys [full?]}]
  (let [omni-data (jaegers.jaeger-primer/query->omni-data query)
        cusipless-jaeger (common/execute-cusipless-jaeger data-type omni-data)
        attempted-cusip-links (handle-cusipless cusipless-jaeger)]
    (map #(if full?
            %
            (update % :jaeger-doc simplify-jaeger-doc)) attempted-cusip-links)))
