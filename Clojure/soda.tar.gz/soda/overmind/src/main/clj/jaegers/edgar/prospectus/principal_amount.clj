(ns jaegers.edgar.prospectus.principal-amount
  (:require
    [clojure.pprint :as pp]
    [edgar.basic-features :as enf]
    [hickory.select :as hs]
    ; TODO remove dependency on this
    [jaegers.edgar.linking :as lnk]
    [jaegers.hickory-utils :as hu]
    [medley.core :refer [find-first]]
    [plumbing.core :refer [defnk]]
    [edgar.geometric-combo-linker :as gcl]
    [tokenvec.core :as tv]))

(def large-enough? #(>= (hu/magnitude %) 4))

(defn principal-amount-like? 
  [{{value-type :value-type} :features, value :value}]
  (and (#{:dollars :dollars-like} value-type)
       (large-enough? value) 
       (hu/multiple-of? value 1000)))

(def principal-amount-row
  (partial enf/features->candidates :principal-amount #{:principal-amount :size} principal-amount-like?))

(def principal-amount-col
  (partial enf/features->candidates :principal-amount #{:principal-amount :issue-price} principal-amount-like?))

(defn link-best-single [enhanced-hickory cusips cands]
  (let [[{:keys [candidate]}] (lnk/link-by-score enhanced-hickory (vec cusips) cands lnk/euclidean-distance)]
    (zipmap cusips (repeat (assoc candidate :jaeger ::principal-amount)))))

(defn solve-with-candidates
  "Selects a candidate set from classifier results. If at least 2 classifier
   candidates exist, each value is filtered against a predicate."
  [{:keys [principal-amount]}]
  (cond->> principal-amount
    (> (count principal-amount) 1) (filter (comp large-enough? :value))))

(defnk principal-amount*
  [enhanced-hickory candidates cusips row-sorted-features col-sorted-features ids->coords]
  (let [cands [(solve-with-candidates candidates)
               (mapcat principal-amount-row row-sorted-features)
               (mapcat principal-amount-col col-sorted-features)] 
        first-cands (find-first (comp pos? count) cands)
        linkable-cands (find-first #(<= 2 (count cusips) (count %)) cands)]
    (cond
      (and (= 1 (count cusips)) first-cands)
      (link-best-single enhanced-hickory cusips first-cands)

      (seq linkable-cands)
      (gcl/solve-for-edgar :principal-amount cusips {:principal-amount linkable-cands} ids->coords))))
