(ns jaegers.muni.mandatory-redemption-bond-selection
  (:require [jaegers.utils :as jutil]
            [plumbing.core :refer [defnk]]
            [utils.mind-food :as utils.mind-food]
            [utils.simple-search :as series]))

(def pro-rata-re #"(?i)pro[ |-]{0,1}rata")

(defn mind-food->mandatory-redemption-bond-selection [mind-food]
  (let [pro-rata-finds (not-empty
                         (filter
                           (fn [{:keys [total-string]}]
                             (and
                               (re-find #"(?i)redemption" total-string)
                               (> (count (re-seq pro-rata-re total-string))
                                  (count (re-seq #"(?i)by lot" total-string)))))
                           (utils.mind-food/find-in-mindfood pro-rata-re mind-food)))]
    (when pro-rata-finds
      (let [words (-> pro-rata-finds first :matches first second)]
        {:value  "Pro Rata"
         :ids    [(map :id words)]
         :coords (map series/word->coord words)
         :class  :mandatory-redemption-bond-selection
         :jaeger :mandatory-redemption-bond-selection}))))

(defnk mandatory-redemption-bond-selection* [mind-food mandatory-redemption-paydown-schedule*]
  (let [candidates (into {} (filter (fn [[_ v]] v) mandatory-redemption-paydown-schedule*))]
    (zipmap
     (keys candidates)
     (map
       (fn [x]
         (if (nil? x)
           {:value  "By Lot" :coords [] :ids []
            :class  :mandatory-redemption-bond-selection
            :jaeger :mandatory-redemption-bond-selection}
           x))
       (jutil/assoc-nearest-series*
         (vals candidates)
         #(-> % :coords flatten first)
         [(mind-food->mandatory-redemption-bond-selection mind-food)])))))
