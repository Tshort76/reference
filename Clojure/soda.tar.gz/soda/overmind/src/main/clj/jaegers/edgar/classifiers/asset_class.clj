(ns jaegers.edgar.classifiers.asset-class
  (:require
    [clojure.edn :as edn]
    [clojure.java.io :as io]
    ; [clj-ml.classifiers :as ml-class]
    ; [clj-ml.data :as ml-data]
    ; [clj-ml.filters :as ml-filt]
    ; [clj-ml.io :as ml-io]
    ; [edgar.tfidf-enfeaturing :as tfidf-enf]
    ; [html.utils :as hu]
    ; [medley.core :refer [map-vals]]
    [ml.classifiers :as mlc]))
    ; [soda.data.core :refer [defcon]]))

(def load-resource (comp edn/read-string slurp io/resource))
(def ->classifier #(partial mlc/classify-ensemble (load-resource %)))

(def models
  {:binary [(load-resource "jaegers/edgar_asset_class_binary_tfidf.edn")
            (->classifier "jaegers/edgar_asset_class_binary_random_forest.edn")]
   :multiclass [(load-resource "jaegers/edgar_asset_class_multiclass_tfidf.edn")
                (->classifier "jaegers/edgar_asset_class_multiclass_random_forest.edn")]})

;; Model training  -------------------------------------------------------------

;; This training set is used for the abs/cmo/equity/corp multiclass classifier
; (def multiclass-config
;   {:scale 1000000
;    :n-grams [1 2 3]
;    :min-df 0.2
;    :max-df 0.8
;    :rf-trees 50
;    :rf-feats 50
;    :rf-depth 20
;    :classes [:corp :abs :cmo :equity]
;    :train-set (->> "edgar/expanded_rainbow_361.edn"
;                    io/resource
;                    slurp
;                    edn/read-string
;                    (map-indexed (fn [i m] (-> m (update :class keyword) (assoc :i i)))))})

;; This training set is used for the corp/not-corp binary classifier
; (def binary-config
;   {:scale 1000000
;    :n-grams [1 2 3]
;    :min-df 0.2
;    :max-df 0.8
;    :rf-trees 100
;    :rf-feats 50
;    :rf-depth 20
;    :classes [:corp :not-corp]
;    :train-set (map (fn [m] (update m :class #(if (not= :corp %) :not-corp :corp))) (:train-set multiclass-config))})

;; tfidf-index is:
;;
;; {:term1 {:file-id1 tfidf-score
;;          :file-id2 tfidf-score
;;          ...}
;;  :term2 {:file-id1 tfidf-score
;;          ...}}
;;
; TODO Should this be moved? Its fn is used by coupon-rate-type
; (defn create-model [train-set min-df max-df nseq scale class-vec]
;   (let [tf-index (apply merge-with merge (pmap (fn [{:keys [md5 i]}]
;                                                  (tfidf-enf/index-tf nseq (tfidf-enf/md5->html md5) i))
;                                                train-set))
;         tfidf-index (->> tf-index
;                          (map-vals (fn [termdocs]
;                                      (map-vals (fn [tf]
;                                                  (tfidf-enf/calc-tfidf tf (count train-set) (count termdocs)))
;                                                termdocs)))
;                          (tfidf-enf/prune-terms (count train-set) min-df max-df tf-index))
;         doc-classes (reduce (fn [m {c :class i :i}] (assoc m i c)) {} train-set)]
;     {:dataset (-> (ml-data/make-dataset
;                     "asset-class"
;                     (conj (keys tfidf-index) {:class class-vec})
;                     (map (fn [[i terms]]
;                            (conj (map #(when % (* % scale)) (map terms (keys tfidf-index))) (keyword (doc-classes i))))
;                          (tfidf-enf/id-term-map tfidf-index)))
;                   (ml-data/dataset-set-class :class)
;                   (->> (ml-filt/make-apply-filter :replace-missing-values {})))
;      :doc-freqs (into {} (map (fn [[k v]] [k (count v)]) tfidf-index))
;      :doc-count (count train-set)
;      :scale scale
;      :n-gram-sizes nseq
;      :means (reduce-kv
;               (fn [m k v]
;                 (let [scores (map val v)]
;                   (assoc m k (* scale (/ (reduce + scores) (count scores))))))
;               {} tfidf-index)}))

; (defn create-and-save-model-files
;   [id {:keys [train-set min-df max-df n-grams scale classes rf-trees rf-feats rf-depth]}]
;   (let [{:keys [dataset] :as tfidf-model} (create-model train-set min-df max-df n-grams scale classes)
;         cls (-> (ml-class/make-classifier :decision-tree :random-forest
;                                           (cond-> {:parallelism 0 :print-classifiers true}
;                                             rf-trees (assoc :num-trees-in-forest rf-trees)
;                                             rf-feats (assoc :num-features-to-consider rf-feats)
;                                             rf-depth (assoc :depth rf-depth)))
;                 (ml-class/classifier-train dataset))]
;     (spit (format "resources/jaegers/edgar_asset_class_%s_tfidf.edn" id) (dissoc tfidf-model :dataset))
;     (ml-io/save-instances :arff (format "resources/jaegers/edgar_asset_class_%s_dataset.arff" id) dataset)
;     (spit (format "resources/jaegers/edgar_asset_class_%s_random_forest.edn" id)
;           (pr-str (mlc/ensemble-classifier->edn-trees cls)))))

;; Run this to recreate the dataset file and decision trees for the classifiers
#_(create-and-save-model-files "binary" binary-config)
#_(create-and-save-model-files "multiclass" multiclass-config)

;; Testing ---------------------------------------------------------------------

; model-type is in #{:corp :not-corp}
; (defcon "training-sets" "feature-maps")
; (defn training-set->test-set-data
;   "Converts an overmind training set to a vector of feature maps suitable for conversion to a weka dataset."
;   [model-type & {:keys [model] :or {model (-> models model-type first)}}]
;   (let [fmaps (->> {:descriptor-id (org.bson.types.ObjectId. "5927087856b28425c1c0d3a1")}
;                    feature-maps
;                    (pmap
;                      (fn [{{actual-cls :class} :features md5 :md5}]
;                        (let [actual-cls (keyword actual-cls)
;                              actual-cls (if (and (= :corp model-type) (not= :corp actual-cls)) :not-corp actual-cls)
;                              actual-cls (if (and (= :not-corp model-type) (= :corp actual-cls)) nil actual-cls)]
;                          (when actual-cls
;                            (some->> {:md5 md5}
;                                     soda.data.file-system/find-file
;                                     :input-stream
;                                     slurp
;                                     hu/html-contents
;                                     not-empty
;                                     (#(tfidf-enf/enfeature-tfidf % model))
;                                     (#(assoc % :class actual-cls)))))))
;                    (remove nil?))]
;     (spit "/tmp/foo.edn" (pr-str fmaps))))

; (defn test-set-data->weka-dataset [test-set-file]
;   (let [fmaps (->> test-set-file slurp clojure.edn/read-string
;                    (map (fn [m] (update m :class #(if (not= :corp %) :not-corp :corp))))
;                    #_(remove (comp #{:corp :other} :class)))]
;   (-> (ml-data/make-dataset
;         "asset-class"
;         (conj (-> models :corp first :doc-freqs keys) {:class [:corp :not-corp] #_[:abs :cmo :equity]})
;         fmaps)
;       (ml-data/dataset-set-class :class)
;       (->> (ml-io/save-instances :arff "/tmp/edgar_asset_class_corp_testset.arff")))))

#_(training-set->test-set-data :corp)
#_(test-set-data->weka-dataset "/tmp/foo.edn")

; (comment
;   (require '[clj-ml.io :refer [load-instances]])
;   (require '[clj-ml.data :refer [dataset-set-class]])
;   (require '[clj-ml.classifiers :refer [make-classifier classifier-train classifier-evaluate]])
;
;   (defn eval-hyperparameters [train-ds-file eval-ds-file]
;     (let [train-ds (-> (load-instances :arff (str "resources/jaegers/" train-ds-file)) (dataset-set-class :class))
;           eval-ds (-> (load-instances :arff (str "resources/jaegers/" eval-ds-file)) (dataset-set-class :class))]
;       (->> (for [num-trees [25 50 100 200 300]
;                  num-feats [0 10 20 50 100 200]
;                  max-depth [0 10 20 50 100]
;                  :let [opts {:num-trees-in-forest num-trees :num-features-to-consider num-feats :depth max-depth :parallelism 0}
;                        model (-> (make-classifier :decision-tree :random-forest opts) (classifier-train train-ds))
;                        _ (println (format "trees=%d, feats=%d, depth=%d" num-trees num-feats max-depth))]]
;              (-> model
;                  (classifier-evaluate :dataset train-ds eval-ds)
;                  (dissoc :evaluation-object :summary :confusion-matrix)
;                  (assoc :num-trees num-trees :num-feats num-feats :max-depth max-depth)))
;            (apply min-key :error-rate #_(fn [{fpr :false-positive-rate}] (reduce + (vals fpr))))))))
