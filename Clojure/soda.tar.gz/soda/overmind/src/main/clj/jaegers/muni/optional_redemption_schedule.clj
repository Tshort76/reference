(ns jaegers.muni.optional-redemption-schedule
  (:require
    [clojure.edn :as edn]
    [clojure.instant :as inst]
    [clojure.java.io :as io]
    [clojure.pprint :refer [pprint]]
    [clojure.string :as string]
    [clj-time.core :as t]
    [clj-time.coerce :as tc]
    [clj-time.periodic :as tp]
    [instaparse.core :as insta]
    [ml.classifiers :as mlc]
    [soda-common.parsers :as scp]
    [jaegers.mind-food-utils :as mfu]
    [jaegers.tokenvec-solver :as ts]
    [jaegers.utils :as ju]
    [util.date-time :as date-time]
    [jaegers.core :as jcr]
    [jaegers.jaeger-primer :as primer]
    [utils.mind-food :as mind-food]
    [soda-common.regexes :as re]
    [soda-common.parsers :as parsers]
    [plumbing.core :refer [defnk]]
    [util.date-time :as dt]))

;; Classifier definitions ------------------------------------------------------

(def feature-descriptor
  (mfu/expand-feature-descriptor
    {:counted-items #{:series-terms :optional-terms :mandatory-terms :not-redemption-terms
                      :redemption-terms :maturity-terms :refund-terms :money-terms :word}
     :value-type    #{:date :price :date-freedom}
     :class         #{:ors-date :ors-price :ors-date-freedom :ors-maturity-date :ors-maturity-date-freedom :other}}))

(def decision-tree (-> "jaegers/ors_decision_tree.edn" io/resource slurp edn/read-string))
(def ors-classifier (partial mlc/classify decision-tree))

; TODO: expand to all mind-food when performance is better
(defn page-filter [{page :page-number}] (<= 1 page 20))

;; Grammar definitions ---------------------------------------------------------

(def parse-tree
  (let [[_ & r] (->> "soda_common/parsers.bnf" io/resource slurp string/split-lines)
        [a & b] (->> "grammars/optional_redemption_schedule.bnf" io/resource slurp string/split-lines)]
    (insta/parser (string/join "\n" [a (string/join "\n" r) (string/join "\n" b)]) :string-ci true)))

(defn candidate? [values]
  (->> values
       (map (comp :value-type :features))
       (into #{})
       ((every-pred :date :price :date-freedom))))

(def txmap
  (letfn [(->caps [s] (->> (string/split s #"_") (map string/capitalize) (string/join " ")))]
    (into scp/txmap
          {; Features that need massaging
           :PRICE_PCT    (fn [{:keys [percent] :as s}] s #_(if (< percent 100) nil s))
           :PRICE_NUM    (fn [{:keys [double integer] :as s}]
                           (let [percent (or double integer)]
                             {:percent percent}))
                             ;(if (< percent 100) nil {:percent percent})

           :PRICE_100    (constantly {:percent 100})
           :PARTIAL_DATE (fn [m] (update m :year inst/read-instant-date))
           ; Values
           :DATELIKE     #(mfu/create-value :date (some-fn :date :year) % feature-descriptor)
           :PRICE        #(mfu/create-value :price :percent % feature-descriptor)
           :DATE_FREEDOM #(mfu/create-value :date-freedom (comp ->caps name first) % feature-descriptor)
           ; Final sentence characterization
           :SENTENCE     (fn [& s]
                           (let [values (mfu/characterize-values s)]
                             (when (candidate? values) values)))})))

(def parse-tree->value (partial insta/transform txmap))
(defn parse [s] (->> s parse-tree parse-tree->value))

;; Jaeger definitions ----------------------------------------------------------

(defn find-redemption-period-list [mongo-doc]
  (->> mongo-doc
       :mind-food
       (filter #(= :text (:type %)))
       (map :vals)
       flatten
       (mind-food/find-in-vals #"(?i)redemption (period|dates).*and thereafter")
       :matches
       first
       second
       (mind-food/find-in-vals (re-pattern (str re/date-like "(:?through " re/date-like "|and thereafter)")))
       :matches
       (partition-all 2)
       (map (comp second first))))

(defn find-redemption-price-list [mongo-doc]
  (->> mongo-doc
       :mind-food
       (filter #(= :text (:type %)))
       (map :vals)
       flatten
       (mind-food/find-in-vals #"(?i)redemption (period|dates).*? (\d\d\d%?\s)+")
       :matches
       first
       second
       (mind-food/find-in-vals #"(?i)\b\d\d\d%?\b")
       :matches
       (map second)))

(defn find-schedule [mongo-doc]
  (let [dates (find-redemption-period-list mongo-doc)
        prices (find-redemption-price-list mongo-doc)]
    (when (= (count dates) (count prices))
      (max-key
        (comp count :value)
        (reduce
          (fn [ret [date price]]
            (-> ret
                (update :value conj
                        {:date  (:date (parsers/parse (string/replace (string/join " " (map :text date)) "," "")))
                         :price (let [p (parsers/parse (string/join " " (map :text price)))]
                                  (or (p :integer) (p :percent)))})
                (update :ids conj (concat (map :id date) (map :id price)))))
          {:value  []
           :ids    []
           :jaeger :optional-redemption-schedule}
          (zipmap dates prices))))))


(defn ->solutions [mongo-doc jaeger-docs]
  (-> mongo-doc
      (mfu/tokenvec-stream :prefilter page-filter)
      (mfu/enfeature-tokenvecs parse)
      (->> (apply ts/classify-featuremaps ors-classifier)
           (map #(assoc-in % [:features :class] (-> % :classifier-results :class)))
           (remove (comp (partial = :other) :class :features))
           (group-by :sentence-idx)
           vals
           (map ts/solve-fields)
           (#(ju/assoc-nearest-series jaeger-docs (comp ffirst :coords :ors-date) %
                                      :dist-fn (partial ju/token-dist (:mind-food mongo-doc)))))))

(defn fix-ors-date [mdate ors-date]
  (let [ors-month (date-time/month-of-year ors-date)
        ors-day (date-time/day-of-month ors-date)]
    (if (and (= 1 ors-month ors-day) mdate)
      (date-time/new-date
        (date-time/year-of-date ors-date)
        (date-time/month-of-year mdate)
        (date-time/day-of-month mdate))
      ors-date)))

(defn ->jaeger-form [mdate soln]
  (let [date-ids (select-keys (:ors-date soln) [:ids :coords])
        price-ids (select-keys (:ors-price soln) [:ids :coords])
        date (fix-ors-date mdate (-> soln :ors-date :value))
        price (-> soln :ors-price :value)]
    (when (and date price)
      {:optional-redemption-paydown-schedule
       (merge {:value  [{:date  date
                         :price price}]
               :jaeger :optional-redemption-schedule}
              (merge-with concat date-ids price-ids))
       :optional-redemption-date-freedom
       (assoc (:ors-date-freedom soln)
         :jaeger :optional-redemption-schedule)})))

(defn link-ors [solns jdoc]
  (let [cap-app (-> jdoc :capital-appreciation :value)
        mdate (-> jdoc :maturity-date :value (#(when-not (map? %) (tc/from-date %))))
        series (-> jdoc :series :value)
        solns (if mdate (->>
                          solns
                          (filter #(t/after?
                                     mdate
                                     (tc/from-date (get-in % [:ors-date :value]))))
                          (filter #(zero?
                                     (mod
                                       (t/in-months
                                         (t/interval
                                           (tc/from-date (get-in % [:ors-date :value]))
                                           mdate))
                                       6))))
                        solns)
        ors (when-not cap-app
              (some->> solns
                       (filter (fn [soln]
                                 ; TODO: link with date freedoms
                                 (let [ors-mdate (some-> soln :ors-maturity-date :value tc/from-date)
                                       ors-series (-> soln :series :value)]
                                   (cond
                                     ;; try to merge using series and maturity date
                                     (and mdate series ors-mdate ors-series)
                                     (and (= ors-series series)
                                          (or (t/equal? mdate ors-mdate) (t/after? mdate ors-mdate)))
                                     ;; fall back to merge by series only
                                     (and series ors-series)
                                     (= ors-series series)))))
                       ;; pick the most complete solution
                       (#(if (> (count %) 1) (apply max-key (comp count keys) %) (first %)))
                       (->jaeger-form (-> jdoc :maturity-date :value))))]
    (merge jdoc ors)))

(defn link-schedule [mongo-doc jaeger-docs]
  (let [schedule (find-schedule mongo-doc)]
    (if (not-empty (:value schedule))
      (map
        (fn [jaeger-doc]
          (if (and (not (:optional-redemption-paydown-schedule jaeger-doc))
                   (:maturity-date jaeger-doc))
            (assoc jaeger-doc
              :optional-redemption-paydown-schedule
              (update schedule
                      :value
                      concat
                      (flatten
                        (map
                          #(array-map
                             :date (tc/to-date %)
                             :price (:price (last (:value schedule))))
                          (let [ls (get (last (:value schedule)) :date)
                                md (get-in jaeger-doc [:maturity-date :value])]
                            (when (and ls md)
                              (rest
                               (tp/periodic-seq
                                (tc/to-date-time ls)
                                (tc/to-date-time md)
                                (t/years 1))))))))
              :optional-redemption-date-freedom
              {:value  "Anytime Thereafter"
               :jaeger :optional-redemption-date-freedom})
            jaeger-doc))
        jaeger-docs)
      jaeger-docs)))

(defn count-coupon-periods [first-coupon-length interest-rate yield price]
  (let [discount-base (/ 1 (inc (/ yield 2)))
        translation-to-first (Math/pow discount-base (* 2 first-coupon-length))
        first-coupon-pv (* first-coupon-length interest-rate)
        realign-time (* 2 (- 1 discount-base) (- (/ price translation-to-first) first-coupon-pv))
        z (/ (- realign-time (* interest-rate discount-base)) (- 2 (* discount-base (+ interest-rate 2))))]
    (Math/round (/ (Math/log10 z) (Math/log10 discount-base)))))

(defn link-calculated-ors [jaeger-docs]
  (map
    (fn [{:keys [optional-redemption-paydown-schedule date-of-delivery first-coupon-date
                 coupon-frequency interest-rate yield price maturity-date] :as jaeger-doc}]
      (if (and (not optional-redemption-paydown-schedule)
               date-of-delivery first-coupon-date interest-rate yield maturity-date
               (some-> price :value (== 100) not) (= "Semi-annually" (:value coupon-frequency)))
        (let [[date-of-delivery first-coupon-date interest-rate yield price maturity-date]
              (map :value [date-of-delivery first-coupon-date interest-rate yield price maturity-date])
              first-coupon-length (dt/year-diff-30-360 first-coupon-date date-of-delivery)
              coupon-periods (count-coupon-periods first-coupon-length
                                                   (/ interest-rate 100) (/ yield 100) (/ price 100))
              potential-call-date (dt/inc-month first-coupon-date (* coupon-periods 6))]
          (if (.before potential-call-date maturity-date)
            (assoc jaeger-doc :optional-redemption-paydown-schedule
                              {:value  [{:date potential-call-date :price 100}]
                               :jaeger :optional-redemption-schedule}
                              :optional-redemption-date-freedom
                              {:value  "Anytime Thereafter"
                               :jaeger :optional-redemption-date-freedom})
            jaeger-doc))
        jaeger-doc))
    jaeger-docs))

(defnk optional-redemption-schedule* [mind-food series* capital-appreciation* maturity-date* date-of-delivery* first-coupon-date* interest-rate* yield* price* coupon-frequency*]
  (let [cusips (keys maturity-date*)
        jaeger-docs (->> [series* capital-appreciation* maturity-date* date-of-delivery* first-coupon-date* interest-rate* yield* price* coupon-frequency*]
                         (map (comp (partial map #(array-map (:class %) %)) vals))
                         (concat [cusips])
                         (apply map merge))
        mongo-doc {:mind-food mind-food}
        solns (->solutions mongo-doc jaeger-docs)
        linked-solutions (->> (map (partial link-ors solns) jaeger-docs)
                              (link-schedule mongo-doc)
                              (link-calculated-ors))]
    (zipmap (map #(select-keys % [:cusip-9 :cusip-3 :cusip-6]) linked-solutions)
            linked-solutions)))

(comment
  (require 'jaegers.muni.msrb-supplement
           'jaegers.muni.cusips
           'jaegers.muni.chronos
           'jaegers.muni.capital-appreciation
           'jaegers.muni.coupon-frequency
           'jaegers.muni.first-coupon-date
           'jaegers.muni.series)

  (def memoized-query-omni-data
    (memoize (fn [q] (primer/query->omni-data q))))

  (map (juxt :cusip-9 :maturity-date :optional-redemption-paydown-schedule)
       (run-all {:md5 "7828e78fe570b68338bc5d0e9a69aa71"})))
