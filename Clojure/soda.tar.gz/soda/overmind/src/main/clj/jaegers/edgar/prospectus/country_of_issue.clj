(ns jaegers.edgar.prospectus.country-of-issue
  (:require
    [clojure.spec.alpha :as spec]
    [jaegers.edgar.prospectus.isin :as isin]
    [jaegers.spec]
    [plumbing.core :refer [defnk]]))

; (def default {:jaeger ::country-of-issue :value :US})

;;;;;;;;;;;;;;;;;;;;;Plumbing version
(defn coi [isins cusip]
  (let [{:keys [value ids]} (get isins cusip)
        code (some-> value (subs 0 2) keyword)]
    (cond
      (#{:XS} code) nil
      (isin/country-codes code) {:jaeger ::country-of-issue :value code :ids ids :class :country-of-issue}
      :else nil)))

(defnk country-of-issue* [cusips isin*]
  (zipmap cusips (map (partial coi isin*) cusips)))
