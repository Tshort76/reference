(ns jaegers.edgar.prospectus.call-option-date
  (:require [edgar.link-geometries :as lg]
            [soda-common.regexes :as re]
            [clj-time.format :as f]
            [clojure.string :as cs]
            [clj-time.coerce :as tc]
            [jaegers.edgar.linking :as linking]
            [edgar.geometric-combo-linker :as gcl]
            [jaegers.edgar.prospectus.notes :as notes]
            [jaegers.edgar.tokens :as ec]
            [duckling.core :as p]
            [clj-time.core :as t]
            [edgar.table-utils :as tu]
            [plumbing.core :refer [defnk]]
            [taoensso.timbre :as timbre]
            [clojure.pprint :as pp]
            [edgar.basic-features :as enf]
            [jaegers.utils :as ju]
            [jaegers.edgar.prospectus.security-alias :as sa])
  (:import (org.joda.time IllegalFieldValueException)))

(when-not *compile-files*
  (p/load! {:languages ["en"]}))

(defn link-candidates [cands cusip-docs ids->coords]
  (if (= 1 (count cands))
    (zipmap cusip-docs (repeat (into (first cands) {:class :call-option-date :jaeger ::call-option-date})))
    (gcl/solve-for-edgar :call-option-date cusip-docs {:call-option-date cands} ids->coords)))

(def prefixes-regex (re-pattern (str "(?i)(but not in part|on or after|callable at)[^:]{0,20}(" re/date-like ")")))
(def redemption-regex (re-pattern (str "(?i)(redemption|par call)[a-zA-Z\\s]{0,50}:[^:]{0,500}(prior to|but not in part|on or after|callable at|commencing on|on and after)[^:]{0,10}(" re/date-like ").*?(?=[\\.:]|(" re/date-like ")|" sa/alias-re ")")))
(def prior-to-maturity-date-regex (re-pattern (str "(?i)(" sa/alias-re ")?" enf/re-month-span " (prior to|before the|preceding) .{0,20}maturity.*?(?=[\\.:]|(" re/date-like ")|" sa/alias-re ")")))

(defn parse-date [text]
  (let [text (if (re-matches #"\d\d?/\d\d?/\d\d" text)
               (let [[m d y] (cs/split text #"/")]
                 (cs/join "/" [m d (str "20" y)]))
               text)
        formatter (f/formatter (if (not-empty (re-seq #"\d\d?/\d\d?/\d\d\d\d" text))
                                 "MM/dd/yyyy" "MMM dd yyyy"))
        normalized-text (first (re-find re/date-like (cs/replace text #"[^\d\w\s/]|\s,|\s?th\s?|(\d{1,2})st\s?|\s?nd\s?|\s?rd\s?" "")))]
    (try (tc/to-date (f/parse formatter normalized-text))
         (catch IllegalFieldValueException e
           (->> (cs/replace normalized-text
                            (.getIllegalValueAsString e)
                            (str (dec (.getIllegalNumberValue e))))
                (f/parse formatter)
                tc/to-date)))))

(defn normalize-text [text] (-> text (cs/replace #"[^a-zA-Z0-9\$\%\.\\\/:]" " ") (cs/replace #"\s+" " ")))

(defn find-date [{:keys [text] :as m}]
  (let [text (normalize-text text)]
    (some->> (re-seq re/date-like text)
             (mapcat identity)
             flatten
             (filter (comp not nil?))
             last
             parse-date
             (assoc m :date)
             vector)))

(defn find-by-regex [re enhik]
  (not-empty
    (flatten
      (keep
        find-date
        (ec/token-regex
          (filter #(and (not-empty (:text %)) (not-empty (:id %)))
                  (ec/extract-tokens enhik))
          re)))))

(defn parse-prior-to-maturity [sentence]
  (letfn [(unit->period [{:keys [unit value]}]
            (if (and (= :day unit) (zero? (mod value 30)))
              (t/months (/ value 30))
              ((case unit
                 :day t/days
                 :month t/months
                 :year t/years) value)))]
    (when-let [period (some->> (p/parse :en$core sentence [:duration])
                               first
                               :value
                               unit->period)]
      #(tc/to-date (t/minus (tc/from-date %) period)))))

(defn find-by-maturity [enhik]
  (not-empty
    (flatten
      (keep
        (fn [{text :text :as m}]
          (some->> (parse-prior-to-maturity text) (assoc m :date)))
        (ec/token-regex
          (filter #(and (not-empty (:text %)) (not-empty (:id %)))
                  (ec/extract-tokens enhik))
          prior-to-maturity-date-regex)))))

(defn find-by-table [enhik]
  (keep
    (fn [[tr sr]]
      (when (and sr (re-find #"(?i)redemption|par call|.{0,50}notes" (:text tr)))
        (when-let [date (first (find-date sr))]
          (assoc date :ids [[(:id sr)]]))))
    (map (partial filter (comp not-empty :text)) (mapcat identity (tu/table-data enhik)))))

(defn find-call-option-dates [enhik num-cusips issue-date]
  (letfn [(gte-issue-date? [{date :date}] (or (not issue-date) (fn? date) (= date issue-date) (.after date issue-date)))]
    (keep (fn [{:keys [date ids text]}]
            (when date
              {:call-option-date
               {:value  date
                :text   text
                :ids    (if (string? (first ids)) [ids] ids)
                :jaeger ::call-option-date
                :class  :call-option-date}}))
          (or (some->> (keep (comp not-empty (partial filter gte-issue-date?))
                             [(find-by-regex redemption-regex enhik)
                              (find-by-maturity enhik)
                              (find-by-regex prefixes-regex enhik)])
                       reverse
                       not-empty
                       (apply min-key
                              (fn [vs]
                                (if (empty? vs)
                                  Integer/MAX_VALUE
                                  (Math/abs (- num-cusips (count vs)))))))
              (find-by-table enhik)))))

;{:md5 "1922df0f3fc8b3ce8816ce1d7a8bd63e"} uses the heisenpath in which call-option-date-value is a function.
(defn link-note-value [call-option-date-map maturity-date* [cusip {note-value :value}]]
  (let [{call-option-date-value :value :as res} (call-option-date-map note-value)]
    (if (fn? call-option-date-value)
      (if maturity-date*
        (let [md (some-> cusip maturity-date* :value call-option-date-value)]
          (assoc res :value md)))
      res)))

(defn link-by-notes [notes* maturity-date* cods]
  (let [call-option-date-map (zipmap
                               (map (comp sa/parse-alias (comp :text :call-option-date)) cods)
                               (map :call-option-date cods))]
    (zipmap
      (keys notes*)
      (map (partial link-note-value call-option-date-map maturity-date*) notes*))))

(defn ids->ints [x] (-> x :ids ffirst ju/id->vec))

(defn min-by-id-dist [enhik cusip-docs cod]
  (some->> cusip-docs
           (filter (comp nil? val))
           (map first)
           reverse
           not-empty
           (apply min-key
                  #(let [cusip-id (ids->ints (:cusip-9 %))
                         cod-id (ids->ints (:call-option-date cod))
                         d1 (linking/rom-dist enhik cusip-id cod-id)
                         d2 (linking/euclidean-distance nil cusip-id cod-id)]
                     (+ d1 (/ d2 100))))))

(defn link-cod-to-closest-cusip [maturity-date* enhik cusips cod]
  (if-let [cusip-doc (min-by-id-dist enhik cusips cod)]
    (assoc
      cusips cusip-doc
             (:call-option-date
               (let [cod-value (get-in cod [:call-option-date :value])]
                 (if (fn? cod-value)
                   (when-let [md (get-in maturity-date* [cusip-doc :value])]
                     (assoc-in cod [:call-option-date :value] (cod-value md)))
                   cod))))
    cusips))

(defn link-by-distance [maturity-date* enhik cusips cods]
  (reduce
    (partial link-cod-to-closest-cusip maturity-date* enhik)
    (zipmap cusips (repeat nil))
    cods))

(defn determine-cod-value [maturity-date* cod cusip]
  (let [cod-value (get-in cod [:call-option-date :value])]
    (:call-option-date
      (if (fn? cod-value)
        (when-let [md (get-in maturity-date* [cusip :value])]
          (assoc-in cod [:call-option-date :value] (cod-value md)))
        cod))))

(defn link-by-order [maturity-date* cusips cods]
  (zipmap
    cusips
    (map
      (partial determine-cod-value maturity-date*)
      (sort-by (comp ids->ints :call-option-date) cods)
      (sort-by (comp ids->ints :cusip-9) cusips))))

(defn strip-ids [feature]
  (->> feature ids->ints butlast))
(defn match-to-feature [alias-features cod]
  (let [cod-row (strip-ids (:call-option-date cod))]
    (-> (filter (fn [feature] (= (strip-ids feature)
                                 cod-row)) alias-features)

        first :value (vector (:call-option-date cod)))))

(defn link-alias [cods security-alias* features maturity-dates]
  (let [alias-features  (filter (comp #{:security-alias} :value-type :features) features)
        feature->cod (into {} (map (partial match-to-feature alias-features) cods))]
    (->> (zipmap (keys security-alias*) (->> (map :value (vals security-alias*))
                                             (map (partial get feature->cod))
                                             (map #(if % (assoc % :overmind-details {:method :via-security-alias})))))
         (map (fn [[cusip cod]] (vector cusip (determine-cod-value maturity-dates {:call-option-date cod} cusip))))
         (filter second)
         (into {}))))

(defn link-call-option-dates [maturity-date* cusips enhik cods security-alias* basic-features]
  (let [all-cusips-have-notes (and (every? sa/parse-alias (map (comp :text :call-option-date) cods)) (every? security-alias* cusips))
        cod-with-alias (link-alias cods security-alias* basic-features maturity-date*)]
    (when (not-empty cods)
      (cond
        (= (count cods) (count cusips)) (link-by-order maturity-date* cusips cods)
        all-cusips-have-notes (link-by-notes security-alias* maturity-date* cods) ; these are really the same thing
        (seq cod-with-alias) cod-with-alias
        :else (link-by-distance maturity-date* enhik cusips cods)))))

(defnk call-option-date* [enhanced-hickory candidates cusips issue-date* maturity-date* security-alias* basic-features ids->coords]
  (let [{cands :call-option-date} candidates]
    (if (= (count cusips) (count cands))
      (link-candidates cands cusips ids->coords)   ;{:md5 "c6b1a4c93ecad9614a65cf8a944f5e80"}
      (let [cods (find-call-option-dates enhanced-hickory (count cusips) (get-in issue-date* [(first cusips) :value]))]
        (link-call-option-dates maturity-date* cusips enhanced-hickory cods security-alias* basic-features)))))

;https://jira.arbfund.com/browse/SODA-2394
;MSB - As of 2017/09/15 these all check out with the new plumbing stuff
; (def examples
;   [{:md5 "0681466bc52a3448a7b56487af239fb7"}
;    {:filename "0001104659-14-079874.txt"}
;    {:md5 "17d87510bd96c83d52711d8067bd961e"}
;    {:filename "0000764764-14-000072.txt"}
;    {:filename "0001193125-15-301090.txt"}
;    {:filename "0000950103-16-012761.txt"}
;    {:filename "0001193125-13-045982.txt"}
;    {:filename "0001193125-15-378630.txt"}
;    {:filename "0001193125-17-013239.txt"}
;    {:filename "0000930413-12-006525.txt"}])

;Exercise this where the jaeger function lives (currently in playground/jaegers2).
;(zipmap
;  examples
;  (map #(:call-option-date* (jaeger (jp/query->omni-data %))) examples))
