(ns jaegers.edgar.prospectus.first-coupon-date
  (:require [clojure.string :as str]
            [clojure.pprint :refer [pprint]]
            [edgar.geometric-combo-linker :as gcl]
            [edgar.linker-chunker :as chunk]
            [jaegers.mind-food-utils :as mfu]
            [jaegers.regisector :as rs]
            [plumbing.core :refer [defnk]]
            [tokenvec.core :as tv]
            [util.date-time :as date]))

(defn format-month [month]
  (when month
    ({"January"   1
      "February"  2
      "March"     3
      "April"     4
      "May"       5
      "June"      6
      "July"      7
      "August"    8
      "September" 9
      "October"   10
      "November"  11
      "December"  12}
     (str/capitalize month))))

(defn format-date-regex [[_ m d y1 y2]]
  (when (and y1 y2 m d)
    {:value (date/new-date (Long/parseLong (str y1 y2))
                           (format-month m)
                           (Long/parseLong d))}))

(defn format-date-regex2 [[_ m d y]]
  (when (and y m d)
    {:value (date/new-date (Long/parseLong y)
                           (Long/parseLong m)
                           (Long/parseLong d))}))

(defn process-matches [matches]
  (loop [in (rest (drop-while (fn [x] (not= :begin (:value x))) matches))
         out []]
    (let [[[pre] [_ & post]] (split-with (fn [x] (not= :begin (:value x))) in)
          out (if pre (conj out pre))]
      (if (seq post)
        (recur post out)
        out))))

(defn tokenvec->matches [regex [sentence tokenvec]]
  (when (re-find regex sentence)
    (->> (rs/dissect sentence [{:regex #"(?i)commencing|beginning|initially|starting" ;|payable
                                :handler (fn [_] {:value :begin})}
                               {:regex #"(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2}) ?(?:st|nd|rd|th)?[,\s]+(\d\d) ?(\d\d)\b"
                                :handler format-date-regex}])
         process-matches
         (mapv (fn [{:keys [value indexes]}]
                 {:value value
                  :class :first-coupon-date
                  :sentence sentence
                  :jaeger :first-coupon-date
                  :ids [(mapv :id (tv/unique-tokens tokenvec indexes))]
                  :all-ids tokenvec})))))

(defn tokenvec->single-matches [[sentence tokenvec]]
  ; (prn sentence)
  ; (when (re-find #"(?i)(?:interest payment date\b|1 ?st coupon date\b|first pay date\b|first coupon)" sentence)
  ;   (prn sentence))
  (->> (rs/dissect sentence
                   [{:regex #"(?i)(?:interest payment date\b|1 ?st coupon date\b|first pay date\b|first coupon).{0,25}(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2})[,\s]+(\d\d) ?(\d\d)\b"
                     :handler format-date-regex}
                    {:regex #"(?i)(?:interest payment date\b|1 ?st coupon date\b|first pay date\b|first coupon).{0,25}\b(\d{1,2})/(\d{1,2})/(\d{4})\b"
                     :handler format-date-regex2}])
       (mapv (fn [{:keys [value indexes]}]
               {:value value
                :class :first-coupon-date
                :sentence sentence
                :jaeger :first-coupon-date
                :ids [(mapv :id (tv/unique-tokens tokenvec indexes))]
                :all-ids tokenvec}))))

(defn matches-apply [func tokenvec]
  (seq (mapcat func tokenvec)))

(defn find-first-coupon-date [enhik]
  (let [tokenvec (mfu/enhik->row-and-sentence-tokenvec enhik)]
    (or (matches-apply (partial tokenvec->matches #"(?i)(?:interest|coupon)(?: reset and)? payment(?: and reset)? dates|interest on the notes (will be paid|is payable)|pay interest on the notes") tokenvec)
        (matches-apply tokenvec->single-matches tokenvec))))

;Interest on the notes will be paid
;Interest on the notes is payable
;pay interest on the notes

(defn coord->unique-ids [candidates]
  (->> (for [c candidates
             id (distinct (:all-ids c))
             :when id]
         [(:id id) c])
       (group-by first)
       vals
       (sort-by first)
       (filter #(= (count %) 1))
       (map first)
       (group-by second)
       (map (fn [[c ids-cds]]
              [c (mapv first ids-cds)]))
       (into {})))

(defn fabricate-x-coords [ids->coords candidates]
  (when (seq candidates)
    (let [new-id-coords
          (mapv (fn [c]
                  (let [id (-> c :ids ffirst)]
                    [id (ids->coords id)]))
                candidates)
          avg-x (int
                 (/ (->> new-id-coords
                         (mapv (comp :min-x second))
                         (reduce + 0))
                    (count new-id-coords)))]
      (reduce (fn [r [i c]] (assoc r i (assoc c :min-x avg-x)))
              {} new-id-coords))))

; (defn limited-cusip-coords [ids->coords cusips]
;   (->> cusips
;        (mapv (comp ffirst :ids))
;        (select-keys ids->coords)))

(defn resolve-candidates [cusip-docs candidates ids->coords]
  (cond
    (= 1 (count (distinct (map :value candidates))))
    (zipmap cusip-docs (repeat (dissoc (first candidates) :all-ids)))

    (<= 1 (count cusip-docs) (count candidates))
    (let [cui (coord->unique-ids candidates)]
      (->> candidates
           (remove cui)
           (fabricate-x-coords ids->coords)
           (merge ids->coords)
           (gcl/solve-for-edgar
            :first-coupon-date cusip-docs
            {:first-coupon-date
             (mapv (fn [c]
                     (dissoc (if-let [ids (cui c)]
                               (assoc c :ids [ids])
                               c)
                             :all-ids))
                   candidates)})))))

(defnk first-coupon-date* [candidates enhanced-hickory cusips ids->coords]
  (let [first-coupon-date (find-first-coupon-date enhanced-hickory)]
    (or (not-empty (chunk/form-cusip-groups resolve-candidates cusips first-coupon-date ids->coords))
        (not-empty (chunk/form-cusip-groups resolve-candidates cusips (:first-coupon-date candidates) ids->coords))
        (zipmap cusips nil))))
