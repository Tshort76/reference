(ns jaegers.edgar.prospectus.floating-rate-index
  (:require [plumbing.core :refer [defnk]]
            [edgar.geometric-combo-linker :as gcl]))

(def conversions
  {
   "LIBOR" "US%dMLIB"                                       ;US1MLIB US3MLIB US6MLIB  needs month-span.
   "3mL" "US3MLIB"
   "EURIBOR" "EU%02dMLIB"
   "STISEK" "STIEK%dM"
   "CIDK" "CIDKK%dM"
   "CMT" "FCN%02dYY"
   "CMS" "CMS%d"                                            ;CMS10 CMS30 needs year-span.
   "10CMS" "CMS10"
   "30CMS" "CMS30"
   "Constant Maturity Swap Rate" "CMS%d"
   "BBSW" "AUBB%dM"
   })

(defn filter-same-row [check-boxes indexs]
  (->> indexs
       (remove #(some (fn [{y :min-y x :max-x}] (and (= y (:min-y %))
                                                     (< -50 (- x (:min-x %)) 50))) check-boxes))))

; (defn type->format [t]
;   (if-let [form (get conversions t)]
;     form t))

;distance stuff
(defn square [x] (* x x))
(defn distance [feature1 feature2]
  (+ (square (- (:max-y feature1) (:max-y feature2)))
     (square (- (:max-x feature1) (:min-x feature2)))))

(defn closest-feature [feature features default]
  (if (seq features)
    (let [closest (first (sort-by (partial distance feature) features))]
      (if (> 1000 (distance closest feature))
        closest
        default))
    default))

(defn encandidate [s] {:floating-rate-index (mapv #(assoc % :class :floating-rate-index) s)})

(defn jaeger-form [jaeger {:keys [value ids defaulted]}]
  {:jaeger (keyword (str jaeger)) :value value :ids ids :class jaeger :defaulted defaulted})

(defn smash [{index-value :value index-ids :ids} {time-value :value month-ids :ids defaulted :defaulted} ]
  (let [value (format index-value time-value)
        ids [(apply merge (first index-ids) (first month-ids))]]
    (jaeger-form :floating-rate-index {:value value :ids ids :defaulted defaulted})))

(defmulti normalize-index  (fn [feature months years] (:value feature)))
(defmethod normalize-index :default [feature months years]
  (jaeger-form :floating-rate-index feature))
(defmethod normalize-index "CMS%d" [feature months years]
  (let [span (closest-feature feature years {:value 10 :defaulted true})]
    (smash feature span)))
(defmethod normalize-index "FCN%02dYY" [feature months years] ;CMT
  (let [span (closest-feature feature years {:value 10 :defaulted true})]
    (smash feature span)))
(defmethod normalize-index "US%dMLIB" [feature months years]
  (let [span (closest-feature feature months {:value 3 :defaulted true})]
    (smash feature span)))
(defmethod normalize-index "AUBB%dM" [feature months years]
  (let [span (closest-feature feature months {:value 3 :defaulted true})]
    (smash feature span)))
(defmethod normalize-index "EU%02dMLIB" [feature months years]
  (let [span (closest-feature feature months {:value 3 :defaulted true})]
    (smash feature span)))

(defn update-index [index  basic-features months years]
  (if-let [value (get conversions (:value index))]
    (normalize-index (assoc index :value value) months years)
    (normalize-index index months years)))

(defnk floating-rate-index*
  [coupon-rate-type* cusips basic-features ids->coords]
  (let [cusips      (keys (filter (fn [[_ {:keys [value]}]] (#{:Floating :Fixed-to-float :Float-to-fixed} value)) coupon-rate-type*))
        unchecked   (->> (filter (comp #{:check-box} :value-type :features) basic-features)
                         (filter #(and (:max-y %) (-> % :value #{:unchecked}))))
        index-rows  (->> (filter (comp #{:index} :value-type :features) basic-features)
                         (filter :max-y)
                         (filter-same-row unchecked))
        months      (->> (filter (comp #{:month-span} :value-type :features) basic-features) (filter :max-y))
        years       (->> (filter (comp #{:year-span} :value-type :features) basic-features) (filter :max-y))
        candidates  (map #(update-index % basic-features months years) index-rows)
        strong-cand (filter (comp not :defaulted) candidates)]
    (cond
      (<= 1  (count cusips) (count strong-cand))
      (gcl/solve-for-edgar :floating-rate-index cusips (encandidate strong-cand) ids->coords)
      (<= 1 (count cusips) (count candidates))
      (gcl/solve-for-edgar :floating-rate-index cusips (encandidate candidates) ids->coords))))


;(def samples
;  [
;   {:filename "0001193125-13-117467.txt"  :output "US3MLIB"}
;   {:filename "0000040554-13-000067.txt"  :output "US3MLIB"}
;   {:filename "0001193125-13-021653.txt"  :output "US3MLIB"}
;   {:filename "0001193125-16-704012.txt"  :output "US3MLIB"}
;   {:filename "0001193125-12-495566.txt"  :output "US3MLIB"}
;   {:filename "0000950103-17-000177.txt"  :output "US3MLIB"}
;
;   {:filename "0001193125-14-420065.txt"  :output "EU03MLIB"}
;   {:filename "0000930413-15-002361.txt"  :output "EU03MLIB"} ;no cusips?
;   {:filename "0001193125-16-426052.txt"  :output "EU03MLIB"}
;   {:filename "0001193125-15-311744.txt"  :output "EU03MLIB"}
;   {:filename "0001193125-16-467186.txt"  :output "EU03MLIB"}
;   {:filename "0001104659-16-109543.txt"  :output "EU03MLIB"}
;
;   {:md5 "18acaa9ba3594a430f5a83568edd68d7" :output "CMS10"}
;   {:md5 "6df09037cca249e69984c0af964753d5" :output "CPI?"} ;do better on candidates
;   {:md5 "fcec1a6e328d6293ce618b8888efdc2e" :output "CMS30"}
;   {:md5 "a16f56c05b479930152e790f4de73d03" :output "CMS30}
;
;;;;;;SODA-3141;;;;;;
;   {:md5 "dcee52ec37610bc812aa1c497df0c9f6" :output "CMS10"}     ;no cusips from coupon-rate-type*
;   {:md5 "a679a0c2fa8b91aead8231bec946200c":output "US3MLIB"}
;   {:md5 "09946847573a97923ec31e579441e25c":output "FCN10YY"}
;   {:md5 "41c2c90156b0baf6e7e25a38bb4620ba":output ""}      ;no enhanced-hickory
;   {:md5 "961f7f85fbde4fb9f31e27434b8065b9":output ""}      ;page tag?
;   {:md5 "98e136f843fa895fd77b9f8ebe21f1c9":output ""}      ;null pointer?
;   {:md5 "12c875f43fff8958f254b7e21f487a2c":output ""}      ;no cusips
;   {:md5 "d270a38ff41e0deea05b4ac186f7dea1":output ""}      ;no cusips
;   {:md5 "09464c1c8c2fbe3c89ffbc43930d5216":output ""}      ;no cusips
;   {:md5 "b0faa644f403fcce77d720e50325f88d":output ""}      ;no cusips
;   {:md5 "cd9f27f0642a5f8b31a8df93466d2aed":output "US3MLIB"}
;   {:md5 "e95c0b0da473ce78831c0fb539660c59":output ""}
;   {:md5 "0890001bbc76a9db396a1308b3c306d3":output ""}
;   {:md5 "12c875f43fff8958f254b7e21f487a2c":output "US3MLIB"}
;   {:md5 "cd2981e4d3a621c157640b22dd4e7601":output "US3MLIB"}
;   {:md5 "":output ""}
;   ])
;
;(def omni-samples
;  (map #(jaegers.jaeger-primer/query->omni-data (select-keys % [:md5 :filename])) samples))

;(map (juxt :filename
;           #(->> %
;                 jaegers.edgar.prospectus.core/lazy-jaeger
;                 :floating-rate-index**
;                 vals
;                 (map :value)
;                 ))
;
;     omni-samples)

;(def short-names
;  ["AB3DM"
;   "AUBB1M" "AUBB3M"                         ;australian BBSW
;   "BADLAR"
;   "CAD1MBA" "CAD3MBA" "CIDKK3M" "CIDKK6M"
;   "CITA6M"
;   "CNYDEP1Y"
;   "EU01MLIB" "EU01YLIB" "EU03MLIB" "EU06MLIB" ;euribor
;   "EURSWE10Y" "EURSWE5Y"
;   "FBL3INVQW"
;   "FCN10YY" "FCN5YY" "FCN5YYW" "FCN7YY"
;   "FFQ"
;   "GBP1MLIB" "GBP3MLIB" "GBPSWL5Y"
;   "ITOTR6M"
;   "JIBARR3M"
;   "OINOK3M"
;   "PICZK6M"
;   "PRQ"
;   "STISEK3M"
;   "TEC10"
;   "US1MLIB" "US3MLIB" "US6MLIB"             ;libor
;   "US3MTREF"
;   "USDSF10Y" "USDSF5Y"])
