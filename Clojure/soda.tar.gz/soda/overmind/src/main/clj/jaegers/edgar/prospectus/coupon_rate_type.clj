(ns jaegers.edgar.prospectus.coupon-rate-type
  (:require
    [clojure.pprint :as pp]
    [clojure.string :as string]
    [jaegers.edgar.tokens :as ec]
    [edgar.geometric-combo-linker :as gcl]
    [jaegers.mind-food-utils :as mf-utils]
    [medley.core :refer [map-vals]]
    [plumbing.core :refer [defnk]]
    [simple-mind.naive-bayes.core :as nb]
    [simple-mind.naive-bayes.normalize :refer [normalize-words]]
    [simple-mind.naive-bayes.util :as nbu]))

(def non-fixed-terms
  ["autocall"
   "barrier"
   "based on"
   "buffered"
   "contingent"
   "determination date"
   "digital barrier"
   "fixed to floating"
   "floating rate demand notes"
   "floating rate notes"
   "historical information"
   "knock in"
   "knock out"
   "leveraged"
   "libor"
   "linked"
   "step up"
   "step-up"
   "trigger"
   "valuation date"
   "xfloating"])

(def re-non-fixed-terms (re-pattern (str "(?i)" (string/join "|" non-fixed-terms))))

(defn checkbox-candidates
  "Returns coupon-rate-types from features that are adjacent to checked check-boxes"
  [features]
  (let [value-type->class {:fixed :Fixed, :floating :Floating, :indexed :Floating, :index :Floating}
        vt #(get-in % [:features :value-type])]
    (->> features
         (partition 2 1)
         (keep
           (fn [[x y]]
             (when (and (#{:checked} (:value x))
                        (#{:check-box} (vt x))
                        (#{:fixed :floating :indexed :index} (vt y)))
               (assoc y :value (value-type->class (vt y)))))))))

; TODO expand this to find other types of candidates?
(defn coupon-rate-type-row [features]
  (checkbox-candidates features))

(defn coupon-rate-type-rows [features]
  (mapcat coupon-rate-type-row features))

(defn any-non-fixed-terms? [enhik]
  (->> re-non-fixed-terms
       (ec/token-regex
         (filter #(and (not-empty (:text %)) (not-empty (:id %)))
                 (ec/extract-tokens enhik)))
       seq))

(defn issue-description->coupon-rate-type [issue-desc]
  (let [words (nbu/->words issue-desc)
        n-grams (reduce (fn [m n] (merge m (nb/->bag-of-words words :n n))) {} [1 2])]
    (cond
      (some n-grams [:step :step_up]) :Stepped
      (some n-grams [:fixedflo :fix_float]) :Fixed-to-float
      (some n-grams [:floatfix :float_fix]) :Float-to-fixed
      (some n-grams [:float :floatingr]) :Floating
      (some n-grams [:__percent__ :fix]) :Fixed)))

(defn solve-with-description [issue-description* cusip]
  (let [id (get issue-description* cusip)
        crt (some-> id :value issue-description->coupon-rate-type)]
    (when crt
      (assoc id
             :value crt
             :jaeger ::coupon-rate-type
             :class :coupon-rate-type
             :overmind-details {:method :via-issue-description}))))

(defn solve-with-terms [enhik]
  (when-not (any-non-fixed-terms? enhik) 
    {:value :Fixed
     :ids []
     :jaeger ::coupon-rate-type
     :class :coupon-rate-type
     :overmind-details {:method :via-term-search}}))

(defn encandidate [xs]
  {:coupon-rate-type (mapv #(assoc % :class :coupon-rate-type) xs)})

(defnk coupon-rate-type*
  [enhanced-hickory cusips issue-description* row-sorted-features ids->coords]
  (let [strong-candidates (keep (partial solve-with-description issue-description*) cusips)
        weak-candidates (coupon-rate-type-rows row-sorted-features)]
    (cond
      (<= 1 (count cusips) (count strong-candidates))
      (zipmap cusips strong-candidates)

      (<= 1 (count cusips) (count weak-candidates))
      (gcl/solve-for-edgar :coupon-rate-type cusips (encandidate weak-candidates) ids->coords)

      :else
      (zipmap cusips (repeat (solve-with-terms enhanced-hickory))))))
