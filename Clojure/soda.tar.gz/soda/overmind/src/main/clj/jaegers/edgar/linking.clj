(ns jaegers.edgar.linking
  (:require [clojure.spec.alpha :as s]
            [clojure.zip :as zip]
            [hickory.select :as hs]
            [jaegers.utils :as ju]
            [jaegers.hickory-utils :as hu]))

(defn parts->id
  "Return an id, given its parts"
  [parts]
  (clojure.string/join "_" parts))

;;Jonathan's Distance Metric;;

(defn shared-root
  "Takes two ids and returns the ID of their shared root:
  (shared-root [1 2 3 4 5] [1 2 3 0 0]) => [1 2 3]"
  [id1 id2]
  (loop [result [] coll1 id1 coll2 id2]
    (if (= (first coll1) (first coll2))
      (recur (conj result (first coll1)) (rest coll1) (rest coll2))
      result)))

(defn tags-to-root
  "Returns a collection of tags between id and root."
  [hickory root id]
  {:pre [(.startsWith id root)]} ;id must be root, or a descendant of root
  (loop [loc (hu/id->loc hickory id)
         tags []]
    (if (-> loc first :attrs :id (= root))
      tags
      (recur (zip/up loc) (conj tags (-> loc first :tag))))))

(defn tags-of-children
  "Returns a collection of id's element's children's tags"
  [hickory id]
  (let [first-child (zip/down (hu/id->loc hickory id))
        tags (transient [(-> first-child first :tag)])
        ;Note: using a fn with side-effects as a predicate below is weird, but fast and it works
        tag-accumulator-fn (fn [loc] (conj! tags (-> loc first :tag)) false)]
    (hs/right-pred first-child tag-accumulator-fn)
    (persistent! tags))) ;side-effects are contained within this function

(defn tags-of-siblings-between
  "Returns a collection of the id's found between id1 and id2's elements"
  [hickory id1 id2]
  {:pre [(= (pop (ju/id->vec id1)) (pop (ju/id->vec id2)))]} ;id1 and id2 must point to sibling elements
  (let [sorted-ids (sort [id1 id2])
        left-child (hu/id->loc hickory (first sorted-ids))
        right-id (second sorted-ids)
        tags (transient [(-> left-child first :tag)])
        ;Note: using a fn with side-effects as a predicate below is weird, but fast and it works
        tag-accumulator-fn (fn [loc] (conj! tags (-> loc first :tag))
                             (= right-id (-> loc first :attrs :id)))] ;stop when you reach the right-child
    (hs/right-pred left-child tag-accumulator-fn)
    (persistent! tags))) ;side-effects are contained within this function

(defn rom-path
  "Returns a path from id1 to id2 through hickory in the format: [id1->grandchild1, child1->child2, grandchild2->id2]
   where each element is a vector of tags found along that route (ie. [[:p :td] [:tr :tr :tr] [:td :p]])"
  [hickory id1 id2 root-id]
  (let [id1-str (clojure.string/join "_" id1)
        id2-str (clojure.string/join "_" id2)
        root-depth (count (ju/id->vec root-id))
        root-child-id1 (parts->id (take (inc root-depth) (ju/id->vec id1-str)))
        root-child-id2 (parts->id (take (inc root-depth) (ju/id->vec id2-str)))
        root-children-between-tags (tags-of-siblings-between hickory root-child-id1 root-child-id2)
        id1-to-root-grandchild (try (pop (pop (tags-to-root hickory root-id id1-str))) (catch Exception e []))
        id2-to-root-grandchild (try (pop (pop (tags-to-root hickory root-id id2-str))) (catch Exception e []))]
    [id1-to-root-grandchild root-children-between-tags (reverse id2-to-root-grandchild)]))

(def hardcoded-weights {:hr 200 :div 100 :table 80 :tr 30 :td 10 :span 2 :p 1})
(defn weigh [tag] (hardcoded-weights tag 1))

;TODO: Move all this stuff to jaegers.edgar.util.clj?
;TODO: Should this have a multiplier by depth? A div inside a td isn't a big deal, a div containing tables is
;TODO: Detect and invert column-oriented tables?
(defn rom-dist
  "Multiplies tags on a rom-path by weights and returns a distance score"
  [hickory id1 id2]
  (let [root-id (parts->id (shared-root id1 id2))
        root-tag (->> root-id (hu/id->loc hickory) first :tag)
        [id1-to-root-grandchild root-children-between-tags id2-to-root-grandchild] (rom-path hickory id1 id2 root-id)
        total-children-weight (apply + (map weigh (tags-of-children hickory root-id)))
        weights-between-root-children (->> root-children-between-tags
                                           (map #(/ (weigh %) total-children-weight))
                                           (apply +)
                                           (* (weigh root-tag)))
        path1-weight (apply + (map weigh id1-to-root-grandchild))
        path2-weight (apply + (map weigh id2-to-root-grandchild))]
    (+ path1-weight weights-between-root-children path2-weight)))

;;End Jonathan's Distance Metric;;

;; NOTE: these distance metrics are duplicated in jaegers.edgar.utils
; (defn manhattan-distance [_ u v]
;   (reduce + (map (comp #(Math/abs ^double %) -) u v)))

(defn euclidean-distance [_ u v]
  (Math/sqrt (reduce + (map #(* % %) (map - u v)))))

; (defn log-distance [_ u v]
;   (let [x (euclidean-distance _ u v)]
;     (if (zero? x) 0 (long (Math/ceil (Math/log10 x))))))

(defn cusip-docs->identifiers
  "Extracts all identifiers from cusip-docs and returns them in the form [{:doc-id 0 :id [1 2 3]} ...].
   Includes multiple occurrences of the same identifier, but only includes the first id for each occurrence."
  [cusip-docs]
  (let [identifiers-to-include #{:cusip-9}]
    (into [] (flatten
               (for [i (range (count cusip-docs))]
                 (let [doc (nth cusip-docs i)]
                   (for [identifier identifiers-to-include]
                     (for [occurrence (-> doc identifier :ids)]
                       {:doc-id i :id (first occurrence)}))))))))

(defn score-all-links
  "Associates a score with every possible linking and returns as
   [{:doc-id 0 :id [1 2 3] :score 50 :candidate {...} :identifier-id \"1_2_3\"]} ...]"
  ([hickory cusip-docs candidates score-fn]
   (score-all-links hickory cusip-docs candidates score-fn <))
  ([hickory cusip-docs candidates score-fn comp] ;TODO: implement comp
   (into [] (flatten
              (for [identifier (cusip-docs->identifiers cusip-docs)]
                (for [candidate candidates]
                  (let [identifier-id (-> identifier :id ju/id->vec)
                        candidate-id (-> candidate :ids ffirst ju/id->vec)]
                    (merge identifier {:score (score-fn hickory identifier-id candidate-id)
                                       :candidate candidate
                                       :identifier-id (parts->id identifier-id)}))))))))

(defn link-by-score
  "Return the best possible linkings as idenitifed by the provided score-fn.
   Returns links in form: [{:doc-id 0 :id [1 2 3] :score 50 :candidate {...}} ...]"
  ([hickory cusip-docs candidates score-fn]
   (link-by-score hickory cusip-docs candidates score-fn false))
  ([hickory cusip-docs candidates score-fn max?]
   (let [scored-links (score-all-links hickory cusip-docs candidates score-fn comp)
         comp-fn (if max? max-key min-key)]
     (loop [remaining-links scored-links chosen-links []]
       (if (empty? remaining-links)
         chosen-links
         (let [min-score (apply comp-fn :score remaining-links)
               min-doc (:doc-id min-score)]
           (recur (filter #(not= min-doc (:doc-id %)) remaining-links)
                  (conj chosen-links min-score))))))))

; (defn apply-links
;   "Merges links into cusip-docs"
;   [cusip-docs links jaeger]
;   (loop [docs cusip-docs remaining-links links]
;     (if (empty? remaining-links)
;       docs
;       (let [link (peek remaining-links)
;             assoc-path [(:doc-id link) (-> link :candidate :class)]]
;         (recur (assoc-in docs assoc-path (assoc (:candidate link) :jaeger jaeger))
;                (pop remaining-links))))))
