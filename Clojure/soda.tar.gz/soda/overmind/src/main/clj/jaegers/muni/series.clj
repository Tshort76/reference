(ns jaegers.muni.series
  (:require [clojure.string :as str]
            [utils.simple-search :as search]
            [taoensso.timbre :as timbre]
            [plumbing.core :refer [defnk]]
            [utils.mind-food :as umf]))

(defn clean-word [word]
  (-> word
      str/lower-case
      (str/split #"[-,.?!\"_()]")))

(defn contains-words-fn [word-set]
  (fn [word]
    (some->> word
             :text
             clean-word
             (apply (some-fn word-set)))))

(defn regex-helper-fn [regex]
  (fn [word]
    (some->> word
             :text
             (re-matches regex)
             (remove nil?)
             rest)))


;How can  we identify the components that make up the  series description?
;physical characteristics--- Text is often centered on the page, or within the cell.   Most often it is on the first
;page.  What we really want is to create components that we can send to the (find-primary-series) function

; 1.  series component broken by extra information in the sequence (md5=63d2fb6b565fb10b157bc056cb3087b9)
;     On the first page, gather all components that  appear to be centered. merge those that are in sequence into
;     a single component, then feed the components to (find-primary-series)
; 2.  For any table on  the first page we'll convert each column to its own text component.
;     md5=cf47b991a16529bd0c7b3fed63f29d9b)
; 3.  for any centered text followed by a table, we'll do 1, then 2, only adding the component right before if it is
;     centered.   This will be fed to the find-primary-series jaeger.







;When we talk about "year" we should realize there is also just a numeric sequence type of tagging.
;For example $51,920,000 Single Family Housing Revenue Bonds, Series 187 (Non-AMT)
;where Series 187 is used instead of Series 2007 for example.
(def year?
  (regex-helper-fn #"[-,.?!\"_()]*([12]\d{3})|(\d{3})[-,.?!\"_()]*")) ; this will need to be updated to handle multiple years

(def district-regex #"(?i)[-,.?!\"_()]*(district no. \d{1,5})[-,.?!\"_()]*")

(def serial?
  (regex-helper-fn #"\d{3}"))

(defn tag-year [word]
  (when-let [years (year? word)]
    (map (fn [year]
           {:year   year
            :group  nil
            :ids    [(:id word)]
            :coords [(search/word->coord word)]
            :bold?  (:bold? word)})
         years)))

(def group-regex?
  (regex-helper-fn #"[-,.?!\"_()]*([A-Z0-9]{2}|[A-Z0-9](?:-[A-Z0-9]){0,2})[-,.?!\"_()]*"))

(def word-numbers?
  (contains-words-fn #{"one" "two" "three" "four" "five" "six" "seven" "eight" "nine"}))

(def year-group?
  (comp
    (fn [[y :as yg]]
      (when y                                               ; because the regex might fail
        (filter identity yg)))
    (regex-helper-fn #"[-,.?!\"_()]*([12]\d{3})(?:([A-Z][A-Z0-9]?(?:-[A-Z0-9]){0,2})|-([A-Z0-9][A-Z0-9]?(?:-[A-Z0-9]){0,2}))(?:\/([A-Z0-9]{2}|[A-Z0-9](?:-[A-Z0-9]){0,2}))*[-,.?!\"_()]*")))

(defn tag-year-group [word]
  (when-let [[year & groups :as stuff] (year-group? word)]
    (map (fn [group]
           {:year   year
            :group  group
            :ids    [(:id word)]
            :coords [(search/word->coord word)]
            :bold?  (:bold? word)})
         groups)))

;; Robert's regex:
;  (?:its|the|\([a-zA-Z1-9]*\)|and)\s
; ((?:(?!its|the|\([a-zA-Z1-9]*\))[$(]?[A-Za-z0-9,-]+[,)]??\s){0,20}
;(?:bonds|certificates|certifications|notes|debt|obligations|series\s[A-Za-z0-9-]*|loan|participations))

(def series-terminator?
  (contains-words-fn #{"bonds"}))

(def series-terms?
  (contains-words-fn #{"series" "certificates" "notes"}))

(def special-word?
  (contains-words-fn #{"series" "bonds" "certificates" "notes"}))

(def taxable?
  (contains-words-fn #{"taxable"}))

(def padding?
  (contains-words-fn #{"and" "of"}))

(def junk-word?
  (contains-words-fn #{"the" "of" "and" "on" "or" "tax" "for"}))

(def false-word?
  (contains-words-fn #{"due" "yield"}))

(def terminator-word?
  (contains-words-fn #{"dated" "due" "date"}))

(defn group? [word]
  (or (word-numbers? word)
      (and (not (junk-word? word))
           (first (group-regex? word)))))

(defn tag-group [word]
  (when-let [group (group? word)]
    {:year   nil
     :group  group
     :ids    [(:id word)]
     :coords [(search/word->coord word)]
     :bold?  (:bold? word)}))

(defn tag-word [word]
  (cond
    (special-word? word) :special-word
    (padding? word) :padding
    (junk-word? word) nil
    (year? word) :year
    (serial? word) :serial
    (group? word) :group
    (year-group? word) :year-group
    :else nil))

(defn series-word? [word]
  (when (tag-word word)
    true))

(defn valid-series [words]
  (if (some false-word? words)
    false
    (some->> words
             (keep tag-word)
             (remove #{:padding})
             not-empty
             (apply hash-set)
             ((every-pred :special-word #(<= 2 (count %)))))))


(defn format-phrase [phrase]
  (loop [out []
         year nil
         rem (remove (some-fn series-terms? junk-word?) phrase)]
    (if (empty? rem)
      (filter not-empty
              (if year
                (conj out [year])
                out))
      (let [[sp [wrd & rst]]
            (-> (some-fn series-terminator? year? year-group?)
                complement
                (split-with rem))]
        (recur
          (conj out (if year
                      (cons year sp)
                      sp))
          (when-not (series-terminator? wrd) wrd)
          rst)))))


(defn merge-group-tags [{year1 :year group1 :group ids1 :ids coords1 :coords b1 :bold?}
                        {year2 :year group2 :group ids2 :ids coords2 :coords b2 :bold?}]
  {:year   (or year1 year2)
   :group  (->> [group1 group2] (filter not-empty) (str/join "-") not-empty)
   :ids    (into (or ids1 []) ids2)
   :coords (into (or coords1 []) coords2)
   :bold?  (or b1 b2)})

(defn nest-ids [tag]
  (-> tag
      (update :ids hash-set)
      (update :coords hash-set)))

(defn normalize-groups [and? y-groups other-groups]
  (if (>= 1 (count y-groups))
    (let [base (or (first y-groups) {})]
      (if and?
        (map (partial merge-group-tags base) other-groups)
        (filter not-empty [(reduce merge-group-tags base other-groups)])))
    (do (when (< 0 (count other-groups))
          (timbre/debug (str "WARNING: multiple year-groups found; other-groups are being ignored.\n"
                             " >> year-groups: " y-groups "\n >> other-groups: " other-groups "\n")))
        y-groups)))

(defn normalize-series [series]
  (let [years (-> series first tag-year)
        year-groups (-> series first tag-year-group)
        groups (keep tag-group series)
        and? (not-empty (keep (contains-words-fn #{"and"}) series))]
    (map nest-ids
         (normalize-groups and? (or years year-groups) groups))))


(defn merge-series [series-list]
  (->> series-list
       (group-by (juxt :year :group))
       vals
       (map (partial reduce
                     (fn [a b]
                       (-> a
                           (update :ids into (:ids b))
                           (update :coords into (:coords b))
                           (update :bold? (fn [& all] (some identity all)) (:bold? b))))))))

(defn overlap? [test target]
  (if (not (empty? test))
    (some test (:ids target))
    false))

(defn normalize-single [raw-series]
  (let [series (filter (some-fn group? year-group? year?) raw-series)
        district (->> raw-series
                      (umf/find-in-vals district-regex)
                      :matches
                      first
                      second)
        district-ids (into #{} (map :id district))
        district-overlap? (partial overlap? district-ids)
        year-groups (->> series (mapcat tag-year-group) (remove district-overlap?) merge-series not-empty)
        years (->> series (mapcat tag-year) (remove district-overlap?) merge-series not-empty)
        groups (->> series (keep tag-group) (remove district-overlap?) merge-series not-empty)]
    ;(clojure.pprint/pprint [series,district,district-ids,year-groups,years,groups])
    (some->
      (if year-groups
        (when (and (nil? years)
                   (-> groups count #{0 1})
                   (-> year-groups count (= 1)))
          (nest-ids (merge-group-tags (first year-groups)
                                      (first groups))))
        (when (and (-> years count #{0 1})
                   (-> groups count #{0 1}))
          (nest-ids (merge-group-tags (first years)
                                      (first groups)))))
      (assoc :long-name {:value (->> raw-series
                                     (map :text)
                                     (str/join " "))
                         :ids   [(mapv :id raw-series)]}))))

(defn normalize-by-line-or-component [raw-series]
  (if-let [series (normalize-single raw-series)]
    series
    (normalize-single (flatten raw-series))))

(defn subgroup-of [group1 group2]
  (if (and group1 group2)
    (let [gl1 (str/split group1 #"\-")
          gl2 (str/split group2 #"\-")]
      (and (<= (count gl1) (count gl2))
           (every? identity (map = gl1 gl2))))
    true))

(defn subseries-of [{year1 :year group1 :group bold1 :bold? :as series1}
                    {year2 :year group2 :group bold2 :bold? :as series2}]
  (and (not= series1 series2)
       (not (or (and (nil? year1) year2 group1 (nil? group2))
                (and year1 (nil? year2) (nil? group1) group2)))
       (subgroup-of group1 group2)
       (or (nil? year1)
           (nil? year2)
           (= year1 year2))
       (if bold1 bold2 true)))

(defn submerge [base-series subseries]
  (cond
    (subseries-of subseries base-series)
    (-> base-series
        (update :ids into (:ids subseries))
        (update :coords into (:coords subseries)))
    (subseries-of base-series subseries)
    nil
    :default
    base-series))

(defn one-way-submerge [base-series subseries]
  (if (subseries-of subseries base-series)
    (-> base-series
        (update :ids into (:ids subseries))
        (update :coords into (:coords subseries)))
    base-series))

(defn merge-subseries [series-list]
  (reduce
    (fn [lst s] (keep #(submerge % s) lst))
    series-list
    series-list))


(defn matched-series->jaeger-form [series]
  (map (fn [{:keys [year group ids coords long-name]}]
         {:series                 {:ids    (vec ids)
                                   :coords (vec coords)
                                   :value  (->> [year group]
                                                (remove empty?)
                                                (str/join " ")
                                                (str "Series "))
                                   :class  :series
                                   :jaeger :series}
          :group-name-description (assoc long-name
                                    :jaeger :series :class :group-name-description)})
       series))


(defn count-line-chars [line]
  (->> line
       (map (comp inc count :text))
       (apply + 0)))

(defn get-left-most-xs [c]
  (->> (:vals c)
       (keep (comp :x first flatten))
       (map int)
       (drop 1)))

(defn ragged-left [c]
  (let [x-s (get-left-most-xs c)]
    (if (empty? x-s)
      false
      (not (apply = x-s)))))


;what are the things that might be a series description?
;we know that not all lines are bolder,
;but what about things like text is centered?

(defn series-def-component? [cmp]
  (and (not= (:type cmp) "table")
       (or
         (ragged-left cmp)
         (every?
           (every-pred
             #(< (count-line-chars %) 90))                   ;90 seem arbitrary.  Lets raise it!
             ;(partial every? :bold?) ;sometimes, we're not bolded
                                                           ; or every capitalized?
           (:vals cmp)))))

(defn series-begin-line? [line]
  (->> line
       (map :text)
       (str/join " ")
       (re-find #"\$ ?[\d,]+(\.\d\d)?")))

(defn series-end-line? [line]
  (valid-series line))

(defn conjn [coll & r]
  (apply conj coll (remove nil? r)))


(defn line-reducer [result line]
  (cond
    (some terminator-word? line)
    (-> result
        (update :out conjn (:done result))
        (dissoc :done :part)),
    (series-begin-line? line)
    (-> result
        (update :out conjn (:done result))
        (assoc :part line
               :done (when (series-end-line? line) line)))
    (:part result)
    (cond-> (update result :part concat line)
            (or (series-end-line? line)
                (some taxable? line)) (#(assoc % :done (:part %))))
    :else result))


(defn make-long-series-lines [lines]
  (->> lines
       (reduce
         line-reducer
         {:out []})
       (#(update % :out conjn (:done %)))
       :out))

(defn make-series-def-chunks [cmps]
  (let [{:keys [out part]}
        (reduce
          (fn [{:keys [out part] :as result} cmp]
            (if (series-def-component? cmp)
              (update result :part concat (:vals cmp))
              {:out (if part
                      (conj out part)
                      out)}))
          {:out []} cmps)]
    (if part
      (conj out part)
      out)))


(defn get-ids-from-tokens [tokens]
  (mapcat (fn [t] (or (:ids t) [(:id t)])) tokens))

(defn find-components [components id-set]
  (filter (fn [c] (some
                    id-set
                    (get-ids-from-tokens (flatten (:vals c))))) components))

(defn re-work-components-by-series [mind-food]
  (let [chopped (take-while #(< (:page-number %) 5) mind-food)
        fixed (mapcat umf/columns->text chopped)
        cleaned (map umf/component-clean-up fixed)
        all-vals (nth (iterate umf/merge-big-cap-small-cap (flatten (map :vals fixed))) 2)
        found-by-vals (umf/find-in-vals #"(?i)\$ ?[\d,]+(\.\d\d)?.{5,1000}?series \d{1,4}" all-vals)
        ;found-by-comp (umf/find-in-mindfood #"(?i)\$ ?[\d,]+(\.\d\d)?.{5,1000}?series \d{1,4}" cleaned)
        series (:matches found-by-vals)
        series-ids (map (fn [s] (into #{} (get-ids-from-tokens (second s)))) series)
        component-lists (map (partial find-components cleaned) series-ids)
        components (map umf/->text-component (map umf/merge-components component-lists))]

    components))

(defn build-primary-series [mind-food]
  (let [primary (->> mind-food
                     (take-while #(< (:page-number %) 5))
                     make-series-def-chunks
                     (mapcat make-long-series-lines)
                     (keep normalize-by-line-or-component)
                     flatten
                     merge-series
                     merge-subseries)]
    (if (empty? primary) nil primary)))                     ;to make the or work.



(defn find-primary-series
  "Finds the series statements on the document. The mind-food may have sliced up the series statements
  in weird ways due to problems with different fonts, weird capitalization.  So this function tries to
  find series first by using our the original component layout, and if that fails, tries rearranging
  components."

  [mind-food]
  (or (build-primary-series mind-food)
      (build-primary-series (re-work-components-by-series mind-food))))



(defn parse-component [{:keys [type vals]}]
  (if (= type "table")
    (mapcat (partial keep (comp not-empty
                                (partial filter series-word?)))
            vals)
    (->> vals
         (map (partial partition-by series-word?))
         ;  (mapcat (partial filter (comp series-word? first)))
         (mapcat (partial filter valid-series))
         (filter (partial some special-word?)))))

(defn mind-food->series [food]
  (->> food
       (mapcat parse-component)
       (mapcat format-phrase)
       (mapcat normalize-series)
       (reduce (fn [lst s] (mapv #(one-way-submerge % s) lst)) ;; this MUST be force-evaluated to prevent lazy-recursion-of-death
               (find-primary-series food))
       matched-series->jaeger-form))

;; custom series/cusip merging logic

(defn above?
  "Returns true if mindfood token a is found on or above the line where token b is found."
  [a b]
  (neg? (compare ((juxt :page-number #(some-> % :y (- 5))) a)
                 ((juxt :page-number :y) b))))

(defn abs [x]
  (max x (- x)))

(defn vertical-distance
  [{x0 :x y0 :y p0 :page-number}
   {x1 :x y1 :y p1 :page-number}]
  (+ (abs (if (and x0 x1) (- x1 x0) 0))
     (* 1000 (abs (if (and y0 y1) (- y1 y0) 0)))
     (* 1000000 (abs (if (and p0 p1) (- p1 p0) 0)))))


(defn smash-coords [series-doc]
  (->> series-doc
       :series
       :coords
       flatten))

(defn filter-series-coords [coordinate series-coords]
  (->> series-coords
       (filter #(above? % coordinate))
       seq))

(defn nearest-series-fn [coordinate]
  (fn [doc]
    (some->> doc
             smash-coords
             (map (partial vertical-distance coordinate))
             (apply min))))

(defn nearest-series [series-docs coordinate]
  (let [series-above (->> series-docs
                      smash-coords
                      (filter (partial filter-series-coords coordinate))
                      seq)]
    (if series-above  ;;first check for closest series above
        (apply min-key
           (nearest-series-fn coordinate)
           series-above)
        (when (seq series-docs)
          (apply min-key ;;no series, check for closest series
               (nearest-series-fn coordinate)
               series-docs)))))


(defn merge-nearest-series [series-docs cusip-docs]
  (map #(->> (or (:cusip-3 %) (:cusip-9 %))
             :coords
             flatten
             first
             (nearest-series series-docs)
             (merge %))
       cusip-docs))

; (defn get-series [{:keys [mind-food, cusip-docs] :as omni-doc}]
;   (-> omni-doc
;       mind-food->series
;       (merge-nearest-series cusip-docs)))

(defnk series* [mind-food cusips*]
  (zipmap
    (keys cusips*)
    (map :series (merge-nearest-series (mind-food->series mind-food) (vals cusips*)))))

;; Functions Used By Other Jaegers ;;

(defn parse-component-strict [{:keys [type vals]}]
  (if (= type "table")
    (mapcat (partial keep (comp not-empty
                                (partial filter series-word?)))
            vals)
    (->> vals
         (map (partial partition-by series-word?))
         (mapcat (partial filter valid-series))
         (filter (partial some special-word?)))))

(defn component->strict-series [component]
  (->> component
       parse-component-strict
       (mapcat format-phrase)
       (mapcat normalize-series)
       matched-series->jaeger-form))

#_(comment

    (require '[jaegers.jaeger-primer :as primer])
    (require '[jaegers.muni.msrb-supplement])
    (require '[jaegers.muni.cusips])


    (def memoized-query-omni-data
      (memoize (fn [q] (primer/query->omni-data q))))

    (defn run-all [query]
      (let [m (memoized-query-omni-data query)]
        (some-> (#(jcr/accrete-jaeger-docs m nil :msrb))
                (#(jcr/accrete-jaeger-docs m % :cusips))
                (#(jcr/accrete-jaeger-docs m % :series)))))


    (defn get-series [query] (into #{} (map (comp :value :series) (run-all query))))
    (def all-vals (flatten (map :vals (filter (comp #{:text} :type) mf))))
    (def mega-comp {:vals all-vals :page-number 1 :type :text})
    (umf/find-in-component #"(?i)\$[0-9,]{4,12}.{20,200}?series \d{1,4}" mega-comp)
    (def mf (take-while #(< (:page-number %) 5) (:mind-food (primer/query->omni-data {:md5 "fe110d1c39c28080eedae5a4762b32dc"}))))
    (find-primary-series-deux mf))
    ;this one, which I am currently working on, the series info is in a table.
    ;I will need to flatten tables also. note, done
    ;table cleanup for big cap to small cap will need to work. (or just flatten everything!)
    ;Algorithm:
    ;




;; todo:
; "Series A of 2012"
; http://dev-soda-app3:8084/soda-jerk-ws/overmind/original/?md5=430b495c40c0a15c3caaee17fd8f898a

; investigate:
; http://dev-soda-app3:8084/soda-jerk-ws/overmind/original/?md5=23bf60cd88d94758e56f3984773e4464

;; Examples:
; ["Series" "A" "Bonds"]
; ["Bonds," "Series" "2015B"]
; ["2014" "Series"]
; ["Series" "2012A" "Bonds"]
; ["2016" "Bonds"]
; ["2016" "SERIES" "B"]
; ["2014" "Series" "1," "2" "and" "3" "Bonds."]
; ["2013" "Series" "B-1-A" "Bonds,"]

;; more examples:
; Series 150  check!
; Series G-1
; SERIES 2016B-1
; 2013, Series EH
; Bonds 2011B
; Bonds 2011A
; Bonds 2011E-2
; 2010 Series C
; Subseries C-2
; Series EV
; 2013 Series D-2
; 2009 Series H-2

; 2014 Subseries A-1 ;; ?
; 2011-2012 BONDS, SERIES C ;; <-- we currently can't handle this
; 2015 BONDS, SERIES A
