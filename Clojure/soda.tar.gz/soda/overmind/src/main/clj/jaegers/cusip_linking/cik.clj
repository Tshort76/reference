(ns jaegers.cusip-linking.cik
  (:require [clojure.string :as cs]
            [clojure.tools.trace :refer :all]
            [jaegers.cusip-linking.common :as clc]
            [soda.data.core :as sdc]
            [soda.data.figi :as figi]
            [taoensso.timbre :as timbre]))

(sdc/defcon "soda" "cusip-db")
(sdc/defcon "edgar" "ciq-oracle")
(sdc/defcon "soda" "cik-cusip6") ;newer

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;cik-cusip-stuff;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn ciks->cusip-6s [ciks]
  (some->> (seq ciks)
           (map clc/cik-sanitize->long)
           ((fn [ciks] (cik-cusip6 {"$or" (mapv hash-map (repeat :cik) ciks)})))
           (map :cusip-6s)
           flatten
           seq))

(defn cusip-db-filter-fn [{:keys [field-filter description-removal-regex cfi-code registered?] :as context}]
  (fn [{:keys [form iso-cfi-code cusip-issue-description] :as cusip-db-doc}]
    (and (clc/field-filter-fn field-filter cusip-db-doc)
         (if (and description-removal-regex cusip-issue-description) (not (re-find description-removal-regex cusip-issue-description)) true)
         (if (and cfi-code iso-cfi-code) (re-find cfi-code iso-cfi-code) true)
         (if (and registered? form) (#{"Registered"} form) true))))

(defn figi-data? [cusip-doc]
  (let [figi-data (apply merge (figi/query-norm-figi {:cusip (:cusip cusip-doc) :exchange-specific.exchange-code "US"}))]
    (when (and figi-data (< 3 (count (vals figi-data))))
      figi-data)))

(defn cusip-db-reform [cusips context]
  (some->> (filter :cusip cusips)
           (group-by :cusip)
           vals
           (map (partial apply merge))
           (filter (cusip-db-filter-fn context))
           (map #(assoc % :figi-data (figi-data? %)))))

(defn ciks->cusips
  "Looks in ciq-oracle using cik for cusip-6s and pull the relevant documents from cusip-db"
  [ciks & {:as context}]
  (let [cusip-docs (some-> (ciks->cusip-6s ciks) seq
                           ((fn [cusip-6s] (cusip-db {"$or" (mapv hash-map (repeat :cusip-issuer-number) cusip-6s)})))
                           (cusip-db-reform context))]
    (if (seq cusip-docs)
      cusip-docs
      (do (timbre/info "Found no possible cusips from cik->cusips with ciks " (print-str ciks))
          []))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;ticker-cusip-stuff;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(def shareclass-ticker-re #"^([^\/\-\.]{2,5})([ABab])$")

(defn add-separator [ticker]
  (if-let [[_ before class] (re-find shareclass-ticker-re ticker)] [ticker (str before "." class)] [ticker]))

(defn expand-ticker [ticker]
  (some->> ticker
           cs/upper-case
           ((fn [new-v] (map #(cs/replace new-v #"[/\.-]" %) ["/" "." "-"])))
           distinct
           (into [])))

(defn detailed-tickers->cusips
  "currently meant just for edgar-10k, deals with tickers"
  [tickers {:keys [no-figi no-cusip-db] :as opts}]
  (when-not (sequential? tickers)
    (throw (ex-info "tickers needs to be sequential" {:tickers tickers
                                                      :opts    opts})))
  (let [tickers (filter identity (mapcat expand-ticker tickers))
        cusip-db-docs (when (and (not no-cusip-db) (seq tickers))
                        (cusip-db {"$or" (mapv hash-map (repeat :ticker-symbol) tickers)}))
        figi-docs (when (and (not no-figi) (seq tickers))
                    (figi/query-norm-figi {"$or"   [{:exchange-specific$ticker        {:$in tickers}
                                                     :exchange-specific$exchange-code "US"}
                                                    {:exchange-specific.ticker        {:$in tickers}
                                                     :exchange-specific.exchange-code "US"}]
                                           :schema "equity-schema"}))
        intersection-cusips (clojure.set/intersection (into #{} (keep :cusip cusip-db-docs))
                                                      (into #{} (keep :cusip figi-docs)))]
    {:cusip-db-docs cusip-db-docs
     :figi-docs figi-docs
     :only-cusips (cond
                    (pos? (count intersection-cusips)) (into [] intersection-cusips)
                    (pos? (count figi-docs)) (->> figi-docs (keep :cusip) distinct)
                    (pos? (count cusip-db-docs)) (->> cusip-db-docs (keep :cusip) distinct))}))

(defn tickers->cusips
  "currently meant just for edgar-10k, deals with tickers"
  [tickers opts]
  (let [{:keys [only-cusips]} (detailed-tickers->cusips tickers opts)]
    (if (seq only-cusips)
      only-cusips
      (do (timbre/info "Found no possible cusips from ticker->cusips")
          []))))

(defn tickers->cusip-db-docs [tickers context]
  (some->
    (if-let [cusips (some-> (tickers->cusips tickers context) seq)]
      cusips
      (if (some #(and % (re-find shareclass-ticker-re %)) tickers)
        (some-> tickers (#(map add-separator %)) (tickers->cusips context) seq)))
    ((fn [cusips] (cusip-db {"$or" (mapv hash-map (repeat :cusip) cusips)})))
    (cusip-db-reform context)))