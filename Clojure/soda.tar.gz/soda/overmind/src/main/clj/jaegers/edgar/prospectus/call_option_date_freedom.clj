(ns jaegers.edgar.prospectus.call-option-date-freedom
  (:require [jaegers.edgar.tokens :as ec]
            [simple-mind.parse-objects-utils :as pou]
            [plumbing.core :refer [defnk]]
            [clojure.string :as cs]
            [clojure.pprint :as pp]))

(defn normalize-text [text] (cs/replace text #"[^a-zA-Z0-9:]" ""))

(defn get-candidates [enhik]
  (->> (filter #(and (not-empty (:text %)) (not-empty (:id %))) (ec/extract-tokens enhik))
       (pou/rematch-in #"(?i)((Optional )?Redemption|Redemption (dates?|provisions?|terms|information)|(Optional )?Call Dates|Par Call):.{0,300}" [:text])
       (map (comp (partial map #(update % :text normalize-text)) :objs))))

(defn classify-candidates [cands]
  (keep
    (fn [cand]
      (some->>
        (loop [[[re value] & r]
               [[#"(?i)each interest payment date thereafter|any interest payment date|any scheduled .{0,20} date thereafter"
                 "Every Distribution Date"]
                [#"(?i)semiannually thereafter"
                 "Semi-Annually"]
                [#"(?i)any time on or after|par call.{0,20}(on or after|after the date)|redeemable in whole or in part on or after|on or after .{0,30} may redeem all or a part of|callable thereafter|in whole or in part at any time|at any time in whole or in part"
                 "Anytime Thereafter"]
                [#"(?i)quarterly"
                 "Quarterly"]]]
          (when re
            (if-let [match (first (ec/token-regex cand re))]
              [match value]
              (recur r))))
        ((fn [[{:keys [ids text]} value]]
           {:value  value
            :text   text
            :jaeger ::call-option-date-freedom
            :class :call-option-date-freedom
            :ids    [ids]}))))
    cands))

(defn call-option-date-context [call-option-date* cusip]
  (when-some [cod (some->> cusip call-option-date* :text (re-find #"(?i)on or after"))]
    {:value  "Anytime Thereafter"
     :text   (:text cod)
     :jaeger ::call-option-date-freedom
     :class :call-option-date-freedom
     :ids    (:ids cod)}))

(defnk call-option-date-freedom* [enhanced-hickory cusips call-option-date*]
  (when call-option-date*
    (if-let [cand (first (classify-candidates (get-candidates enhanced-hickory)))]
      (zipmap cusips (repeat cand))
      (zipmap cusips (map (partial call-option-date-context call-option-date*) cusips)))))
