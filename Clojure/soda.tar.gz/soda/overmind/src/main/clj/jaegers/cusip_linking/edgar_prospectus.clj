(ns jaegers.cusip-linking.edgar-prospectus
  (:require [jaegers.cusip-linking.common :as common]
            [jaegers.cusip-linking.cik :as cik]
            [jaegers.edgar.classifiers.cusip-match :as cm]
            [simple-mind.naive-bayes.core :as nb]
            [taoensso.timbre :as timbre]
            [jaegers.edgar.prospectus.core :as jec]
            [clojure.tools.trace :refer :all]
            [soda.core :as soda]
            [jaegers.cusip-linking.identifier-derivation :as id]))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;matching stuff;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defmethod common/flag-other-matches :edgar-prospectus
  [_ cusip-doc jaeger-doc]
  (cond-> []
          (not (#{"NOT AVAILABLE" "NOT APPLICABLE"} (:where-traded cusip-doc))) (conj {:where-traded :matched})
          (some->> cusip-doc :cusip-issue-description (re-find #"(?i)\bcom new\b")) (conj {:new-indicator :matched})
          (some->> cusip-doc :cusip-issue-description (#(not (re-find #"(?i)\bcom new\b" %)))) (conj {:new-indicator :not-matched})
          ;true (conj {:figi-data (if (:figi-data cusip-doc) :present :not-present)}) ;this will do nothing right now as it's geared towards equities.
          ))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;normalizing stuff;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defmulti normalize->cusip-db (fn [k v] k))
(defmethod normalize->cusip-db :default [k v] {k [v]})
(defmethod normalize->cusip-db :coupon-frequency [k v]
  {k (get {"Daily"         ["Daily"],
           "Biennially"    ["Biennial"],
           "At Maturity"   ["At Maturity"],
           "Monthly"       ["Monthly"],
           "Annually"      ["Annual"],
           "Biennielly"    ["Biennielly"],
           "Weekly"        ["Weekly"],
           "Quarterly"     ["Quarterly"],
           "Semi-annually" ["Semi-annual"]}
        v)})
(defmethod normalize->cusip-db :coupon-rate-type [k v]
  {k (get {"Fixed"          ["Fixed Rate"]
           "Floating"       ["Floating Rate" "Variable Rate"]
           "Fixed-to-float" ["Variable Rate"]
           "Float-to-fixed" ["Variable Rate"]
           "Stepped"        ["Step Up" "Step Down"]
           ;need to handle this from zero-coupon
           "Zero"           ["Zero Coupon/Discounted"]}
           ;todo here are other cusip-db values we don't use
           ;["Fixed / Floating Rate"]
           ;["Payment In Kind"]
           ;["Increasing Rate"]
           ;["Split Coupon"]
           ;["Contingent Rate"]

        (name v))})

(defn format-principal-amount [v n]
  (let [amount (float (/ v n))]
    [(soda/parse-double (format "%.1f" amount)) (soda/parse-double (format "%.0f" amount))]))
(defmethod normalize->cusip-db :principal-amount [k v]
  (if v
    (cond
      (> 1000000 v 999)
      {:principal-amount (format-principal-amount v 1000)
       :offering-amount-code ["K"]}
      (> 1000000000 v 999999)
      {:principal-amount (format-principal-amount v 1000000)
       :offering-amount-code ["M"]}
      (> 1000000000000 v 999999999)
      {:principal-amount (format-principal-amount v 1000000000)
       :offering-amount-code ["B"]})
    []))

(defn normalize-field [[k v]]
  (let [norm (normalize->cusip-db k v)]
    (if (every? nil? (vals norm))
      (do (timbre/info (str "Could not normalize to cusip-db form: " k " (" norm ")"))
          {k []})
      norm)))


(defmethod common/normalize-doc :edgar-prospectus
  [file-type simplified-jaeger-doc]
  (->> (if (:zero-coupon simplified-jaeger-doc) (assoc simplified-jaeger-doc :coupon-rate-type :Zero) simplified-jaeger-doc)
       (map normalize-field)
       (apply merge)))

(defmethod common/cusip-selecting-short :edgar-prospectus [original-doc cusips]
  (if-let [derived-cusip (-> original-doc :jaeger-doc :isin :value id/isin->cusip)]
    (some #(if (#{derived-cusip} (:cusip %)) %) cusips)))
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;cik stuff;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defmethod common/field-filter-fn :edgar-prospectus
  [_ {:keys [maturity-date coupon-rate first-coupon-date dated-date coupon-frequency rate-type offering-amount offering-amount-code]}]
  (< 1 (cond-> 0
               maturity-date inc   coupon-rate inc          first-coupon-date inc
               dated-date inc      coupon-frequency inc     rate-type inc
               offering-amount inc offering-amount-code inc)))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;entry point;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defmethod common/execute-cusipless-jaeger :edgar-prospectus [data-type omni-data]
  (->> (jec/execute-cusipless-jaeger omni-data)
       (map #(hash-map :jaeger-doc % :meta {:data-type data-type}))))

(defmethod common/classify-match :edgar-prospectus
  [_ {{:keys [cusip-matched-on]} :meta :as m}]
  (let [fmap (cm/matched-fields->feature-map :edgar-prospectus cusip-matched-on)
        {t :true f :false} (apply hash-map (flatten (nb/classify-multinomial cm/edgar-prospectus-model fmap :verbose? true)))]
    (assoc-in m [:meta :probability] {:match t :not-match f :class (if (< f t) :match :not-match)})))

(defmethod common/find-possible-cusips :edgar-prospectus
  [jaeger-docs]
  (let [first-cusip (:value (:cusip-9 (:jaeger-doc (first jaeger-docs))))]
    (if (and first-cusip (re-find #"fakecusip\d{1,2}" first-cusip))
      (let [ciks (map :cik (:value (:filers (:jaeger-doc (first jaeger-docs)))))
            possible-cusips (distinct (cik/ciks->cusips ciks
                                                        :field-filter :edgar-prospectus
                                                        :registered? true
                                                        :description-filter-regex #"CTF DEP"))]
        possible-cusips)
      [])))


(defmethod common/cusip-link-needed? :edgar-prospectus
  [jaeger-doc]
  (< 3 (count (keep #(% (:jaeger-doc jaeger-doc))
                    [:interest-rate :coupon-frequency
                     :first-coupon-date :issue-date
                     :maturity-date :coupon-rate-type
                     :principal-amount]))))
