(ns jaegers.muni.coupon-rate-type
  (:require
    [clojure.edn :as edn]
    [clojure.java.io :as io]
    [simple-mind.naive-bayes.core :as nb]
    [simple-mind.naive-bayes.util :as nbu]
    [plumbing.core :refer [defnk]]))

(def n-grams [3])
(def bayes-model (-> "jaegers/coupon_rate_type_bayes.edn" io/resource slurp edn/read-string))

(defn classify [text]
  (let [words (nbu/->words text)
        bag-of-words (reduce (fn [m n] (merge m (nb/->bag-of-words words :n n))) {} n-grams)
        klass (nb/classify bayes-model bag-of-words)]
    (when-not (#{:bayes/unclassified} klass)
      klass)))

(defn determine-rate-type [{issue-desc :value meta :meta}]
  ;(taoensso.timbre/debug (with-out-str (clojure.pprint/pprint issue-desc)))
  (when-let [rate-type (some-> issue-desc classify)]
    {:class :coupon-rate-type
     :jaeger :coupon-rate-type
     :value rate-type
     :overmind-details {:method :issue-description
                        :value issue-desc
                        :meta meta}}))

(defnk coupon-rate-type* [issue-description* linked-floating-rate]
  (into {} (map (fn [[k v]]
         (if (get-in linked-floating-rate [k :class])
           {k {:class :coupon-rate-type :jaeger :linked-floating-rate :value "Floating" :overmind-details {:method :linked-floating-rate}}}
           {k (determine-rate-type v)}))
          issue-description*))) ;if we can link to floating, we do it.



 ; (zipmap
 ;   (keys issue-description*)
 ;   (map determine-rate-type (vals issue-description*))))

;; Testing---------------------------------------------------------------------


;; Model training --------------------------------------------------------------
(comment
  (require '[soda.data.core :refer [defcon]])
  (require '[clojure.string :as string])
  (import [org.bson.types ObjectId])
  (defcon "soda-raw" "data" :prefix "raw-")

  (def oracle
    (->> "edgar/edgar_rate_type_cusips_oracles.csv"
         io/resource
         slurp
         string/split-lines
         rest
         (map #(string/split % #","))
         (map rest)
         (map #(zipmap [:id :cusip :coupon-rate-type] %))))

  (def train-set
    (pmap (fn [{:keys [id cusip] :as m}]
            (let [desc (->> {:_id (ObjectId. id)} raw-data first :issue-description)]
              (assoc m :issue-description desc)))
          oracle))

  (spit "resources/jaegers/coupon_rate_type_dataset.edn"
        (with-out-str (clojure.pprint/pprint train-set)))

  (def bayes-model
    (->> train-set
         (group-by :coupon-rate-type)
         (reduce-kv
           (fn [model klass samples]
             (reduce
               (fn [m n]
                 (nbu/train-all m klass (map :issue-description samples) :n n)) model n-grams)) {})))

  (spit "resources/jaegers/coupon_rate_type_bayes.edn" (pr-str bayes-model)))
