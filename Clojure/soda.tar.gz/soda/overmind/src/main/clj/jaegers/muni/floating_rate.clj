(ns jaegers.muni.floating-rate
  (:require [clojure.pprint :refer [pprint]]
            [jaegers.floating-rate-parser :as frp]
            [utils.mind-food :as umf]
            [taoensso.timbre :refer [debug]]
            [plumbing.core :refer [defnk]]))

;given the cusips, find the floating rate.
;if one cusip and one floating rate, and the cusip is tagged floating rate, link them.
;if more than one cusip and one floating rate, link to the nearest cusip.
;if more than one floating rate and only one cusip, link the closest.
;otherwise attempt to use the geometric comb solve to solve it.

(defn tag-cusip
  "Given a cusip key, and a map whose key is the cusip-3 value,
   if the cusip key cusip-3 value is in the map, and there is a floating-rate
   entry in the fields, returns a cusip doc with floating rate information added"
  [indexes cusip]
  (let [cusip-index (get-in cusip [:cusip-3 :value])]       ;check to see if we have a cusip
    (if-let [floating-rate (first (get-in indexes [cusip-index :floating-rate]))]
      {cusip floating-rate}
      {cusip {}})))

(defnk linked-floating-rate [cusips* full-links]
  (let [indexed-by-cusip (->> full-links
                              (map (partial group-by :class))
                              (group-by (comp :value first :cusip-3))
                              (map (fn [[k v]] {k (first v)}))
                              (apply merge))
        new-docs (into {} (map (partial tag-cusip indexed-by-cusip) (keys cusips*)))]
    new-docs))

(defnk floating-rate-details [mind-food coupon-rate-type* linked-floating-rate]
  (->> coupon-rate-type*
       (map (fn [[k _]]
              (if (get-in linked-floating-rate [k :class])  ;; we have a floating rate
                (let [floating-rate (get-in linked-floating-rate [k])
                      id (:id floating-rate)
                      component (first (filter (partial umf/component-any-id? #{id}) mind-food))
                      [text ids] (umf/id-surrounding-text id component)
                      detail (into {} (map (fn [[k v]] {k {:value  v
                                                           :jaeger :floating-rate-details
                                                           :text   text
                                                           :ids    [ids]}})
                                           (frp/parse-floating-rate-text text)))]
                  {k detail})
                {k {}})))
       (into {})))


;todo add beam search to find nearby stuff.  (calculate distance from centers)
;todo add in location of found data

#_(comment
    (require '[jaegers.muni.msrb-supplement :as msrb-supplement])
    (require '[jaegers.muni.cusips :as cusips])
    (require '[jaegers.jaeger-primer :as jp])
    (require '[utils.mind-food :as umf])
    (require '[jaegers.floating-rate-parser :as frp])
    (require '[jaegers.muni.coupon-rate-type :as coupon-rate-type])
    (require '[jaegers.muni.series :as series])

    (mapv normalize msrb-supplemental-data)
    ;This was used to generate the test document below
    (defn build-test-document [query]
      (let [omni-data (jp/query->omni-data query)
            omni-data (assoc omni-data :cusip-docs (mapv msrb-supplement/normalize (:msrb-supplemental-data omni-data)))
            omni-data (assoc omni-data :cusip-docs (cusips/get-the-cusips omni-data (:cusip-docs omni-data)))
            omni-data (assoc omni-data :cusip-docs (coupon-rate-type/determine-rate-type (:cusip-docs omni-data)))
            ;omni-data (assoc omni-data :cusip-docs (maturity-schedule/find-maturity-schedule omni-data))
            ;omni-data (assoc omni-data :cusip-docs (series/get-series omni-data))
            ;omni-data (assoc omni-data :cusip-docs (single-bond/single-bond omni-data))
            ;omni-data (assoc omni-data :cusip-docs (maturity-date/maturity-date (:enhanced-hickory omni-data) (:candidates omni-data) (:cusip-docs omni-data)))
            ;omni-data (assoc omni-data :cusip-docs (notes/notes (:enhanced-hickory omni-data)  (:cusip-docs omni-data)))
            ;omni-data (assoc omni-data :cusip-docs (call-option-date/call-option-date (:enhanced-hickory omni-data) (:candidates omni-data) (:cusip-docs omni-data)))
            ;omni-data (assoc omni-data :cusip-docs (jaegers.edgar.prospectus.call-option-schedule/call-option-schedule (:enhanced-hickory omni-data)  (:cusip-docs omni-data)))
            ]
        omni-data))

    (defn build-britta-report [md5]
      (let [test-document (build-test-document {:md5 md5})]
        (when test-document
          (link-floats-to-cusips (:mind-food test-document) (:cusip-docs test-document)))))



    (def test-document (build-test-document {:md5 "befab2b7291b529f97df0b99f9a2910f"}))
    (def tables (filter (fn [c] (= :table (:type c))) (:mind-food test-document)))
    (map frp/parse-floating-rate-text (map :matches (umf/find-in-mindfood #".{3,30} plus \d.\d\d%" (:mind-food test-document))))
    (def text (filter (fn [c] (= :text (:type c))) (:mind-food test-document)))
    (filter (comp not empty?) (flatten (map (partial tu/find-in-table #"(.{3,30} plus \d.\d\d%)|(\d{1,2}% of .{3,30} LIBOR)|(.{3,30} LIBOR)") tables)))
    (def docs ["eaeab67d87d79bae650c7aeef4074c27"
               "d44c255895aff6d5e70b6bb868d3e8cf"
               ])
    ;test data
    ;["112d79482756a0cc67377cfc6a78356f" ("Floating")]
    ; ([[{:page-number 1, :x 441.32016, :y 245.34} {:page-number 1, :x 477.77615, :y 245.34}]])

    ;["f7d6874fa630337b0a20cc5853fb8d22" ("Floating")]
    ;([[{:page-number 2, :x 290.03555, :y 224.4} {:page-number 2, :x 321.69327, :y 224.4}]])

    ;["6079e10bb8686c006455ff2ada5ce3aa" ("Floating" "Floating" "Floating")]
    ;([[{:page-number 2, :x 260.4747, :y 388.08}]]
    ;  [[{:page-number 2, :x 338.80472, :y 388.08}]]
    ;  [[{:page-number 2, :x 415.81473, :y 388.08}]])]

    ;["efcf66dcaccbfbb5a4bc11bb950f30a7" ("Floating" "Floating")]
    ;([[{:page-number 2, :x 517.2082, :y 209.92}]] [[{:page-number 2, :x 518.4582, :y 426.06}]])]

    ;["befab2b7291b529f97df0b99f9a2910f" ("Floating")]
    ;[[{:page-number 2, :x 498.731, :y 291.6}]])]

    ;["666b53869dc40564f2910ae5d04e6690" ("Floating" "Floating")]
    ;([[{:page-number 2, :x 464.68765, :y 267.36} {:page-number 2, :x 499.56116, :y 267.36}]]
    ;  [[{:page-number 2, :x 464.68765, :y 366.42} {:page-number 2, :x 499.6122, :y 366.42}]])]


    ;["0512cd9e3cc6b8e6404009a0b4f269ed" ("Floating")]
    ;([[{:page-number 2, :x 394.49985, :y 490.5} {:page-number 2, :x 427.02283, :y 490.5}]])]

    (defn show-links [md5]
      (let [omni-doc (jaegers.jaeger-primer/query->omni-data {:md5 md5})
            omni-doc-floats (fr/add-floating-rates omni-doc)
            g (link-candidates-to-candidates omni-doc-floats)
            ]
        (lio/dot g "d:\\test.dot")
        (sort-by count (loom.alg/connected-components g))
        ))



    (def omni-doc (jaegers.jaeger-primer/query->omni-data {:md5 "8b47c4bd3d90b909a7a93bd7060d5b9d"}))
    (def omni-doc-floats (fr/add-floating-rates omni-doc))
    (def g (link-candidates-to-candidates omni-doc-floats))
    (sort-by count (loom.alg/connected-components g))
    )
