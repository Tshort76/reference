(ns jaegers.edgar.prospectus.core
  (:require [plumbing.core :refer [fnk defnk ?>]]
            [plumbing.graph :as graph]
            [jaegers.edgar.prospectus
             [accrual-start-date :as accrual-start-date]
             [call-option-date :as call-option-date]
             [call-option-date-freedom :as call-option-date-freedom]
             [call-option-prior-notice :as call-option-prior-notice]
             [call-option-schedule :as call-option-schedule]
             [collateral-type :as collateral-type]
             [convertible :as convertible]
             [country-of-issue :as country-of-issue]
             [coupon-frequency :as coupon-frequency]
             [coupon-rate-type :as coupon-rate-type]
             [coupon-reset-frequency :as coupon-reset-frequency]
             [covered :as covered]
             [currency :as currency]
             [day-count :as day-count]
             [debt-level :as debt-level]
             [face-value :as face-value]
             [first-coupon-date :as first-coupon-date]
             [floating-rate-index :as floating-rate-index]
             ;[guarantors :as guarantors]
             [interest-rate :as interest-rate]
             [isin :as isin]
             [issue-date :as issue-date]
             [issue-description :as issue-description]
             [issue-price :as issue-price]
             [issuer-name :as issuer-name]
             [filers :as filers]
             [make-whole-call :as make-whole-call]
             [maturity-date :as maturity-date]
             [notes :as notes]
             [pass-thru-cert :as pass-thru-cert]
             [perpetual :as perpetual]
             [principal-amount :as principal-amount]
             [put-date :as put-date]
             [rate-floor-cap :as rate-floor-cap]
             [rate-multiplier :as multiplier]
             [security-alias :as security-alias]
             [spread :as spread]
             [underwriter :as underwriter]
             [zero-coupon :as zero-coupon]]
            [clojure.string :as cs]
            [edgar.link-geometries :as elg]
            [jaegers.mind-food-utils :as mfu]
            [tokenvec.core :as tv]
            [edgar.basic-features :as enf]
            [jaegers.utils :as utils]))

(defn fake-by-cand [candidates]
  (let [common-n-candidates (->> (dissoc candidates :issue-date :face-value)
                                 (group-by (fn [[k v]] (count v)))
                                 (sort-by (comp count second))
                                 last
                                 ((fn [[n xs]] (if (< 1 (count xs)) xs []))))
        ids (->> common-n-candidates first second (map :ids))
        vs (some->> common-n-candidates
                    (map (fn [[k v]] (map #(str (name k) ": (" (:value %) ") ") v)))
                    seq (apply map str))]
    (map (fn [id v n] {:cusip-9 {:ids id :text v :value (str "fakecusip" n)}}) ids vs (range 1 20))))

;todo come up with better fake cusip values
(defn fake-cusip-docs [sorted-row-features enhick candidates]
  (let [num-candidates     (fake-by-cand candidates)
        common-codes       (->> (jaegers.edgar.common-code/enhik->common-codes enhick)
                                (filter (comp #(if % (re-find #"\d{9}" %)) :value)))
        issue-descriptions (->> (issue-description/find-issue-descriptions sorted-row-features enhick)
                                issue-description/dedup-issue-desc)]
    (cond
      (seq issue-descriptions)
      (map #(hash-map :cusip-9 {:ids (:ids %1) :value (str "fakecusip" %2) :text (:value %1)}) issue-descriptions (range 1 20))
      (seq common-codes)
      (map #(hash-map :cusip-9 {:ids (:ids %1) :value (str "fakecusip" %2) :text (:value %1)}) common-codes (range 1 20))
      (seq num-candidates)
      num-candidates)))

(defn split-solns [ks v solns]
  (zipmap
    (map (comp (fn [m] (zipmap (keys m) (map #(dissoc % :coords) (vals m)))) #(select-keys % ks)) solns)
    (map (fn [soln]
           (when-some [s (not-empty (soln v))]
             (assoc s :class v)))
         solns)))

(def jaeger-graph
  {:security-keys             (fnk [cusips] (distinct (mapcat keys cusips)))
   :conformer                 (fnk [security-keys] (partial split-solns security-keys))
   :ids->coords               (fnk [enhanced-hickory]
                                (elg/create-ids->geometries-map (elg/create-geometry-maps enhanced-hickory)))
   :tokenvecs                 (fnk [enhanced-hickory] (mfu/enhik->sentence-tokenvecs enhanced-hickory))
   :basic-features            (fnk [tokenvecs] (tv/tokenvecs->basic-features enf/dissect-text tokenvecs))
   :row-sorted-features       (fnk [enhanced-hickory basic-features] (enf/group-by-row enhanced-hickory basic-features))
   :col-sorted-features       (fnk [enhanced-hickory basic-features] (enf/group-by-col enhanced-hickory basic-features))
   ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
   :accrual-start-date*       accrual-start-date/accrual-start-date*
   :asset-class*              (fnk [asset-class cusips] (zipmap cusips (repeat {:class :asset-class :jaeger ::asset-class :value asset-class})))
   :call-option-date*         call-option-date/call-option-date*
   :call-option-date-freedom* call-option-date-freedom/call-option-date-freedom*
   :call-option-prior-notice* call-option-prior-notice/call-option-prior-notice*
   :call-option-schedule*     call-option-schedule/call-option-schedule*
   :collateral-type*          collateral-type/collateral-type*
   :is-secured*               collateral-type/is-secured*
   :convertible*              convertible/convertible*
   :country-of-issue*         country-of-issue/country-of-issue*
   :coupon-frequency*         coupon-frequency/coupon-frequency*
   :coupon-rate-type*         coupon-rate-type/coupon-rate-type*
   :coupon-reset-frequency*   coupon-reset-frequency/coupon-reset-frequency*
   :covered*                  covered/covered*
   :currency*                 currency/currency*
   :cusips                    (fnk [cusip-docs enhanced-hickory row-sorted-features candidates cusip-matching-allowed?]
                                (if (and (not (seq cusip-docs)) cusip-matching-allowed?)
                                  (fake-cusip-docs row-sorted-features enhanced-hickory candidates) cusip-docs))
   :day-count*                day-count/day-count*
   :debt-level*               debt-level/debt-level*
   ;revisit
   :face-value                (fnk [candidates cusips] (face-value/face-value-fn candidates cusips))
   :face-value*               (fnk [conformer face-value] (conformer :face-value face-value))
   :first-coupon-date*        first-coupon-date/first-coupon-date*
   :floating-rate-index*      floating-rate-index/floating-rate-index*
   :filers*                   filers/filers*
   ;:guarantors*               guarantors/guarantors* ;don't think that we want this at all - SODA-3161
   :interest-rate*            interest-rate/interest-rate*
   :isin*                     isin/isin*
   :issue-date*               issue-date/issue-date*
   :issue-description*        issue-description/issue-description*
   :issue-price*              issue-price/issue-price*
   :issuer-name*              issuer-name/issuer-name*
   :make-whole-call-spread*   make-whole-call/make-whole-call-spread*
   :maturity-date*            maturity-date/maturity-date*
   :multiplier*               multiplier/multiplier*
   :notes*                    notes/notes*
   :pass-through-cert*        pass-thru-cert/pass-thru-cert*
   :perpetual*                perpetual/perpetual*
   :principal-amount*         principal-amount/principal-amount*
   :put-date*                 put-date/put-date*
   :underwriter*              underwriter/underwriter*
   :security-alias*           security-alias/security-alias*
   :zero-coupon*              zero-coupon/zero-coupon*
   :rate-cap*                 rate-floor-cap/rate-cap*
   :rate-floor*               rate-floor-cap/rate-floor*
   :spread*                   spread/spread*})




(def cusipless-jaeger-graph
  (assoc jaeger-graph
    :cusips (fnk cusips [cusip-docs enhanced-hickory candidates row-sorted-features]
              (fake-cusip-docs row-sorted-features enhanced-hickory candidates))))

; (def profiled-jaeger (graph/compile (graph/profiled :profile-data jaeger-graph)))
; (def jaeger (graph/compile jaeger-graph))
(def par-jaeger (graph/par-compile jaeger-graph))
(def lazy-jaeger (graph/lazy-compile jaeger-graph))

(def cusipless-jaeger (graph/compile cusipless-jaeger-graph))

(defn smash [[security fields]]
  (reduce
    (fn [s [_ {:keys [class value] :as m}]]
      (cond-> s (and class (some? value)) (assoc class m)))
    security
    fields))

(defn big-merge [m]
  (->> m
       (keep (fn [[k v]] (when (-> k name (cs/ends-with? "*")) v)))
       (mapcat seq)
       (group-by first)
       (map smash)))

(defn safe-execute-jaeger
  [jaeger-method {:keys [enhanced-hickory] :as omni-doc} & [jaegers]]
  (when enhanced-hickory
    (some-> omni-doc jaeger-method (?> (seq jaegers) (select-keys jaegers)) big-merge)))

; (def execute-jaeger (partial safe-execute-jaeger jaeger))
(def execute-parallel-jaeger (partial safe-execute-jaeger par-jaeger))
(def execute-lazy-jaeger (partial safe-execute-jaeger lazy-jaeger))

(def execute-cusipless-jaeger (partial safe-execute-jaeger cusipless-jaeger))
