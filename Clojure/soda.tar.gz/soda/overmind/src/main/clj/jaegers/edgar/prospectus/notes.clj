(ns jaegers.edgar.prospectus.notes
  (:require [jaegers.core :as jcr]
            [clojure.spec.alpha :as s]
            [jaegers.hickory-utils :as hu]
            [jaegers.edgar.tokens :as ec]
            [clojure.string :as cs]
            [plumbing.core :refer [defnk]]))

(def notes-re #"(?i)\d{4} notes|notes due \d{4}")

(defn normalize-text [text]
  (cs/replace (cs/lower-case text) #"[^a-zA-Z0-9\s]" ""))

; (defn re-find-notes [text]
;   (some-> (last (re-seq notes-re text))
;           (normalize-text)))

(defn find-note [cusip enhik]
  (first
    (ec/token-regex
      (filter #(and (not-empty (:text %)) (not-empty (:id %)))
              (ec/extract-tokens enhik))
      (re-pattern (str ".{30}" cusip ".{30}"))
      notes-re)))

(defn determine-note [enhanced-hickory {{cusip :value text :text [ids] :ids} :cusip-9 :as doc}]
  (let [{:keys [text ids]} (or (some->> text (re-find notes-re) (array-map :ids ids :text)) (find-note cusip enhanced-hickory))]
    (when (and text ids)
      {:ids [ids] :value (normalize-text text) :jaeger ::notes :class :notes})))

(defnk notes* [enhanced-hickory cusips]
  (zipmap cusips (mapv (partial determine-note enhanced-hickory) cusips)))
