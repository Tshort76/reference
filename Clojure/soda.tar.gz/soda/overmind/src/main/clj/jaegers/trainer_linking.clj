(ns jaegers.trainer-linking
  (:require [clojure.set :refer [rename-keys]]
            [clojure.string :as str]
            [monger.result :as mr]
            [soda.data.core :as data])
  (:import org.bson.types.ObjectId))

(data/defcon "training-sets" "link-data" :updatable true :basename "link-data")

(defn update-trainer-id [class id]
  (mr/updated-existing?
   (update-link-data-by-id
    (ObjectId. id)
    {:$set {:resolved true :class class}})))

(defn update-trainer [{:keys [correct-ids wrong-ids class]}]
  (concat
   (map (partial update-trainer-id class) correct-ids)
   (map (partial update-trainer-id (str "not-" class)) wrong-ids)))


(defn while-matching-fn [matching-fields]
  (let [match (volatile! nil)]
    (fn [x]
      (cond
        (= @match (select-keys x matching-fields)) true
        (nil? @match) (do (vreset! match (select-keys x matching-fields))
                        true)
        :else false))))

(defn format-link-data [data]
  (when-let [fdata (first data)]
    (-> fdata
        (select-keys [:md5 :class :start-value :filename])
        (update :class (fnil str/replace-first "") #"^maybe-" "")
        (assoc :start-ids (-> data first :start-ids first)
               :candidates (map (fn [{:keys [end-ids _id]}]
                                  {:mid (str _id)
                                   :end-ids (first end-ids)})
                                data)))))

(defn query-data []
  (data/query
   "training-sets" "link-data"
   :query {:resolved {:$in [nil false]}}
   :fields [:md5 :class :start-value :start-ids :end-ids :_id :filename]
   :sort (array-map :md5 1 :start-value 1 :class 1)))

(def data-fetcher
  (let [cursor (atom [])
        new-data (fn []
                   (or (seq @cursor)
                       (reset! cursor (query-data))))]
    (fn []
      (let [[result remaining] (split-with (while-matching-fn [:md5 :class :start-value])
                                           (new-data))]
        (reset! cursor remaining)
        result))))

(defn next-trainer [md5]
  (format-link-data (data-fetcher)))
