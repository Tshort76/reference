(ns jaegers.muni.tax-exemption
  (:require [clojure.string :as str]
            [plumbing.core :refer [defnk]]
            [jaegers.mind-food-utils :as mfu]
            [tfidf.core :as tfidf]))

(defn calc-tax-exemption [mind-food search-text]
  (if (->> mind-food
           mfu/mind-food->sentence-tokenvecs
           (keep (fn [[text foods]] (re-find search-text text)))
           not-empty)
    true false))

(def not-qte-ref-paragraphs
  (mapv #(str/split % #"\s")
        ["The Notes will NOT be designated as qualified tax-exempt obligations for purposes of section"
         "The Bonds have NOT been designated as Qualified Tax-Exempt Obligations for Financial Institutions."
         "warrants should note that such obligations will not qualify as qualified tax-exempt obligations under section"
         "THE CERTIFICATES HAVE NOT BEEN DESIGNATED AS \"QUALIFIED TAX-EXEMPT OBLIGATIONS\" FOR FINANCIAL INSTITUTIONS"
         "The Bonds shall NOT be designated by the Town as qualified tax-exempt obligations under provisions of section"
         "The Bonds are NOT \"Qualified Tax Exempt Obligations\" for purposes of section"
         "The Bonds and Notes do not constitute \"qualified tax-exempt obligations\" as defined in and for the purpose of section"
         "The District will NOT designate the Notes as \"qualified tax exempt obligations\" for purposes of section"]))

(defn not-qualified-tax-exempt-language? [s]
  (->> not-qte-ref-paragraphs
       (map (partial tfidf/calc-cosine-similarity s))
       (some (partial < 0.6))))

(defn find-not-qualified-tax-exempt-language [mindfood]
  (some
    #(not-qualified-tax-exempt-language? (str/split (first %) #"\s"))
    (mfu/mind-food->sentence-tokenvecs mindfood)))

;; note: also used by the :msrb normalization spec
(defn calc-state-tax-exempt [state-code]
  (not (#{"IL" "WI" "IA"} state-code)))

(defnk tax-exemption [mind-food issue-description* state-code*]
  (zipmap
    (keys issue-description*)
    (let [qualified-tax-exempt (and (calc-tax-exemption mind-food #"(?i)qualified tax[\s|-]?exempt obligations?")
                                    (not (or (calc-tax-exemption mind-food #"(?i)The (bonds|notes|certificates|obligations|warrants) (are not|have not|will not|shall not|do not constitute).{0,20}qualified tax[-|\s]?exempt obligations?.{0,20}")
                                             (find-not-qualified-tax-exempt-language mind-food))))]
      (map
        (fn [{issue-desc :value} {state-code :value}]
          (let [federal-tax-exempt (let [taxable (some-> issue-desc str/lower-case (str/includes? "taxable"))
                                         exempt (some-> issue-desc str/lower-case (str/includes? "exempt"))
                                         no-not (not (some-> issue-desc str/lower-case (str/includes? "not")))]
                                     (cond
                                       (and taxable no-not) false
                                       (and exempt no-not) true
                                       (not (or taxable exempt)) true
                                       :else false))
                qualified-tax-exempt-value (and qualified-tax-exempt federal-tax-exempt)]
            (cond-> {:federal-tax-exempt {:value  federal-tax-exempt
                                          :jaeger :tax-exemption}
                     :state-tax-exempt   {:value  (calc-state-tax-exempt state-code)
                                          :jaeger :tax-exemption}}
                    qualified-tax-exempt-value (merge {:qualified-tax-exempt-obligation
                                                       {:value  qualified-tax-exempt-value
                                                        :jaeger :tax-exemption}}))))
        (vals issue-description*)
        (vals state-code*)))))
