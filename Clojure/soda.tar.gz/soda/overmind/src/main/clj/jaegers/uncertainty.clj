(ns jaegers.uncertainty
  (:require [soda.data.core :refer [defcon]]
            [taoensso.timbre :as timbre]
            [clojure.string :as s]
            [html.utils :as hu]
            [medley.core :refer [assoc-some]]))

(defcon "soda_configs" "reprocess" :updatable true)

;returns confident (cusips) , doubtful (cusip, reasons)
(defmulti categorize
          "Takes a group of security documents, the result of parsing
           a single prospectus, and returns a map of the documents whose accuracy
           we have cause to doubt." (comp keyword :data-type :meta first))

(defmethod categorize :edgar-prospectus [docs]
  (map
    (fn [security]
      (let [cusip (get-in security [:jaeger-doc :cusip-9 :value])
            uncertainty
               (cond-> nil
                       (not= :corp (keyword (get-in security [:jaeger-doc :asset-class :value]))) (conj "not-corp")
                       (or (nil? cusip) (re-find #"fakecusip\d{1,2}" cusip )) (conj "no-cusip"))]
        (cond-> security
                uncertainty (assoc :uncertainty-flags uncertainty))))
    docs))

(defmethod categorize :edgar-equity [docs]
  (map
    (fn [security]
      (let [cusip (get-in security [:jaeger-doc :cusip-9 :value])
            uncertainty (when (or (nil? cusip) (re-find #"fakecusip\d{1,2}" cusip )) ["no-cusip"])]
        (cond-> security
                uncertainty (assoc :uncertainty-flags uncertainty))))
    docs))

(defmethod categorize :default [docs] docs)

(defmulti categorize-file
          "Adds any applicable uncertainty flags to file map"
          (fn [file & _] (:file-type file)))

(defmethod categorize-file :default [file & _] file)

(defmethod categorize-file :edgar-prospectus
  ([{:keys [input-stream] :as file}] (categorize-file file (slurp input-stream)))
  ([file ^String contents]
     (let [html (hu/get-html contents)]
      (assoc-some file
                  :uncertainty-flags
                  (cond-> nil
                          (> (hu/tag-count html) 20000) (conj "too-many-html-tags")
                          (> (count html) 5e6) (conj "too-many-bytes")
                          (> (hu/pre-ratio html) 95.0) (conj "plain-text"))))))

(defn ->record! [docs]
  (let [issues (->> docs (keep :uncertainty-flags) (apply concat) distinct)]
    (do (timbre/info (str "Document with md5 " (-> docs first :meta :md5)
                          " will need to be reprocessed for the following reasons: "
                          (s/join "," issues)))
        (update-reprocess {:md5 (-> docs first :meta :md5)}
                          {"$set" (apply merge {:data-type (-> docs first :meta :data-type)}
                                         (map #(hash-map (str "reasons." %) true) issues))}
                          {:upsert true}))))

(defn ->record-file! [{:keys [md5 file-type uncertainty-flags]}]
  (timbre/info (str "Document with md5 " md5
                    " will need to be reprocessed for the following reasons: "
                    (s/join "," uncertainty-flags)))
  (update-reprocess {:md5 md5}
                    {"$set" (apply merge {:file-type file-type}
                                   (map #(hash-map (str "reasons." %) true) uncertainty-flags))}
                    {:upsert true})
  nil)

(defn record-rejects [rejects]
  (->> rejects (filter :uncertainty-flags) (group-by (comp :md5 :meta)) (map (comp ->record! second)) dorun))

(defn remove-n-record-doubtfuls! [docs]
  (let [categorized (->> docs
                         (group-by (comp :md5 :meta))                   ;need to group-by md5 for the multisecurity condition
                         (mapcat (comp categorize second)))]
    (->> categorized (filter :uncertainty-flags) (group-by (comp :md5 :meta)) (map (comp ->record! second)) dorun) ;side effects!
    (->> categorized (remove :uncertainty-flags) (map #(dissoc % :uncertainty-flags)))))

(defn tag-uncertainties [docs]
  (->> docs
       (group-by (comp :md5 :meta))                   ;need to group-by md5 for the multisecurity condition
       (mapcat (comp categorize second))))
