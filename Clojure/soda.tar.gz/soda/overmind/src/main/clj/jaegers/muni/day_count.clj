(ns jaegers.muni.day-count
  (:require [simple-mind.parse-objects-utils :as pou]
            [clojure.string :as cs]
            [clojure.core.match :refer [match]]
            [plumbing.core :refer [defnk]]
            [utils.simple-search :as series]))

(def pattern #"(?i)(36\d-?\s?day[s]?.{0,100}?month[s]?.{15})|(3\d{1}-?\s?day.{0,100}?year)|(36\d.{0,100}?year.{0,100}?day[s]?)|(year.{0,100}365\/366)")

(defn get-ids-and-coords [objs]
  {:ids    [(mapv :id objs)]
   :coords [(mapv series/word->coord objs)]
   :jaeger "daycount"})

(defn match-daycount [text]
  (let [text (cs/replace text #"(?i)thirty" "30")]
    (match [(cs/includes? text "12")
            (cs/includes? text "30")
            (cs/includes? text "360")
            (cs/includes? text "365")
            (cs/includes? text "366")]
           [true false true false false] "Actual/360"
           [false false false true false] "Actual/365"
           [false true true false false] "30/360"
           [_ _ _ _ true] "Actual/Actual"
           :else nil)))

(defn create-jaeger [{text :text objs :objs}]
  (when (and (not (cs/blank? text)) (not-empty objs))
    (when-let [value (match-daycount text)]
      (merge {:value value :jaeger :day-count :class :day-count} (get-ids-and-coords objs)))))

(defn mind-food->daycount [mind-food]
  (when (not-empty mind-food)
    (let [jaeger (first
                   (keep
                     create-jaeger
                     (pou/rematch-in pattern [:text] (flatten (map :vals mind-food)))))]
      (if (empty? jaeger)
        {:value "30/360" :ids [[]] :coords [[]] :jaeger :day-count :class :day-count}
        jaeger))))

(defnk day-count* [mind-food cusips*]
  (zipmap
    (keys cusips*)
    (repeat (mind-food->daycount mind-food))))

(comment
  (process-daycount {:md5 {:$in jaegers.md5-control-sets/kilo-of-happiness}})
  (map (comp mind-food->daycount first #(mf/mind-food {:filename %}))
       ["00344NHU1.pdf"
        "014393QA3.pdf"
        "052404MU1.pdf"])

  (time (mind-food->daycount (first (mf/mind-food {:md5 "fe73e42e0b398de1bf77848f6a40cd16"})))))
