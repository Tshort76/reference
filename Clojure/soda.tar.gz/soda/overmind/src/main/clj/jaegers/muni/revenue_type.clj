(ns jaegers.muni.revenue-type
  (:require
    [clojure.edn :as edn]
    [clojure.java.io :as io]
    [clojure.string :as string]
    [simple-mind.naive-bayes.core :as nb]
    [simple-mind.naive-bayes.util :as nbu]
    [plumbing.core :refer [defnk]]))

(def n-grams 2)
(def class->string
  #(-> %
       name
       (string/split #"-")
       (->> (map string/capitalize))
       (->> (string/join " "))))

(def bayes-model (memoize #(-> "jaegers/revenue_type_bayes2.edn" io/resource slurp edn/read-string)))


(defn mind-food->revenue-type [_] nil)

(defn find-revenue-type
  [text]
  (let [bag-of-words (some-> text nbu/->words (nb/->bag-of-words :n n-grams))
        probs (nb/classify-multinomial (bayes-model) bag-of-words true)
        cls (ffirst probs)]
    (if (not= cls :bayes/unclassified)
      {:value            (class->string cls)
       :overmind-details {:method        :bayes
                          :n-grams       bag-of-words
                          :probabilities (into {} probs)}
       :class            :revenue-type
       :jaeger           :revenue-type})))

(defnk revenue-type* [extended-issue-description]
  (zipmap
    (keys extended-issue-description)
    (map find-revenue-type (vals extended-issue-description))))
;; -----------------------------------------------------------------------------


;; Code to re-build the Bayesian classifier model
#_(comment
  (def samples (some-> "jaegers/revenue_type_trainset.edn" io/resource slurp edn/read-string))

  (defn convert-data-to-samples [data allow-duplicates]
    (let [converted (map (juxt :issuer-name :issue-description :soda-revenue-type) data)
          ready (if allow-duplicates
                  converted
                  (seq (set converted)))
          smashed (map (fn [[a b c]] [(str a " " b) c]) ready)
          by-tag (group-by second smashed)
          cleaned-up (into {} (map (fn[[k v]] {(keyword (cs/lower-case k)) (map first v) }) by-tag))
          ]
      cleaned-up))

  (defn build-bayes-model [samples]
    (reduce (fn [m [cls sams]] (nbu/train-all m cls sams :n n-grams)) {} samples))

  (defn calculate-accuracy-clazz [data clazz]
    (let [ nice-clazz (class->string clazz)
          results  (frequencies (pmap (comp :value find-revenue-type) (clazz data)))]
      ;(clojure.pprint/pprint [results  clazz])
      [(get results nice-clazz 0.0) (count (clazz data)) nice-clazz (int (float (* 100(/ (get results nice-clazz 0.0) (count (clazz data)))))) results]
      ))

  (defn calculate-accuracy [data]
    (let [ results  (map (partial calculate-accuracy-clazz data) (keys data))
          total-correct (reduce + (map first results))
          total (reduce + (map second results))]
      [results total-correct total (int (float (* 100(/ total-correct total))))]))



  )
