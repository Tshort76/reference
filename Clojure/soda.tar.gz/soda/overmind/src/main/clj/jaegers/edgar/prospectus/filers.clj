(ns jaegers.edgar.prospectus.filers
  (:require
    [plumbing.core :refer [defnk]]))

(defn header-entities
  "Returns a map of cik to entity-name from header data"
  [header]
  (let [f (fn [m k] (-> m :company-data first k first))]
    (->> [:subject-company :filed-by :filer]
         (mapcat (partial get header))
         (mapv (fn [m] {:cik (f m :central-index-key) :name (f m :company-conformed-name)})))))

(defn ->jaeger-form [filers]
  {:jaeger ::filers
   :value filers
   :class :filers})

(defnk filers* [header cusips]
  (zipmap cusips (repeat (->jaeger-form (header-entities header)))))
