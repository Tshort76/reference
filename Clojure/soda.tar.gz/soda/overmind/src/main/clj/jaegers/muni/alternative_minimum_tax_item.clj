(ns jaegers.muni.alternative-minimum-tax-item
  (:require [tfidf.core :as tfidf]
            [jaegers.mind-food-utils :as mfu]
            [plumbing.core :refer [defnk]]
            [clojure.string :as string]
            [utils.simple-search :as simple-search]))

(def alternative-minimum-tax-ref-paragraphs
  (mapv #(string/split % #"\s")
        ["Interest on the Series 2017B Bonds will be an item of tax preference for purpose of determining the alternative minimum tax imposed on individuals and corporations under section"
         "In addition, interest on the 2016G Senior Lien Bonds is an item of tax preference for purposes of computing individual and corporate alternative minimum taxable income;"
         "interest on the Series 21 Bonds is treated as a preference item in calculating the alternative minimum tax imposed on individuals and corporations"
         "interest on the Series 2016B Subordinate Bonds is a specific preference item for purposes of the federal alternative minimum tax."
         "interest on the Series 2017B Bonds will be included in a corporate taxpayer’s adjusted current earnings for purposes of computing its federal alternative minimum tax."
         "The interest on the Series 2017C Bonds is included in gross income for federal income tax purposes"
         "Interest on the 2016D Senior Lien Bonds, the 2016E Senior Lien Bonds and the 2016F Senior Lien Bonds is not an item of tax preference for purposes of computing individual and corporate alternative minimum taxable income"
         "interest on the Series 18 Bonds, the Series 19 Bonds and the Series 20 Bonds is not treated as a preference item in calculating the alternative minimum tax imposed on individuals and corporations"
         "the interest on the Bonds is excludable from gross income for federal income tax purposes and is not an item of tax preference for purposes of the federal alternative minimum tax imposed on individuals and corporations"]))

(defn alternative-minimum-tax-language? [s]
  (when (and (not (re-find #"(?i)\bnot\b" s))
             (re-find #"(?i)\balternative\b" s)
             (re-find #"(?i)\bitem\b"s)
             (re-find #"(?i)\bseries|\d{4} bonds\b" s))
    (->> alternative-minimum-tax-ref-paragraphs
         (map (partial tfidf/calc-cosine-similarity (string/split s #"\s")))
         (some (partial < 0.6)))))

(defn cleanup-ids [tokenvecs]
  (->> tokenvecs
       (group-by :text)
       vals
       (map first)
       (remove nil?)))

(defn parse-series-name [s]
  (re-find #"(?i)series \d{1,4}[a-z]?|\d{4} bonds" s))

(defn split-sentence-tokenvecs [[sentence tokenvecs]]
  (mapv
    (fn [[begin-idx end-idx]]
      [(subs sentence begin-idx end-idx)
       (subvec tokenvecs begin-idx end-idx)])
    (partition
      2 1
      (concat [0]
              (map #(string/index-of sentence %)
                   (distinct (re-seq #"\s\([a-zA-Z]+\)\s" sentence)))
              [(count sentence)]))))

(defn tfidf-find-alternative-minimum-tax [mindfood]
  (some (fn [[sentence tokenvecs]]
          (when (alternative-minimum-tax-language? sentence)
            (when-let [series (parse-series-name sentence)]
              (let [objs (cleanup-ids tokenvecs)]
                {:jaeger :alternative-minimum-tax-item
                 :class  :alternative-minimum-tax-item
                 :value true
                 :text   sentence
                 :ids    [(mapv :id objs)]
                 :coords [(mapv simple-search/word->coord objs)]
                 :series series}))))
        (mapcat split-sentence-tokenvecs
                (mfu/mind-food->sentence-tokenvecs
                  (filter #(<= (:page-number %) 1) mindfood)))))

(defn normalize-series-name [series]
  (string/replace series #"(?i)bonds|series|\s|a" ""))

(defn link-with-series [series {series-atmi :series :as atmi}]
  (some->> (group-by (comp :value second) series)
           (keep
             (fn [[series-name grouped-series]]
               (when (and series-name series-atmi
                          (= (normalize-series-name series-name)
                             (normalize-series-name series-atmi)))
                 (map #(array-map % atmi) (keys grouped-series)))))
           flatten
           (into {})))

(defnk alternative-minimum-tax-item* [mind-food series*]
  (some->> (tfidf-find-alternative-minimum-tax mind-food)
           (link-with-series series*)))
