(ns jaegers.core
  (:require
    [clojure.set :as set]
    [jaegers.conflicts :as conflicts]
    [medley.core :refer [assoc-some]]))

(def illegal-meta-keys
  #{:asset-class :contents :cusip-docs :enhanced-hickory :raw :header
    :last-update :meta :metadata :mind-food :msrb-supplemental-data
    :mime-type :file-path :content-type :byte-size :uploader :raw-file-contents
    :feature-flags :query-db})

(def data-type->tags
  {:edgar-taxability-status ["edgar" "entity"]})

(defn sanitize-ids [ids]
  (filter string? (if (sequential? ids) (flatten ids) [ids])))

(defn jaeger-db-form->ecs
  [{{:keys [data-type] :as meta} :meta :keys [jaeger-doc uncertainty-flags _id]}]
  (let [{:keys [cusip-9] :as entity-map} (zipmap (keys jaeger-doc)
                                                 (map :value (vals jaeger-doc)))
        mod-hi-lite-ids (zipmap (keys jaeger-doc)
                                (->> jaeger-doc
                                     vals
                                     (map (comp
                                            (partial take 5)
                                            sanitize-ids
                                            :ids))))]
    (assoc entity-map
           :uncertainty-flags uncertainty-flags
           :meta (-> meta
                     (dissoc :vocabulary :candidates)
                     (assoc :source-type :jaeger
                            :mod-hi-lite-ids mod-hi-lite-ids
                            :_id _id
                            :database "soda-raw"
                            :collection "jaegers")
                     (assoc-some :tags (data-type->tags data-type))
                     (cond-> cusip-9 (assoc :cusip cusip-9))))))


;; this assumes that there will only be one supplemental data point used
(defn get-supplemental-data [jaeger-doc]
  (first (keep (comp :meta second) jaeger-doc)))

(defn metaprep
  [{{:keys [edgar]} :meta :as mind-food-doc} username extra-meta]
  (-> (apply dissoc mind-food-doc illegal-meta-keys)
      (set/rename-keys {:_id :mindfood-id})
      (merge extra-meta)
      (assoc-some :edgar edgar)))

(defn ->jaeger-db-form
  [{:keys [file-type] :as mind-food-doc}
   {:keys [jaeger-docs meta]}
   username]
  (let [f (fn [doc]
            (conflicts/add-conflict-meta
              {:jaeger-doc doc
               :meta (merge (get-supplemental-data doc) (metaprep mind-food-doc username meta))}))]
    (map f jaeger-docs)))
