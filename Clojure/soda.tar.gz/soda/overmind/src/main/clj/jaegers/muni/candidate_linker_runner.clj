(ns jaegers.muni.candidate-linker-runner)
  ; (:require
  ;   [jaegers.muni.candidate-linker :refer :all]
  ;   [jaegers.muni.candidate-linker-utils :refer :all]
  ;   [jaegers.jaeger-primer :as jp]
  ;   [clojure.java.browse :as b]
  ;   [clojure.pprint :as pp]
  ;   [taoensso.timbre :refer [debug]]))

; (defn test-candidate-linker [omni-doc]
;   (let [solutions (into {} (map normalize-solution (link-candidates-to-cusips omni-doc)))
;         supplements (into {} (map normalize-supplement (:msrb-supplemental-data omni-doc)))]
;     (doall (map (fn [k]
;                   (println "**************************")
;                   (pp/pprint (get solutions k))
;                   (pp/pprint (get supplements k))) (keys solutions)))
;
;     nil))


; (defn score-omni-doc [omni-doc]
;   (let [solutions (into {} (map normalize-solution (correct-cusip-doc-filter (:cusip-docs omni-doc))))
;         supplements (into {} (map normalize-supplement (correct-msrb-filter (:msrb-supplemental-data omni-doc))))
;         scores (map (fn [k] (score-by-cusip (solutions k) (supplements k))) (keys supplements))
;         found-cusips (count (:cusips (:candidates omni-doc)))
;         [pmf pma] (score-by-principal-amount (:candidates omni-doc) (:msrb-supplemental-data omni-doc))]
;     [(reduce + (map first scores)) (reduce + (map second scores)) pmf pma found-cusips]))

; (defn score-md5 [md5]
;   (let [omni-doc (jp/query->omni-data {:md5 md5})
;         [doc candidates] (link-candidates-to-cusips omni-doc)]
;     (score-omni-doc (assoc omni-doc :cusip-docs doc))))
;
; (defn fourth [t] (nth t 3))
; (defn third [t] (nth t 2))
;
;
; (defn tally-scores [scores]
;   (let [with-cusips (remove (comp zero? second) scores)
;         by-cusip-correct (reduce + (map first with-cusips))
;         by-cusip-total (reduce + (map second with-cusips))
;         by-cusip-percent (float (/ by-cusip-correct by-cusip-total))
;         by-cusip-tagger-correct (reduce + (map (fn [[a b c d & r]] c) with-cusips))
;         by-cusip-tagger-total (reduce + (map (fn [[a b c d & r]] d) with-cusips))
;         by-cusip-tagger-percent (float (/ by-cusip-tagger-correct by-cusip-tagger-total))
;
;         by-document-linker-correct (reduce + (map (fn [[a b c d & r]] (/ a b)) with-cusips))
;         by-document-linker-percent (float (/ by-document-linker-correct (count with-cusips)))
;
;         by-document-tagger-correct (reduce + (map (fn [[a b c d & r]] (/ c d)) with-cusips))
;         by-document-tagger-percent (float (/ by-document-tagger-correct (count with-cusips)))
;         ]
;     {:by-cusip-linker                     by-cusip-percent
;      :by-cusip-principal-amount-tagger    by-cusip-tagger-percent
;      :by-document-linker                  by-document-linker-percent
;      :by-document-principal-amount-tagger by-document-tagger-percent
;      }))
;
;
;
;
; (def doc-open
;   "<!DOCTYPE html>\n<html>\n<body>\n\n<svg height=\"1000\" width=\"1000\">")
;
; (def doc-close
;   "</svg>\n\n</body>\n</html>")
;
;
; (def type->color
;   {:noise              "\"red\""
;    :targets            "\"green\""
;    :sources            "\"blue\""
;    :cusip              "\"green\""
;    :principal-amount   "\"blue\""
;    :interest-rate      "\"lawngreen\""
;    :maturity-date      "\"goldenrod\""
;    :yield              "\"slategrey\""
;    :price              "\"turquoise\""
;    :other              "\"red\""
;    :maturity-year      "\"black\""
;    :maturity-month-day "\"magenta\""
;    })
;
; (defn nil->0 [d] (if (nil? d) 0 d))
;
;
; (defn keys->rectangles [component-keys]
;   ;(debug (ps component-keys))
;   (clojure.string/join "\n"
;                        (map (fn [[p y1 y2]]
;                               (str "<rect   x=\"1.0\""
;                                    "  y=\"" y1 "\""
;                                    "  width=\"999.0\""
;                                    "  height=\"" (- y2 y1) "\""
;                                    " style=\"fill:blue;stroke:pink;stroke-width:1;fill-opacity:0.1;stroke-opacity:0.9\"/>"))
;                             component-keys)))
;
;
;
;
;
; (defn points->svg [points]
;   (clojure.string/join "\n"
;                        (map (fn [[x y p t]]
;                               (str "<ellipse cx=\"" (float x) "\" "
;                                    "cy=\"" (float y) "\" "
;                                    " rx=\"5\"  ry= \"1\" stroke=" (get type->color t "\"black\"") " stroke-width=\"1\" fill=" (get type->color t "\"black\"") "/>")) points)))
;
;
;
;
;
; (defn lines->svg [lines color]
;   ;(debug (ps lines))
;   (clojure.string/join "\n"
;                        (map (fn [[[x1 y1 p1 t1] [x2 y2 p2 t2]]]
;                               (str "<line   x1=\"" (float (nil->0 x1)) "\""
;                                    "  y1=\"" (float (nil->0 y1)) "\""
;                                    "  x2=\"" (float (nil->0 x2)) "\""
;                                    "  y2=\"" (float (nil->0 y2)) "\""
;                                    " style=\"stroke:" color ";stroke-width:0.1\" />")) lines)))
;
;
;
; (defn grid-x-lines []
;   (take 10 (for [x (range 10) :while (< x 11)] [[(* x 100) 0 0 0] [(* x 100) 1000 0 0]])))
;
; (defn grid-y-lines []
;   (take 10 (for [y (range 10) :while (< y 11)] [[0 (* y 100) 0 0] [1000 (* y 100) 0 0]])))
;
; (defn grid-lines []
;   (str
;     (lines->svg (grid-x-lines) "rgb(120,120,255)")
;     "\n"
;     (lines->svg (grid-y-lines) "rgb(120,120,255)")
;     ))
;
;
; (defn view-data [md5 points lines the-keys]
;   (let [
;         doc (str doc-open
;                  "\n"
;                  (grid-lines)
;                  "\n"
;                  (keys->rectangles the-keys)
;                  "\n"
;                  "\n"
;                  (lines->svg lines "rgb(0,0,255)")
;                  "\n"
;                  (points->svg points)
;                  "\n"
;                  doc-close)]
;     (spit (str "d:\\" md5 ".html") doc))
;   (b/browse-url (str "file:///D:/" md5 ".html")))
;
; (defn on-page? [page-number doc]
;   (= page-number (id->page (first (flatten (doc :ids))))))
;
; (defn ->point [field-doc]
;   (vec (concat ((juxt :min-x :min-y) (:coords field-doc)) [(id->page (first (flatten (field-doc :ids)))) (get field-doc :class :cusip)])))
;
; ;(defn candidates->points)
;
; (defn cusip-doc->lines [cusip-doc]
;   (let [source (->point (:cusip-3 cusip-doc))
;         cusips-gone (dissoc cusip-doc :cusip-3 :cusip-6 :cusip-9)
;         other-points (map (fn [[k v]] (->point v)) cusips-gone)]
;     (map (fn [target] [source target]) other-points)))

; (defn view-doc [md5 page]
;   (let [omni-doc (jp/query->omni-data {:md5 md5})
;         [doc candidates] (link-candidates-to-cusips omni-doc)
;         components (filter (comp #{page} :page-number) (:mind-food omni-doc))
;         ;_ (debug (ps (map make-key components))
;         the-keys (merge-keys (map make-key components))
;         _ (debug (ps the-keys))
;         points (map ->point (filter (partial on-page? page) candidates))
;         lines (mapcat cusip-doc->lines (vals doc))
;         lines (filter (fn [[[x1 y1 p1 t1] p2]] (#{page} p1)) (mapcat cusip-doc->lines (vals doc)))
;         ]
;     (view-data md5 points lines the-keys)
;     (b/browse-url (str "http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/overmind/original/?md5=" (:md5 omni-doc)))
;     (assoc omni-doc :cusip-docs doc)))

;***********************************All this is very nice, but too complicated.



;(defn point-within-segment [[x y] [[x1 y1] [x2 y2]]]
;  ;(clojure.pprint/pprint [[x y] [[x1 y1] [x2 y2]]])
;  (and (between x (sort [x1 x2]))
;       (between y (sort [y1 y2]))))

;(defn segment-cross [[[x1 y1 t1] [x2 y2 t2]] [[x3 y3 t3] [x4 y4 t4]]]
;  (let [d (- (* (- x1 x2) (- y3 y4)) (* (- y1 y2) (- x3 x4)))]
;    (if (zero? d)
;      false
;      (let [n1 (- (*
;                    (- (* x1 y2) (* y1 x2))
;                    (- x3 x4))
;                  (*
;                    (- x1 x2)
;                    (- (* x3 y4) (* y3 x4))))
;            n2 (- (*
;                    (- (* x1 y2) (* y1 x2))
;                    (- y3 y4))
;                  (*
;                    (- y1 y2)
;                    (- (* x3 y4) (* y3 x4))))
;            px (/ n1 d)
;            py (/ n2 d)]
;        ;(clojure.pprint/pprint [n1 n2 px py d])
;        (and (point-within-segment [px py] [[x1 y1] [x2 y2]])
;             (point-within-segment [px py] [[x3 y3] [x4 y4]]))))))
;
;
;(defn cross-any? [line lines]
;  (some (partial segment-cross) lines))
;
;(defn create-link-data-set [how-many flag step]
;  (let [x-base (rand-int 1000)
;        y-base (rand-int 1000)
;        ;spread (+ (rand-int 500) 20)
;        between step                                        ;(/ spread how-many)
;        ]
;    (map (fn [i] [x-base (+ y-base (* i between)) flag]) (range how-many))))
;
;(defn create-noise-data-set [how-many flag]
;  (map (fn [i] [(rand-int 1000) (rand-int 1000) flag]) (range how-many)))

;
;
(comment
  (defn find-problems [scored-tagged]
    (->> scored-tagged
         (remove (comp #{0 1 2} last first)) ;documents which don't fit the model
         (remove (fn [[[a b c d e] m]] (= a b (* 3 e)))) ;drop 'good' documents
         (remove (comp #{0} second first ))
         (sort-by (fn [[[a b c d e] m]] [(/ a b) e])) ;sort the rest
         ))

  (def july (seq (into #{} (map :md5 (edn/read-string (slurp "C:\\code\\soda_fountain\\overmind\\src\\main\\resources\\controls\\july-msrb.edn"))))))
  (def zilla (seq (into #{} (map :md5 (edn/read-string (slurp "C:\\code\\soda_fountain\\overmind\\src\\main\\resources\\controls\\monstrous-msrb.edn"))))))
  (def cusip-docs (map (fn [d] (select-keys d [:cusip-3])) (get-in omni-doc [:candidates :cusips])))
  (def candidates (dissoc (:candidates omni-doc) :cusips))
  ;m (zipmap (map (comp :value :cusip-9) cusip-docs) cusip-docs)
  (def ids->coords (elg/create-ids->geometries-map (elg/create-geometry-maps (:enhanced-hickory omni-doc))))
  (def ids->muni-geom (partial elg/add-muni-doc-geom ids->coords))
  (def ids->geom (partial elg/add-jaeger-doc-geom ids->coords))
  (def s (map cusip->point-form (elg/create-muni-security-nodes cusip-docs ids->muni-geom)))
  (def c (elg/create-solution-nodes candidates ids->geom))
  ;now this part is a bit tricky.   We need to
  ;group the cusips by component, then only link to other items in the components.
  ;seperate out the cussips by page.
  ;then for each page, group by components
  (def sources (by-page-comp (:mind-food omni-doc) s))
  )
