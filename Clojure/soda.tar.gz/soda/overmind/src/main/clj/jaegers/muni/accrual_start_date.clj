(ns jaegers.muni.accrual-start-date
  (:require [plumbing.core :refer [defnk]]
            [soda-common.parsers :as parsers]
            [soda-common.regexes :as regexes]
            [clojure.pprint :refer [pprint]]
            [utils.mind-food :as utils.mind-food]))

(def link-examples ["Interest Accrues: Date of Initial Delivery"
                    "Interest with respect to the Certificates accrues from their date of delivery"
                    "(Interest accrues from date of delivery)"
                    "Interest Accrues from Date of Delivery"
                    "Interest Accrues: Delivery Date"
                    "(Interest accrues from the Delivery Date (hereinafter defined))"
                    "Interest on the Certificates will accrue from the Delivery Date"
                    "Interest on the $57,225,000 City of Bryan, Texas Electric System Revenue Refunding Bonds, New Series 2017 (the “Bonds”) will accrue from the date of the initial delivery of the Bonds"])

(def found-examples ["Interest Accrues: August 1, 2017 (the “2017 Conversion Date”)"
                     "Interest Accrual Date: June 1, 2017 (Conversion Date)"
                     "Term Rate Conversion Date: August 15, 2017 (Interest accrues from the Term Rate Conversion Date)"
                     "Interest accrues from August 1, 2017"
                     "Interest accrues from: October 1, 2017"
                     "Interest accrues from October 1, 2017, and is payable March 1, 2018, and on each September 1 and March 1 thereafter"])

(def accrual-date-re (re-pattern (str "(?i)(interest accru(e|es|al)|term rate conversion date).{0,10}(" regexes/date-like ")")))

(defn create-jaeger [[text mf-vals]]
  (when-let [date (:date (parsers/parse (first (re-find regexes/date-like text))))]
    {:text   text
     :value  date
     :jaeger :accrual-start-date
     :ids    [(map :id mf-vals)]}))

(defn find-accrual-date [mind-food]
  (some->
    (utils.mind-food/find-in-mindfood accrual-date-re mind-food)
    first
    :matches
    first
    create-jaeger))

(def accrual-link-re #"(?i)accru(e|es|al).{0,10}(date|delivery).{0,10}(date|delivery)")

(defn find-accrual-link [mind-food]
  (not-empty (utils.mind-food/find-in-mindfood accrual-link-re mind-food)))

(defnk accrual-start-date* [mind-food date-of-delivery* msrb]
  (let [issue-closing-dates (map :issue-closing-date (vals msrb))
        found-date (find-accrual-date mind-food)
        found-link (find-accrual-link mind-food)]
    (zipmap
      (keys date-of-delivery*)
      (map
        (comp
          #(assoc % :class :accrual-start-date)
          (fn [icd dod]
            (cond
              found-link (or dod icd)
              found-date found-date
              :else (or icd dod))))
        issue-closing-dates
        (vals date-of-delivery*)))))
