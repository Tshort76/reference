(ns jaegers.md5-control-sets
  (:require [clojure.java.io :as io]
            [clojure.edn :as edn]
            [medley.core :refer [map-vals]]
            [soda.control-sets :as cs]))

;; For details about each control set, see:
;; https://confluence.arbfund.com/display/DEV/Edgar+Control+Sets

(defn load-resource [file-name]
  (-> (str "controls/" file-name) io/resource slurp edn/read-string))

(def control-sets (map-vals (comp load-resource :file) cs/control-sets))

(defn set->file-type [control-set-name]
  (cond
    (#{:minuscule-msrb :monstrous-msrb :july-msrb :insurers-msrb :muni-floater-72 :msrb-sample :msrb-2016-6 :msrb-2009-2015-backfill} (keyword control-set-name))
    :muni-jaeger

    (#{:edgar-abs-hundo :edgar-fall-floaties :edgar-floaters :edgar-floating-corps :edgar-fwp-500
       :edgar-multi-hundo :edgar-multi-issue-80 :edgar-scsf-393 :edgar-scsf-393-test
       :edgar-tiny-2 :edgar-triumphant-2900 :edgar-two-week-fixed
       :edgar-winter-2weeks :edgar-multi-1600 :edgar-multi-600
       :edgar-crt-multi-50 :edgar-crt-single-50 :edgar-put-date
       :edgar-multi-1000 :edgar-multi-1000-full :edgar-winter-78 :edgar-cusipless-fun
       :edgar-jan-2018 :edgar-feb-2018 :edgar-mar-2018} (keyword control-set-name))
    :edgar-prospectus

    (#{:edgar-single-equity-10ks :edgar-easy-equities-800 :elaborate-equity-300 :edgar-equity-multi-300} (keyword control-set-name))
    :edgar-equity))
