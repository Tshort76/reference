(ns jaegers.edgar.prospectus.perpetual
  (:require [clojure.spec.alpha :as s]
            [jaegers.mind-food-utils :as mfu]
            [jaegers.regisector :as rs]
            [plumbing.core :refer [defnk]]
            [tokenvec.core :as tv]
            [taoensso.timbre :as timbre]))


(def indicators
  #"((?i)(is|are) perpetual|no fixed maturity|Maturity Date: None|(does not|doesn't) have (any|a) maturity date)")
(def secondary-indicators                                   ;this is to see if I missed any with the previous regex
  #"((?i)perpetual|perpetuity)")
(def table-regex
  #"((?i)maturity date:|maturity:)")
(defn thin-ids [token] [(->> (map (fn [x] (:id x)) (second token))
                             (into #{}) sort (remove nil?) (into []))])

(defn filter-table [cell]
  (let [result (re-find secondary-indicators (first cell))]
    (if result [(first result) (second cell)])))


(defn tokenvec->matches
  [[sentence tokenvec] regex]
  (let [matches (rs/dissect sentence [{:regex regex :handler (fn [[_ & v]] {:value v})}])]
    (map (fn [{:keys [value indexes]}]
           {:value (first value)
            :id    [(mapv :id (tv/unique-tokens tokenvec indexes))]})
         matches)))

(defn search-doc [enhick]
  (->> enhick
          mfu/enhik->sentence-tokenvecs
          (mapcat #(tokenvec->matches % indicators))))
;for improvement
;think about id->loc then going one right?
(defn find-in-row [enhik]
  (some->> enhik
           mfu/enhik->sentence-tokenvecs
           (#(loop [[[sentence ids] & next] %]
               (if (and sentence (re-find table-regex sentence)) next (if next (recur next)))))
           first
           (#(if (not (re-find indicators (first %))) %)) ;in the case we have a sentence indicator we ignore it.
           filter-table                                   ;in the case it's not 'perpetual' or the like
           (#(hash-map :value (first %) :id (thin-ids %)))
           list
           ))

(defn build-perpetual [enhick]
  (let [sentence-indicators (search-doc enhick)
        table-indicators (find-in-row enhick)
        all-indicators (concat table-indicators sentence-indicators)]
    (when-not (empty? all-indicators)
      {:jaegers             ::perpetual
       :value               true
       :class         :perpetual
       :indicator           (first all-indicators)
       :secondary-indicator table-indicators
       :id                  (:id (first all-indicators))})))

(defnk perpetual* [enhanced-hickory cusips]
  (zipmap cusips (repeat (build-perpetual enhanced-hickory))))

(comment
  (def sample-docs (map filename->security-docs ["0000950103-15-002079.txt",
                                                 "0001193125-14-340903.txt",
                                                 "0000950103-09-002090.txt",
                                                 "0001193125-13-443690.txt",
                                                 "0000950103-14-002361.txt",
                                                 "0001193125-14-233003.txt",
                                                 "0001193125-14-419341.txt",
                                                 "0001193125-16-431104.txt",
                                                 "0001193125-16-684227.txt"
                                                 ]))
  (map #(map :cusip  %) sample-docs))


#_(def are-perpetual (map second [["1015780", "0001193125-16-683249.txt"], ["1039765", "0001193125-15-125270.txt"], ["1039765", "0001193125-15-127429.txt"], ["1039765", "0001193125-15-129150.txt"], ["1089113", "0001193125-14-338138.txt"], ["1089113", "0001193125-14-338143.txt"], ["1089113", "0001193125-15-101869.txt"], ["1089113", "0001193125-16-600793.txt"], ["1089113", "0001193125-17-171034.txt"], ["109380", "0001193125-13-323926.txt"], ["109380", "0001193125-13-327112.txt"], ["109380", "0001193125-13-327577.txt"], ["1099219", "0001193125-15-202299.txt"], ["1159508", "0000903423-14-000613.txt"], ["1159508", "0001193125-14-419341.txt"], ["1160106", "0000950103-14-002361.txt"], ["1390777", "0001193125-13-214624.txt"], ["1390777", "0001193125-15-144779.txt"], ["1390777", "0001193125-16-656760.txt"], ["19617", "0000019617-08-000276.txt"], ["19617", "0000019617-08-000278.txt"], ["19617", "0001193125-13-298090.txt"], ["19617", "0001193125-14-011523.txt"], ["19617", "0001193125-14-223507.txt"], ["312069", "0001193125-13-441757.txt"], ["312069", "0001193125-13-443690.txt"], ["312069", "0001193125-14-233003.txt"], ["312069", "0001193125-14-331485.txt"], ["316709", "0001193125-12-020665.txt"], ["316709", "0001193125-16-745475.txt"], ["35527", "0001193125-13-216914.txt"], ["35527", "0001193125-14-222811.txt"], ["36104", "0001104659-15-079360.txt"], ["36104", "0001104659-17-006173.txt"], ["36270", "0001193125-14-039132.txt"], ["36270", "0001193125-16-746759.txt"], ["4962", "0001104659-15-013901.txt"], ["70858", "0000950144-08-000388.txt"], ["70858", "0000950144-08-003154.txt"], ["70858", "0001193125-13-229911.txt"], ["70858", "0001193125-14-234874.txt"], ["70858", "0001193125-14-329346.txt"], ["70858", "0001193125-14-376541.txt"], ["70858", "0001193125-15-089560.txt"], ["70858", "0001193125-16-495450.txt"], ["713676", "0001193125-16-749811.txt"], ["750556", "0001193125-14-396529.txt"], ["750556", "0001193125-17-144508.txt"], ["831001", "0000950123-08-004438.txt"], ["831001", "0001193125-12-430919.txt"], ["831001", "0001193125-12-495067.txt"], ["831001", "0001193125-13-169027.txt"], ["831001", "0001193125-15-092432.txt"], ["831001", "0001193125-15-139608.txt"], ["831001", "0001193125-15-279954.txt"], ["831001", "0001193125-15-369264.txt"], ["831001", "0001193125-16-545695.txt"], ["844150", "0000950103-15-006288.txt"], ["844150", "0000950103-15-006342.txt"], ["844150", "0000950103-16-015488.txt"], ["844150", "0000950103-16-015506.txt"], ["895421", "0000905148-14-000380.txt"], ["895421", "0000905148-15-000393.txt"], ["895421", "0000950103-15-002079.txt"], ["91576", "0001193125-16-702189.txt"], ["927628", "0001193125-15-182627.txt"], ["93751", "0001193125-15-189229.txt"]]))


;;;;;;;;;;;;;;;known bugs;;;;;;;;;;;;;;;
;1) if we find 'maturity:' in a table it might not go to the cell to the right
;     in the case that the html is rows within columns
;2) not really a bug, but I'm thinking we should not return false when
;     no indicator is found.
