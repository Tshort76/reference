(ns jaegers.muni.guarantor
  (:require [clojure.string :as str]
            [clojure.set :as set]
            [plumbing.core :refer [defnk]]
            [simple-mind.naive-bayes.core :refer [->bag-of-words]]
            [simple-mind.naive-bayes.normalize :refer :all]
            [clojure.java.io :as io]
            [medley.core :refer [map-keys map-vals]]
            [ml.classifiers :as mlc]
            [clojure.edn :as edn]))

(def load-resource (comp edn/read-string slurp io/resource))

(def features-and-classes
  (memoize (fn [] (load-resource "jaegers/muni/guarantor/features_and_classes.edn"))))

(def ->classifier
  (partial mlc/classify-ensemble
           (load-resource "jaegers/muni/guarantor/muni_guarantor_random_forest.edn")))

(def normalize
  (comp
    norm-empty
    norm-chars
    norm-numbers
    norm-money
    norm-percents
    norm-cusip9s
    norm-months
    norm-years
    norm-stopwords
    norm-case))

(defn mind-food->words
  ([mf] (mind-food->words mf 1))
  ([mf min-page] (mind-food->words mf min-page (apply max (map :page-number mf))))
  ([mf min-page max-page]
   (->> mf
        (filter #(<= min-page (:page-number %) max-page))
        (map :vals)
        flatten
        (map :text))))

(defn words->sparse-feature-map [words]
  (let [features (:features (features-and-classes))
        n (->> (keys features)
               (map (comp count #(str/split % #" ")))
               (apply max)
               inc)]
    (->> (range 1 n)
         (map #(->bag-of-words words :normalize-fn normalize :n %))
         (apply merge)
         (#(select-keys % (vals features))))))

(defn sparse-feature-map->full-feature-map [sfm]
  (merge (reduce #(assoc %1 %2 0) {} (vals (:features (features-and-classes)))) sfm))

(defnk guarantor* [mind-food cusips*]
  (let [guarantor (some-> mind-food
                          (mind-food->words 1 15)
                          words->sparse-feature-map
                          sparse-feature-map->full-feature-map
                          ->classifier
                          (#(get (set/map-invert (:classes (features-and-classes))) (:class %) "none"))
                          (#(assoc {:jaeger :guarantor
                                    :class  :guarantor} :value %)))]
    (zipmap (keys cusips*) (repeat guarantor))))
