(ns jaegers.edgar.equity.header-scraper
  (:require [clojure.string :as str]
            [jaegers.jaeger-primer :as jp]
            [jaegers.edgar.equity.exchange-mapping :as ex-map]
            [medley.core :as med]))

(defn clean-html-text [text]
  (-> text
      (str/replace #"<[^>]+>" "")
      (str/replace #"&#?\w+;" " ")
      (str/replace #"[\s\n\r]+" " ")
      str/trim))


(defn format-raw-text [raw-text]
  (->> (str/split raw-text #"(?i)</?(?:p|div|table|hr|h\d|br|td|th)(?:\s[^>]+)?>")
       (map clean-html-text)
       (remove (partial = ""))))

(defn text->share-class [text]
  (or (second (re-find #"(?i)\b12\([bg]\).* Act:? ?(.*)" text))
      text))

(defn merge-types [types]
  (map (fn [type
            {class :share-class c-line :lines}
            {pval :par-value p-line :lines}
            {exch :exchange mic :mic coi :country-of-issue x-line :lines x-code :exchange-code}]
         (-> (med/assoc-some type
                             :share-class class
                             :par-value pval
                             :exchange exch
                             :mic mic
                             :country-of-issue coi
                             :exchange-code x-code)
             (update :lines into (concat c-line p-line x-line))
             (update :lines distinct)))
       (filter :stock-type types)
       (concat (filter :share-class types) (repeat nil))
       (concat (filter :par-value types) (repeat nil))
       (concat (filter :exchange types) (repeat nil))))

; (defn merge-securities [securities]
;   (->> securities
;        (group-by (juxt :stock-type :share-class :par-value :exchange))
;        vals
;        (mapv (partial reduce (fn [a b] (update a :lines into (:lines b)))))))

(defn >subset? [a b] ;; is "b" a subset of "a"?
  (let [fields [:stock-type :share-class :par-value :exchange]]
    (and (not (= (mapv a fields) (mapv b fields)))
         (every? (fn [k] (let [sub-a (get a k)
                               sub-b (get b k)]
                           (or (= sub-a sub-b)
                               (nil? sub-b))))
                 fields))))

(defn distinct-securities [securities]
  (->> securities
       (med/dedupe-by (juxt :stock-type :share-class :par-value :exchange))
       (remove (fn [sec] (some #(>subset? % sec) securities)))))

(defn filter-securities [securities]
  (filter (fn [sec] (#{"Common" "Capital"} (:stock-type sec)))
          securities))


(defn parse-stock-type [line]
  (if-let [[_ warrant right unit]
           (re-find #"(?i)(warrant)|(right)|(unit)" line)]
    (cond
      warrant "Warrant"
      right "Right"
      unit "Unit")
    (let [[_ com cap pref lp gp note]
          (re-find #"(?i)(?:(common)|(capital)|(preferred)) (?:stock|share)|(?:(limited)|(general)) partner|(notes)" line)]
      (cond
        com "Common"
        cap "Capital"
        pref "Preferred"
        lp "Limited Partership"
        gp "General Partnership"
        note "Bond"))))

(defn parse-par-value [line]
  (when-let [par (second (or (re-find #"(?i)par value \$?(\d*\.\d+|\d+)" line)
                             (re-find #"(?i)\$?(\d*\.\d+|\d+) par value" line)))]
    (Double/parseDouble par)))

(defn parse-exchange [line]
  (some-> line
          (str/replace #"(?i)name of( each)? exchange(?: on which registered)?|exchange? on which registered|none.?" "")
          ex-map/exchange->mic))

(defn parse-share-class [s]
  (or (second (re-find #"(?:[Cc]lass|CLASS) ([A-Z](?:-\d)?)\b" s))
      (when (re-find #"(?i)Common Stock" s) "N/A")))

(defn line->type [line]
  (let [{:keys [mic exchange-name score orig iso-country-code exchange-code]}
        (parse-exchange line)]
    (med/assoc-some {:lines [line]}
                    :share-class (parse-share-class line)
                    :stock-type (parse-stock-type line)
                    :par-value (parse-par-value line)
                    :exchange exchange-name
                    :mic mic
                    :country-of-issue iso-country-code
                    :exchange-code exchange-code)))
                    ; :exchange-lookup-score score
                    ; :exchange-lookup orig)))

(defn not-re-fn [regex]
  (complement (partial re-find regex)))

(defn find-10k-security-sections [texts]
  (->> texts
       (drop-while (not-re-fn #"\b12\([bg]\)"))
       (take-while (not-re-fn #"(?i)indicate|check"))))

(defn veq [s]
  (when (seq s)
    (vec s)))

(defn parse-security-sections [sections]
  (->> sections
       (map text->share-class)
       (remove (partial re-matches #"\s*"))
       (mapv line->type)
       merge-types
       filter-securities
       distinct-securities))
       ; merge-securities)) ;; this is to fix the issue when one security is listed in both the 12(b) and the 12(g)

(defn find-10k-header-info [raw-text]
  (when raw-text
    (->> (format-raw-text raw-text)
         find-10k-security-sections
         parse-security-sections
         veq)))


(defn find-15-12-security-sections [texts]
  (->> texts
       (drop-while (not-re-fn #"(?i)registrant.s principal executive offices"))
       (take-while (not-re-fn #"(?i)Titles? of all other classes of securities"))))

(defn find-15-12-header-info [raw-text]
  (when raw-text
    (->> (format-raw-text raw-text)
         find-15-12-security-sections
         parse-security-sections
         veq)))


(defn md5->raw [md5]
  (-> (jp/query->omni-data {:md5 (:md5 md5 md5)})
      :raw
      :ten-k))

(defn md5->titles [md5]
  (find-10k-header-info (md5->raw md5)))


;; TODO:
;; filter out warrants, rights, and units
;; e.g. http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/overmind/food/raw?md5=7f331267e324a29686f823a6ca1af29e

;; one line -> two securities
;; e.g. http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/overmind/food/raw?md5=3408dde80e89d6a6c3b1296e1803ed68


;; repl code

; (require '[jaegers.edgar.equity.header-scraper :as h]'[datasources.core :as ds]'[monger.collection :as mc]'[jaegers.edgar.equity.exchange-info :as ex]'[clojure.stacktrace :as st] :reload)
; (def md5s (->> (mc/find-maps (ds/get-db "soda-raw") "files-meta" {:file-type "edgar-10k"} [:md5]) vec))
; (defn md5->url [md5] (str "http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/overmind/food/raw?md5=" (:md5 md5 md5)))
; (defn write-sample [x] (mc/insert (ds/get-db "equity") "test_5" x))
;
; (->> md5s
;      (map-indexed vector)
;      (run! (fn [[i {md5 :md5}]]
;              (println i "-" md5)
;              (write-sample (try
;                              (let [[x h] ((juxt ex/find-exchange-info h/find-10k-header-info)
;                                           (h/md5->raw md5))
;                                    match (ex/match-info x h)]
;                                (cond-> {:md5 md5}
;                                        x (assoc :exchange-count (count x)
;                                                 :exchange x)
;                                        h (assoc :header-count (count h)
;                                                 :header h)
;                                        (seq match) (assoc :match-count (count match)
;                                                           :match match)))
;                              (catch Exception e
;                                {:md5 md5
;                                 :error (with-out-str (st/print-throwable e))}))))))

; (try (let [md5 "a72b428690bb842332c089cb0a26432c" raw (h/md5->raw md5) x (ex/find-exchange-info raw) h (h/find-header-info raw)] {:exchange (seq x) :header (seq h) :match (ex/match-info x h)}) (catch Exception e {:error (with-out-str (st/print-throwable e))}))

;; TODO!!
;; no exchange header data:
; http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/overmind/food/raw?md5=a568cfb186e8ea77f4f2f0fb5010b814
; http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/overmind/food/raw?md5=8697d89da1675532509093ccedf45b47

 ;; "thinly traded"
; http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/overmind/food/raw?md5=3c57a868f20a774e92d7922430ad2443

;;  	Over the Counter Bulletin Board
; http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/overmind/food/raw?md5=de448d987f565abe3885c1c7e761fd18
