(ns jaegers.hickory-utils
  (:require
    [clojure.core.reducers :as r]
    [clojure.string :as string]
    [clojure.walk :as walk]
    [clojure.zip :as zip]
    [hickory.select :as hs]
    [hickory.zip :as hz]
    ; [medley.core :refer [map-keys map-vals]]
    [taoensso.tufte :refer [defnp]]
    ; [jaegers.mind-food-utils :as mfu]
    [jaegers.utils :as ju]
    [soda.core :refer [into!] :as soda]
    [html.utils :as hu]
    [enhanced-hickory.spec]))

(def block-level-tags
  #{:address :blockquote :dd :div :dl :fieldset :form :h1 :h2 :h3 :h4 :h5
    :li :main :nav :noscript :ol :p :pre :table :tfoot :ul
    ; pseudo-block-level tags
    :body :document :html :page :tbody :td :th :thead :tr})

(defnp block-level? [loc] (some-> loc zip/node :tag block-level-tags))

; (defnp cond-count-until
;   "Like hickory.select/count-until, but only increments count when cpred is true."
;   [f val pred cpred]
;   (loop [next-val val cnt 0]
;     (if (pred next-val)
;       cnt
;       (recur (f next-val) (cond-> cnt (cpred next-val) inc)))))

(defnp text
  "Returns all text content in the subtree rooted at the given hickory node"
  [hik]
  (flatten (walk/postwalk (fn [x] (cond-> x (map? x) (:content x))) hik)))

; (defnp ids
;   "Returns all ids in the subtree rooted at the given hickory node"
;   ([hik] (flatten (ids hik [])))
;   ([hik ids-ret]
;    (if (map? hik)
;      (if (:token? hik)
;        (get-in hik [:attrs :id])
;        (into ids-ret (ids (:content hik) ids-ret)))
;      (into ids-ret (map #(ids % ids-ret) hik)))))

(defnp text->words [texts]
  (->> texts
       (r/remove nil?)
       (r/mapcat #(string/split % #"[\t\n\p{Z}]"))
       (r/remove empty?)
       r/foldcat))

(def tr? (hs/tag :tr))
(def td? (hs/tag :td))
(def table? (hs/tag :table))
(def body-child? (hs/child (hs/tag :body) hs/any))

; (defn id->node
;   "Gets the hickory element with the given id by direct lookup"
;   [enhik id]
;   (get-in enhik (into [:content 0 :content] (interpose :content (ju/id->vec id)))))

(defn id->loc
  "Gets the zip-loc of the element with the given id by direct navigation"
  [enhik id]
  (let [body (zip/down (hz/hickory-zip enhik))
        step (fn [loc x] (some->> loc zip/down (iterate zip/right) (take (inc x)) last))]
    (reduce step body (ju/id->vec id))))

(defn id->row-id
  "Returns the row id of the element given by id"
  [enhik id]
  (let [loc (id->loc enhik id)
        row (hs/select-next-loc tr? loc zip/up (some-fn nil? table?))]
    (some-> row zip/node :attrs :id)))

(defn id->col-id
  "Returns the column id of the element given by id"
  [enhik id]
  (let [loc (id->loc enhik id)
        td (hs/select-next-loc td? loc zip/up (some-fn nil? table?))
        coln (hs/count-until #(hs/left-pred % td?) td nil?)
        tab (hs/select-next-loc table? loc zip/up nil?)
        col (when tab (hs/select-next-loc (hs/nth-of-type 0 coln :td) tab))]
    (some-> col zip/node :attrs :id)))

; (defnp tag-parent
;   "Returns a selector that returns true when the zip-loc given as the argument
;    has the given tag and some descendant node of the loc has the given id."
;   [tag id]
;   (hs/and
;     (hs/tag tag)
;     (hs/has-descendant (hs/id id))))

; (defnp block-level-parent
;   "Returns a selector that returns true when the zip-loc given as the argument is
;    a block-level element and some descendant node of the loc has the given id."
;   [id]
;   (hs/and
;     (apply hs/or (map hs/tag block-level-tags))
;     (hs/has-descendant (hs/id id))))

; (defnp top-parent [top-tag loc]
;   (let [pred (hs/child (hs/tag top-tag) hs/any)]
;     (or (pred loc) (hs/up-pred loc pred))))

(defnp parent-pred [pred loc]
  (hs/select-next-loc pred loc zip/up (some-fn nil? zip/end?)))

(defnp words-pred
  [end-pred next-fn loc]
  (loop [loc loc strs (transient [])]
    (let [s (some-> loc zip/node text)]
      (if (end-pred loc)
        (->> strs persistent! text->words)
        (recur (next-fn loc) (into! strs s))))))

; (defnp words-in-block [loc]
;   (let [block (cond-> loc ((complement block-level?) loc) (hs/up-pred block-level?))]
;     (some-> block zip/node text text->words)))

; (defnp words-in-table [loc]
;   (let [table? (hs/tag :table)
;         table (cond-> loc ((complement table?) loc) (hs/up-pred table?))]
;     (some-> table zip/node text text->words)))

(defnp words-in-row-pred [start-td-fn next-fn loc]
  (let [td (cond-> loc ((complement td?) loc) (hs/up-pred td?))
        tr (cond-> loc ((complement tr?) loc) (hs/up-pred tr?))
        id (some-> td zip/node :attrs :id)
        start-td (when tr (hs/next-pred tr (hs/and (hs/tag :td) start-td-fn)))]
    (when (and id (not= td start-td))
      (words-pred (some-fn nil? (hs/id id)) #(next-fn % (hs/tag :td)) start-td))))

(def words-in-row-before (partial words-in-row-pred hs/first-child hs/right-pred))
; (def words-in-row-after  (partial words-in-row-pred hs/last-child hs/left-pred))

; (defnp words-in-row [loc]
;   (let [tr (cond-> loc ((complement tr?) loc) (hs/up-pred tr?))
;         td (when tr (hs/next-pred tr (hs/and (hs/tag :td) hs/first-child)))]
;     (words-pred nil? #(hs/right-pred % (hs/tag :td)) td)))

; (defnp words-in-col [loc]
;   (let [td (cond-> loc ((complement td?) loc) (hs/up-pred td?))
;         tab (some-> td (hs/up-pred (hs/tag :table)) zip/node)
;         coln (hs/count-until #(hs/left-pred % td?) td nil?)]
;     (->> tab
;          (hs/select (hs/nth-of-type 0 coln :td))
;          (mapcat text)
;          text->words)))

; (defnp content-in-col-pred [filter-fn loc]
;   (let [td (cond-> loc ((complement td?) loc) (hs/up-pred td?))
;         id (some-> td zip/node :attrs :id)
;         tab (when td (some-> loc (hs/prev-pred (hs/tag :table)) zip/node))
;         coln (hs/count-until #(hs/left-pred % td?) td nil?)]
;     (some->> tab
;              (hs/select (hs/nth-of-type 0 coln :td))
;              (split-with (comp not #{id} :id :attrs))
;              filter-fn
;              (map text))))

; (defnp words-in-col-pred [filter-fn loc]
;   (text->words (flatten (content-in-col-pred filter-fn loc))))

; (def words-in-col-above (partial words-in-col-pred (fn [[x _]] x)))
; (def words-in-col-below (partial words-in-col-pred (fn [[_ [_ & x]]] x)))
; (def content-in-col-above-inclusive (partial content-in-col-pred (fn [[a [x & _]]] (conj (vec a) x))))

; (defnp nearest-row-label-words [loc]
;   (let [td (cond-> loc ((complement td?) loc) (hs/up-pred td?))
;         leftmost (when td (hs/left-pred td hs/first-child))]
;     (some->> leftmost
;              content-in-col-above-inclusive
;              (filter seq)
;              last)))

; (def first-column? #(some? (hs/select-next-loc (hs/and (hs/tag :td) hs/first-child) % zip/up (some-fn nil? (hs/tag :table)))))
; (def first-row?    #(some? (hs/select-next-loc (hs/and (hs/tag :tr) hs/first-child) % zip/up (some-fn nil? (hs/tag :table)))))
; (def last-column?  #(some? (hs/select-next-loc (hs/and (hs/tag :td) hs/last-child) % zip/up (some-fn nil? (hs/tag :table)))))
; (def last-row?     #(some? (hs/select-next-loc (hs/and (hs/tag :tr) hs/last-child) % zip/up (some-fn nil? (hs/tag :table)))))

; (defnp row-count [loc]
;   (or (some-> (cond-> loc ((complement table?) loc) (hs/up-pred table?))
;               zip/node
;               (->> (hs/select-locs (hs/child (hs/tag :tr))))
;               count)
;       0))

; (defnp col-count [loc]
;   (or (some-> (cond-> loc ((complement table?) loc) (hs/up-pred table?))
;               zip/node
;               (->> (hs/select-locs (hs/child (hs/and (hs/tag :tr) hs/first-child) (hs/tag :td))))
;               count)
;       0))

(defnp alignment [attr-key style-key default allowed-vals loc]
  (letfn [(f [l]
            (let [attr-align (some->> l zip/node :attrs attr-key string/lower-case keyword)
                  style-align (some->> l zip/node :attrs :style (hu/get-style style-key) string/lower-case keyword)]
              (or style-align attr-align)))]
    (some allowed-vals [(f loc) (f (hs/up-pred loc f)) default])))

(def horiz-align-values #{:left :right :center :justify :initial :inherit})
(def vert-align-values  #{:baseline :sub :super :top :text-top :middle :bottom :text-bottom :initial :inherit})

(def horiz-alignment (partial alignment :align :text-align :left horiz-align-values))
(def vert-alignment (partial alignment :valign :vertical-align :baseline vert-align-values))

; (defnp has-attribute [attr-key style-key default allowed-vals loc]
;   (letfn [(f [l]
;             (letfn [(tag [ll] (some->> ll zip/node :tags (some #(= % attr-key)) (#(do % attr-key))))
;                     (attr [ll] (some->> ll zip/node :attrs attr-key string/lower-case keyword))
;                     (style [ll] (some->> ll zip/node :attrs :style (hu/get-style style-key) string/lower-case keyword))]
;               (let [p-attr (attr l)
;                     p-style (style l)
;                     p-tag (tag l)
;                     child-attr (first (map (comp attr hickory.zip/hickory-zip) (:content (first l))))
;                     child-tag (first (map (comp tag hickory.zip/hickory-zip) (:content (first l))))
;                     child-style (first (map (comp style hickory.zip/hickory-zip) (:content (first l))))]
;                 (or p-style p-attr child-attr child-style p-tag (if (= :b child-tag) :bold)))))]
;     (some allowed-vals [(f loc) (f (hs/up-pred loc f)) default])))

; (def bold-values #{:normal :bold :bolder :lighter :initial :inherit})
; (def underlined-values  #{:u})
; (def bold? (partial has-attribute :b :font-weight :normal bold-values))
; (def underlined? (partial has-attribute :u :none false underlined-values))

; TODO: this is very slow
; (defnp tag-depth [pred loc]
;   (cond-count-until zip/left loc pred block-level?))

; (def doc-tag-depth (comp inc (partial tag-depth hs/first-child) (partial top-parent :body)))
; (def page-tag-depth
;   (comp (partial tag-depth
;                  (some-fn nil?
;                           (hs/tag :page)
;                           (hs/attr :style #(hu/get-style :page-break-before %))
;                           (hs/attr :style #(hu/get-style :page-break-after %))))
;         (some-fn nil? (partial top-parent :page) (partial top-parent :body))))

; (defnp table-nest-depth [loc]
;   (cond-count-until zip/up loc (some-fn nil? (hs/tag :body)) (hs/tag :table)))

(def magnitude #(if (pos? %) (int (Math/log10 %)) 0))
(def precision #(or (some-> % (string/split #"[.]") second (string/replace #"[^0-9]" "") count) 0))
(def multiple-of? #(== 0 (mod %1 %2)))

; (defnp dissection->feature-map [d & [term-sfx]]
;   (->> d
;        (r/remove nil?)
;        (r/map (comp :value-type :features))
;        r/foldcat
;        frequencies
;        (map-keys #(keyword (str (name %) (or term-sfx ""))))))

; (defnp term-freqs
;   "Returns a feature map of the terms found by (word-fn loc)"
;   [word-fn term-sfx loc dissect-fn]
;   (-> loc
;       word-fn
;       (->> (string/join " "))
;       dissect-fn
;       (dissection->feature-map term-sfx)))

; (defnp terms-in-block [loc dissection m]
;   (let [w (string/join " " (words-in-block loc))
;         [tb [_ & ta]] (split-with (partial not= m) dissection)]
;     (merge (dissection->feature-map tb "-terms-before")
;            (dissection->feature-map ta "-terms-after"))))

; (def terms-in-row-before (partial term-freqs words-in-row-before "-terms-in-row-before"))
; (def terms-in-row-after  (partial term-freqs words-in-row-after "-terms-in-row-after"))
; (def terms-in-col-above  (partial term-freqs words-in-col-above "-terms-in-col-above"))
; (def terms-in-col-below  (partial term-freqs words-in-col-below "-terms-in-col-below"))
; (def terms-in-nearest-row-label
;   (partial term-freqs nearest-row-label-words "-terms-in-nearest-row-label"))
