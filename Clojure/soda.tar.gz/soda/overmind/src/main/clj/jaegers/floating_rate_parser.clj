(ns jaegers.floating-rate-parser
  (:require [clojure.string :as str]))

(def number-words
  {"one" 1, "two" 2, "three" 3, "four" 4, "five" 5,
   "six" 6, "seven" 7, "eight" 8, "nine" 9, "ten" 10,
   "eleven" 11, "twelve" 12})

(def libor-regex
  (re-pattern (str "(" (str/join "|" (apply concat number-words))
                   ")\\s*(?:-\\s*)?(month|year)")))

; count of and name of indexes in our data
;34 CMT - 1 Year - Monthly - 12 Month Moving Average - USD
;311 CMT - 1 Year - Monthly - USD
;313 CMT - 1 Year - USD
;290 CMT - 1 Year - Weekly - USD
;4 CMT - 10 Year - USD
;1 CMT - 2 Year - Monthly - USD
;1 CMT - 2 Year - Weekly - USD
;28 CMT - 3 Year - USD
;24 CMT - 3 Year - Weekly - USD
;3 CMT - 5 Year - USD
;2 CMT - 5 Year - Weekly - USD
;101 COFI - 11th District - Monthly - USD
;4 COFI - Federal - USD
;10 Federal Funds Effective Rate - Daily - USD
;1 Interest Rate Swap - 5 Year - USD
;693 Libor - 1 Month - USD
;1115 Libor - 1 Year - USD
;13 Libor - 3 Month - USD
;1 Libor - 6 Month - 15th Day Of Month - USD
;120 Libor - 6 Month - USD
;1 TBill - 3 Month - USD
;2 TBill - 6 Month - Auction Discount Rate - USD
;1 TBill - 6 Month - Auction Discount Rate - Weekly - USD
;1 TBill - 6 Month - Auction Investment Rate - USD


;; TODO: add more index names
(defn parse-index-name [text]
  (let [index (re-find #"libor|sifma|s&p|consumer price" text)]
    (case index
      "libor" (when-let [[_ num unit] (re-find libor-regex text)]
                (str "Libor - " (number-words num num)
                     " " (str/capitalize unit) " - USD"))
      "sifma" "SIFMA"
      nil)))

(defn blind-convert-to-bps [n]
  (cond
    (< n 0.01) (* n 10000) ;; probably a "normal" number
    (< n 10) (* n 100) ;; probably a percent
    :else n)) ;; probably already a bps

(defn convert-to-bps [n type-string]
  (case type-string
    "%" (* n 100)
    ;TODO: handle bps variants
    (blind-convert-to-bps n)))

(defn parse-spread [text]
  (when-let [[_ spread type] (re-find #"(?:plus|spread\s+of)\s+(\d+(?:\.\d+)?)\s*(%)?" text)]
    (-> spread
        Double/parseDouble
        (convert-to-bps type))))

;; #"(?<!plus|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w{0,6})(?<=^|\s)(\b\d{1,2}\b(?:\.\d+)?)\s*(%)?"
(defn parse-multiplier [text]
  (when-let [[_ mult type] (re-find #"(?<!plus|spread\s{1,3}of)(?:^|[(),\s]+)(\d{1,2}(?:\.\d+)?)\s*(%)?(?:\s|$)" text)]
    (-> mult
        Double/parseDouble
        ((if (= "%" type)
           #(/ % 100)
           identity)))))

(defn parse-floating-rate-text
  "Takes a string and returns a map with these fields:
  :index - a string with the (mostly) normalized index name
  :spread - a double representing the spread in basis-points
  :multiplier - a double representing the multiplier in factors"
  [raw-text]
  (when raw-text
    (let [text (str/lower-case raw-text)
          index (parse-index-name text)
          spread (parse-spread text)
          multiplier (parse-multiplier text)]
      (cond-> {}
              index (assoc :floating-rate-index index)
              spread (assoc :floating-rate-spread spread)
              multiplier (assoc :floating-rate-multiplier multiplier)))))
