(ns jaegers.conflicts)
  ; (:require [datasources.core :as ds]
  ;           [monger.collection :as mc]
  ;           [monger.util :as mu]
  ;           [soda.jobs.job-defs :as jdefs]
  ;           [soda.jobs.utils :as jutils]))

; (defn conflict-db [] (ds/get-db "soda-raw"))
; (def conflict-coll "jaegers")

; (defn get-next-conflict []
;   (-> (mc/find-and-modify
;        (conflict-db) conflict-coll
;        {:meta.conflict.status "conflict"
;         :meta.outdated? nil}
;        {:$inc {:meta.conflict.attempts 1}}
;        {:sort {:meta.conflict.attempts 1}})
;       (update :_id str)))

; (defn get-conflicts [& {:keys [cusip]}]
;   (when cusip
;     (->> {:meta.conflict.status "conflict"
;           :meta.outdated? nil
;           :jaeger-doc.cusip-9.value cusip}
;          (mc/find-maps
;           (conflict-db) conflict-coll)
;          (map #(update % :_id str)))))

; (defn count-conflicts []
;   (mc/count (conflict-db) conflict-coll
;             {:meta.conflict.status "conflict"
;              :meta.outdated? nil}))

; (defn resolve-conflict [{id :_id :as doc}]
;   (when (mc/update-by-id
;          (conflict-db) conflict-coll
;          (if (string? id) (mu/object-id id) id)
;          {:$set {:meta.conflict.status "resolved"
;                  :meta.outdates? true}})
;     (if-let [_id (:_id (mc/insert-and-return
;                         (conflict-db) conflict-coll
;                         (-> doc
;                             (dissoc :_id)
;                             (assoc-in [:meta :conflict :status] "resolved")
;                             (assoc-in [:meta :conflict :id] id))))]
;       (->> {:min-id _id :max-id _id}
;            jdefs/migrate-jaeger-docs
;            jutils/enqueue-job))))


(defn conflicted-fields? [field-doc]
  (->> field-doc vals (some :conflict)))

(defn conflicted-doc? [doc]
  (-> doc :meta :conflict :status (= "conflict")))

(defn add-conflict-meta [doc]
  (if (-> doc :jaeger-doc conflicted-fields?)
    (assoc-in doc [:meta :conflict :status] "conflict")
    doc))
