(ns jaegers.edgar.prospectus.call-option-schedule
  (:require [clojure.string :as cs]
            [edgar.table-utils :as tu]
            [clojure.instant :refer [read-instant-date]]
            [clj-time.coerce :as tc]
            [clj-time.core :as t]
            [soda-common.regexes :as re]
            [soda-common.parsers :as parsers]
            [plumbing.core :refer [defnk]]))

(def date-cruft-re #"(:? and thereafter)?")

(defn remove-date-cruft [text]
  (-> text
      (cs/replace date-cruft-re "")
      (cs/replace #"," "")))

(defn try-select-key
  "Selects the first truthy value from the map."
  [m ks]
  (first (keep m ks)))

(defn parse-and-format-candidates [cands]
  (not-empty
    (keep
      (fn [cand]
        (some->>
          (keep
            (fn [[date price]]
              (let [p-date (map #(try-select-key (parsers/parse %) [:date :integer])
                                (->> (-> (str re/date-like "|\\d{4}") re-pattern
                                         (re-seq (remove-date-cruft (:text date))))
                                     flatten distinct (remove nil?)))
                    p-price (map #(try-select-key (parsers/parse %) [:double :integer])
                                 (cs/split (:text price) #"\s?%\s?"))]
                (when (and date price)
                  (map
                    (fn [pdate pprice]
                      {:value [{:effective-date pdate :price pprice}]
                       :ids   [[(:id date) (:id price)]]})
                    p-date p-price))))
            cand)
          not-empty
          flatten
          (apply merge-with into)
          (array-map :call-option-schedule)))
      cands)))

(defn get-candidates [enhik]
  (not-empty
    (keep
      (fn [t]
        (not-empty (filter (fn [[{f :text} {s :text}]]
                             (and f s (< (count f) 100)
                                  (or (and (or (re-matches (re-pattern (str re/four-digit-year date-cruft-re)) f)
                                               (re-matches (re-pattern (str "(" re/date-like ")" date-cruft-re)) f))
                                           (re-matches re/percent-like s))
                                      (and
                                        (re-seq (re-pattern (str re/four-digit-year date-cruft-re)) f)
                                        (= (count (re-seq (re-pattern (str re/four-digit-year date-cruft-re)) f))
                                           (count (re-seq (re-pattern (str re/percent-like "%")) s))))))) t)))
      (keep (partial keep (comp not-empty (partial filter (comp not-empty :text)))) (tu/table-data enhik)))))

(def proto
  {:jaeger ::call-option-schedule
   :class :call-option-schedule
   :type :call-option-schedule})

(defn map-to-candidates [call-option-dates cusip {:keys [call-option-schedule]}]
  (when-let [cod (some-> (get-in call-option-dates [cusip :value]) tc/to-date-time)]
    (into
      proto
      {:value  (map (fn [{:keys [effective-date price]}]
                      {:effective-date (if (inst? effective-date)
                                         effective-date
                                         (tc/to-date (t/date-time effective-date (t/month cod) (t/day cod))))
                       :price          price})
                    (:value call-option-schedule))
       :ids    (:ids call-option-schedule)})))

(defn map-to-call-option-date [call-option-dates cusip]
  (when-let [cod (get-in call-option-dates [cusip :value])] ;do we have a call option date?
    (assoc proto :value  [{:effective-date cod :price 100}])))

(defn link-candidates [candidates cusips call-option-dates]
  (zipmap
    cusips
    (if (= (count candidates) (count cusips) (count (keys call-option-dates)))
      ;zipper the cusips with the call-option dates
      (map (partial map-to-candidates call-option-dates) cusips candidates)
      (map (partial map-to-call-option-date call-option-dates) cusips))))

(defnk call-option-schedule* [enhanced-hickory cusips call-option-date*]
  (when call-option-date*
    (-> enhanced-hickory get-candidates parse-and-format-candidates
        (link-candidates cusips call-option-date*))))

;(or (-> enhanced-hickory get-candidates parse-and-format-candidates)
;      (link-candidates cusip-docs call-option-dates*))
 ;     cusip-docs))

;Examples
;(def issue-description-sample {:md5 "b53e08b4ad95af4eaffd53daeee239c7"})
;(def crts-sample {:md5 "802e89ff57c9a75fced7b445b0248916"})
;(def find-simple-fixed-rates-sample {:md5 "f2b652a0b227a502d9bdf4eb0801fa26"}) ;note - is not fixed rate



;some md5s to use.
;"1832b51371123091398b3e8930feb57a"
;"b06cc00dbd23e0244c889084a1da0969"
;"b864422566e353bb6d878d8d80282efe"
;"779d74e9934c72c5057888cdce8f1d07"
;"454e975ae65f72950cd6fae081dbf9ae"
;"22b7c9b1c9903e31062a66290eecf2bd"
;"7e98e9a67ff1fc610a1ab2a0480fab8e"
;"8a1dcfded97f6be8874e2ba4c231ad08"
;"53cc97196c4231fc3c586b6a007ce4e3"
;"1f2e0099d3ec34bfedae458d72b74760"
;"989c318262536dde7c3cb4a123b80a3d"
;"c398e87bd352e6e53c2a14697fae8214"
;"fe2d4208405b296e1fe84f0f8bee6238"
;"300f225d8899d3e43a52799d3654ae8f"
;"5a9b6b2b0ddd201171bb57087cb6a9ad"
;
;

(comment
  (require '[jaegers.jaeger-primer :as primer])
  (def omni-data (primer/query->omni-data {:md5 "1832b51371123091398b3e8930feb57a"}))
  (require '[jaegers.md5-control-sets :as cset])
  (def control-set (cset/control-sets :edgar-multi-1000))
  (def cusips (partition 4 (cs/split (slurp (io/resource "edgar/call-option-schedule-cusips-with-data.csv")) #"[,\r\n]")))
  (filter #(= (first %) "14912HSX9") cusips)
  (def multi-cusips
    (clojure.set/intersection
      (set (map :cusip control-set))
      (set cusips)))
  (def filenames
    (distinct
      (map :filename
           (filter
             #(multi-cusips (:cusip %))
             control-set))))
  (def md5s
    (distinct
      (map :md5
           (filter
             #(multi-cusips (:cusip %))
             control-set))))

  )