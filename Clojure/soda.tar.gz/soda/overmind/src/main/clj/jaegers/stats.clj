(ns jaegers.stats
  (:require [clojure.pprint :refer [pprint]]
            [clojure.data :as data]
            [clojure.set :as set]
            [clojure.string :as str]
            [datasources.core :as ds]
            [jaegers.md5-control-sets :as cs]
            [jaegers.soda-pipe :as sp]
            [jaegers.oracle :as oracle]
            [medley.core :as med]
            [monger.collection :as mc]
            [util.date-time :as date]
            [soda.core :as basic]
            [clj-fuzzy.jaro-winkler :refer [jaro-winkler]])
  (:import (java.text DecimalFormat SimpleDateFormat)
           org.bson.types.ObjectId
           (java.util Date)))

(defn map-vals [f m]
  (zipmap (keys m)
          (map f (vals m))))

;; COMPARISON LOGIC ;;

(defn get-decimal-format [field]
  (DecimalFormat.
    ({:factors$factor                                       "0.####"
      :interest-distributions$accrued-interest-amount       "0.##"
      :interest-distributions$interest-shortfall-amount     "0.##"
      :interest-distributions$distributed-interest-amount   "0.##"
      :principal-distributions$distributed-principal-amount "0.##"
      :coupon-rates$coupon-rate                             "0.##"}
     field
     "0.#############E0")))

(defn format-value [field value]
  (cond
    (inst? value) (date/date->yyyy-mm-dd value)
    (string? value) (or (re-matches #"\d{4}-\d\d-\d\d" value) ;; date
                        (re-matches #"\d+(?:\.\d+)?(?:[eE]-?\d+)?" value) ;; number
                        (-> value str/trim str/lower-case (#(str/replace % #"[^a-z0-9\s]" ""))))
    (number? value) (str/lower-case (.format (get-decimal-format field) value)) ;; terrible forced rounding
    (sequential? value) (mapv (partial format-value field) value)
    (map? value) (reduce (fn [m [k v]] (assoc m k (format-value (keyword (str (name field) "$" (name k)))
                                                                v)))
                         {} value)
    :else value))

(def some-date
  (some-fn :date :begin-date :issue-date
           :redemption-date :effective-date))

(defn format-seqs [data]
  (if (sequential? data)
    (group-by some-date data)
    data))

(defn score-values [soda lm]
  (let [[only-soda only-lm both]
        (data/diff (format-seqs soda)
                   (format-seqs lm))]
    (if (and (some? both) (nil? only-soda))
      (if (nil? only-lm)
        1
        0.5)
      0)))

(defn cleanup-entity [underwriter]
  (let [replace-words {"corp" "corporation"
                       "co"   "company"
                       "inc"  "incorporated"
                       "ltd"  "limited"}
        blacklist-words ["the"]]
    (-> underwriter
        str/lower-case
        (str/replace #"\W+" " ")
        (str/split #" ")
        ((fn [vals] (filter #(not (contains? blacklist-words %)) vals)))
        ((fn [v] (map #(get replace-words % %) v)))
        (#(str/join " " %)))))

(defn score-entities [soda-val lm-val]
  (let [soda-val (map cleanup-entity (if (coll? soda-val) soda-val [soda-val]))
        lm-val (cleanup-entity lm-val)]
    (if
      (some
        #(<= 0.7 (jaro-winkler % lm-val))
        (if (sequential? soda-val) soda-val [soda-val]))
      1 0)))

(defn compare-values [field soda-val truth-val]
  (cond
    (and (nil? soda-val) (nil? truth-val)) nil
    (nil? soda-val) "no-soda"
    (nil? truth-val) "no-lm"
    :else ({1 "valid" 0 "diff"}
           (cond
             (or (= (some-> field name) "underwriter")
                 (= (some-> field name) "guarantors")
                 (= (some-> field name) "issuer-name"))
             (score-entities soda-val truth-val)

             (= (some-> field name) "shares-outstanding")
             (score-values (:shares-outstanding (first soda-val)) truth-val)

             :default
             (score-values soda-val truth-val))
           "partial")))

(defn remove-fields [doc]
  (dissoc doc
          :bond-dated-date :cusip-1 :cusip-2 :cusip-3 :cusip-6 :due-date :group-name-description
          :incomplete-data :series :series-name :unparseable-text :us-muni :_id
          :cache-last-updated-ts :cache-last-updated :figi :meta :schema :other-share-classes :exchange-specific))

(defn normalize-doc [doc]
  (-> doc
      (set/rename-keys {:optional-call-schedule :call-option-schedule
                        :rate-cap               :cap
                        :rate-floor             :floor})
      (cond-> (:make-whole-call-spread doc)
              (assoc :is-make-whole-call {:value true}))))

(def imply-nil-fields
  {:capital-appreciation            false
   :state-tax-exempt                false
   :federal-tax-exempt              false
   :is-make-whole-call              false
   :make-whole-call                 false
   :zero-coupon                     false
   :perpetual                       false
   :qualified-tax-exempt-obligation false
   :alternative-minimum-tax-item    false
   :floor                           0
   :multiplier                      1})

(defn compare-field [field truth-val {soda-val :value jaeger :jaeger}]
  (let [soda-format (format-value
                      field
                      (if (and (nil? soda-val)
                               (some? truth-val))
                        (imply-nil-fields field soda-val)
                        soda-val))]
    (when-let [comp-val (compare-values field soda-format (format-value field truth-val))]
      {:soda      soda-val
       :lm        truth-val
       :result    comp-val
       :jaeger    jaeger
       :formatted soda-format})))

(defn compare-documents [doc {lm-doc "lm" notary-doc "notary"}]
  (let [doc (normalize-doc doc)
        cusip (-> doc :cusip :value)
        results (apply merge-with merge
                       (for [field (-> (merge doc lm-doc notary-doc)
                                       remove-fields
                                       keys)
                             :let [truth-val (->> (merge lm-doc notary-doc)
                                                  field)
                                   result (compare-field field truth-val (field doc))]]
                         {field (if-let [conflicts (or (-> doc field :alternates)
                                                       (some-> doc field :conflict vector flatten seq))]
                                  (assoc result :alternates
                                                (map (partial compare-field field truth-val)
                                                     conflicts))
                                  result)}))]
    (when-let [nr (-> results :add-notary not-empty)]
      (oracle/add-validation cusip nr))
    (dissoc results :add-notary)))

;; SODA QUERY LOGIC ;;

(defn most-recent-api [cusip-docs & {:keys [after]}]
  (->> (cond-> {:cusip {:$in (keys cusip-docs)}}
               after (assoc :meta.cache-last-updated {:$gt after}))
       (mc/find-maps (ds/get-db "soda-normalized") "agg-cache")
       (map (fn [{cusip :cusip :as m}]
              {:meta {:cusip cusip
                      :index (:index (first (get cusip-docs cusip)))}
               :jaeger-doc (reduce-kv
                             (fn [m k v]
                               (assoc m k {:value v :jaeger :api}))
                             {} (remove-fields m))}))))

(defn get-soda-docs [docs & {:keys [after]}]
  (->> docs
       (group-by :cusip)
       (partition-all 200)
       (map (partial into {}))
       (pmap (fn [cusip-docs]
               (most-recent-api cusip-docs :after after)))
       (apply concat)))

(defn add-time-stamp [doc]
  (assoc-in doc [:meta :time-stamp] (.getDate (:_id doc))))

(defn clean-jaeger-doc [doc]
  (-> doc
      (update :meta select-keys [:filename :md5])
      (add-time-stamp)
      (dissoc :_id)
      (update :jaeger-doc remove-fields)
      (update :jaeger-doc (partial med/map-vals (fn [x] (select-keys x [:value :jaeger]))))
      (update :jaeger-doc set/rename-keys {:cusip-9 :cusip})
      (#(assoc-in % [:meta :cusip] (-> % :jaeger-doc :cusip :value)))
      (#(if-let [ticker (-> % :jaeger-doc :ticker :value)]
          (assoc-in % [:meta :ticker] ticker)
          %))))

(defn set-jaeger-index [md5-docs jaeger]
  (let [{:keys [md5 ticker cusip]} (:meta jaeger)]
    (some->> (get md5-docs md5)
             (filter (fn [{t :ticker c :cusip}]
                       (or (and t ticker (= t ticker))
                           (and c cusip (= c cusip)))))
             first
             :index
             (assoc-in jaeger [:meta :index]))))

(defn get-jaeger-docs [docs]
  (->> docs
       (group-by :md5)
       (partition-all 200)
       (map (partial into {}))
       (pmap (fn [md5-docs]
               (->> {:meta.md5 {:$in (keys md5-docs)}
                     :meta.outdated? nil}
                    sp/*query->jaeger-data
                    (map clean-jaeger-doc)
                    (med/distinct-by (fn [{{:keys [cusip ticker md5]} :meta}]
                                       [(or ticker cusip) md5]))
                    (keep (partial set-jaeger-index md5-docs)))))
       (apply concat)))

;; LM QUERY LOGIC ;;

(defn format-data [data]
  (->> data
       (group-by :source)
       (map-vals (comp :data first))))

(def api-rename-map
  {:yield     :issue-yield
   :price     :issue-price
   :day-count :day-count
   :ticker    :primary-exchange-ticker})

(defn make-index->lm-data [docs soda-api?]
  (let [cusip-docs (group-by :cusip docs)]
    (->> cusip-docs
         keys
         oracle/cusips->oracle-data
         (map (fn [data]
                (-> data
                    (dissoc :_id)
                    (assoc :index (->> data :data :cusip
                                       (get cusip-docs)
                                       first :index))
                    (update :data set/rename-keys
                            (when soda-api?
                              api-rename-map)))))
         (group-by :index)
         (map-vals format-data))))


;; MAIN FUNCTION ;;

(defn all-stats [control-set-name & {:keys [soda-api? after]}]
  (let [cs (->> (get cs/control-sets
                     (keyword control-set-name)
                     (:active-lm cs/control-sets))
                (filter (every-pred (some-fn :cusip :ticker) :md5))
                (med/distinct-by (juxt (some-fn :cusip :ticker) :md5))
                (map-indexed (fn [i x] (assoc x :index i))))
        index-lm (make-index->lm-data cs soda-api?)
        index-soda (->> (if soda-api?
                          (get-soda-docs cs :after after)
                          (get-jaeger-docs cs))
                        (group-by (comp :index :meta))
                        (med/map-vals first))]
    (mapv (fn [{i :index :as doc}]
            (update (get index-soda i {:jaeger-doc {}
                                       :meta (select-keys doc [:md5 :filename :cusip :ticker])})
                    :jaeger-doc compare-documents
                    (get index-lm i {})))
          cs)))
