(ns jaegers.edgar.classifiers.taxability-training
  (:require [html.utils :as html]
            [edgar.tfidf-enfeaturing :as tfidf-enf]
            [clojure.data.csv :as csv]
            [simple-mind.naive-bayes.core :as nb]
            [clojure.java.io :as io]
            [medley.core :refer [map-vals]]
            [utils.metrics :refer [compute-metrics]]
            [soda.data.file-system :as sdfs]))

(defn- md5->html
  "Returns the html for a file identified by md5"
  [md5]
  (->> {:md5 md5}
       sdfs/find-file
       :input-stream
       slurp
       html/get-html))

(defn- get-tfidfs
  "Returns the tf-idf scores for a file identified by md5"
  [md5 tfidf-model]
  (-> md5
      md5->html
      (tfidf-enf/enfeature-tfidf tfidf-model)))

(defn- md5-class-filter
  "Return all md5s that match class"
  [class maps]
  (map :md5 (filter #(= (:class %) class) maps)))

(defn- scale
  "Multiplies a scalar to all values in map m"
  [m scalar]
  (map-vals (fn [val] (* val scalar)) m))

(defn- train-class
  "Returns a trained naive bayes model for just one class"
  [model class md5s tfidf-model]
  (let [scalar (/ 1.0 (count md5s))]
    (update
      (reduce
        (fn [m md5] (nb/train m class (get-tfidfs md5 tfidf-model)))
        model
        md5s)
      class scale scalar)))

(defn- confusion-matrix
  "Makes predictions using model and returns a confusion matrix"
  [model input tfidf-model]
  (reduce
    (fn [v {:keys [md5 class]}]
      (let [pred (nb/classify model (get-tfidfs md5 tfidf-model))]
        (update v (cond
                    (= pred :process class) :tp
                    (= pred :process) :fp
                    (= pred :not-process class) :tn
                    (= pred :not-process) :fn)
                inc)))
    {:tp 0 :fp 0 :fn 0 :tn 0}
    input))

(defn- load-csv
  "Loads a list of vectors from file-path where each vector contains md5 and label (0 or 1)"
  [file-path]
  (when file-path
    (rest ; "rest" removes the column titles
      (with-open [in-file (clojure.java.io/reader file-path)]
        (doall (csv/read-csv in-file))))))

(def reshape-train-data
  (partial
    map
    (fn [i [md5 label]]
      {:md5   md5
       :class (case label
                "1" :process
                "0" :not-process)
       :i     i})
    (range)))

(defn- load-training-data
  "Loads training data from a file"
  ([] (load-training-data "jaegers/edgar_taxability_training.csv"))
  ([file-path]
   (->> file-path
        io/resource
        load-csv
        shuffle
        reshape-train-data)))

(defn- train-bayes-model
  "Returns a trained naive bayes model"
  ([tfidf-model] (train-bayes-model (load-training-data) tfidf-model))
  ([input tfidf-model]
   (-> {}
       (train-class :process
                    (md5-class-filter :process input)
                    tfidf-model)
       (train-class :not-process
                    (md5-class-filter :not-process input)
                    tfidf-model))))

(defn- get-tf-index
  [input n-gram-sizes]
  (apply
    merge-with
    merge
    (pmap
      (fn [{:keys [md5 i]}]
        (tfidf-enf/index-tf n-gram-sizes (md5->html md5) i))
      input)))

(defn- get-tfidf-index
  [input tf-index min-df max-df]
  (->> tf-index
       (map-vals
         (fn [term-docs]
           (map-vals
             (fn [tf]
               (tfidf-enf/calc-tfidf tf (count input) (count term-docs)))
             term-docs)))
       (tfidf-enf/prune-terms (count input) min-df max-df tf-index)))

(defn- get-means
  [tfidf-index scale]
  (reduce-kv
    (fn [m k v]
      (let [scores (map val v)]
        (assoc m k (* scale (/ (reduce + scores) (count scores))))))
    {} tfidf-index))

(defn- create-tfidf-model
  "Creates a tf-idf model based on training data"
  ([] (create-tfidf-model (load-training-data)))
  ([input] (create-tfidf-model input [1 2 3] 1000000 0.2 0.8))
  ([input n-gram-sizes scale min-df max-df]
   (let [tf-index (get-tf-index input n-gram-sizes)
         tfidf-index (get-tfidf-index input tf-index min-df max-df)]
     {:doc-freqs    (into {} (map (fn [[k v]] [k (count v)]) tfidf-index))
      :doc-count    (count input)
      :scale        scale
      :n-gram-sizes n-gram-sizes
      :means        (get-means tfidf-index scale)})))

(defn- train-and-test
  "Trains a tf-idf model and naive bayes model and prints metrics on test data"
  ([] (train-and-test (load-training-data) 0.7))
  ([input train-percent]
   (time
     (let [[train-input test-input] (partition-all (* train-percent (count input)) input)
           tfidf-model (create-tfidf-model train-input)
           bayes-model (train-bayes-model train-input tfidf-model)]
       (-> (confusion-matrix bayes-model test-input tfidf-model)
           compute-metrics
           println)))))

(defn- train-full-models
  "Trains models on all training data and writes them to files"
  ([] (train-full-models
        "src/main/resources/jaegers/edgar_taxability_binary_tfidf.edn"
        "src/main/resources/jaegers/edgar_taxability_naive_bayes.edn"))
  ([tfidf-path bayes-path]
   (time
     (let [tfidf-model (create-tfidf-model)
           bayes-model (train-bayes-model tfidf-model)]
       (do (spit tfidf-path (pr-str tfidf-model))
           (spit bayes-path (pr-str bayes-model)))))))




; Commenting out train and test so they don't run on load
(comment
  (train-and-test)
  (train-full-models)
  )
