(ns jaegers.mind-food-utils
  (:require [clojure.string :as cs]
            ; [clojure.java.io :as io]
            [clojure.spec.alpha :as spec]
            ; [clojure.pprint :refer [pprint]]
            ; [clojure.spec.test.alpha :as stest]
            ; [clj-ml.classifiers :as ml-class]
            ; [clj-ml.data :as ml-data]
            ; [clj-ml.io :as ml-io]
            [enhanced-hickory.tokenvec :as eht]
            [instaparse.core :as insta]
            [jaegers.spec]
            [nlp.core :as nlp]
            [tokenvec.core :as tv]))

; (defn ->kv [jaeger-doc]
;   (zipmap (keys jaeger-doc) (map :value (vals jaeger-doc))))

; (defn string-id->map-id [s]
;   (if (string? s)
;     (let [[_ page x y] (re-matches #"(?:id)?(\d+)_(\d+)_(\d+)" s)]
;       {:page (Long/parseLong page) :x (Long/parseLong x) :y (Long/parseLong y)})
;     s))

; (defn map-id->string->id [m]
;   (if (map? m) (let [{:keys [page x y]} m] (str page "_" (int x) "_" (int y))) m))

; (defn jaeger-doc-transformer
;   [jaeger-doc form]
;   {:pre [(spec/assert :jaeger/jaeger-doc jaeger-doc)
;          (spec/assert #{:key-val :flat-string-ids} form)]}
;   (case form
;     :key-val (zipmap (keys jaeger-doc) (map :value (vals jaeger-doc)))
;     :flat-string-ids (zipmap (keys jaeger-doc) (mapv #(update % :ids (comp (partial map map-id->string->id) flatten)) (vals jaeger-doc)))
;     jaeger-doc))

; (defn mind-food->candidate-lines [mind-food & {:keys [sanitizer line-filter token-filter] :or {token-filter identity}}]
;   (for [component (map :vals (filter #(-> % :type keyword #{:text}) mind-food))
;         linevec component
;         :let [line (cs/join " " (for [{:keys [text] :as token} linevec
;                                       :when (token-filter token)]
;                                   (cond-> text sanitizer sanitizer)))]
;         :when (cond-> line line-filter line-filter)]
;     [line linevec]))

; (defn mind-food->lines [mind-food]
;   (for [component (map :vals (filter #(-> % :type keyword #{:text}) mind-food))
;         linevec component
;         :let [line (cs/join " " (for [{:keys [text]} linevec] text))]]
;     [line linevec]))

; (defn mind-food->comp [mind-food ids]
;   (for [component (map :vals (filter #(-> % :type keyword #{:text}) mind-food))
;         linevec component
;         {:keys [text id]} linevec
;         :when (ids id)]
;     text))

; (defn tokens [mind-food & ids]
;   (let [s (apply hash-set ids)]
;     (->> mind-food flatten (map :vals) flatten (filter (comp s :id)))))

(defn terms [mind-food & {:keys [sanitizer prefilter postfilter]}]
  (let [tokens (->> mind-food flatten (map :vals) flatten (map (fn [{:keys [text id]}] [text [id]])))]
    (cond->> tokens
             prefilter (filter (comp prefilter first))
             sanitizer (map #(update % 0 sanitizer))
             postfilter (filter (comp postfilter first)))))

(defn n-grams [n terms]
  (->> terms (partition n 1) (map (fn [v] [(cs/join " " (map first v)) (reduce into (map second v))]))))

; (defn token-handler [token & {:keys [token-transformer]}]
;   (cond-> token token-transformer token-transformer))

; (defn line-handler [line & {:keys  [token-prefilter
;                                     line-transformer
;                                     token-postfilter] :as m}]
;   (cond->> line
;            token-prefilter (filter token-prefilter)
;            line (map (fn [token] (apply token-handler (cons token (reduce concat m)))))
;            line-transformer line-transformer
;            token-postfilter (filter token-postfilter)))

; (defn text-handler [text & {:keys [text-prefilter
;                                    text-transformer
;                                    text-postfilter] :as m}]
;   (cond->> (:vals text)
;            text-prefilter (filter text-prefilter)
;            text (map (fn [line] (apply line-handler (cons line (reduce concat m)))))
;            text-postfilter (filter text-postfilter)))

; (defn cell-handler [cell & {:keys [] :as m}]
;   (map (fn [token] (apply token-handler (cons token (reduce concat m)))) cell))

; (defn column-handler [column & {:keys [] :as m}]
;   (map (fn [cell] (apply cell-handler (cons cell (reduce concat m)))) column))

; (defn row-handler [row & {:keys [] :as m}]
;   (map (fn [column] (apply column-handler (cons column (reduce concat m)))) row))

; (defn table-handler [table & {:keys [] :as m}]
;   (map (fn [row] (apply row-handler (cons row (reduce concat m)))) (:vals table))
;   #_(cond-> table table-filter (table-filter table)))

; (defn component-handler [{:keys [type] :as component} & {:keys [] :as m}]
;   (case type
;     "text" (apply text-handler (cons component (reduce concat m)))
;     "table" (apply table-handler (cons component (reduce concat m)))
;     component))


; (defn mind-food-handler [mind-food & {:keys[component-prefilter
;                                             component-postfilter] :as m}]
;   (cond->> mind-food
;            component-prefilter (filter component-prefilter)
;            mind-food (map (fn [component] (apply component-handler (cons component (reduce concat m)))))
;            component-postfilter (filter component-postfilter)))

; (defn tbl [table-component]
;   (for [row table-component]
;     (for [col row]
;       (for [cell col]
;         (for [token cell]
;           (:text token))))))

; (defn txt [text-component & {:keys [text-component-fn
;                                     line-fn
;                                     token-fn]
;                              :or {text-component-fn identity
;                                   line-fn identity
;                                   token-fn identity}}]
;   (for [line (text-component-fn text-component)]
;     (for [token (line-fn line)]
;       (token-fn token))))

; (defn paragraphs [mind-food]
;   (for [{:keys [vals type]} mind-food :when (#{:text} (keyword type))]
;     (cs/join " " (for [line vals]
;                    (cs/join " " (for [{:keys [text]} line] text))))))

; (defn sentences [mind-food]
;   (flatten (map #(map cs/trim (cs/split % #"[.!?]\s")) (paragraphs mind-food))))

; (defn mind-food->table-tokenvecs [mind-food]
;   (for [{:keys [vals type]} mind-food :when (#{:table} (keyword type)) row vals]
;     (tv/tokens->tokenvec (for [cols row token cols] token))))

(defn mind-food->paragraph-tokenvecs [mind-food]
  (for [{:keys [vals type]} mind-food :when (#{:text} (keyword type))
        :let [tokenvec (tv/tokens->tokenvec (for [line vals token line] token))]
        :when tokenvec]
    tokenvec))

(defn mind-food->sentence-tokenvecs [mind-food]
  (mapcat (partial tv/tokenvec-splitter nlp/parse-sentences)
          (mind-food->paragraph-tokenvecs mind-food)))

(defn mind-food->line-tokenvecs [mind-food]
  {:pre  []
   :post [(spec/assert :tokenvec/tokenvecs %)]}
  (for [{:keys [vals type]} mind-food
        :when (#{:text} (keyword type))
        line vals
        :let [tokenvec (tv/tokens->tokenvec (for [token line] token))]
        :when tokenvec]
    tokenvec))

; (defn enhik->tokenvecs
;   [enhik]
;   ; {:pre [(spec/assert :enhanced-hickory/document enhik)]
;   ;  :post [(spec/assert :tokenvec/tokenvecs %)]}
;   (eht/enhik->tokenvecs enhik))

(defn enhik->sentence-tokenvecs
  [enhik]
  ; {:pre [(spec/assert :enhanced-hickory/document enhik)]
  ;  :post [(spec/assert :tokenvec/tokenvecs %)]}
  (mapcat (partial tv/tokenvec-splitter nlp/parse-sentences)
          (eht/enhik->tokenvecs enhik)))


(defn element->token [{text :text :as element}]
  (when element
    [text (repeat (count text) element)]))

(defn concat-tokenvecs [tokenvecs]
  (when (seq tokenvecs)
    [(->> tokenvecs
          (map first)
          (cs/join " "))
     (->> tokenvecs
          (map second)
          (interpose [nil])
          (apply concat)
          vec)]))

(defn flatten-element [{:keys [attrs content]}]
  (->> content
       (keep (fn [c]
               (if (string? c)
                 (when (and (:id attrs) (not= " " c))
                   (assoc attrs :text c))
                 c)))
       vec))

(defn element->flat-tokenvec [element]
  (loop [tokenvec ["" []]
         elements (flatten-element element)]
    (if (seq elements)
      (let [elements (into (flatten-element (first elements))
                           (rest elements))]
        (recur
          (->> elements
               (take-while :text)
               (map element->token)
               (cons tokenvec)
               (filter (comp seq second))
               vec
               concat-tokenvecs)
          (vec (drop-while :text elements))))
      tokenvec)))

(defn table-row? [element]
  (= :tr (:tag element)))

(defn max-size-tokenvecs [tokenvecs]
  (reduce (fn [r v] (max r (count (first v)))) 0 tokenvecs))

(defn header? [tokenvec]
  (some-> tokenvec first (cs/ends-with? ":")))

(defn make-header-cell-fn []
  (let [left-cell (volatile! nil)]
    (fn [cell up-cell]
      (vreset! left-cell
              (or (when (header? cell)
                    {:header cell})
                  (some->> @left-cell :header (array-map :left))
                  (some->> up-cell :header (array-map :up))
                  (when (:left @left-cell)
                    @left-cell)
                  (when (:up up-cell)
                    up-cell)
                  (when (:left up-cell)
                    up-cell)
                  (when (:up @left-cell)
                    @left-cell))))))

(defn make-header-row-fn []
  (let [last-row (volatile! nil)]
    (fn [tokenvec-row]
      (->> (mapv (make-header-cell-fn)
                 tokenvec-row
                 (concat @last-row (repeat nil)))
           (vreset! last-row)
           (mapv (some-fn :left :up))))))

(defn make-explicit-headers-table [tokenvec-table cell-split-fn]
  (let [headers-table (mapv (make-header-row-fn) tokenvec-table)]
    (mapcat (fn [tokenvec-row headers-row]
              (-> (mapcat (fn [tokenvec-cell headers-cell]
                            ; (when (and headers-cell tokenvec-cell)
                            ;   (->> (cell-split-fn tokenvec-cell)
                            ;        (mapv #(concat-tokenvecs [headers-cell %]))))
                            (when tokenvec-cell
                              (cond->> (cell-split-fn tokenvec-cell)
                                       headers-cell
                                       (mapv #(concat-tokenvecs [headers-cell %])))))

                          tokenvec-row headers-row)
                  vec))
            tokenvec-table headers-table)))

(defn multi-sentence-tokenvec? [tokenvec]
  (some-> (first tokenvec)
          (cs/split #"(?<![A-Z])\. (?=[A-Z])")
          second))

(defn flip-table [colls]
  (let [step (fn step [cs]
               (lazy-seq
                (let [ss (map seq cs)]
                  (when (some identity ss)
                    (cons (map first ss) (step (map rest ss)))))))]
    (map vec (step colls))))

(defn clean-tokenvec-table [tvec-table]
  (letfn [(when-pred [pred] (fn [x] (when (pred x) x)))]
    (some->> tvec-table
      (map (partial mapv (when-pred tv/valid?)))
      (filter (partial some identity))
      seq
      flip-table
      (filter (partial some identity))
      seq
      flip-table
      vec)))

(defn make-implied-headers-table [tokenvec-table cell-split-fn]
  (let [col-headers (first tokenvec-table)
        row-headers (mapv first tokenvec-table)
        col-count (if (some multi-sentence-tokenvec? col-headers)
                    0
                    (count (filter identity col-headers)))
        row-count (if (some multi-sentence-tokenvec? row-headers)
                    0
                    (count (filter identity row-headers)))]
    (cond
      (= 0 row-count col-count)
      (mapcat (fn [row]
                (->> (filter identity row)
                     (mapcat cell-split-fn)
                     vec))
              tokenvec-table)

      (< row-count col-count)
      (mapcat (fn [row]
                (->> (mapcat (fn [cell-header cell]
                               (when cell
                                 (let [cells (cell-split-fn cell)]
                                   (cond
                                     (not cell-header) cells
                                     (= cell cell-header) cells
                                     :else (mapv #(concat-tokenvecs [cell-header %])
                                                 cells)))))
                             col-headers row)
                     vec))
              tokenvec-table)

      :else
      (mapcat (fn [row-header row]
                (if row-header
                  (->> row
                       (mapcat (fn [cell]
                                 (when cell
                                   (let [cells (cell-split-fn cell)]
                                     (if (= cell row-header)
                                       cells
                                       (mapv #(concat-tokenvecs [row-header %])
                                             cells))))))
                       vec)
                  (->> (filter identity row)
                       (mapcat cell-split-fn)
                       vec)))
              row-headers tokenvec-table))))

(defn process-table [cell-split-fn enhik-table]
  (let [tokenvec-table (->> enhik-table
                            (mapv (fn [{row :content}]
                                    (mapv element->flat-tokenvec row)))
                            clean-tokenvec-table)]
    (if (some header? (apply concat tokenvec-table))
      (make-explicit-headers-table tokenvec-table cell-split-fn)
      (make-implied-headers-table tokenvec-table cell-split-fn))))

(defn enhik->row-tokenvec [enhik]
  (loop [tokenvec []
         elements [enhik]]
    (if (seq elements)
      (let [elements (->> (rest elements)
                          (concat (flatten-element (first elements)))
                          (remove :text)
                          vec)
            [table-rows rest-elements] (split-with table-row? elements)]
        (recur
          (->> table-rows
               (process-table vector)
               (into tokenvec))
          (vec rest-elements)))
      tokenvec)))

(defn enhik->row-and-paragraph-tokenvec [enhik]
  (loop [tokenvec []
         text-tokens []
         elements [enhik]]
    (if (seq elements)
      (let [[new-text rest-elements]
            (->> (rest elements)
                 (concat (flatten-element (first elements)))
                 (split-with :text))
            [row-elements rest-elements]
            (split-with table-row? rest-elements)
            new-text-tokens (->> (map element->token new-text)
                                 (filter (comp seq second))
                                 (concat text-tokens)
                                 vec)]
        (if (seq row-elements)
          (recur
            (into (if (seq new-text-tokens)
                    (conj tokenvec (concat-tokenvecs new-text-tokens))
                    tokenvec)
                  (process-table vector row-elements))
            []
            (vec rest-elements))
          (recur
            tokenvec
            new-text-tokens
            (vec rest-elements))))
      (if (seq text-tokens)
          (conj tokenvec (concat-tokenvecs text-tokens))
          tokenvec))))

(defn paragraph->sentences [paragraph]
  (let [ss (cs/split paragraph #"(?<![A-Z])\. (?=[A-Z])")]
    (conj (mapv #(str % ". ") (butlast ss))
          (last ss))))

(defn para-vec->sentence-vec [para-vec]
  (when (first para-vec)
    (tv/tokenvec-splitter paragraph->sentences para-vec)))

;; TODO: this does bad things to tables that have multiple sentences in a cell. Fix it.
(defn enhik->row-and-sentence-tokenvec [enhik]
  (loop [tokenvec []
         text-tokens []
         elements [enhik]]
    (if (seq elements)
      (let [[new-text rest-elements]
            (->> (rest elements)
                 (concat (flatten-element (first elements)))
                 (split-with :text))

            [row-elements rest-elements]
            (split-with table-row? rest-elements)

            new-text-tokens (->> (map element->token new-text)
                                 (filter (comp seq second))
                                 (concat text-tokens)
                                 vec)]
        (if (seq row-elements)
          (recur
            (into (if (seq new-text-tokens)
                    (->> (concat-tokenvecs new-text-tokens)
                         para-vec->sentence-vec
                         (into tokenvec))
                    tokenvec)
                  (process-table para-vec->sentence-vec row-elements))
            []
            (vec rest-elements))
          (recur
            tokenvec
            new-text-tokens
            (vec rest-elements))))
      (if (seq text-tokens)
        (->> (concat-tokenvecs text-tokens)
             para-vec->sentence-vec
             (into tokenvec))
        ;(conj tokenvec (concat-tokenvecs text-tokens))
        tokenvec))))

; (defn enhik->row-and-sentence-tokenvec [enhik]
;   (->> (enhik->row-and-paragraph-tokenvec enhik)
;        (filter identity)
;        (mapcat (partial tv/tokenvec-splitter paragraph->sentences))))


(defn tokenvec-stream [{:keys [mind-food]} & {:keys [mind-food-splitter prefilter postfilter]
                                              :or {mind-food-splitter mind-food->sentence-tokenvecs prefilter identity postfilter identity}}]
  (some->> mind-food
           (filter prefilter)
           mind-food-splitter
           (filter postfilter)))

(defn insta-indexes [x]
  (when-let [m (meta x)]
    ((juxt :instaparse.gll/start-index :instaparse.gll/end-index) m)))

(defn add-indexes-from [f s] (assoc f :indexes (insta-indexes s)))

; (defn add-indexes [s] (add-indexes-from s s))

(defn tagfact [m tag] (assoc-in m [:features tag] true))

(def geometric-features-descriptor
  (zipmap [:top-quarter? :top-half? :top-third? :bottom-third? :bottom-quarter?
           :left-quarter? :left-half? :left-third? :right-third? :right-quarter?]
          (repeat {:default false :options #{true false}})))

(defn categorize-geometries [{:keys [x y] :or {x Double/NaN y Double/NaN}}]
  (cond-> (zipmap (keys geometric-features-descriptor) (map :default (vals geometric-features-descriptor)))
          ;vertical
          (< y 0.25) (assoc :top-quarter? true)
          (< y 0.5) (assoc :top-half? true)
          (< y 0.33) (assoc :top-third? true)
          (> y 0.66) (assoc :bottom-third? true)
          (>= y 0.5) (assoc :bottom-half? false)
          (>= y 0.75) (assoc :bottom-quarter? true)
          ;;horizontal
          (< x 0.25) (assoc :left-quarter? true)
          (< x 0.5) (assoc :left-half? true)
          (< x 0.33) (assoc :left-third? true)
          (> x 0.66) (assoc :right-third? true)
          (>= x 0.5) (assoc :right-half? false)
          (>= x 0.75) (assoc :right-quarter? true)))

(defn add-geometric-features [{:keys [features real-coords features-descriptor]
                               :or {features {} features-descriptor {}} :as m}]
  (-> m
      (assoc :features (into features (categorize-geometries real-coords)))
      (assoc :features-descriptor (into features-descriptor geometric-features-descriptor))))

(defn page-coords [{:keys [coords]}]
  (let [{:keys [x y] :or {x 0.0 y 0.0}} (some-> coords flatten first)]
    {:x (/ x 650) :y (/ (rem y 800) 800)}))

(defn add-page-num-feature [{:keys [coords] :as m}]
  (let [page-num (-> coords flatten first :page-number)]
    (-> m
        (assoc-in [:features :page-num] page-num)
        (assoc-in [:features-descriptor :page-num] :implicit))))

(defn add-token-data[{:keys [indexes] :as m} [sentence tokenvec]]
  (let [u (tv/unique-tokens tokenvec indexes)]
    (-> m
        (dissoc :indexes)
        (assoc :ids [(mapv :id u)])
        (assoc :sentence sentence)
        (assoc :coords [(mapv #(select-keys % [:page-number :x :y]) u)])
        ((fn [m] (assoc m :real-coords (page-coords m))))
        add-geometric-features
        add-page-num-feature)))

(defn feature-descriptor->feature-map [fd]
  (into {}
        (map (fn [[k v]]
               [k (if (#{:implicit nil} v)
                   (cond
                     (cs/ends-with? (name k) "?") false
                     (cs/ends-with? (name k) "-num") 0
                     :default nil)
                   (:default v))])
             fd)))

(defn create-counted-features [feature-name]
  (map keyword (let [n (str (name feature-name) "-num")] [(str "pre-" n) n (str "post-" n)])))

(defn expand-feature-descriptor [{:keys [counted-items value-type class]}]
  (into
    {:value-type {:options value-type :default :?}
     :class {:options class :default :?}}
    (zipmap (map keyword (flatten (map create-counted-features (into counted-items value-type))))
            (repeat :implicit))))

(defn implicit->explicit-feature-descriptor [feature-descriptor]
  (into {}
        (map (fn [[k v]]
               [k (if (#{:implicit} (keyword v))
                    (cond
                      (cs/ends-with? (name k) "?") #{true false}
                      :default nil)
                    (:options v))])
             feature-descriptor)))

(defn create-reference-date-keyword [s]
  (-> s cs/lower-case (cs/replace #"\W+" "-") (#(str "date-of-" %)) keyword))

(defn rekey [m f] (zipmap (map f (keys m)) (vals m)))

(defn kw->feature-term [kw]
  (-> kw name cs/lower-case (cs/replace #"\p{Punct}+" "-") (str "-num") keyword))

(defn termfreqs [sentence]
  (->> sentence (filter vector?) (map first) frequencies))

(defn assign-value-type [m t]
  (assoc-in m [:features :value-type] t))

(defn valuefreqs [sentence]
  (->> sentence (filter map?) (map #(get-in % [:features :value-type] :unknown)) frequencies))

(defn sentence-freqs [f sentence]
  (let [freqs (f sentence)]
    (zipmap (map kw->feature-term (keys freqs)) (vals freqs))))

(defn characterize [pre value post]
  (let [pre-term-freqs (sentence-freqs termfreqs pre)
        post-term-freqs (sentence-freqs termfreqs post)
        pre-value-freqs (sentence-freqs valuefreqs pre)
        post-value-freqs (sentence-freqs valuefreqs post)]
    (-> value
        (update :features into (rekey pre-term-freqs #(->> % name (str "pre-") keyword)))
        (update :features into (rekey post-term-freqs #(->> % name (str "post-") keyword)))
        (update :features into (merge-with + pre-term-freqs post-term-freqs))
        (update :features into (rekey pre-value-freqs #(->> % name (str "pre-") keyword)))
        (update :features into (rekey post-value-freqs #(->> % name (str "post-") keyword)))
        (update :features into (merge-with + pre-value-freqs post-value-freqs)))))

(defn split-values [sentence]
  (loop [[f [v & post]] (split-with (complement :value) sentence) pre [] res []]
    (if v
      (let [p (into pre f)] (recur (split-with (complement :value) post) (conj p v) (conj res [p v (or post (empty p))])))
      res)))

(defn characterize-values [sentence & {:keys [characterizer] :or {characterizer characterize}}]
  (map #(apply characterizer %) (split-values sentence)))

(defn enfeature-tokenvec [parse-fn sentence-idx [sentence _ :as tv]]
  (let [res (parse-fn sentence)]
    (when (not (insta/failure? res))
      (map (fn [m] (assoc (add-token-data m tv) :sentence-idx sentence-idx)) res))))

(defn enfeature-tokenvecs [tokenvecs parse-fn]
  (->> tokenvecs
       (pmap (fn [i tv] (enfeature-tokenvec parse-fn i tv)) (range (count tokenvecs)))
       (filter not-empty)
       flatten))

(defn create-feature-map [value & {:keys [features-descriptor features] :or {features-descriptor {} features {}}}]
  {:value value
   :features-descriptor features-descriptor
   :features (into (feature-descriptor->feature-map features-descriptor) features)})

(defn create-value [value-type value-path-fn m feature-descriptor]
  (-> (create-feature-map (value-path-fn m) :features-descriptor feature-descriptor)
      (add-indexes-from m)
      (assign-value-type value-type)))

;; Graveyard -- where unused code goes to die

;(defn default-page-filter [{:keys [page-number]}] (<= page-number 5))
;(defn default-sentence-filter [[sentence _]] (not (cs/includes? sentence ".....")))

;(defn md5->featuremaps [md5 sentence-parser
;                        & {:keys [page-filter sentence-filter]
;                           :or {page-filter default-page-filter sentence-filter default-sentence-filter}}]
;  (-> {:md5 md5}
;      find-mindfood
;      (tokenvec-stream :prefilter page-filter :postfilter sentence-filter)
;      (enfeature-tokenvecs sentence-parser)
;      (->> (map #(assoc % :md5 md5)))))

;(defn add-geometric-data [{:keys [page-number] :as m}]
;  (let [dy (* 800 (or page-number 0))]
;    (-> m
;        (select-keys [:x0 :y0 :x1 :y1])
;        (update :y0 + dy)
;        (update :y1 + dy))))

;(defn add-token-bounds [{:keys [x y height width page-number] :as m}]
;  (let [dy (* 800 (or page-number 0))]
;    (into m {:x0 x :y0 (+ y dy) :x1 (+ x width) :y1 (+ y height dy)})))

;(defn gaps [{ax0 :x0 ax1 :x1 ay0 :y0 ay1 :y1} {bx0 :x0 bx1 :x1 by0 :y0 by1 :y1}]
;  (cond-> []
;          (<= ax1 bx0) (conj (- bx0 ax1))
;          (>= ax0 bx1) (conj (- ax0 bx1))
;          (<= ay1 by0) (conj (- by0 ay1))
;          (>= ay0 by1) (conj (- ay0 by1))))

;(defn min-gap[a b]
;  (if-some [gaps (not-empty (gaps a b))] (apply min gaps) 0))

;(defn max-gap[a b]
;  (if-some [gaps (not-empty (gaps a b))] (apply max gaps) 0))

;(defn union [{ax0 :x0 ax1 :x1 ay0 :y0 ay1 :y1 :as a} {bx0 :x0 bx1 :x1 by0 :y0 by1 :y1 :as b}]
;  (if (and ax0 ax1 ay0 ay1)
;    (if (and bx0 bx1 by0 by1)
;      {:x0 (min ax0 bx0) :x1 (max ax1 bx1) :y0 (min ay0 by0) :y1 (max ay1 by1)} a)
;    (if (and bx0 bx1 by0 by1)
;      b nil)))
