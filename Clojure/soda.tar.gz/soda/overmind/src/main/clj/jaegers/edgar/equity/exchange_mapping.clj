(ns jaegers.edgar.equity.exchange-mapping
  (:require [clojure.edn :as edn]
            [clojure.java.io :as io]
            [clj-fuzzy.metrics :as fuzz]
            [medley.core :as med]
            [clojure.string :as str]))

(defn clean-exchange-string [s]
  (-> (str/lower-case s)
      (str/replace #"national association of securities dealers automated quotation" "nasdaq")
      (str/replace #"(?:\bstock )?(?:market(?:place|s)?|exchange)|\b(?:high|low).*|mkt|llc|the" "")
      str/trim
      (str/replace #" {2,}" " ")))

(defn prep-ex-map [ex-map]
  (assoc ex-map :compare-names
         (->> (keep ex-map [:exchange-name :exchange-name-alt :acronym])
              (map clean-exchange-string)
              vec)))

(defn mic->ex-code-mapping []
  (->> "edgar/figi_exchange_map.edn"
       io/resource
       slurp
       edn/read-string
       (reduce (fn [r x] (assoc r (:mic x) (:exchange-code x)))
               {})))

(defn add-ex-code [ex-maps]
  (let [ex-codes (mic->ex-code-mapping)]
    (mapv (fn [x] (->> (:mic x)
                       ex-codes
                       (med/assoc-some x :exchange-code)))
          ex-maps)))

(def mapping
  (->> "edgar/ISO10383_MIC.edn"
       io/resource
       slurp
       edn/read-string
       (mapv prep-ex-map)
       add-ex-code))

(defn fuzzy-compare [exchange ex-map]
  [(->> (:compare-names ex-map)
        (map (partial fuzz/jaro-winkler exchange))
        (apply max))
   ex-map])

(defn exchange->mic [exchange]
  (let [format-ex (clean-exchange-string exchange)]
    (->> mapping
         (map (partial fuzzy-compare format-ex))
         (reduce (fn
                   ([] nil)
                   ([a b]
                    (cond
                      (== 1 (first a)) (reduced a)
                      (> (first a)
                         (first b)) a
                      :else b)))
                 [0.8 nil]) ;; minimum matching score
         ((fn [[x m]]
            (when m
              (assoc m :orig exchange
                       :score x)))))))


(def mic->omic
  (reduce (fn [r x]
            (assoc r (:mic x) (:operating-mic x)))
          {}
          mapping))
