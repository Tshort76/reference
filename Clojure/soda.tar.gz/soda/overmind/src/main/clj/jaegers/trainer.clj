(ns jaegers.trainer
  (:require
    [clojure.core.memoize :as memo]
    [clojure.set :refer [rename-keys]]
    [clojure.string :as str]
    [monger.collection :as mc]
    [monger.result :as mr]
    [datasources.core :as ds]
    [ml.training-sets :as training-sets]
    [jaegers.utils :as ju])
  (:import org.bson.types.ObjectId))

(def five-min-in-ms (* 5 60 1000))

(defn remove-nil [map]
  (reduce (fn [m [k v]]
            (cond-> m, v (assoc k v)))
          {} map))

(defn db []
  (ds/get-db "training-sets"))

(defn list-training-sets []
  (->> (mc/find-maps (db) "features-descriptors" {} {:_id 1})
       (map :_id)))

(defn get-features-descriptor [jaeger]
  (mc/find-one-as-map (db) "features-descriptors" {:_id jaeger}))

(defn get-feature-maps [jaeger & [query]]
  (mc/find-maps (db) "feature-maps" (merge query {:descriptor-id jaeger})))

(defn distinct-feature-maps [jaeger distinct-field & [query]]
  (mc/distinct (db) "feature-maps" distinct-field
               (merge query {:descriptor-id jaeger})))

(defn get-training-set [jaeger & [query]]
  (-> (get-features-descriptor jaeger)
      (dissoc :_id)
      (assoc :feature-maps (get-feature-maps jaeger query))))

(defn count-classes [set]
  (->> set
       (map (comp :class :features))
       frequencies))

(defn sort-most-recent [map-group]
  (->> map-group
       (map (juxt identity #(some->> % :ids flatten seq ju/sort-ids first)))
       (sort-by (comp ju/id->vec second) ju/id-cmp)
       (map first)))

(defn select-by-id [fms oid]
  (when oid
    (->> fms
         (drop-while (comp not #{oid} str :_id))
         next
         (drop-while :validated?)
         first)))

(defn select-trainer [jaeger md5 oid]
      ; get the next unvalidated value in the md5 document
  (or (when (and md5 oid)
        (some-> (get-feature-maps jaeger {:md5 md5})
                sort-most-recent
                (select-by-id oid)))
      ; get the next unvalidated value in a random document
      (->> (get-feature-maps jaeger {:validated? nil})
           (group-by :md5)
           vals
           rand-nth
           sort-most-recent
           first)
      {}))

(defn update-trainer
  [{:keys [oid class]} & {:keys [validate?] :or {validate? true}}]
  (when (and oid class)
    (mr/updated-existing?
      (mc/update-by-id (db) "feature-maps"
                       (ObjectId. oid)
                       {:$set {:features.class class
                               :validated? validate?}}))))

(defn add-class
  [{:keys [jaeger class]}]
  (when (and jaeger class)
    (mr/updated-existing?
     (mc/update (db) "features-descriptors"
                {:_id jaeger}
                {:$addToSet {:features-descriptor.class.options class}}))))

(def evaluate-classifier
  (memo/ttl
    (fn [jaeger]
      (let [set (get-training-set jaeger {:validated? true})
            class-freqs (count-classes (:feature-maps set))]
        (-> (training-sets/training-set->classifier set)
            :evaluation
            (select-keys [:precision :recall :f-measure :percentage-correct])
            (assoc :frequencies class-freqs
                   :total-examples (apply + (vals class-freqs))))))
    :ttl/threshold five-min-in-ms))

(def get-classifier
  (memo/ttl
    (fn [jaeger]
      (-> (get-training-set jaeger {:validated? true})
          (training-sets/training-set->classifier :evaluate? false)
          :classify-fn))
    :ttl/threshold five-min-in-ms))

(defn classify-sample [jaeger trainer]
  (let [classify-fn (get-classifier jaeger)]
    (-> trainer :features classify-fn :class name)))

(defn rand-trainer [jaeger md5 oid]
  (let [{did :_id fd :features-descriptor} (get-features-descriptor jaeger)
        trainer (select-trainer jaeger md5 oid)]
    (-> (or trainer {})
        (select-keys [:value :ids :md5 :sentence :class :_id :filename])
        (rename-keys {:_id :oid})
        (update :oid str)
        (update :ids flatten)
        (assoc :total (mc/count (db) "feature-maps" {:descriptor-id did})
               :remaining (mc/count (db) "feature-maps" {:descriptor-id did :validated? nil})
               :class (when (seq trainer) (classify-sample jaeger trainer))
               :jaeger jaeger
               :options (-> fd :class :options))
        remove-nil)))


(defn select-document [jaeger]
  (when-let [md5s (seq (distinct-feature-maps jaeger :md5 {:validated? nil}))]
    (let [md5 (rand-nth md5s)]
      {:trainers (get-feature-maps jaeger {:validated? nil :md5 md5})
       :md5 md5})))

(defn clean-trainer [jaeger trainer]
  (-> trainer
      (select-keys [:_id :ids])
      (rename-keys {:_id :oid})
      (update :oid str)
      (update :ids flatten)
      (assoc :class (or (get-in trainer [:features :class]) "other"))))
             ;(classify-sample jaeger trainer)


(defn rand-document [jaeger]
  (let [fd (:features-descriptor (get-features-descriptor jaeger))
        doc (select-document jaeger)]
    (-> (or doc {:trainers []})
        (update :trainers (partial map (partial clean-trainer jaeger)))
        (assoc :total (mc/count (db) "feature-maps" {:descriptor-id jaeger})
               :remaining (mc/count (db) "feature-maps" {:descriptor-id jaeger :validated? nil})
               :options (-> fd :class :options)
               :jaeger jaeger)
        remove-nil)))

;; -----------------------------------------------------------------------------

#_(time (clojure.pprint/pprint (rand-trainer :edgar-scsf-393 "2a097b48e64d59229a6b5d0e4450e0f6" "590224e956b2842ce3428013")))
#_(time (evaluate-classifier :edgar-scsf-393))
