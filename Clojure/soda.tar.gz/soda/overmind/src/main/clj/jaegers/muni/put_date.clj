(ns jaegers.muni.put-date
  (:require [clojure.string :as str]
            [jaegers.mind-food-utils :as mfu]
            [jaegers.muni.series :as series]
            [jaegers.core :as jcr]
            [clojure.instant :refer [read-instant-date]]
            [plumbing.core :refer [defnk]]
            [jaegers.jaeger-primer :as primer]))

(def date-preregex
  "(january|february|march|april|may|june|july|august|september|october|november|december)\\s([1-3]?[0-9]),\\s((?:19|20)\\d\\d)")

(def put-date-regex
  (re-pattern (str "^(.*?)(?:subject to mandatory tender|required to be tendered|required to tender|mandatory purchase date|(?:initial |new )?mandatory tender date)(?: [\\w,\\s]+? on)?.*?(" date-preregex ")")))

(def put-date-regex2 (re-pattern (str "().*?(" date-preregex ")(?: mandatory put date).*")))

(def month->number
  {"january"   "01"
   "february"  "02"
   "march"     "03"
   "april"     "04"
   "may"       "05"
   "june"      "06"
   "july"      "07"
   "august"    "08"
   "september" "09"
   "october"   "10"
   "november"  "11"
   "december"  "12"})

(defn format-number [x]
  ({"1" "01"
    "2" "02"
    "3" "03"
    "4" "04"
    "5" "05"
    "6" "06"
    "7" "07"
    "8" "08"
    "9" "09"} x x))

(defn has-series [words]
  (when (series/valid-series words)
    words))

(defn detect-mandatory-put-dates [mind-food]
  (some->> mind-food
           mfu/mind-food->sentence-tokenvecs
           (keep (fn [[text foods]]
                   (let [clean-text (str/lower-case text)]
                     (when-let [[raw series date month day year] (or (re-find put-date-regex clean-text)
                                                                     (re-find put-date-regex2 clean-text))]
                       ;(clojure.pprint/pprint raw) ;DEBUG
                       (let [date-tokens (->> foods
                                              (drop (+ (str/index-of clean-text raw)
                                                       (str/last-index-of raw date)))
                                              (take (count date))
                                              dedupe
                                              (filter identity))
                             series-ids (when (not-empty series)
                                          (->> foods
                                               (drop (+ (str/index-of clean-text raw)
                                                        (str/last-index-of raw (not-empty series))))
                                               (take (count series))
                                               dedupe
                                               has-series
                                               (filter identity)))]
                         {:value      (read-instant-date (str year "-" (month->number month) "-" (format-number day)))
                          :ids        [(mapv :id date-tokens)]
                          :series-ids (map :id series-ids)
                          :jaeger     :put-date
                          :class      :put-date})))))))

(defn merge-put-dates [{val1 :value ids1 :ids s-ids1 :series-ids w1 :series-words}
                       {val2 :value ids2 :ids s-ids2 :series-ids w2 :series-words}]
  {:value      val1
   :ids        (concat ids1 ids2)
   :series-ids (if (and s-ids1 s-ids2)
                 (concat s-ids1 s-ids2)
                 (or s-ids1 s-ids2))
   :jaeger     :put-date
   :class      :put-date})

(defn series-filter [dates]
  (or (seq (filter (comp seq :series-ids) dates))
      dates))

(defn calc-put-date [put-dates series]
  (when-let [series-id-set (->> series :ids flatten (apply hash-set) not-empty)]
    (->> put-dates
         (keep (fn [{ids :series-ids :as put-date}]
                 (when (or (empty? ids)
                           (some series-id-set ids))
                   put-date)))
         series-filter
         (group-by :value)
         vals
         (map (partial reduce merge-put-dates))
         (sort-by :value (fn [a b] (compare b a)))
         first
         ((fn [date] (select-keys date [:value :ids :jaeger :class])))
         not-empty)))

(defnk put-date* [mind-food series*]
  (zipmap
    (keys series*)
    (map (partial calc-put-date (detect-mandatory-put-dates mind-food)) (vals series*))))

(comment
  (def memoized-query-omni-data
    (memoize (fn [q] (primer/query->omni-data q))))

  (map :put-date (run-all {:md5 "8994c2cbf2389c8efeb3a917f419cb8f"})))
