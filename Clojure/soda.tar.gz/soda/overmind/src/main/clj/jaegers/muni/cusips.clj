(ns jaegers.muni.cusips
  (:require [jaegers.spec]
            [plumbing.core :refer [defnk]]
            [soda-common.cusip :as cusip]
            ; [clojure.spec.alpha :as s]
            ; [clojure.spec.test.alpha :as stest]
            [clojure.string :as cs]
            [taoensso.timbre :as timbre]))


;Not sure if I need to do this or not. Seems to work for test docs.
(defn sanitize [s] (some-> s (cs/replace #"(^\W+)|(\W+$)" "")
                           (cs/replace #"(\()|(\))" "")))


(defn joinmaps [o n]
  (merge-with
    (partial merge-with
             (fn [a b] (if (string? a) a (vec (distinct (into a b)))))) o n))

(defn cusip-map [value id coord] {:value value :ids [[id]] :coords [[coord]]})
(defn build-cusip-2 [value id coord] {:cusip-2 {:value value :ids [[id]] :coords [[coord]]}})

(defn build-cusip
  ([c9 id coord]
   {:cusip-9 {:value c9 :ids [[id]] :coords [[coord]] :as-9 "true"}
    :cusip-6 {:value (subs c9 0 6) :ids [[id]] :coords [[coord]]}
    :cusip-3 {:value (subs c9 6 9) :ids [[id]] :coords [[coord]]}})
  ([{:keys [cusip-6]} new-cusip-3 id coord]
   (let [c9 (str (:value cusip-6) new-cusip-3)]
     {:cusip-9 (-> cusip-6 (assoc :value c9) (update-in [:ids 0] conj id) (update-in [:coords 0] conj coord))
      :cusip-6 cusip-6
      :cusip-3 (cusip-map new-cusip-3 id coord)}))
  ([{:keys [cusip-6]} {:keys [cusip-2]} new-cusip-1 id coord]
   (let [c9 (str (:value cusip-6) (:value cusip-2) new-cusip-1)]
     {:cusip-9 (-> cusip-6
                   (assoc :value c9)
                   (update-in [:ids 0] into (conj (first (:ids cusip-2)) id))
                   (update-in [:coords 0] into (conj (first (:coords cusip-2)) coord)))
      :cusip-6 cusip-6
      :cusip-3 (-> cusip-2
                   (update :value str new-cusip-1)
                   (update-in [:ids 0] conj id)
                   (update-in [:coords 0] conj coord))
      :cusip-2 cusip-2
      :cusip-1 (cusip-map new-cusip-1 id coord)})))

(defn update-cusip-6-map [cusip-6-map new-cusip-6 id coord]
  (assoc-in cusip-6-map [new-cusip-6 :cusip-6] (cusip-map new-cusip-6 id coord)))

(defn join-new-cusip [cusip-9-map {:keys [cusip-9] :as new-cusip}]
  (let [{:keys [value]} cusip-9]
    (assoc cusip-9-map value (joinmaps (cusip-9-map value) new-cusip))))

;(defn id->map [id]
;  (if (string? id) (zipmap [:page :x :y] (map edn/read-string (cs/split id #"_"))) id))
;(s/fdef id->map :ret :jaeger/id)
;(stest/instrument `id->map)

(defn find-potential-cusips [mindfood]
  (loop [[{:keys [text id] :as tok} & toks] (->> mindfood (map :vals) flatten (filter identity))
         c6s {}
         {:keys [cusip-2] :as c2} nil
         res {}]
    (when (and tok (nil? id)) (timbre/warn (str "id was nil for " tok)))
    (let [s (sanitize text)
          coord (select-keys tok [:page-number :x :y])]
      (cond
        (nil? s) res
        ;;; Conditions where cusips are found.
        ; 9
        (cusip/cusip? s)
        (let [new-cusip (build-cusip s id coord)]
          (recur toks c6s nil (join-new-cusip res new-cusip)))

        (and (re-matches #"(?i)CUSIP:.*" s) (cusip/cusip? (last (cs/split s #":"))))
        (let [new-cusip (build-cusip (last (cs/split s #":")) id coord)]
          (recur toks c6s nil (join-new-cusip res new-cusip)))
        ;6 + 3
        (and (re-matches cusip/cusip-3-rgx s) (some #(cusip/cusip? % s) (keys c6s)))
        (let [c6m (some (fn [[k v]] (when (cusip/cusip? k s) v)) c6s)
              new-cusip (build-cusip c6m s id coord)]
          (recur toks c6s nil (join-new-cusip res new-cusip)))
        ;6 + 2 + 1
        (and (not-empty c2) (some #(cusip/cusip? % (:value cusip-2) s) (keys c6s)))
        (let [c6m (some (fn [[k v]] (when (cusip/cusip? k (:value cusip-2) s) v)) c6s)
              new-cusip (build-cusip c6m c2 s id coord)]
          (recur toks c6s nil (join-new-cusip res new-cusip)))
        ;;;
        ;;New CUSIP6
        (re-matches cusip/cusip-6-rgx s)
        (recur toks (update-cusip-6-map c6s s id coord) nil res)
        ;;New CUSIP2
        (and (not-empty c6s) (re-matches cusip/cusip-2-rgx s))
        (recur toks c6s (build-cusip-2 s id coord) res)
        :default (recur toks c6s nil res)))))

; (s/fdef find-potential-cusips :ret :jaeger/docs)
; (stest/instrument `find-potential-cusips)

(defn select-most-frequent-cusip6s
  "Assuming you should never see multiple CUSIP6s in the same document, this function will filter out any cusips that
  were generated from happenstance combinations that look like cusips, but aren't. This solves the problem introduced by
  http://dev-soda-app3:8084/soda-jerk-ws/overmind/original/?md5=351b08783a6e5ed5030b8f1d1b6f5438. Note that if a bad
  CUSIP6 appears before corresponding C3s, you are pretty much SOL."
  [jaeger-docs]
  ;first, get all the ones with as-9, and anyplace where we have 2 or more keep 'em
  ;then also get the max key value.
  ;finally only keep the cusip cusips whose max 6 value are in this set.
  (let [ cusip-sixes (into #{} (some->> jaeger-docs
                                not-empty
                                (filter (comp :as-9 :cusip-9))
                                (map (comp  :value :cusip-6))
                                (frequencies)
                                (remove (comp #{1 0} second))
                                (map first)))
        most-common #{(some->> jaeger-docs
                             not-empty
                             (group-by #(-> % :cusip-6 :value))
                             (apply max-key (comp count second))
                             key)}
        all-cusips (clojure.set/union cusip-sixes most-common)]

    ;TODO remove the :as-9 flag.   I don't know if it will cause any problems
    ;otherwise.
    (filter (comp all-cusips :value :cusip-6) jaeger-docs)))


(defn clean-up-values
  "Final touch to push all the letters in the cusips to uppercase.
  for a variety of reasons we get lowercase, font choices, pdf encoding,
  poor choices made by the person entering them"
  [cusip]
  (into {} (map (fn [[k v]]  [k  (assoc v :value (cs/upper-case (:value v)))]) cusip)))

(defn find-cusips [mind-food]
  (->> mind-food
       find-potential-cusips
       vals
       select-most-frequent-cusip6s
       (map clean-up-values)))


; (s/fdef find-cusips :ret :jaeger/docs)
; (stest/instrument `find-cusips)
; (s/fdef select-most-frequent-cusip6s :ret :jaeger/docs)
; (stest/instrument `select-most-frequent-cusip6s)



; (defn filter-valid [results]
;   (filter (comp cusip/valid? :value :cusip-9) results))

(defn mind-food->cusips [mind-food]
  (->> mind-food
       (filter (comp #{1 2 3 4 5} :page-number))
       find-cusips
       (mapv (fn [m] (zipmap (keys m) (map #(assoc % :jaeger :cusips) (vals m)))))))

;Add the location of a cusip into each document by using the
;cusip jaeger return result if it exists.
; Note that it will now be impossible to generate jaeger values without msrb data.
; (defn get-the-cusips [mind-food jaeger-docs]
;   (let [cusip->cusip-doc (->> (mind-food->cusips mind-food)
;                               (map (juxt #(get-in % [:cusip-9 :value]) identity))
;                               (into {}))]
;     (map #(merge % (cusip->cusip-doc (get-in % [:cusip-9 :value]))) jaeger-docs)))

(defnk cusips* [mind-food]
  (let [cusips (mind-food->cusips mind-food)]
    (zipmap cusips cusips)))
