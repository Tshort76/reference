(ns jaegers.edgar.tokens
  (:require [edgar.parse-utils :as pu]
            [clojure.string :as cs]
            [simple-mind.parse-objects-utils :as pou]))

;TODO - MSB move this to jaegers project.

(defn extract-tokens [v]
  (letfn [(sjoin [s] (cs/join " " (filter not-empty (map pu/realtrim s))))]
    (cond
      (and (map? v) (:content v))
      (let [{:keys [content attrs page-number]} v]
        (if (every? string? content) [{:text (sjoin content) :id (:id attrs) :page-number page-number}]
                                     (extract-tokens (map extract-tokens content))))
      (nil? v) nil
      (every? :text (flatten v)) (flatten v)
      (every? string? v) {:text (sjoin v)}
      :default (extract-tokens (map extract-tokens v)))))

(defn token-regex [tokens & [regex & r]]
  (reduce
    (fn [v {objs :objs}]
      (if (not-empty r)
        (concat v (apply token-regex objs r))
        (if (not-empty objs)
          (conj v {:text (cs/join " " (map :text objs)) :ids (map :id objs)})
          v)))
    []
    (pou/rematch-in regex [:text] tokens)))
