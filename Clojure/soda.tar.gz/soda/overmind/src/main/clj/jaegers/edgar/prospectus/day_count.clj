(ns jaegers.edgar.prospectus.day-count
  (:require
    [clojure.pprint :as pp]
    [clojure.string :as string]
    [clojure.zip :as zip]
    [edgar.geometric-combo-linker :as gcl]
    [edgar.basic-features :as enf]
    [hickory.select :as hs]
    [hickory.zip :as hz]
    [jaegers.hickory-utils :as hu]
    [jaegers.mind-food-utils :as mfu]
    [jaegers.regisector :as rs]
    [medley.core :refer [find-first map-vals]]
    [plumbing.core :refer [defnk]]
    [taoensso.tufte :refer [defnp p]]
    [tokenvec.core :as tv]))

(def default {:value "30/360" :class :day-count :jaeger ::day-count :overmind-details {:method :default}})

(def re-day-count #"(?i)(30|actual|act) ?(?:/|over) ?(360|365|actual|act)")
(def re-year-basis #"(\d+)[\p{Pd}\p{Z}]day year")
(def re-month-basis #"(?:(\d+)[\p{Pd}\p{Z}]day months?)|(?:(actual) number of days)")

(def normalize
  #(-> %
       (string/replace #"(?i)act\b" "actual")
       (string/replace #"[,.;\p{Z}]" "")
       string/capitalize))

(def value-splits
  [(enf/value :day-count re-day-count :parser (fn [[_ x y]] (str (normalize x) "/" (normalize y))))
   (enf/value :year-basis re-year-basis :parser (fn [[_ x]] x))
   (enf/value :month-basis re-month-basis :parser (fn [x] (some identity (rest x))))
   (enf/value :interest-period #"(?i)(interest period)")])

(def plain-candidates
  "Returns basic day-counts from features"
  (partial filter (comp #{:day-count} :value-type :features)))

(defnp checkbox-candidates
  "Returns day-counts from features that are adjacent to checked check-boxes"
  [features]
  (->> features
       (partition 2 1)
       (keep (fn [[x y]]
               (when (and (#{:checked} (:value x))
                          (#{:check-box} (get-in x [:features :value-type]))
                          (#{:day-count} (get-in y [:features :value-type])))
                 y)))))

(defnp verbose-candidates
  "Returns day-counts from features that are composed of separate month- and year-bases"
  [features]
  (let [find-bases (juxt (partial find-first (comp #{:month-basis} :value-type :features))
                         (partial find-first (comp #{:year-basis} :value-type :features)))
        [mb yb] (when (some (comp #{:interest-period} :value-type :features) features)
                  (find-bases features))
        idx (into (:indexes mb) (:indexes yb))]
    (when (and mb yb)
      (-> mb
          (update :value #(str (normalize %) "/" (normalize (:value yb))))
          (update :ids #(vector (into (flatten %) (flatten (:ids yb)))))
          (assoc :indexes [(apply min idx) (apply max idx)])
          vector))))

(defn encandidate [m]
  (assoc m :jaeger ::day-count :class :day-count))

(defn find-day-counts [features]
  (mapcat
    (fn [fs]
      (let [checked (checkbox-candidates fs)
            verbose (verbose-candidates fs)
            plain (plain-candidates fs)]
        (cond
          (seq checked) (map encandidate checked)
          (seq verbose) (map encandidate verbose)
          (seq plain) (map encandidate plain))))
    features))

(defn tokenvecs->day-counts [enhik tvs]
  (->> (enf/tokenvecs->row-features enhik tvs value-splits)
       find-day-counts))

(defn apply-found-and-default
  "Links found days counts with non-fixed-rate securities and applies a default to fixed-rate securities"
  [day-counts cusips coupon-rate-type* ids->coords]
  (let [{:keys [fixed non-fixed]} (group-by (fn [[_ {:keys [value]}]] (if (#{:Fixed} value) :fixed :non-fixed)) coupon-rate-type*)]
    (merge (gcl/solve-for-edgar :day-count (keys non-fixed) {:day-count day-counts} ids->coords)
           (zipmap (keys fixed) (repeat default)))))

(defn apply-default
  "Applies a default day-count to fixed-rate securities"
  [coupon-rate-type*]
  (let [fixed-cusips (keys (filter (comp #{:Fixed} :value val) coupon-rate-type*))]
    (zipmap fixed-cusips (repeat default))))

(defnk day-count* [enhanced-hickory tokenvecs cusips ids->coords coupon-rate-type*]
  (let [day-counts (tokenvecs->day-counts enhanced-hickory tokenvecs)]
    (cond
      (<= 1 (count cusips) (count day-counts))
      (gcl/solve-for-edgar :day-count cusips {:day-count day-counts} ids->coords)

      (and (pos? (count cusips)) (pos? (count day-counts)))
      (apply-found-and-default day-counts cusips coupon-rate-type* ids->coords)

      :else
      (apply-default coupon-rate-type*))))
