(ns jaegers.edgar.prospectus.isin
  (:require
    [clojure.spec.alpha :as spec]
    [clojure.string :as string]
    [edgar.geometric-combo-linker :as gcl]
    [jaegers.mind-food-utils :as mfu]
    [jaegers.regisector :as rs]
    [jaegers.spec :as js]
    [plumbing.core :refer [defnk]]
    [soda-common.isin :as isin]
    [tokenvec.core :as tv]))

(def country-codes
  #{:XS :AD :AE :AF :AG :AI :AL :AM :AO :AQ :AR :AS :AT :AU :AW :AX :AZ :BA :BB
    :BD :BE :BF :BG :BH :BI :BJ :BL :BM :BN :BO :BQ :BR :BS :BT :BV :BW :BY :BZ
    :CA :CC :CD :CF :CG :CH :CI :CK :CL :CM :CN :CO :CR :CU :CV :CW :CX :CY :CZ
    :DE :DJ :DK :DM :DO :DZ :EC :EE :EG :EH :ER :ES :ET :FI :FJ :FK :FM :FO :FR
    :GA :GB :GD :GE :GF :GG :GH :GI :GL :GM :GN :GP :GQ :GR :GS :GT :GU :GW :GY
    :HK :HM :HN :HR :HT :HU :ID :IE :IL :IM :IN :IO :IQ :IR :IS :IT :JE :JM :JO
    :JP :KE :KG :KH :KI :KM :KN :KP :KR :KW :KY :KZ :LA :LB :LC :LI :LK :LR :LS
    :LT :LU :LV :LY :MA :MC :MD :ME :MF :MG :MH :MK :ML :MM :MN :MO :MP :MQ :MR
    :MS :MT :MU :MV :MW :MX :MY :MZ :NA :NC :NE :NF :NG :NI :NL :NO :NP :NR :NU
    :NZ :OM :PA :PE :PF :PG :PH :PK :PL :PM :PN :PR :PS :PT :PW :PY :QA :RE :RO
    :RS :RU :RW :SA :SB :SC :SD :SE :SG :SH :SI :SJ :SK :SL :SM :SN :SO :SR :SS
    :ST :SV :SX :SY :SZ :TC :TD :TF :TG :TH :TJ :TK :TL :TM :TN :TO :TR :TT :TV
    :TW :TZ :UA :UG :UM :US :UY :UZ :VA :VC :VE :VG :VI :VN :VU :WF :WS :YE :YT
    :ZA :ZM :ZW})

;; Note: we can't use a strict cusip regex here because foreign ISINs do not contain a cusip
(def isin-regex
  (re-pattern
    (str "\\b(?:" (string/join "|" (map name country-codes)) ")"
         "\\s?"
         "([A-Z0-9*@#]{9})"
         "\\d\\b")))

(defn tokenvec->matches
  [[sentence tokenvec]]
  (let [matches (rs/dissect sentence [{:regex isin-regex :handler (fn [v] {:value v})}])]
    (map (fn [{[isin cusip] :value indexes :indexes}]
           {:value isin
            :class :isin
            :jaeger :isin
            :ids [(mapv :id (tv/unique-tokens tokenvec indexes))]})
         matches)))

(defn find-isins [enhik]
  (->> enhik
       mfu/enhik->sentence-tokenvecs
       (mapcat tokenvec->matches)
       (filter (comp isin/valid? :value))))

(defn encandidate [xs]
  {:isin (mapv #(assoc % :class :isin) xs)})

(defnk isin* [enhanced-hickory cusips ids->coords]
  (let [isins (find-isins enhanced-hickory)]
    (if (<= 1 (count cusips) (count isins))
      (gcl/solve-for-edgar :isin cusips (encandidate isins) ids->coords))))
      ; (zipmap cusips (map fake-isin cusips))))) ;; isins should only be derived in normalization

;; -----------------------------------------------------------------------------

;; This will regenerate the set of country codes
(comment
  (require '[hickory.core :as hc])
  (require '[hickory.select :as hs])
  (->> "http://www.isin.net/country-codes"
       slurp
       hc/parse
       hc/as-hickory
       (hs/select (hs/descendant
                    (hs/id :tc_list)
                    (hs/nth-of-type 0 3 :td)))
       (map (comp keyword first :content))
       (cons :XS)
       (into #{})))

;(require 'jaegers.md5-control-sets)
;(require 'doc-transforms.core)
;(require 'clojure.data.json)
;(defn get-oracle [control]
;  (->> control
;       name
;       (str "http://dev-soda-intake-group1-app1:8084/soda_jerk_ws/api/soda-api/stats?control-name=")
;       slurp
;       clojure.data.json/read-str
;       (map clojure.walk/keywordize-keys)
;       (map (juxt (comp :lm :cusip :jaeger-doc) (comp :lm :isin :jaeger-doc)))
;       (into {})))

;(defn test-isin [control]
;  (let [oracle (get-oracle control)]
;    (->> control
;         jaegers.md5-control-sets/control-sets
;         (pmap (fn [{md5 :md5 fname :filename cusip :cusip}]
;                 (let [enhik (:enhanced-hickory (doc-transforms.core/mongo->transform :enhanced-hickory {:md5 md5}))
;                       isins (when enhik (find-isins enhik))
;                       isin (:value (get isins cusip))]
;                   (when (> (count isins) 1)
;                     [fname isins]))))
;         (remove nil?))))
