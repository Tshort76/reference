(ns jaegers.edgar.prospectus.put-date
  (:require [clojure.string :as str]
            [edgar.geometric-combo-linker :as gcl]
            [jaegers.mind-food-utils :as mfu]
            [jaegers.regisector :as rs]
            [plumbing.core :refer [defnk]]
            [tokenvec.core :as tv]
            [util.date-time :as date]))

(defn format-month [month]
  (when month
    ({"January"   1
      "February"  2
      "March"     3
      "April"     4
      "May"       5
      "June"      6
      "July"      7
      "August"    8
      "September" 9
      "October"   10
      "November"  11
      "December"  12}
     (str/capitalize month))))

(defn format-date-regex [[_ m d y]]
  (when (and m d y)
    {:value (date/new-date (Long/parseLong y)
                           (format-month m)
                           (Long/parseLong d))}))

(defn tokenvec->matches [[sentence tokenvec]]
  (->> (rs/dissect sentence [{:regex #"(?i)change of control"
                              :handler (fn [_] {:value :ignore})}
                             {:regex #"(?i)matur(e|ity)|%|\$"
                              :handler (fn [_] {:value nil})} ;; this is to force breaks in the following regexes
                             {:regex #"(?i)(?:repurchase|repayment date).*? (January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2}),\s+(\d{4})"
                              :handler format-date-regex}
                             {:regex #"(?i)(?:(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2}),\s+(\d{4})[, and]*)*\([^)]*?(?:repurchase|repayment date)"
                              :handler format-date-regex}])
       ((fn [a] (when-not (some #(= :ignore (:value %)) a)
                  a)))
       (filter :value)
       (mapv (fn [{:keys [value indexes]}]
               {:value value
                :class :put-date
                :sentence sentence
                :jaeger :put-date
                :ids [(mapv :id (tv/unique-tokens tokenvec indexes))]}))))

(defn find-put-dates [enhik]
  (mapcat tokenvec->matches
          (mfu/enhik->row-and-sentence-tokenvec enhik)))

(defnk put-date* [enhanced-hickory cusips ids->coords]
  (let [put-dates (find-put-dates enhanced-hickory)]
    (cond
      (= 1 (count (distinct (map :value put-dates))))
      (zipmap cusips (repeat (first put-dates)))
      (<= 1 (count cusips) (count put-dates))
      (gcl/solve-for-edgar :put-date cusips
                           {:put-date put-dates}
                           ids->coords)
      :else (zipmap cusips nil))))

;; ----------------------------Examples----------------------------------
;These are all single-solution :(
;(->> {:filename "0000950103-16-014570.txt"} query->omni-data lazy-jaeger :put-date)
;(->> {:filename "0000950123-08-017861.txt"} query->omni-data lazy-jaeger :put-date)
;(->> {:filename "0001193125-12-100218.txt"} query->omni-data lazy-jaeger :put-date)

; (def test-md5s
;   (map first
;        [["b415eed43a0e2e8e75cda406d1615c33" "0000950103-16-014570.txt"]
;         ["c372b690359203309bc723b0b9fbf037" "0000950123-08-017861.txt"]
;         ["a9922e03d32dfea8de01d60a10025531" "0001193125-12-100218.txt"]]))
;
; (require 'jaegers.md5-control-sets)
; (require 'doc-transforms.core)
;
; (defn get-enhik [md5]
;   (->> {:md5 md5}
;        (doc-transforms.core/mongo->transform :enhanced-hickory)
;        :enhanced-hickory))
