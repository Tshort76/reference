(ns jaegers.muni.capital-appreciation
  (:require [utils.simple-search :as search]
            [jaegers.utils :as jutil]
            [plumbing.core :refer [defnk]]))

(def search-phrases
  ["capital appreciation" "deferred interest bonds"])

(defn format-capital-appreciation [{:keys [ids coords]}]
  (if ids
    {:value  true
     :ids    ids
     :coords coords
     :class  :capital-appreciation
     :jaeger :capital-appreciation}))

(defn mind-food->capital-appreciation [mind-food]
  (->> mind-food
       (take-while (comp #(<= % 5)
                         :page-number))
       (search/search-components search-phrases)
       not-empty
       format-capital-appreciation))

;TODO need sub-series logic, right now joinging on series will produce lots of false-positives
(defnk capital-appreciation* [mind-food series*]
  (zipmap
    (keys series*)
    (jutil/assoc-nearest-series*
      (vals series*)
      #(-> % :coords flatten first)
      (vector (mind-food->capital-appreciation mind-food)))))
