(ns jaegers.edgar.prospectus.zero-coupon
  (:require
    [clojure.spec.alpha :as s]
    [jaegers.regisector :as rs]
    [jaegers.mind-food-utils :as mfu]
    [clojure.string :as string]
    [jaegers.jaeger-primer :as primer]
    [jaegers.core :as jcr]
    [plumbing.core :refer [defnk]]
    [tokenvec.core :as tv]))

(def search-terms
  [                                                         ;"no interest payments"
   "willing to forgo interest"
   "do not pay interest"
   "will not bear interest"
   "interest: not applicable"
   "do not bear interest"
   "no periodic interest payments"
   "do not pay any coupons"
   "will not pay any coupon"
   "forgo the interest payments"])

(def zero-coupon-re (re-pattern (str "(?i)" (string/join "|" search-terms))))

(defn find-zero-coupon [enhanced-hickory]
  (not-empty
    (mapcat
      (fn [[sentence tokenvec]]
        (let [results (not-empty
                        (rs/dissect
                          sentence
                          [{:regex   zero-coupon-re
                            :handler (fn [v] {:value v})}]))]
          (map
            (fn [{text :value indexes :indexes}]
              {:value  true
               :class :zero-coupon
               :text   text
               :ids    [(mapv :id (tv/unique-tokens tokenvec indexes))]
               :jaeger ::zero-coupon})
            results)))
      (mfu/enhik->sentence-tokenvecs enhanced-hickory))))

(defnk zero-coupon* [enhanced-hickory cusips]
  (let [[f :as candidates] (find-zero-coupon enhanced-hickory)]
    (zipmap
      cusips
      (cond
        (= (count candidates) (count cusips)) candidates
        f (repeat f)
        :else (repeat nil)))))

;;;;;;;;;;;;;;;;;;;;;;;;;;Examples;;;;;;;;;;;;;;;;;;;;;;;;;
; NOTE : MSB on 30/10/2017 says we can use the regisector to completely capture this and use the candidates straightaway.
; See https://jira.arbfund.com/browse/SODA-2577
;(->> {:filename "0001193125-12-291891.txt"} query->omni-data lazy-jaeger :zero-coupon*)
;(->> {:filename "0001140361-17-027036.txt"} query->omni-data lazy-jaeger :zero-coupon*)
