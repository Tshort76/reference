(ns jaegers.edgar.prospectus.maturity-date
  (:require
    [edgar.basic-features :as features]
    [edgar.geometric-combo-linker :as gcl]
    [medley.core :refer [find-first]]
    [plumbing.core :refer [defnk]]))

(defn maturity-date-like?
  [{:keys [features] :as m}]
  (and (-> features :value-type #{:date})
       (-> features :term? not)))

(def features->maturity-date
  (partial features/features->candidates :maturity-date #{:maturity-date} maturity-date-like?))

(def sort-fn
  (juxt
    (comp (partial * -1) :confidence :classifier-results)
    (comp (partial * -1) first :contributions :classifier-results)))

(defn best-from-classifier
  [{:keys [maturity-date]}]
  (some-> 
    maturity-date
    (->> (sort-by sort-fn))
    first
    (assoc :jaeger ::maturity-date)))

(defnk maturity-date*
  [enhanced-hickory candidates cusips row-sorted-features col-sorted-features ids->coords]
  (let [cands [(:maturity-date candidates)
               (mapcat features->maturity-date row-sorted-features)
               (mapcat features->maturity-date col-sorted-features)]
        best-cand (best-from-classifier candidates)
        linkable-cands (find-first #(<= 1 (count cusips) (count %)) cands)]
    (cond
      (and (= 1 (count cusips)) best-cand)
      (zipmap cusips (repeat best-cand))

      (seq linkable-cands)
      (gcl/solve-for-edgar :maturity-date cusips {:maturity-date linkable-cands} ids->coords))))
