(ns jaegers.muni.first-coupon-date
  (:require [clojure.string :as cs]
            [simple-mind.parse-objects-utils :as pou]
            [utils.simple-search :as ss]
            [clj-time.format :as f]
            [clj-time.coerce :as tc]
            [clojure.core.match :refer [match]]
            [clojure.pprint :refer [pprint]]
            [jaegers.core :as jcr]
            [jaegers.jaeger-primer :as primer]
            [jaegers.utils :as jutil]
            [taoensso.timbre :as timbre]
            [clj-time.core :as clj-time]
            [plumbing.core :refer [defnk]]
            [clj-time.coerce :as coerce]
            [utils.mind-food]))

(def required-tags-regex #"(?i)(interest|payable)")
(def word-cut-regex #" *- *")
(def roman-numeral-one-regex #"\(i\)")
(def sanitize-regex #"[,.\)\(]|[^\x00-\x7F]")
(def coupon-date-finder-regex #"(?i)interest(?!.{0,50}principal).{0,200}(?:commencing|beginning|payable|initially).{0,15}((?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|(?:nov|dec)(?:ember)?) ?[0-9]{1,2}[,]{0,1} [0-9]{4})")

(defn sanitize-word [word]
  (some-> word
          (cs/replace word-cut-regex "")
          (cs/replace sanitize-regex " ")
          (cs/replace #" {2,}" " ")
          (cs/replace roman-numeral-one-regex "1")
          (cs/trim)))

(defn multi-parse [text & parsers]
  (let [parsed-value
        (reduce (fn [text parser]
                  (try
                    (reduced (f/parse parser text))
                    (catch IllegalArgumentException _ text)))
                text parsers)]
    (if (string? parsed-value)
      (timbre/warn (str "First Coupon Date JAEGER Parse Failure: " text))
      parsed-value)))

(defn parse-date [sentence {:keys [objs text]}]
  (when-let [parsed-date (multi-parse text (f/formatter "MMM dd yyyy") (f/formatter "MMMdd yyyy"))]
    {:first-coupon-date {:value    (tc/to-date parsed-date)
                         :coords   (mapv ss/word->coord objs)
                         :sentence sentence
                         :ids      [(mapv :id objs)]
                         :jaeger   :first-coupon-date}}))

(defn has-required-words? [vals]
  (let [text (cs/join " " (map :text vals))]
    (re-find required-tags-regex text)))

(defn get-first-coupon-date [[sentence vals]]
  (when (has-required-words? vals)
    (->> vals
         (keep #(update % :text sanitize-word))
         (#(pou/rematch-in coupon-date-finder-regex [:text] % :group 1))
         (keep (partial parse-date sentence)))))

(defn extract-sentence-vals [component]
  (let [vals (-> component :vals flatten)
        sentence (cs/join " " (map :text vals))]
    (when (and vals sentence)
      [sentence vals])))

(defn aggregate-fcds [fcds]
  (map
    (fn [grouped-fcds]
      (reduce
        (fn [ret {{:keys [coords ids]} :first-coupon-date}]
          (-> ret
              (update-in [:first-coupon-date :coords] conj coords)
              (update-in [:first-coupon-date :ids] concat ids)))
        {:first-coupon-date {:value    (get-in (first grouped-fcds) [:first-coupon-date :value])
                             :sentence (get-in (first grouped-fcds) [:first-coupon-date :sentence])
                             :class    :first-coupon-date
                             :jaeger   :first-coupon-date}}
        grouped-fcds))
    (vals (group-by (comp :value :first-coupon-date) fcds))))

(defn mind-food->first-coupon-date [mind-food]
  (or
    (some-> (flatten (keep (fn [comp] (some->> comp extract-sentence-vals get-first-coupon-date not-empty)) mind-food))
            not-empty
            aggregate-fcds)
    (some->> (flatten (map :vals mind-food))
             (utils.mind-food/find-in-vals coupon-date-finder-regex)
             :matches
             (map get-first-coupon-date)
             flatten
             aggregate-fcds)))

; (defn link-by-series [cusip-docs first-coupons]
;   (jutil/aggregate-by-series
;     cusip-docs
;     (jutil/assoc-nearest-series
;       cusip-docs
;       #(-> % :first-coupon-date :coords flatten first)
;       first-coupons
;       :dist-fn jutil/manhattan-dist)))

(defn calculate-fcd [issue-dated-date maturity-date first-coupons]
  (when (and issue-dated-date maturity-date)
    (let [found-fcds (set (map #(get-in % [:first-coupon-date :value]) first-coupons))
          issue-dated-date (coerce/to-date-time issue-dated-date)
          calc-fcd (some->>
                     (iterate #(clj-time/minus % (clj-time/months 6)) (coerce/to-date-time maturity-date))
                     (take-while #(and (clj-time/after? % issue-dated-date)
                                       (> (clj-time/in-months (clj-time/interval issue-dated-date %)) 4)))
                     last
                     coerce/to-date
                     (#(array-map :first-coupon-date {:value % :jaeger :first-coupon-date :class :first-coupon-date})))]
      (when (or (not first-coupons)
                (get found-fcds (get-in calc-fcd [:first-coupon-date :value])))
        calc-fcd))))

(defn find-first-coupon-date [first-coupons {ca :value} {md :value} {idd :value} {note :value} linked-fcd]
  (cond
    note {:value md :jaeger :first-coupon-date :class :first-coupon-date}
    ca nil
    :else
    (:first-coupon-date
      (if-let [fcd (or (calculate-fcd idd md first-coupons) (first first-coupons))]
        fcd
        linked-fcd))))

(defnk first-coupon-date* [mind-food series* capital-appreciation* maturity-date* issue-dated-date* is-note*]
  (let [first-coupons (mind-food->first-coupon-date mind-food)]
    (zipmap
      (keys maturity-date*)
      (map (partial find-first-coupon-date first-coupons)
           (vals capital-appreciation*) (vals maturity-date*) (vals issue-dated-date*) (vals is-note*)
           (jutil/assoc-nearest-series*
             (vals series*) #(-> % :coords flatten first) first-coupons :dist-fn jutil/manhattan-dist)))))

(comment
  (require 'jaegers.muni.msrb-supplement
           'jaegers.muni.cusips
           'jaegers.muni.capital-appreciation
           'jaegers.muni.series
           'jaegers.muni.is-note)

  (def memoized-query-omni-data
    (memoize (fn [q] (primer/query->omni-data q))))

  (map (juxt :cusip-9 :series :first-coupon-date)
       (run-all {:md5 "0e77b833494544cc6d11dad2b1ef9ec0"})))
