(ns jaegers.cusip-linking.common
  (:require [taoensso.timbre :as timbre]
            [soda.core :as soda]))
;this is the namespace for all the multimethods expected for each data-type

(defmulti flag-other-matches
          "Add any other matching flags related just to file-type.
           ie where-traded #{\"NOT AVAILABLE\" \"NOT APPLICABLE\"}"
          (fn [file-type cusip-doc jaeger-doc] file-type))
(defmethod flag-other-matches :default [file-type cusip-doc jaeger-doc] [])


(defmulti normalize-doc
          "This fuction is for normalizing a jaeger-doc to cusip-db values"
          (fn [file-type jaeger-doc] file-type))
(defmethod normalize-doc :default [file-type jaeger-doc]
  (timbre/warn "Attempted to norm-doc with invalid data-type(" file-type ")")
  (apply merge (map (fn [[k v]] {k [v]}) jaeger-doc)))


(defmulti field-filter-fn
          "Predicate for filtering out cusip-db-docs with nothing to match on."
          (fn [data-type _] data-type))
(defmethod field-filter-fn :default [_ _] true)


(defmulti classify-match
          "Classify cusip match, adding probability of a match as a meta key"
          (fn [data-type _] data-type))
(defmethod classify-match :default [_ m]
  (timbre/warn "Attempted to classify-match with invalid data-type(" _ ")")m)


(defmulti find-possible-cusips
          "Given some jaeger-docs it attempts to find matching cusips if cusip is not present."
          (fn [jaeger-docs] (-> jaeger-docs first :meta :data-type)))
(defmethod find-possible-cusips :default [jaeger-docs]
  (timbre/warn "Attempted to find-possible-cusips with invalid data-type(" (-> jaeger-docs first :meta :data-type) ")")
  [])

(defmulti cusip-selecting-short
          "Given a data-type this will allow logic to short cusip scoring."
          (fn [original-doc _] (->> original-doc :meta :data-type)))
(defmethod cusip-selecting-short :default [_ _] nil)

(defmulti execute-cusipless-jaeger (fn [data-type omni-data] data-type))

(defmulti additional-cusips (fn dispatcher [data-type jaeger-doc] data-type))
(defmethod additional-cusips :default [data-type jaeger-doc]
  (do (timbre/info "Tried to get additional cusips with [" data-type "] data-type")
      []))


(defmulti cusip-link-needed? (fn [jaeger-doc] (-> jaeger-doc :meta :data-type)))
(defmethod cusip-link-needed? :default [_] nil)


(defmulti isin-follow-up (fn [data-type jaeger-doc best-match] data-type))
(defmethod isin-follow-up :default [data-type jaeger-doc best-match] nil)

(defn dissoc-in [coll path]
  (update-in coll (butlast path) #(dissoc % (last path))))

;will by default chop out mixed cusip6s
(defmulti cusip-6-check (fn [jaeger-docs] (first (filter (comp (into #{} (keys (methods cusip-link-needed?))) :data-type :meta) jaeger-docs))))
(defmethod cusip-6-check :default
  [jaeger-docs]
  (if (->> (keep (comp :value :cusip-9 :jaeger-doc) jaeger-docs)
           (map #(subs % 0 6))
           distinct
           count
           (< 1))
    (do (timbre/info "Removing identifiers from jaeger-docs as there were multiple cusip-6s from cusip-linking.")
      (->> jaeger-docs
           (map #(assoc-in % [:meta :cusip-linking :multiple-cusip6-problem :cusip-9] (->> % :jaeger-doc :cusip-9)))
           (map #(assoc-in % [:meta :cusip-linking :multiple-cusip6-problem :isin] (->> % :jaeger-doc :isin)))
           (map #(dissoc-in % [:jaeger-doc :cusip-9]))
           (map #(dissoc-in % [:jaeger-doc :isin]))))
    jaeger-docs))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;utility functions;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


(defn cik-sanitize->long
  "Takes a cik string and sanitizes it into a long"
  [cik]
  (cond
    (= "class java.lang.String" (str (type cik)))
    (soda/parse-long cik)

    (= "class java.lang.Long" (str (type cik)))
    cik))