(ns jaegers.ml-pipe
  (:require [surveyor-interop.enqueue-questions :as si]
            [ml.predictions :as pred]
            [surveyor-interop.ml.core :as siml]
            [taoensso.timbre :as log]
            [jaegers.taxability :refer [process-taxability-status?]]))

(def data-type->fields {:edgar-taxability-status (keys (:edgar-corporate-action si/file-type->fields))})

(defmulti should-use? (fn [data-type _] data-type))

(defmethod should-use? :default [data-type omni-data]
  (throw (ex-info (str "no should-use? fn defined for data-type=" data-type)
                  (select-keys omni-data [:md5 :mime-type :filename :asset-class
                                          :file-type :file-path :uploader :feature-flags]))))

(defmethod should-use? :edgar-taxability-status [_ {:keys [raw-file-contents] :as omni-data}]
  (and (#{:edgar-s4} (:file-type omni-data))
       (process-taxability-status? raw-file-contents)))

(defn- gather-data-types [omni-data]
  (reduce (fn [acc [data-type _]]
            (if-not (should-use? data-type omni-data)
              acc
              (conj acc data-type))) [] data-type->fields))

(defmulti post-process (fn [_ _ data-type] data-type))

(defmethod post-process :default [_ ml-doc data-type]
  (throw (ex-info (str "no post-process defined for data-type=" data-type) ml-doc)))

(defn- extract-fields [ml-doc classes]
  (filter (comp (set classes) :class) ml-doc))

(defmethod post-process :edgar-taxability-status [omni-data ml-doc data-type]
  (let [fields (group-by :class (extract-fields ml-doc (data-type data-type->fields)))
        involved-entities (:involved-entity fields)
        others (dissoc fields :involved-entity)
        jaeger-doc (-> (reduce (fn [acc [class values]]
                                 (let [best (last (sort-by :probability values))]
                                   (assoc acc class {:value (:value best)
                                                     :class class
                                                     :docs  values}))) {} others)
                       (assoc :involved-entities {:value (keep :value involved-entities)
                                                  :class :involved-entities
                                                  :docs  involved-entities})
                       (assoc :cik {:class :cik
                                    :value (get-in omni-data [:header :filer 0 :company-data 0
                                                              :central-index-key 0])
                                    :docs  []})
                       (assoc :filed-as-of-date {:class :filed-as-of-date
                                                 :value (get-in omni-data [:header :filed-as-of-date 0])
                                                 :docs  []}))]
    {:jaeger-docs [jaeger-doc]
     :meta        {:data-type data-type}}))

(defn accrete [{{:keys [accrete-ml-pipeline-predictions-in-jaegers
                        use-retrieval-in-ml-pipe-jaegers]} :feature-flags
                :keys [md5 query-db file-type] :as omni-data}]
  (when (and accrete-ml-pipeline-predictions-in-jaegers (not-empty md5) query-db)
    (when-let [data-types (not-empty (gather-data-types omni-data))]
      (when-let [ml-result
                 (not-empty (try
                              (pred/prediction-pipeline
                                query-db
                                (siml/file-type->source file-type)
                                {:use-retrieval? (true? use-retrieval-in-ml-pipe-jaegers)})
                              (catch Exception e (do (log/debug e (str "error calling prediction-pipeline on md5=" md5)) nil))))]
        (keep (partial post-process omni-data ml-result) data-types)))))
