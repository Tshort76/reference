(ns jaegers.edgar.cluster
  (:require
    [clojure.string :as string]
    [medley.core :refer [map-vals]]
    [taoensso.tufte :refer [defnp]]
    [simple-mind.k-means :as km]

    [jaegers.utils :as ju]))

(defn find-clusters [fields & means]
  (let [ids (map (comp ju/id->vec ffirst :ids) fields)
        means (or means
                  (->> fields
                       (map (comp ffirst :ids))
                       ju/sort-ids
                       (mapv ju/id->vec) 
                       ((juxt first last))
                       (map (partial take 2))))]
    (first ((km/k-groups ids km/vec-distance km/vec-average) means))))

(defn idv->field [fields idv]
  (let [id (string/join #"_" idv)]
    (first (filter (comp #{id} ffirst :ids) fields))))

(defn cluster-fields [fields & [means]]
  (->> (apply (partial find-clusters fields) means)
       (map (fn [cl] (map (partial idv->field fields) cl)))
       (sort-by (fn [x] (->> x (map (comp ffirst :ids)) ju/sort-ids first ju/id->vec)) 
                ju/id-cmp)))

(defn merge-field
  "Given a cusip-level document, finds the best match for field among the
   candidates in cluster (a sequence of candidate solutions)."
  [cluster cusip-doc field]
  (let [top-cusip (-> cusip-doc :cusip-9 :ids flatten ju/sort-ids first ju/id->vec)
        min-fn #(km/vec-distance top-cusip (-> % :ids ffirst ju/id->vec))
        candidates (filter (comp #{field} :class) cluster)]
    (cond-> cusip-doc
      (seq candidates) (assoc field (apply min-key min-fn candidates)))))

(defn merge-doc
  "Given a cusip-level document, finds the best match for each field. Candidate
   solutions are clustered and clusters are searched sequentially from document
   start."
  [clusters fields cusip-doc]
  (loop [wanted (into #{} fields)
         clusters clusters
         cusip-doc cusip-doc]
    (if (or (empty? wanted) (empty? clusters))
      cusip-doc
      (let [new-doc (reduce (partial merge-field (first clusters)) cusip-doc wanted)]
        (recur (apply disj wanted (keys new-doc)) (rest clusters) new-doc)))))
