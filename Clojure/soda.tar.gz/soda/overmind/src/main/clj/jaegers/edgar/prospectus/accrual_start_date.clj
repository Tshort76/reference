(ns jaegers.edgar.prospectus.accrual-start-date
  (:require
    [edgar.basic-features :as enf]
    [edgar.geometric-combo-linker :as gcl]
    [medley.core :refer [find-first]]
    [plumbing.core :refer [defnk]]))

(defn accrual-start-date-like?
  [{:keys [features]}]
  (-> features :value-type #{:date}))

(def features->accrual-start-date
  (partial enf/features->candidates :accrual-start-date #{:accrual-start-date} accrual-start-date-like?))

(defn apply-default [xs]
  (map #(assoc % :class :accrual-start-date, :jaeger ::accrual-start-date) xs))

(defnk accrual-start-date*
  [enhanced-hickory cusips issue-date* row-sorted-features col-sorted-features ids->coords]
  (let [cands [(mapcat features->accrual-start-date row-sorted-features)
               (mapcat features->accrual-start-date col-sorted-features)]
        linkable-cands (find-first #(<= 1 (count cusips) (count %)) cands)]
    (if linkable-cands
      (gcl/solve-for-edgar :accrual-start-date cusips {:accrual-start-date linkable-cands} ids->coords)
      (zipmap (keys issue-date*) (apply-default (vals issue-date*))))))
