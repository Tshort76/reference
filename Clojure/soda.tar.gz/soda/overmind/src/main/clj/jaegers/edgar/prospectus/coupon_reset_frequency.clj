(ns jaegers.edgar.prospectus.coupon-reset-frequency
  (:require [clojure.string :as str]
            [edgar.geometric-combo-linker :as gcl]
            [medley.core :as med]
            [plumbing.core :refer [defnk]]
            [jaegers.mind-food-utils :as mfu]
            [jaegers.regisector :as rs]
            [tokenvec.core :as tv]))

(defn safe-min
  ([] nil)
  ([a] a)
  ([a b & args] (apply min a b args)))

(defn safe-max
  ([] nil)
  ([a] a)
  ([a b & args] (apply max a b args)))

(defn add-coords [m objects]
  (assoc m :min-x (apply safe-min (keep :min-x objects))
         :max-x (apply safe-max (keep :max-x objects))
         :min-y (apply safe-min (keep :min-y objects))
         :max-y (apply safe-max (keep :max-y objects))))

(defn format-index-values [sentence tokenvec {:keys [indexes value]}]
  (let [tokens (tv/unique-tokens tokenvec indexes)]
    (add-coords
     {:value value
      :text  sentence
      :class :make-whole-call-spread
      :ids   [(mapv :id tokens)]}
     tokens)))

(defn rate-matches [tag-regex [sentence tokenvec]]
  (->> (rs/dissect sentence
                   [{:regex tag-regex
                     :handler (fn [v] {:value :use})}
                    {:regex #"(?i)(?<! [^x] )semi.?annually"
                     :handler (fn [v] {:value "Semi-annually"})}
                    {:regex #"(?i)each month"
                     :handler (fn [v] {:value "Monthly"})}
                    {:regex #"(?i)(?<! [^x] )quarterly|annually|weekly|monthly|daily"
                     :handler (fn [v] {:value (str/capitalize v)})}])
       ((fn [rs]
          (when (some (comp #{:use} :value) rs)
            (remove (comp #{:use} :value) rs))))
       (mapv (partial format-index-values sentence tokenvec))))

(defn merge-matches [matches]
  (add-coords
   {:value (->> (keep :value matches)
                distinct
                count
                {1 "Annually"
                 2 "Semi-annually"
                 4 "Quarterly"
                 12 "Monthly"})
    :text  (-> matches first :text)
    :class :make-whole-call-spread
    :ids   [(vec (apply concat (mapcat :ids matches)))]}
   matches))

(defn month-matches [tag-regex [sentence tokenvec]]
  (some->> (rs/dissect sentence
                       [{:regex tag-regex
                         :handler (fn [v] {:value :begin})}
                        {:regex #"January|February|March|April|May|June|July|August|September|October|November|December"
                         :handler (fn [v] {:value v})}
                        {:regex #"(?i)beginning|commencing"
                         :handler (fn [v] {:value :end})}])
           (drop-while (fn [x] (not= :begin (:value x))))
           (remove (fn [x] (= :begin (:value x))))
           (take-while (fn [x] (not= :end (:value x))))
           (map (partial format-index-values sentence tokenvec))
           (group-by (fn [x] (->> x :ids first first (re-find #"(.*)_\d+") second)))
           vals
           (mapv merge-matches)))

(defn tokenvec-apply [func regex tokenvec]
  (seq (mapcat (partial func regex) tokenvec)))

(defn find-coupon-reset-frequency [enhik]
  (let [tokenvec (mfu/enhik->row-and-sentence-tokenvec enhik)]
    (or (tokenvec-apply rate-matches #"(?i)interest reset" tokenvec)
        (tokenvec-apply month-matches #"(?i)interest reset dates" tokenvec))))

(defnk coupon-reset-frequency* [coupon-rate-type* coupon-frequency* ids->coords enhanced-hickory]
  (let [cusips (keys (filter (fn [[_ {:keys [value]}]]
                               (#{:Floating :Fixed-to-float :Float-to-fixed} value))
                             coupon-rate-type*))
        candidates (find-coupon-reset-frequency enhanced-hickory)]
    (if (<= 1 (count cusips) (count candidates))
      (gcl/solve-for-edgar :coupon-reset-frequency cusips
                           {:coupon-reset-frequency (mapv #(assoc % :class :coupon-reset-frequency)
                                                       candidates)}
                           ids->coords)
      (->> coupon-frequency*
           (med/filter-keys (set cusips))
           (med/map-vals #(when (#{"Annually" "Semi-annually" "Quarterly" "Monthly" "Weekly" "Daily"}
                                  (:value %))
                            (assoc % :class :coupon-reset-frequency
                                   :jaeger :jaegers.edgar.prospectus.coupon-reset-frequency/coupon-reset-frequency)))))))

;; -----------------------------------------------------------------------------
;These all have 0 or 1 reset freq.
;(->> {:filename "0001193125-10-200170.txt"} query->omni-data lazy-jaeger :coupon-reset-frequency)
;(->> {:filename "0000891092-14-004118.txt"} query->omni-data lazy-jaeger :coupon-reset-frequency)
;(->> {:filename "0001193125-16-529032.txt"} query->omni-data lazy-jaeger :coupon-reset-frequency)
;(->> {:filename "0000950103-11-000270.txt"} query->omni-data lazy-jaeger :coupon-reset-frequency)

; (def test-md5s
;   (map first
;        [["8be6c844fda6f5a9612c83a8cf905ae3" "0001193125-10-200170.txt"]
;         ["fcec1a6e328d6293ce618b8888efdc2e" "0000891092-14-004118.txt"]
;         ["53ae15ed836b6f7009ff7abdb41fc8d9" "0001193125-16-529032.txt"]
;         ["efe7c767334d0d810f92f907938ef21a" "0000950103-11-000270.txt"]]))
;
; (require 'jaegers.md5-control-sets)
; (require 'doc-transforms.core)
; ; (require 'clojure.data.json)
;
; (defn get-enhik [md5]
;   (->> {:md5 md5}
;        (doc-transforms.core/mongo->transform :enhanced-hickory)
;        :enhanced-hickory))
