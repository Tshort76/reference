(ns jaegers.edgar.cusips
  (:require [jaegers.core :as jcr]
            [jaegers.spec]
            [enhanced-hickory.tokenvec :as eht]
            [clojure.edn :as edn]
            [clojure.string :as cs]
            [jaegers.edgar.utils :refer [log-distance]]
            [jaegers.utils :as ju]
            [edgar.cusip-utils.cusip-finder :as cf]
            [mind-food.core :as mfc]
            [clojure.spec.alpha :as spec]
            [clojure.spec.alpha :as s]
            [soda-common.cusip :as cusip]
            [soda.core :as soda]
            [taoensso.tufte :refer [p]]))

(defn ensure-proximity [finds]
  (let [{:keys [cusip string]} (group-by #(get #{:cusip} (first %) :string) finds)]
    (distinct
      (for [[_ ida] cusip [cstr idb text] string
            :when (<= (log-distance ida idb) 2)]
        [(cs/upper-case cstr) (cs/join "_" idb) text]))))

(defn group-securities [securities]
  (let [g (group-by first securities)]
    (zipmap (keys g) (mapv (juxt #(mapv (comp vector second) %) (comp last last)) (vals g)))))

(defn explicit-search [enhik]
  ; {:pre [(or (nil? enhik) (spec/assert :enhanced-hickory/document enhik))]}
  (some->> enhik
       eht/enhik->tokenvecs
       (filter (fn [[_ vec]] (not (nil? (:id (first vec))))))
       (mapcat (fn [[sentence token-vec]]
                 (let [idv (ju/id->vec (:id (first token-vec)))]
                   (into (cond-> [] (cf/has-cusip-word? sentence) (conj [:cusip idv sentence]))
                         (map (fn [cusip] [cusip idv sentence]) (cf/line->cusips sentence))))))
       ensure-proximity
       group-securities))

;(def tvs
;  (-> "ES1011620-ES792606-ES1193978.pdf"
;    (mfc/pdf->mind-food [3 3])
;    mfc/mind-food->enhik
;    ;(->> (s/conform :enhanced-hickory/document))
;    hu/enhik->tokenvecs
;    ;(->> (map first))
;    ;explicit-search
;    ))
;
;(defn cusip-search [wordseq]
;  (loop [[c6 & r] (drop-while (complement (partial re-matches cusip/cusip-6-rgx)) wordseq)
;         cusips (set (keep (comp second (partial re-matches cusip/cusip-9-rgx)) wordseq))]
;    (if (seq r)
;      (let [[_ c6actual] (re-matches cusip/cusip-6-rgx c6)
;            c3s (keep (comp second (partial re-matches cusip/cusip-3-rgx)) r)
;            cusip63s (keep (partial cusip/cusip? c6actual) c3s)
;            c21s (partition 2 1 r)
;            cusip621s (keep (fn [[c2 c1]] (cusip/cusip? c6actual c2 c1)) c21s)]
;        (recur r (-> cusips (into cusip63s) (into cusip621s))))
;      cusips)))

(defn enhik->cusip-docs
  [enhik]
  (->> enhik
       explicit-search
       (mapv (fn [[k [ids text]]]
               (let [m {:ids ids :text text :jaeger ::cusips}]
                 {:cusip-3 (assoc m :value (subs k 6 9))
                  :cusip-6 (assoc m :value (subs k 0 6))
                  :cusip-9 (assoc m :value k)})))))
