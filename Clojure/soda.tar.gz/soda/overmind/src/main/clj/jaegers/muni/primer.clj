(ns jaegers.muni.primer
  (:require
    ; [medley.core :refer [map-vals]]
    [soda-common.parsers :as scp]
    [soda-common.regexes :as re]
    ; [jaegers.edgar.classifiers.asset-class :as asset-class]
    [jaegers.edgar.classifiers.candidates :as candidates]
    [jaegers.edgar.cusips :as cusips]
    [jaegers.features.enfeature :as enfeature]
    [jaegers.hickory-utils :as hu]
    [enhanced-hickory.util :as ehu]
    [jaegers.mind-food-utils :as mfu]
    [jaegers.regisector :as rs]
    [jaegers.tokenvec-solver :as solver]
    ; [html.utils :as html]
    [plumbing.core :refer [?>>]]
    ; [soda.data.file-system :as sdfs]
    ; [edgar.tfidf-enfeaturing :as tfidf-enf]
    [clojure.string :as cs]
    ; [clojure.pprint :as pp]
    [utils.mind-food :as umf]))

(def provides
  {:accrual-start-date :date
   :face-value         :dollars
   :first-coupon-date  :date
   :interest-rate      :percent
   :issue-date         :date
   :issue-price        :percent
   :maturity-date      :date
   :principal-amount   :dollars
   :call-option-date   :date})

(def interesting-words
  (->> ["aggregate" "allocation" "amount" "annual" "annum" "authorized"
        "beginning" "benchmark"
        "call" "callable" "certificate" "commencing" "coupon" "cusip"
        "date" "delivery" "denomination" "due"
        "face" "first" "fixed" "frequency"
        "gross"
        "inception" "increment" "information" "initial" "interest" "issue"
        "mandatory" "maximum" "maturity" "minimum" "multiple"
        "note" "number"
        "offering" "offered" "option" "optional" "original"
        "par" "payment" "price" "pricing" "principal" "prospectus"
        "rate" "record" "redemption" "registration"
        "securities" "security" "settlement" "size" "spread" "state" "stated" "supplement"
        "tax" "term" "title" "total" "trade" "treasury"
        "yield"]
       (map (fn [w] {(keyword (str w "-word")) (re-pattern (str "(?i)(?:^|\\b)" w "(?:\\b|$)"))}))
       (into {})))

(def interesting-terms
  {:key-like          #"(\w+:)"
   :interest-rate     #"(?i)(coupon|((interest|coupon|annual) rate)|(fixed rate note)):?"
   :issue-date        #"(?i)(((original )?(issue|issuance|settle(ment)?) date)|(date of issue)):?"
   :maturity-date     #"(?i)((stated )?maturity( date)?|matur(e|ing|ities)):?"
   :principal-amount  #"(?i)((aggregate )?(principal|face) amount)( offered)?:?"
   :issue-price       #"(?i)(initial )?((price to public)|(issue price)|((public )?offering price)):?"
   :first-coupon-date #"(?i)(1\s?st |first )?(((interest )?pay(ment)?)|coupon) dates?:?"
   :call-option-date  #"(?i)(((optional )?redemption( information| provisions)?)):?"})

(def re-percent #"((?:\d|[1-9]\d|1\d{2})|(?:\.\d+)|(?:\d|[1-9]\d|1\d{2})\.\d+)\s?%")
(def re-money #"\$?(\d{1,3})(,\d{3})+(\.\d{1,2})?")
(def re-double #"(\d{1,3}\.\d{1,3})")
(def re-number #"\b(\d\d++)\b")
(def muni-four-year #"\b((?:19|20|21)\d{2})\b")

(def term-splits
  (let [split-def (fn [[kw re]] {:regex re :handler (fn [[s]] {:value s :features {:value-type kw :term? true}})})]
    (into (map split-def interesting-words) (map split-def interesting-terms))))

(defn month-day-formatter [month-day]
  (let [a-parse (scp/parse (cs/trim month-day))]
    (str (a-parse :month-of-year) "/" (a-parse :day-of-month))))

; (defn pass-through-debug [data]
;   (taoensso.timbre/debug (with-out-str (pp/pprint data)))
;   data)

(def value-splits
  [{:regex re-percent :handler (fn [[s]] {:value (-> s scp/parse first val double) :features {:value-type :percent}})}
   {:regex re/date :handler (fn [[s]] {:value (:date (scp/parse s)) :features {:value-type :date}})}
   {:regex re-money :handler (fn [[s]] {:value (-> s scp/parse first val double) :features {:value-type :dollars}})}
   {:regex muni-four-year :handler (fn [s] {:value (-> s first scp/parse first val) :features {:value-type :year}})}
   {:regex re/month-day :handler (fn [[s]] {:value (month-day-formatter s) :features {:value-type :month-day}})}
   {:regex #"(?i)(date of delivery|delivery date|dated date)" :handler (fn [[s]] {:value s :features {:value-type :reference-date}})}
   {:regex re-double :handler (fn [[s]] {:value (Double/parseDouble s) :features {:value-type :number}})}
   {:regex re-number :handler (fn [s] {:value (-> s first scp/parse first val) :features {:value-type :number}})}])

(def split-set (reduce into [] [value-splits term-splits]))
(defn dissect-text [s] (rs/dissect s split-set))

(def features-descriptor
  (merge
    {:class               {:options [:accrual-start-date
                                     :face-value
                                     :first-coupon-date
                                     :interest-rate
                                     :issue-date
                                     :issue-price
                                     :maturity-date
                                     :other
                                     :principal-amount
                                     :call-option-date]
                           :default :other}
     :value-type          {:options [:date :percent :dollars :number :year :month-day :reference-date]}
     ; general features
     :page-number         {:options :implicit}
     :vert-alignment      {:options hu/vert-align-values}
     :horiz-alignment     {:options hu/horiz-align-values}
     :words-in-block      {:options :implicit}
     ; value features
     :magnitude           {:options :implicit}
     :multiple-of-1000?   {:options [:true :false] :default false}
     :precision           {:options :implicit}
     ; table features
     :table-nest-depth    {:options :implicit}
     :col-count           {:options :implicit}
     :row-count           {:options :implicit}
     :words-in-table      {:options :implicit}
     ; table cell features
     :words-in-row        {:options :implicit}
     :words-in-col        {:options :implicit}
     :words-in-row-before {:options :implicit}
     :words-in-row-after  {:options :implicit}
     :words-in-col-above  {:options :implicit}
     :words-in-col-below  {:options :implicit}
     :first-column?       {:options [:true :false] :default false}
     :last-column?        {:options [:true :false] :default false}
     :first-row?          {:options [:true :false] :default false}
     :last-row?           {:options [:true :false] :default false}}
    ; word/value features
    (->> (for [term (concat (map key interesting-words) [:date :percent :dollars :number])
               sfx ["-terms-before" "-terms-after" "-terms-in-row-before" "-terms-in-row-after" "-terms-in-col-above" "-terms-in-col-below"]]
           {(keyword (str (name term) sfx)) {:options :implicit :default 0}})
         (apply merge))
    ; term (keyword) features
    (->> (for [term (map key interesting-terms)
               sfx ["-terms-before" "-terms-in-row-before" "-terms-in-col-above" "-terms-in-nearest-row-label"]]
           {(keyword (str (name term) sfx)) {:options :implicit :default 0}})
         (apply merge))))

; (def simple-features-descriptor
;   (map-vals (fn [{:keys [options] :as m}]
;               (if (#{:implicit} options) :implicit m))
;             features-descriptor))

(defn enfeature-enhik
  ([enhik]
   (enfeature-enhik enhik 10))
  ([enhik max-pages]
   (let [db (enfeature/enhik->db dissect-text enhik)]
     (some->>
       enhik
       (?>> (pos? max-pages) (ehu/filter-pages max-pages))
       mfu/enhik->sentence-tokenvecs
       (enfeature/enfeature-tokenvecs db features-descriptor dissect-text)))))

(def xform
  (comp (map #(assoc % :class (-> % :classifier-results :class)))
        ;(filter #(= (provides (:class %)) (get-in % [:features :value-type])))
        (map #(dissoc % :string :sentence :indexes :features))))
        ;(filter (comp provides :class))


(defn classify-candidates
  ([enhanced-hickory normalizer classifier]
   (some->> enhanced-hickory
            enfeature-enhik
            (map normalizer)
            (apply solver/classify-featuremaps classifier)
            (sequence xform)
            (group-by :class)))
  ([{:keys [enhanced-hickory] :as omni-data}]
   (let [[normalizer classifier] (candidates/select-model omni-data)]
     (classify-candidates enhanced-hickory normalizer classifier))))

(defn ->candidates
  "Convenience function for classifying candidates in enhik using the model
   specified by asset-class. asset-class is in #{:abs :cmo :corp :equity} and
   defaults to :corp."
  [enhik & [asset-class]]
  (classify-candidates
    {:enhanced-hickory enhik
     :asset-class      (or asset-class :corp)
     :cusip-docs       (cusips/enhik->cusip-docs enhik)}))

;;this hackerish
(defn umf->candidate-form [class umf-candidate]
  {:value (first umf-candidate)
   :ids   (vec (second umf-candidate))
   :class class})

(defn umf-candidates [mind-food class regex]
  (let [class-matches (umf/find-in-mindfood regex mind-food)
        class-texts (mapcat :matches class-matches)
        targets (map (juxt first (comp (fn [d] (map :id d)) second)) class-texts)]
    {class (map (partial umf->candidate-form class) targets)}))

(def extra-candidates
  {:floating-rate #"(LIBOR)|(SIFMA)"})

(defn ->extra-candidates [omni-doc]
  (let [extra-data (into {} (map (fn [[class regex]]
                                   (umf-candidates (:mind-food omni-doc) class regex))
                                 extra-candidates))]
    (assoc omni-doc :candidates (merge (:candidates omni-doc) extra-data))))

; (defn classify-html-asset
;   [html]
;   (let [[binary-tfidf binary-classifier] (:binary asset-class/models)
;         [multiclass-tfidf multiclass-classifier] (:multiclass asset-class/models)]
;     (or (-> html (tfidf-enf/enfeature-tfidf binary-tfidf) binary-classifier :class #{:corp})
;         (-> html (tfidf-enf/enfeature-tfidf multiclass-tfidf) multiclass-classifier :class))))

; (defn classify-asset-class
;   [query]
;   (classify-html-asset (-> query sdfs/find-file :input-stream slurp html/html-contents)))
