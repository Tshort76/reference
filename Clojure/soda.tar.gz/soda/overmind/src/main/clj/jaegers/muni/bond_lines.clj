(ns jaegers.muni.bond-lines
  (:require [soda-common.regexes :as rgx]
            [soda-common.parsers :as scp]
            [jaegers.mind-food-utils :as mfu]
            [jaegers.regisector :as r]
            ; [ml.training-sets :as training-sets]
            [soda.data.core :refer [defcon]]
            [clojure.java.io :as io]
            [ml.classifiers :as mlc]
            [clojure.edn :as edn]
            ; [clj-ml.io :refer [save-instances]]
            [jaegers.tokenvec-solver :as ts]
            [plumbing.core :refer [defnk]]
    ;[jaegers.bond-lines :as bl]
            [clojure.set :as st]))

(defcon "soda-raw" "mindfood")
(defcon "mekadragon" "training-sets")

(def decision-tree
  (-> "jaegers/bond_lines_decision_tree.edn" io/resource slurp edn/read-string)
  ;(training-sets/training-set->decision-tree (find-training-sets {:jaeger :bond-lines-redux-2}))
  )
(def classifier (partial mlc/classify decision-tree))

;(save-instances
;  :arff
;  "foo.arff"
;  (training-sets/training-set->weka-data-set (find-training-sets {:jaeger :prospectus-dates})))

#_(save-instances
    :arff
    "bond-lines.arff"
    (training-sets/training-set->weka-data-set (find-training-sets {:jaeger :bond-lines-redux})))

(def interesting-words
  (sort #(>= (count %1) (count %2))
        #{"price" "priced" "to" "at" "yield" "initial" "suffix" "issue" "serial" "term"
          "bond" "bonds" "certificate" "certificates" "due" "maturing" "cusip"}))

(def pct #"((?:\d|[1-9]\d|1\d{2})|(?:\.\d+)|(?:\d|[1-9]\d|1\d{2})\.\d+)\s?%")
(def dbl #"\d{1,3}\.\d{1,3}")
(def money #"\$?(\d{1,3})(,\d{1,3})+(\.\d{1,3})?")

(def word-splits
  (into [{:regex #"(?i)(no\.|number)" :handler (fn [[s]] {:value-type :number})}]
        (mapv (fn [w] {:regex   (re-pattern (str "(?i)(" w ")"))
                       :handler (fn [[s]] {:value-type (keyword w)})})
              interesting-words)))

(def value-splits
  [{:regex rgx/month-day-year :handler (fn [[s]] {:value (:date (scp/parse s)) :features {:value-type :date}})}
   {:regex   #"([A-Z0-9]{6})\s?([A-Z0-9]{2})\s?(\d)"
    :handler (fn [[_ c6 c2 c1]] {:value (str c6 c2 c1) :features {:value-type :cusip-9}})}
   {:regex pct :handler (fn [[s]] {:value (:percent (scp/parse s)) :features {:value-type :percent}})}
   {:regex money :handler (fn [[s]] {:value (-> s scp/parse first val) :features {:value-type :dollars}})}
   {:regex dbl :handler (fn [s] {:value (Double/parseDouble s) :features {:value-type :number}})}
   {:regex #"\d{4}" :handler (fn [s] {:value (Integer/parseInt s) :features {:value-type :year}})}])

(def cusip-3-split [{:regex   #"([A-Z0-9]{2})\s?(\d)"
                     :handler (fn [[_ c2 c1]] {:value (str c2 c1) :features {:value-type :cusip-3}})}])

(def split-set (reduce into [] [value-splits word-splits cusip-3-split]))

(defn dissect-bond-lines [s] (r/dissect s split-set))
(defn process-bond-line [s] (->> s dissect-bond-lines (remove :other-type)))

(defn page-filter [{:keys [page-number]}] (<= page-number 5))

(defn characterize-term [t]
  (cond
    (nil? t) :none
    (:value t) (-> t :features :value-type)
    :default t))

(def value-options [:cusip-9 :cusip-3 :percent :dollars :date :number :year])
(def interesting-keywords (map keyword interesting-words))
(def LR-options (reduce into #{:none} [interesting-keywords value-options]))

(def feature-descriptor
  {:first?           :implicit
   :last?            :implicit
   :pre-terms-num    :implicit
   :post-terms-num   :implicit
   :numeric?         :implicit
   :gt100?           :implicit
   :gt1000?          :implicit
   :gt10000?         :implicit
   :preceding-value? :implicit
   :precedes-value?  :implicit
   :R1               {:options LR-options}
   :R2               {:options LR-options}
   :R3               {:options LR-options}
   :L1               {:options LR-options}
   :L2               {:options LR-options}
   :L3               {:options LR-options}
   :value-type
                     {:options value-options}
   :class
                     {:options
                      #{:cusip-9 :cusip-3 :maturity-date :maturity-year :principal-amount :interest-rate :price :yield :?}}})

(defn bond-line-characterizer [pre {:keys [value] :as v} post]
  (let [[L1 L2 L3] (reverse pre)
        [R1 R2 R3] post]
    (-> v (update :features into
                  {:first?           (empty? pre)
                   :last?            (empty? post)
                   :pre-terms-num    (count (remove :value pre))
                   :post-terms-num   (count (remove :value post))
                   :numeric?         (number? value)
                   :gt100?           (and (number? value) (> value 100))
                   :gt1000?          (and (number? value) (> value 1000))
                   :gt10000?         (and (number? value) (> value 1000))
                   :preceding-value? (some? (:value L1))
                   :precedes-value?  (some? (:value R1))
                   :R1               (characterize-term R1)
                   :R2               (characterize-term R2)
                   :R3               (characterize-term R3)
                   :L1               (characterize-term L1)
                   :L2               (characterize-term L2)
                   :L3               (characterize-term L3)})
        (assoc :features-descriptor feature-descriptor))))

(defn bond-line-fragment? [frags]
  (let [toks (map (fn [k] (cond-> k (:features k) (get-in [:features :value-type]))) frags)
        tokset (set toks)]
    (>= (count (filter tokset [:cusip-9 :cusip-3 :cusip :date :dollars :percent :number])) 3)))

(defn parse [line]
  (let [pbl (process-bond-line line)]
    (when (bond-line-fragment? pbl)
      (mfu/characterize-values pbl :characterizer bond-line-characterizer))))

(defn mind-food->feature-maps [mind-food]
  (-> {:mind-food mind-food}
      (mfu/tokenvec-stream :prefilter page-filter :mind-food-splitter mfu/mind-food->line-tokenvecs)
      (mfu/enfeature-tokenvecs parse)
      (->> (map #(assoc % :jaeger :bond-lines-redux)))))

(defn mind-food->classified-feature-maps [mind-food]
  (-> mind-food
      mind-food->feature-maps
      (->> (apply ts/classify-featuremaps classifier)
           (map #(assoc-in % [:features :class] (get-in % [:classifier-results :class]))))))

;;;;;;;;;;;;;;;;;;
(defn distinct-keys? [a b]
  (empty? (st/intersection (set (keys a)) (set (keys b)))))

(defn avg [r]
  (let [n (count r)]
    (-> (reduce (fn [c {:keys [page-number x y]}]
                  (-> c (update :x + x) (update :y + y (* 800 page-number))))
                {:x 0.0 :y 0.0} r)
        (update :x / n)
        (update :y / n))))

(defn centroid [m] (->> m vals (map :coords) flatten avg))

(defn characterize [a b]
  (let [{ax :x ay :y} (centroid a)
        {bx :x by :y} (centroid b)
        ^double dx (- ax bx)
        ^double dy (- ay by)]
    {:dy (Math/abs dy) :dx (Math/abs dy) :dist (Math/sqrt (+ (* dx dx) (* dy dy))) :that b}))

(defn best-merge-candidate [candidate options]
  (when-some [distinct-fragments (not-empty (filter (partial distinct-keys? candidate) options))]
    (let [o (->> distinct-fragments
                 (map (partial characterize candidate))
                 (filter (fn [{:keys [dy]}] (< dy 100)))
                 (sort-by (juxt :dy :dist))
                 not-empty)]
      (some->> o first :that))))

(defn best-new-candidate [c]
  (some->> c not-empty (apply max-key count)))

(defn assemble [assembly-function fragments]
  (loop [candidate (best-new-candidate fragments) merge-candidates (disj (set fragments) candidate) res []]
    (if candidate
      (if-some [c (best-merge-candidate candidate merge-candidates)]
        (recur (into candidate c) (disj merge-candidates c) res)
        (let [next-candidate (best-new-candidate merge-candidates)]
          (recur next-candidate
                 (disj merge-candidates next-candidate)
                 (cond-> res (assembly-function candidate) (conj candidate)))))
      res)))

(defn mostly-complete? [{:keys [maturity-date principal-amount interest-rate cusip-3 cusip-9]}]
  (and maturity-date principal-amount interest-rate (or cusip-9 cusip-3)))
;;;;;;;;;;;;;;;;;;

(defn mind-food->bond-lines [mind-food]
  (->> (mind-food->classified-feature-maps mind-food)
       (group-by :sentence)
       vals
       (mapcat #(ts/solve-all-fields % :distinct-fields [:cusip-9 :cusip-3 :maturity-date :principal-amount :interest-rate :price :yield]))
       (assemble mostly-complete?)))

(defn link-with-cusips [cusips bond-lines]
  (map (comp :value :cusip-9)
       (let [cusip->bondline (group-by (comp :value :cusip-9) bond-lines)]
         (reduce
           (fn [ret {{cusip :value} :cusip-9}]
             (conj ret (first (cusip->bondline cusip))))
           []
           cusips))))

(defnk bond-lines [mind-food cusips*]
  (zipmap
    (keys cusips*)
    (link-with-cusips (vals cusips*) (mind-food->bond-lines mind-food))))

;(dissect-bond-lines "$2,935,000 3.750% BONDS DUE SEPTEMBER 15, 2032, TO YIELD 3.000%, CUSIP 098437FP6")
;(->> {:md5 "30faabbf29ed3cd0c75252485801a0db"}
;     find-mindfood
;     mind-food->bond-lines
;     (map mfu/->kv))

#_(->> {:md5 "2c02262593466e73f41ef3e822bf0893"}
       find-mindfood
       mind-food->bond-lines
       (map mfu/->kv))

;(->> {:md5 "2c02262593466e73f41ef3e822bf0893"}
;     find-mindfood
;     bl/mind-food->bond-lines
;     (map mfu/->kv))

#_(->> {:md5 "251ddfee41fb741468b5e530a2a3f04f"}
       find-mindfood
       mind-food->bond-lines
       (map mfu/->kv))

;mongo soda@dev-soda-app1:27017

#_(->> {:md5 "15d1522c75a30766e70024d04f5a6603"}
       find-mindfood
       mind-food->bond-lines
       ;(map mfu/->kv)
       )

;(-> {:md5 "15d1522c75a30766e70024d04f5a6603"}
;     find-mindfood
;     (mfu/tokenvec-stream :prefilter page-filter :mind-food-splitter mfu/mind-food->line-tokenvecs)
;    (->> (map first)))

;(process-bond-line "$64,840,000 5.00% Term Bond due June 1, 2041. Yield: 3.18%* CUSIP © Issue No.: AW3.")
;(process-bond-line "$131,565,000 5.00% Term Bond due June 1, 2046. Yield: 3.24%* CUSIP © Issue No.: AX1.")

;(r/rgx-split "$1,135,000.. 6.750% Term Bonds due December 15, 2025 Yield 6.500% CUSIP Number 705625 JM4"
;             (first value-splits))
;(r/dissect "$1,135,000.. 6.750% Term Bonds due December 15, 2025 Yield 6.500% CUSIP Number 705625 JM4" split-set)
#_(bond-line-fragment?
    (process-bond-line "1,680,000.. 7.000% Term Bonds due December 15, 2030 Yield 6.750% CUSIP Number 705625 JS1"))
;(process-bond-line "2,425,000.. 7.250% Term Bonds due December 15, 2035 Yield 7.000% CUSIP Number 705625 JX0")
;(process-bond-line "$  79,520,000  5.250% Term Bonds due May 15, 2034 – Priced to Yield: 5.370% – Price: 98.358 – CUSIP†: 79730AGK8 ")

;(->> "$  79,520,000  5.250% Term Bonds due May 15, 2034 – Priced to Yield: 5.370% – Price: 98.358 – CUSIP†: 79730AGK8 "
;     process-bond-line
;     bond-line-fragment?)
;(r/dissect "$6,355,000 5.375% TERM CERTIFICATES DUE 2041, Price 98.000% CUSIP⌐(a) No. 971044 AE2" split-set)

;(->> {:md5 "1ec9585117e64f8447683e89f0e6cde6"}
;     find-mindfood
;     mind-food->feature-maps)

;(->> "jaegers/training_set_1.txt" io/resource slurp cs/split-lines create-training-set vector ->training-sets)

#_(-> (find-training-sets {:jaeger :bond-lines-redux-2})
      (update-in [:features-descriptor :class :options] conj "maturity-year")
      (update :feature-maps
              (fn [m] (mapv #(cond-> %
                                     (#{:year "year"} (get-in % [:features :value-type]))
                                     (-> (assoc-in [:features :class] :maturity-year)
                                         (dissoc :validated?))) m)))
      (assoc :jaeger :bond-lines-redux-3)
      (dissoc :_id)
      vector
      ->training-sets)

;Date not being picked up?
;ef1c4d2898dedb070aae1eb95ccfe816
;$2,935,000 3.750% BONDS DUE SEPTEMBER 15, 2032, TO YIELD 3.000%, CUSIP 098437FP6
