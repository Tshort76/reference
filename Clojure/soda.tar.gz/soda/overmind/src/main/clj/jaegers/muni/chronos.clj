(ns jaegers.muni.chronos
  (:require [instaparse.core :as insta]
            [clojure.string :as cs]
            [clojure.java.io :as io]
            [jaegers.mind-food-utils :as mfu]
            [soda-common.parsers :as scp]
            [soda.data.core :refer [defcon]]
            [soda.core :as soda]
            [clojure.edn :as edn]
            [ml.classifiers :as mlc]
            [jaegers.tokenvec-solver :as ts]
            [clojure.set :refer [rename-keys]]
            [plumbing.core :refer [defnk]]))

(defcon "soda-raw" "mindfood")
(defcon "mekadragon" "training-sets")

(def decision-tree
  (-> "jaegers/chronos_decision_tree.edn" io/resource slurp edn/read-string))
  ;(mfu/training-set->decision-tree (find-training-sets {:jaeger :chronos-2}))

(def date-classifier (partial mlc/classify decision-tree))

(def parse-tree
  (let [[_ & r] (->> "soda_common/parsers.bnf" io/resource slurp cs/split-lines)
        [a & b] (->> "jaegers/chronos.bnf" io/resource slurp cs/split-lines)]
    (insta/parser (cs/join "\n" [a (cs/join "\n" r) (cs/join "\n" b)]))))
(defn group-meta [coll]
  (merge (-> coll first meta (select-keys [:instaparse.gll/start-index]))
         (-> coll last meta (select-keys [:instaparse.gll/end-index]))))

(def concise-feature-descriptor
  {:counted-items #{:word :due-terms :dated-terms :legal-terms :first-coupon-date-terms
                    :official-statement-terms :required-delivery-terms :delivery-terms
                    :non-delivery-terms :issue-dated-date-terms :maturity-terms}
   :value-type    #{:date :year :month-day :reference-date :date-range}
   :class         #{:maturity-date :maturity-day :official-statement-dated-date :issue-dated-date
                    :first-coupon-date :coupon-day :date-of-sale :date-of-indenture :non-temporal
                    :date-of-delivery :year :call-date :?}})

(def feature-descriptor (mfu/expand-feature-descriptor concise-feature-descriptor))

(def txmap
  (into scp/txmap
        {
         ;Items requiring further transformation
         :REFTARGET            (fn [s] {:date (mfu/create-reference-date-keyword s)})
         ;Parentheticals need a little more thinking
         :HINT                 (comp keyword #(cs/replace % #"\W+" "-") cs/lower-case)
         :HINTED_DATE          (fn [m hint] (assoc m :hint hint))
         ;Objects that are detected
         :DATE_RANGE_VALUE     #(mfu/create-value :date-range :date-range % feature-descriptor)
         :REFERENCE_DATE_VALUE #(mfu/create-value :reference-date :date % feature-descriptor)
         :YEAR_VALUE           #(mfu/create-value :year (comp soda/parse-long :year) % feature-descriptor)
         :DATE_VALUE           #(mfu/create-value :date :date % feature-descriptor)
         :MONTH_DAY_VALUE      #(mfu/create-value :month-day identity % feature-descriptor)
         ;The final characterization of all items
         :SENTENCE             (fn [& s] (mfu/characterize-values s))}))

(def parse-tree->value (partial insta/transform txmap))

(defn parse [s] (->> s parse-tree parse-tree->value))

(defn page-filter [{:keys [page-number]}] (<= page-number 5))
(defn sentence-filter [[sentence _]] (not (cs/includes? sentence ".....")))

(defn mind-food->feature-maps [mind-food]
  (-> {:mind-food mind-food}
      (mfu/tokenvec-stream :prefilter page-filter :postfilter sentence-filter)
      (mfu/enfeature-tokenvecs parse)
      (->> (apply ts/classify-featuremaps date-classifier)
           (map #(assoc-in % [:features :class] (get-in % [:classifier-results :class]))))))

(defn mind-food->prospectus-dates [mind-food]
  (-> (mind-food->feature-maps mind-food)
      (ts/solve-all-fields :distinct-fields [:official-statement-dated-date :issue-dated-date :first-coupon-date :date-of-delivery]
                           :nondistinct-fields [:maturity-date])))

(defn resolve-references [{:keys [issue-dated-date date-of-delivery] :as m}]
  (let [idd (:value issue-dated-date) dod (:value date-of-delivery)]
    (cond-> m
            (or (string? idd) (keyword? idd))
            (dissoc :issue-dated-date dod)
            ;For now we'll assume ANY referential idd refers to dod
            (and (or (string? idd) (keyword? idd)) (inst? dod))
            (assoc-in [:issue-dated-date :value] dod))))

(defn resolve-bad-values [{:keys [issue-dated-date date-of-delivery] :as m}]
  (if (and (some->> (:sentence date-of-delivery) (re-find #"(?i)official statement"))
           (inst? (:value issue-dated-date)))
    (assoc m :date-of-delivery (:issue-dated-date m))
    m))

(defnk chronos [mind-food cusips*]
  (let [chrono (-> (->> mind-food
                        mind-food->prospectus-dates
                        (map resolve-bad-values)
                        (map resolve-references)
                        (map #(rename-keys % {:maturity-date :due-date :first-coupon-date :first-coupon-date-chronos}))
                        first)
                   (select-keys [:official-statement-dated-date :issue-dated-date :first-coupon-date :date-of-delivery]))]
    (zipmap
      (keys cusips*)
      (repeat chrono))))
