(ns jaegers.edgar.prospectus.pass-thru-cert
  (:require [jaegers.edgar.tokens :as ec]
            [plumbing.core :refer [defnk]]))

(defn get-candidates [enhik]
  (not-empty
    (ec/token-regex
      (filter #(and (not-empty (:text %)) (not-empty (:id %)))
              (ec/extract-tokens enhik))
      #"(?i)pass (through|thru)")))

(defnk pass-thru-cert* [enhanced-hickory cusips]
  (zipmap
    cusips
    (repeat
      {:value  (boolean (get-candidates enhanced-hickory))
       :class  :pass-thru-cert
       :jaeger ::pass-thru-cert})))
