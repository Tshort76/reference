(ns jaegers.edgar.prospectus.issue-price
  (:require
    [clojure.pprint :as pp]
    [clojure.set :as set]
    [edgar.basic-features :as enf]
    [edgar.geometric-combo-linker :as gcl]
    [jaegers.hickory-utils :as hu]
    [medley.core :refer [find-first]]
    [plumbing.core :refer [defnk]]))

(defn issue-price-percent?
  [{:keys [features string value]}]
  (and (-> features :value-type #{:percent :number})
       (number? value)
       (<= 90 value 110)
       (if (= 100.0 value) true (>= (hu/precision string) 2))))

(defn issue-price-dollars?
  [{:keys [features string value]}]
  (and (-> features :value-type #{:dollars})
       (number? value)
       (< (hu/magnitude value) 4)))

(def features->issue-prices
  (partial enf/features->candidates :issue-price #{:issue-price} issue-price-percent?))

(defn row-col-cands [row-feats col-feats]
  (let [f (partial enf/features->candidates :issue-price #{:per-note :issue-price} issue-price-dollars?)]
    (set/join
      (set (mapcat f row-feats))
      (set (mapcat f col-feats))
      {:ids :ids})))

(def sort-fn
  (juxt
    (comp (partial * -1) :confidence :classifier-results)
    (comp (partial * -1) first :contributions :classifier-results)))

(defn best-from-classifier
  [{:keys [issue-price]}]
  (some-> 
    issue-price
    (->> (sort-by sort-fn))
    first
    (assoc :jaeger ::issue-price)))

(defn calculate-price
  "Calculates price as a percentage of face value when it is expressed as a dollar amount"
  [face-value* issue-prices]
  (->> issue-prices
       (map
         (fn [[cusip issue-price]]
           (let [vt (-> issue-price :features :value-type)
                 fv (->> cusip (get face-value*) :value)]
             [cusip (cond-> issue-price
                      (and fv (#{:dollars} vt))
                      (update :value #(-> % (/ fv) (* 100.0))))])))
       (into {})))

(defnk issue-price*
  [candidates tokenvecs cusips face-value* row-sorted-features col-sorted-features ids->coords]
  (let [cands [(:issue-price candidates)
               (mapcat features->issue-prices row-sorted-features)
               (mapcat features->issue-prices col-sorted-features)
               (row-col-cands row-sorted-features col-sorted-features)]
        best-cand (best-from-classifier candidates)
        linkable-cands (find-first #(<= 1 (count cusips) (count %)) cands)]
    (cond
      (and (= 1 (count cusips)) best-cand)
      (zipmap cusips (repeat best-cand))

      (seq linkable-cands)
      (calculate-price face-value* (gcl/solve-for-edgar :issue-price cusips {:issue-price linkable-cands} ids->coords)))))
