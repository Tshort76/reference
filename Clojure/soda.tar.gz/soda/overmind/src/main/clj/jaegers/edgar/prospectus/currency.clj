(ns jaegers.edgar.prospectus.currency
  (:require
    [clojure.set :as set]
    [clojure.spec.alpha :as spec]
    [clojure.string :as string]
    [enhanced-hickory.util :as ehu]
    [jaegers.mind-food-utils :as mfu]
    [jaegers.regisector :as rs]
    [jaegers.spec :as js]
    [plumbing.core :refer [fnk defnk]]
    [soda.core :refer [some-index]]
    [soda.data.file-system :as sdfs]
    [tokenvec.core :as tv]))

(def dollar "\\u0024|&#x0{0,2}24;|&#36;|\\$")
(def peso "\\WPs\\.\\W|\\Wpeso\\W|\\u20b1|&#8369")

(def peso-relations [#{:peso} #{:PHP :MXN :COP :CLP :ARS :UYU :IDR}])
(defn country-codify [code]
  (apply str (map #(format % code)
                  ["\\W%s\\W|" "^%s\\W|" "\\W%s$|" "^%s$|"])))
(def symbols
  [; US dollar
   {:class :USD :re (str "(?:^|[^CNDAR]|\\WUSD\\W)" dollar)}
   ; British pound
   {:class :GBP :re "\\u00a3|&#x0{0,2}a3;|&#163;|&pound;"}
   ; Euro
   {:class :EUR :re "\\u20ac|&#x20ac;|&#8364;|&euro;|&#128;|\\x80"}
   ; Canadian dollar
   {:class :CAD :re (str "(?:(?:CDN|CAD)\\s?(?:" dollar "|\\d))|C" dollar)}
   ; Australian dollar
   {:class :AUD :re (str "(?:A|(?:AUD\\s?))" dollar)}
   ; Brazilian real
   {:class :BRL :re (str "R" dollar)}
   ; Japanese yen
   {:class :JPY :re (str "¥|&#165|\\u00a5")}
   ;todo fix the Ambigous Peso
   {:class :peso :re peso}
   ;Philipino Peso
   {:class :PHP :re (str (country-codify "PHP") "Philippine pesos?|Philippine")}
   ;Mexico Peso
   {:class :MXN :re (str (country-codify "MXN") "Mexican Pesos?")}
   ;Colombia Peso
   {:class :COP :re (str (country-codify "COP") "Colombian Pesos?")} ;not sure if 'Ps.' refers to pesos in general
   ;Chilean Peso
   {:class :CLP :re (str (country-codify "CLP") "Chilean Pesos?")}
   ;Argentina Peso
   {:class :ARS :re (str (country-codify "ARS") "Argentine Pesos?")}
   ;Uraquay Peso
   {:class :UYU :re (str (country-codify "UYU") "Uruguayan Pesos?")}
   ;Indonesian rupiah
   {:class :IDR :re (str (country-codify "IDR") (country-codify "Rp") "Rupiah")}])

(defn group [regex] (str "(" regex ")"))
(defn alts [regexes] (re-pattern (str "(?i)" (string/join "|" (map group regexes)))))
(def regex (alts (map :re symbols)))


(defn merge-common->specific
  "Adds generic currency class with each more specific currency classes
  ie. :peso -> :PHP :MXN :COP :CLP :ARS :UYU"
  [[general specific] matches]
  (let [parent (set/intersection specific (into #{} (map :value matches)))
        new-peso (for [value parent
                       match (filter (comp general :value) matches)]
                   (assoc match :value value))]
    (concat (remove (comp general :value) matches) new-peso)))

(defn get-most-frequent-currency
  "Returns the most frequently seen currency in matches, a collection of
   regisector results. Ties are broken in favor of non-USD currencies."
  [matches]
  (->> matches
       (group-by :value)
       vals
       (sort-by (juxt count (comp (complement #{:USD}) :value first)) #(compare %2 %1))
       first
       ((fn [vs] {:value (-> vs first :value) :ids (vec (merge-with conj (mapcat :ids vs)))}))))

(defn tokenvec->matches
  [[sentence tokenvec]]
  (let [matches (rs/dissect sentence [{:regex regex :handler (fn [[_ & v]] {:value v})}])]
    (map (fn [{:keys [value indexes]}]
           {:value (:class (get symbols (some-index identity value)))
            :ids [(mapv :id (tv/unique-tokens tokenvec indexes))]})
         matches)))

(defn find-currency [enhik]
  (or (some->> enhik
               (ehu/filter-pages 3)
               mfu/enhik->sentence-tokenvecs
               (mapcat tokenvec->matches)
               (merge-common->specific peso-relations)
               get-most-frequent-currency)
      {:value :USD}))

(defnk currency* [enhanced-hickory cusips]
  (let [{:keys [value ids]} (find-currency enhanced-hickory)]
    (zipmap
      cusips
      (repeat {:jaeger ::currency :class :currency :value value :ids (or ids [])}))))

;; Tests -----------------------------------------------------------------------

;(require 'taoensso.timbre)
;(taoensso.timbre/merge-config! {:output-fn (fn [x] nil)})

;(comment
;  (require 'doc-transforms.core)
;  (require '[clojure.data.json :as json])
;  (require '[jaegers.md5-control-sets :as csets])
;  (let [control :edgar-scsf-393
;        oracle (->> (str "http://dev-soda-intake-group1-app1:8084/soda_jerk_ws/api/jaeger/stats?control-name=" (name control))
;                    slurp
;                    json/read-str
;                    clojure.walk/keywordize-keys
;                    (mapcat (juxt (comp :lm :cusip :jaeger-doc) (comp :lm :currency :jaeger-doc)))
;                    (apply hash-map))]
;    (->> control
;         csets/control-sets
;         (pmap (fn [{:keys [cusip md5]}]
;                 (let [expect (get oracle cusip)
;                       actual (some->> (find-currency (->> {:md5 md5} (doc-transforms.core/mongo->transform :enhanced-hickory) :enhanced-hickory)) :value name)]
;                   (when (not= expect actual)
;                     (prn md5 expect actual))
;                   (= expect actual))))
;         frequencies)))

;(require 'doc-transforms.core)
;#_(->> {:filename "0000764764-13-000150.txt"} (doc-transforms.core/mongo->transform :enhanced-hickory) :enhanced-hickory
;       find-currency)

; TODO misses
;"a93f4bda274979dc3448b167b6800a76" "USD" "EUR" ; mixed currencies

;(def samples
;  [
;   {:md5 "616872e02f0f54ce111c74b13abe702a" :output :PHP}   ;philipines
;   {:md5 "3c83bf3977aa8e3a9af5e0b55655bfd7" :output :COP}   ;columbia
;   ;{:md5 "" :output :MXN}
;   ;{:md5 "" :output :CLP}
;   ;{:md5 "" :output :ARS}
;   ;(:md5 "" :output :UYU)
;   {:md5 "f4c63c77eb2126d0ee530a39d634bda0" :output :JPN}
;   {:md5 "08c2d526a132867d9209f4af6e9fb92e" :output :IDR}
;   ])
;
;(map #(vector
;        (:md5 %)
;        (:output %)
;        (->> (select-keys % [:md5])
;             jaegers.jaeger-primer/query->omni-data
;             jaegers.edgar.prospectus.core/lazy-jaeger
;             :currency* vals first :value))
;
;     samples)
