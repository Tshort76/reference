(ns jaegers.edgar.prospectus.underwriter
  (:require
    [clojure.spec.alpha :as s]
    [hickory.select :as hs]
    [jaegers.jaeger-primer :as primer]
    [jaegers.core :as jcr]
    [edgar.table-utils :as tu]
    [jaegers.hickory-utils :as hu]
    [clojure.string :as cs]
    [jaegers.mind-food-utils :as mfu]
    [jaegers.regisector :as rs]
    [plumbing.core :refer [defnk]]
    [tokenvec.core :as tv]))

(def underwriter-keys
  ["Book-running Managers"
   "Book-running Managers:"
   "Join lead managers"
   "Joint Book Runners"
   "Joint Bookrunners"
   "Joint Book-Runners"
   "Joint Bookrunning Managers"
   "Joint Book-Running Managers"
   "Joint Active Bookrunners"
   "Joint Lead Managers"
   "solicitation agents"
   "(?<!-)managers"
   "syndicate"
   "bookrunners"
   "sole bookrunner"
   "solicitation agents"
   ;"agents"
   ;"Underwriters"
   "Underwriters Purchase Commitments"
   #_"Underwriting"])

(def underwriter-colon-re #"(?i)(?:underwrit(ers?|ing)|joint[-\s]?(?:book[-\s]?running managers|book[-\s]?runners|book[-\s]?running)|join[-\s]?book[-\s]?running managers|sole book-running manager|selling agent|booking-running managers|underwriters purchase commitments|(?<!-)managers|institution|join lead managers|(solicitation )?agents):.*")

(def underwriters-suffix-re #"(?i).*?(inc\.|ltd|plc|lp|llc|corp\.|incorporated| & Co\.( LLC)?)\.?")

(def underwriter-re (re-pattern (str "(?i)(" (cs/join "|" underwriter-keys) "):?(?!.*:)")))

(defn find-siblings [enhik id & tags]
  (let [parent-id (cs/join "_" (-> id (cs/split #"_") drop-last))]
    (not-empty
      (filter #(and
                 (or
                   (not (re-find underwriter-re (cs/join (hu/text %))))
                   #_(not (re-find underwriter-colon-re (cs/join (hu/text %)))))
                 (not-empty (remove nil? (hu/text %))))
              (hs/select (apply hs/child (hs/id parent-id)
                                (hs/tag :td) (map hs/tag tags)) enhik)))))

(defn find-in-tables-re [tables re]
  (not-empty (remove nil? (map (partial get-in tables) (tu/cell-search tables (partial re-find re)) tables))))

(defn cleanup-underwriter [underwriter]
  (-> underwriter
      (cs/replace (re-pattern (str "(?i)(" (cs/join "|" (conj underwriter-keys "agents" "underwriters" "underwriting")) #"|and |\(\d+\.?\d*%\)" "):?")) "")
      (cs/replace #"^," "")
      cs/trim
      not-empty))

; (def exemptions ["Goldman, Sachs & Co"
;                  "Merrill Lynch, Pierce, Fenner & Smith"])

(def bad-underwriter-values ["incorporated"])

(defn bad-underwriter? [underwriter]
  (or
    (nil? underwriter)
    (some #(= % (cs/lower-case underwriter)) bad-underwriter-values)
    (cs/includes? underwriter ":")
    (> (count underwriter) 65)))

(defn split-underwriters-string [text]
  (cond
    (cs/includes? text ",") (cs/split text #"(?i),\s?(inc\.|ltd|plc|lp|llc|corp\.|incorporated| & Co\.( LLC)?)?,?")
    (cs/includes? text ";") (cs/split text #";")
    (not-empty (map first (re-seq underwriters-suffix-re text)))
    (not-empty (map first (re-seq underwriters-suffix-re text)))
    :else [text]))

(defn get-candidates-by-table [enhik]
  (let [tables (tu/table-data enhik)]
    (not-empty
      (keep
        (fn [{id :id}]
          (when-let [underwriter-hik (or
                                       (find-siblings enhik id :p)
                                       (find-siblings enhik id :font)
                                       (find-siblings enhik id :div)
                                       (find-siblings enhik id))]
            (when-let [values (let [texts (map (comp cs/join hu/text) underwriter-hik)]
                                (not-empty
                                  (remove bad-underwriter?
                                          (keep cleanup-underwriter
                                                (if (= 1 (count texts))
                                                  (let [text (first texts)]
                                                    (or
                                                      (and (cs/includes? text ";") (cs/split text #";"))
                                                      (not-empty (map first (re-seq underwriters-suffix-re text)))
                                                      texts))
                                                  texts)))))]
              {:value  values
               :class :underwriter
               :ids    [(map #(get-in % [:attrs :id]) underwriter-hik)]
               :jaeger ::underwriter})))
        (or (find-in-tables-re tables underwriter-re)
            #_(find-in-tables-re tables underwriter-colon-re))))))

(defn get-candidates-by-text [enhik]
  (not-empty
    (mapcat
      (fn [[sentence tokenvec]]
        (when-let [results (not-empty
                             (rs/dissect sentence
                                         [{:regex   underwriter-re
                                           :handler (fn [v] {:value v})}
                                          {:regex   underwriter-colon-re
                                           :handler (fn [v] {:value v})}]))]
          (not-empty
            (keep (fn [{text :string indexes :indexes}]
                    (some->> text
                             cleanup-underwriter
                             split-underwriters-string
                             (map cleanup-underwriter)
                             (remove bad-underwriter?)
                             ((fn [texts]
                                (when (not-empty texts)
                                  {:value  texts
                                   :class :underwriter
                                   :ids    [(mapv :id (tv/unique-tokens tokenvec indexes))]
                                   :jaeger ::underwriter})))))
                  results))))
      (mfu/enhik->sentence-tokenvecs enhik))))

(defn get-candidates [enhik]
  (or
    (get-candidates-by-table enhik)
    (get-candidates-by-text enhik)))

(defnk underwriter* [enhanced-hickory cusips]
  (zipmap
    cusips
    (let [[f :as candidates] (get-candidates enhanced-hickory)]
      (cond
        (= (count candidates) (count cusips)) candidates
        f (repeat f)
        :else (repeat nil)))))

(comment
  (def memoized-query-omni-data
    (memoize (fn [q] (primer/query->omni-data q))))

  (run-all {:filename "0001193125-13-009554.txt"}))
