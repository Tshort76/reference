(ns jaegers.edgar.equity.xbrl-data
  (:require [medley.core :as med]
            [clojure.string :as str]
            [plumbing.core :refer [defnk]]))

(defn make-so-block [{so :shares-outstanding
                      d :period-instant}]
  (when (and so d)
    {:shares-outstanding so
     :date d}))

(defn clean-xbrl-class [class]
  (when-let [class (some->> class
                            (re-find #"Class(\w+)Member")
                            second)]
    (-> class
        (str/replace #"[oO]ne" "1")
        (str/replace #"[tT]wo" "2")
        (str/replace #"[tT]hree" "3")
        (str/replace #"I+" (comp str count))
        (str/split #"(?i)(?:and(?:class)?|class)"))))

(defn unroll-xbrl-class [xbrl]
  (if-let [classes (clean-xbrl-class (:share-class xbrl))]
    (mapv (fn [x c] (if (= "" c)
                      c
                      (assoc x :share-class c)))
          (repeat xbrl)
          classes)
    [xbrl]))

(defn add-tenq [supplemental data]
  (->> (keep (fn [{:keys [ticker shares-outstanding]}]
               (when (= ticker (:ticker data))
                 shares-outstanding)) supplemental)
       flatten
       (update data :shares-outstanding concat)))


(defn combine-group [[[t s] x]]
  (med/assoc-some {}
                  :ticker t
                  :cik (some :entity-id x)
                  :share-class s
                  :shares-outstanding (keep make-so-block x)))

(defn xbrl->exchange-info
  ([xbrl]
   (->> xbrl
        (mapcat unroll-xbrl-class)
        (group-by (juxt :trading-symbol :share-class))
        (map combine-group)))
  ([xbrl supplemental]
   (map (partial add-tenq supplemental) (xbrl->exchange-info xbrl))))

(defn filter-xbrl-info [xbrl-info]
  (let [last-date (->> xbrl-info
                       (mapcat :shares-outstanding)
                       (map :date)
                       (reduce med/greatest))]
    (->> xbrl-info
         (filter (fn [{so :shares-outstanding}]
                   (some (fn [{d :date}] (= last-date d))
                         so))))))


(defnk xbrl-info [xbrl supplemental]
  (filter-xbrl-info (xbrl->exchange-info xbrl supplemental)))
