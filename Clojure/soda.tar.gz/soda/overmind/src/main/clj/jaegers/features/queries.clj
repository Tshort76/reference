(ns jaegers.features.queries)

; (defn lt
;   "Like <, but for vectors of numbers"
;   [& xs]
;   (every? true? (apply map < xs)))

(defn lteq
  "Like <=, but for vectors of numbers"
  [& xs]
  (every? true? (apply map <= xs)))

;; Context queries -------------------------------------------------------------

(def block-toks
  '[:find [?e2 ...]
    :in $ ?e
    :where
    [?e :token-id ?tok]
    [?e :block-id ?bid]
    [?e2 :block-id ?bid]])

; (def block-toks-exclusive
;   (conj block-toks '[(not= ?e ?e2)]))

; (def block-toks-before
;   (conj block-toks-exclusive
;         '[?e2 :token-id ?tok2]
;         '[(jaegers.features.queries/lteq ?tok2 ?tok)]))

; (def block-toks-after
;   (conj block-toks-exclusive
;         '[?e2 :token-id ?tok2]
;         '[(jaegers.features.queries/lteq ?tok ?tok2)]))

(def component-ids
  '[:find (distinct ?cid) .
    :in $
    :where [_ :component-id ?cid]])

(def component-toks
  '[:find [?e ...]
    :in $ ?cid
    :where
    [?e :component-id ?cid]])

(def token-component-toks
  '[:find [?e2 ...]
    :in $ ?e
    :where
    [?e :component-id ?cid]
    [?e2 :component-id ?cid]])

;; Table queries ---------------------------------------------------------------

(def row-cells
  '[:find [?e2 ...]
    :in $ ?e
    :where
    [?e :cell-id ?cid]
    [?e :row-id ?rid]
    [?e2 :row-id ?rid]])

; (def row-cells-before
;   (conj row-cells
;         '[?e2 :cell-id ?cid2]
;         '[(not= ?cid ?cid2)]
;         '[(jaegers.features.queries/lteq ?rid ?cid2)]
;         '[(jaegers.features.queries/lteq ?cid2 ?cid)]))

; (def row-cells-after
;   (conj row-cells
;         '[?e2 :cell-id ?cid2]
;         '[(not= ?cid ?cid2)]
;         '[(jaegers.features.queries/lteq ?cid2 ?rid)]
;         '[(jaegers.features.queries/lteq ?cid ?cid2)]))

(def column-cells
  '[:find [?e2 ...]
    :in $ ?e
    :where
    [?e :cell-id ?cid]
    [?e :table-id ?tid]
    [?e :column ?col]
    [?e2 :table-id ?tid]
    [?e2 :column ?col]])

; (def column-cells-above
;   (conj column-cells
;         '[?e2 :cell-id ?cid2]
;         '[(not= ?cid ?cid2)]
;         '[(jaegers.features.queries/lteq ?cid2 ?cid)]))

; (def column-cells-below
;   (conj column-cells
;         '[?e2 :cell-id ?cid2]
;         '[(not= ?cid ?cid2)]
;         '[(jaegers.features.queries/lteq ?cid ?cid2)]))

(def table-cells
  '[:find [?e2 ...]
    :in $ ?e
    :where
    [?e :table-id ?tid]
    [?e2 :table-id ?tid]])

(def row-ids
  '[:find [?rid2 ...]
    :in $ ?e
    :where
    [?e :row-id ?rid]
    [?e :table-id ?tid]
    [?e2 :table-id ?tid]
    [?e2 :row-id ?rid2]])

(def column-indexes
  '[:find [?col (min ?col2) (max ?col2)]
    :in $ ?e
    :where
    [?e :row-id ?rid]
    [?e :column ?col]
    [?e2 :row-id ?rid]
    [?e2 :column ?col2]])

(def nearest-row-labels
  '[:find [?e2 ...]
    :in $ ?e
    :where
    [?e :row-id ?rid]
    [?e :table-id ?tid]
    [?e2 :table-id ?tid]
    [?e2 :column 1]
    [?e2 :row-id ?rid2]
    [(jaegers.features.queries/lteq ?rid2 ?rid)]])

;; Experimental ----------------------------------------------------------------

;(def within-rule
;  ""
;  '[[(within ?lower-bound ?p1 ?p2 ?upper-bound)
;     [(<= ?lower-bound ?p1 ?upper-bound)]]
;    [(within ?lower-bound ?p1 ?p2 ?upper-bound)
;     [(<= ?lower-bound ?p2 ?upper-bound)]]])

;(def spatial-lasso
;  '[:find [?e2 ...]
;    :in $ % ?tok ?y1-tolerance ?y2-tolerance
;    :where
;    [?e1 :token-id ?tok]

;    ; this token's vertical bounds
;    [?e1 :min-y ?this-y1] [?e1 :max-y ?this-y2]

;    ; other token's vertical bounds
;    [?e2 :min-y ?that-y1] [?e2 :max-y ?that-y2]

;    ; restrict tokens to same page
;    [?e1 :page-number ?page]
;    [?e2 :page-number ?page]

;    ; set vertical bounds on lasso
;    [(- ?this-y1 ?y1-tolerance) ?lower-bound]
;    [(+ ?this-y2 ?y2-tolerance) ?upper-bound]

;    ; does other token fall within bounds?
;    (within ?lower-bound ?that-y1 ?that-y2 ?upper-bound)])
