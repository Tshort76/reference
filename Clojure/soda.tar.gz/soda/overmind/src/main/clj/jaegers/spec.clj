(ns jaegers.spec
  (:require [clojure.spec.alpha :as s]
            [soda-common.cusip :as cusip]
            [soda-common.state-data :as sd]
            [taoensso.timbre :as timbre]))

; (defn validate [res jaeger]
;   (if (s/valid? :jaeger/docs res)
;     res
;     (timbre/error
;       (str "jaeger " jaeger " result does not conform to spec for:\n\t"
;            res "\n.\tReasons:" (s/explain-data :jaeger/docs res)))))

;todo: Do we need to split out edgar/muni???
;;Muni fields
(s/def :muni/series-name string?)
(s/def :muni/issuer-name string?)
(s/def :muni/coupon-frequency #{"Daily" "Weekly" "Monthly" "Quarterly" "Semi-annually" "Annual" "At Maturity" "Biennially"})
(s/def :muni/coupon-rate-type #{"Floating" "VRDO" "Fixed" :Floating :VRDO :Fixed})
(s/def :muni/day-count #{"Actual/360" "Actual/365" "30/360" "Actual/Actual" "30/Actual"})
(s/def :muni/revenue-source #{"Tax Revenue" "Building" "Education" "Utility" "Housing" "Health" "Transportation" "Other"})
(s/def :muni/mandatory-redemption-paydown-type #{"pro rata" "by lot"})
(s/def :muni/revenue-type #{"General Obligation" "Revenue"})
(s/def :muni/capital-appreciation boolean?)
(s/def :muni/state-code sd/state-codes)
(s/def :muni/prospectus-dated-date (s/inst-in #inst"1900-01-01" #inst"2100-01-01"))
(s/def :muni/issue-dated-date (s/or :date (s/inst-in #inst"1900-01-01" #inst"2100-01-01")
                                    :reference #{"date-of-delivery" "date-of-issue" "delivery" "issuance" :date-of-delivery :date-of-issue :delivery :issuance}))
(s/def :muni/first-coupon-date (s/inst-in #inst"1900-01-01" #inst"2100-01-01"))
(s/def :muni/first-accrual-date (s/inst-in #inst"1900-01-01" #inst"2100-01-01"))
(s/def :muni/date-of-delivery (s/inst-in #inst"1900-01-01" #inst"2100-01-01"))
(s/def :muni/maturity-date (s/inst-in #inst"1900-01-01" #inst"2100-01-01"))
(s/def :muni/put-date (s/inst-in #inst"1900-01-01" #inst"2100-01-01"))
(s/def :muni/accrual-start-date (s/inst-in #inst"1900-01-01" #inst"2100-01-01"))
(s/def :muni/issue-date (s/inst-in #inst"1900-01-01" #inst"2100-01-01"))
(s/def :muni/state-tax-exempt boolean?)
(s/def :muni/federal-tax-exempt boolean?)
(s/def :muni/price (s/or :int integer? :double (s/double-in :min 0.0)))
(s/def :muni/yield (s/double-in :min 0.0))
(s/def :muni/face-value (s/double-in :min 0.0))
(s/def :muni/interest-rate (s/double-in :min 0.0))
(s/def :muni/principal-amount (s/or :int integer? :double (s/double-in :min 0.0)))
(s/def :muni/issue-principal-amount (s/double-in :min 0.0))
(s/def :muni/cusip-3 (s/with-gen (partial re-matches cusip/cusip-3-rgx)
                                 #(s/gen #{"A00" "B00" "C00"})))
(s/def :muni/cusip-6 (s/with-gen (partial re-matches cusip/cusip-6-rgx)
                                 #(s/gen #{"000123" "123IP6" "147SIP"})))
(s/def :muni/cusip-9 (s/with-gen (partial re-matches cusip/cusip-9-rgx)
                                 #(s/gen #{"789123UM1" "741IP6122" "753SIPAB3"})))
(s/def :muni/mandatory-redemption-schedule (s/coll-of (s/map-of :redemption-date (s/inst-in #inst"1900-01-01" #inst"2100-01-01") :redemption-amount (s/double-in :min 0.0))))
(s/def :muni/optional-call-schedule (s/coll-of (s/map-of :effective-date (s/inst-in #inst"1900-01-01" #inst"2100-01-01") :price (s/double-in :min 0.0))))

;(gen/generate (s/gen :muni/prospectus-dated-date))
;(gen/generate (s/gen :muni/cusip-3))
;(gen/generate (s/gen :muni/cusip-6))
;(gen/generate (s/gen :muni/cusip-9))

;;Fields in the jaeger docs
(s/def :jaeger/page-number (s/and int? pos?))
(s/def :jaeger/y (s/or :int (s/int-in 0 Long/MAX_VALUE) :dbl (s/double-in :min 0.0 :infinite? false :NaN? false)))
(s/def :jaeger/x (s/or :int (s/int-in 0 Long/MAX_VALUE) :dbl (s/double-in :min 0.0 :infinite? false :NaN? false)))
(s/def :jaeger/jaeger (s/or :keyword keyword? :string string?))

(s/def :jaeger/id (s/with-gen (partial re-matches #"\d+(_\d+)*")
                              #(s/gen #{"9_16_8" "1_11_3" "13_19_12" "16_14_9" "7_4_8"})))
(s/def :jaeger/idvec (s/coll-of :jaeger/id))
(s/def :jaeger/ids (s/or :empty nil? :not-empty (s/coll-of :jaeger/idvec)))

(s/def :features/features-descriptor map?)
(s/def :features/features map?)
(s/def :features/feature-map (s/keys :req-un [:features/features-descriptor :features/features]))
(s/def :features/feature-maps (s/coll-of :features/feature-map))

;(gen/generate (s/gen :jaeger/map-id))
;(gen/generate (s/gen :jaeger/string-id))

(defmacro defjaegerterm [muni-term]
  (let [s (name muni-term)
        muni-k (keyword (str "muni/" s))
        k-val (keyword (str s "/value"))
        jaeg-k (keyword (str "jaeger/" s))]
    `(do
       (s/def ~k-val ~muni-k)
       (s/def ~jaeg-k (s/keys :req-un [~k-val :jaeger/jaeger]
                              :opt-un [:jaeger/ids])))))

(defmacro defjaegerdoc [terms]
  (let [terms# (mapv #(keyword (str "jaeger/" (name %))) terms)]
     `(do
        ~@(map (fn [term] `(defjaegerterm ~term)) terms)
        (s/def :jaeger/jaeger-doc (s/keys :opt-un ~terms#)))))

;TODO: Add the other jaegers to this list and add the corresponding field above
(defjaegerdoc [:cusip-3 :cusip-6 :cusip-9
               :series-name :issuer-name :state-code :prospectus-dated-date
               :issue-dated-date :first-coupon-date
               :first-accrual-date :date-of-delivery :maturity-date
               :state-tax-exempt :federal-tax-exempt :price :yield
               :interest-rate :principal-amount :coupon-frequency
               :capital-appreciation :coupon-rate-type :day-count
               :issue-principal-amount :mandatory-redemption-paydown-type
               :mandatory-redemption-schedule :optional-call-schedule
               :put-date :revenue-source :revenue-type :accrual-start-date
               :face-value :issue-date])


#_(macroexpand-1 '(defjaegerdoc [:cusip-3 :cusip-6 :cusip-9
                                 :series-name :issuer-name :state-code :prospectus-dated-date
                                 :issue-dated-date :first-coupon-date
                                 :first-accrual-date :date-of-delivery :maturity-date
                                 :state-tax-exempt :federal-tax-exempt :price :yield
                                 :interest-rate :principal-amount :coupon-frequency]))

(s/def :jaeger/docs (s/coll-of :jaeger/jaeger-doc))

;(gen/generate (s/gen :jaeger/jaeger-doc))

(s/def :meta/_id any?)
(s/def :meta/md5 string?)
(s/def :meta/filename string?)
(s/def :meta/file-type (s/or :keyword keyword? :string string?))
(s/def ::meta (s/keys :req-un [:meta/md5 :meta/filename :meta/file-type]))

(s/def :jaeger-db/doc (s/keys :req-un [::meta :jaeger/jaeger-doc]))
(s/def :jaeger-db/docs (s/coll-of :jaeger-db/doc))

(s/def :mongo/mind-food (s/keys :req-un [:meta/md5 :mfs/mind-food]
                                :opt-un [:meta/_id :meta/file-type :meta/filename]))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;feature maps;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(s/def :feature-map/value any?)
(s/def :feature-map/class keyword?)
(s/def :feature-map/features-descriptor map?)
(s/def :feature-map/features
  (s/keys :req-un [:feature-map/class]))
(s/def :feature-map/feature-map
  (s/keys :req-un [:feature-map/value :feature-map/features :jaeger/ids :meta/md5]
          :opt-un [:feature-map/features-descriptor]))

(s/def :training-set/jaeger string?)
(s/def :training-set/feature-maps (s/coll-of :feature-map/feature-map))
(s/def :training-set/training-set
  (s/keys :req-un [:trainer-set/jaeger :feature-map/features-descriptor :training-set/feature-maps]))
