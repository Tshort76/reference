(ns jaegers.edgar.equity.core
  (:require
    [plumbing.core :refer [defnk fnk ?>]]
    [plumbing.graph :as graph]
    [medley.core :as med]
    [jaegers.edgar.prospectus.core :as jec]
    [jaegers.edgar.equity
     [share-class :as share-class]
     [exchange-info :as exchange-info]
     [currency :as currency]
     [shares-outstanding :as shares-os]
     [primary-exchange :as primary-exchange]
     [xbrl-data :as xbrl-data]
     [issuer-name :as issuer-name]]))

(defn get-seed
  "Attempts to find the number of securities in a document.  Defaults to one."
  [share-class ticker]
  (if (< 0 (+ (count share-class) (count ticker)))
    (if (<= (count share-class) (count ticker)) ticker share-class)
    [{:non-seed {:value "No good seed.  Defaulting to 1 security."}}]))

(defn fake-cusip
  "Produces a fake cusip-doc based on a seed"
  [n seed]
  {:cusip-9 {:class :cusip-9
             :value (str "fakecusip" n)
             :text  seed}})

(defn filter-fallback
  "Like filter except in the case where the result is empty.
   In which case it returns the original collection effectively doing nothing."
  [pred coll]
  (let [filtered (filter pred coll)]
    (if (seq filtered)
      filtered
      coll)))

(defnk cusip-seeding [exchange-specific xbrl cusip-linking-allowed?]
  (if cusip-linking-allowed?
    (let [seeds (->> exchange-specific
                     (filter-fallback :ticker)
                     (map #(select-keys % [:ticker :share-class]))
                     distinct)]
      (cond
        (seq seeds)
        (map-indexed fake-cusip seeds)

        (<= 0 (count (filter :shares-outstanding xbrl))) ;; TODO: is this suppose to always be true?
        (list (fake-cusip 1 {:ids [[]] :value "From shares-outstanding in xbrl"}))))))

(def jaeger-graph
  {:cusips                cusip-seeding
   :cik*                  (fnk [cusips header]
                           (zipmap cusips (repeat {:class :cik,
                                                   :value (get-in header [:filer 0 :company-data 0 :central-index-key 0])})))
   :other-share-classes*  share-class/other-share-classes*
   :xbrl-info             xbrl-data/xbrl-info
   :ticker*               primary-exchange/primary-ticker*
   :share-class*          share-class/share-class*
   :exchange-specific     exchange-info/exchange-specific
   :exchange-specific*    exchange-info/exchange-specific*
   :shares-outstanding*   shares-os/shares-outstanding*
   :primary-exchange*     primary-exchange/primary-exchange*
   :primary-exchange-mic* primary-exchange/primary-mic*
   :issuer-name*          issuer-name/issuer-name*
   :currency*             currency/currency*
   :country-of-issue*     primary-exchange/country-of-issue*})

; (def profiled-jaeger (graph/compile (graph/profiled :profile-data jaeger-graph)))
(def jaeger (graph/compile jaeger-graph))
(def par-jaeger (graph/par-compile jaeger-graph))
(def lazy-jaeger (graph/lazy-compile jaeger-graph))

;don't need to check on omni-data as this might only have structured.
(defn safe-execute-jaeger
  [jaeger-method omni-doc & [jaegers]]
  (some-> omni-doc jaeger-method (?> (seq jaegers) (select-keys jaegers)) jec/big-merge))

(def execute-jaeger (partial safe-execute-jaeger jaeger))
(def execute-parallel-jaeger (partial safe-execute-jaeger par-jaeger))
(def execute-lazy-jaeger (partial safe-execute-jaeger lazy-jaeger))
