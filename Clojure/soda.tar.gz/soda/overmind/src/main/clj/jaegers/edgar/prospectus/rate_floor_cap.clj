(ns jaegers.edgar.prospectus.rate-floor-cap
  (:require [plumbing.core :refer [defnk]]
            [edgar.geometric-combo-linker :as gcl]
            [jaegers.mind-food-utils :as mfu]
            [jaegers.regisector :as rs]
            [tokenvec.core :as tv]))

(defn safe-min
  ([] nil)
  ([a] a)
  ([a b & args] (apply min a b args)))

(defn safe-max
  ([] nil)
  ([a] a)
  ([a b & args] (apply max a b args)))

(defn format-index-values [sentence tokenvec {:keys [indexes value]}]
  (let [tokens (tv/unique-tokens tokenvec indexes)]
    {:value value
     :text  sentence
     :class :make-whole-call-spread
     :min-x (apply safe-min (keep :min-x tokens))
     :max-x (apply safe-max (keep :max-x tokens))
     :min-y (apply safe-min (keep :min-y tokens))
     :max-y (apply safe-max (keep :max-y tokens))
     :ids   [(mapv :id tokens)]}))

(defn match-tokenvec [[sentence tokenvec] regex]
  (mapv (partial format-index-values sentence tokenvec)
        (rs/dissect
         sentence
         [{:regex   regex
           :handler (fn [v] {:value (Double/parseDouble (second v))})}])))


;; floating-rate-floor
(defn tokenvec->floor-matches [tokenvec]
  (match-tokenvec tokenvec #"(?i)(?:minimum\s+(?:interest\s+)?rate|coupon\s+floor)\b[^.]*?(-?\d+(?:\.\d+)?\s*)%"))

(defn encandidate-floor [s]
  {:rate-floor (mapv #(assoc % :class :rate-floor) s)})

(defnk rate-floor* [cusips ids->coords enhanced-hickory]
  (let [candidates (mapcat tokenvec->floor-matches (mfu/enhik->row-and-paragraph-tokenvec enhanced-hickory))]
    (if (<= 1 (count cusips) (count candidates))
      (gcl/solve-for-edgar :rate-floor cusips (encandidate-floor candidates) ids->coords)
      (zipmap cusips (repeat nil)))))


;; floating-rate-cap
(defn tokenvec->cap-matches [tokenvec]
  (match-tokenvec tokenvec #"(?i)maximum (?:interest )?rate\b[^.]*?(-?\d+(?:\.\d+)?\s*)%"))

(defn encandidate-cap [s]
  {:rate-cap (mapv #(assoc % :class :rate-cap) s)})

(defnk rate-cap* [cusips ids->coords enhanced-hickory]
  (let [candidates (mapcat tokenvec->cap-matches (mfu/enhik->row-and-paragraph-tokenvec enhanced-hickory))]
    (if (<= 1 (count cusips) (count candidates))
      (gcl/solve-for-edgar :rate-cap cusips (encandidate-cap candidates) ids->coords)
      (zipmap cusips (repeat nil)))))
