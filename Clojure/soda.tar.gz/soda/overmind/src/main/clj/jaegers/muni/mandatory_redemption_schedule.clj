(ns jaegers.muni.mandatory-redemption-schedule
  (:require [clojure.string :as cs]
            [soda-common.regexes :as rgx]
            [tfidf.core :as tfidf]
            [soda-common.parsers :as soda-parse]
            [jaegers.muni.series :as js]
            [clojure.pprint :refer [pprint]]
            [simple-mind.parse-objects-utils :as sp]
            [jaegers.spec]
            [jaegers.core :as jcr]
            [jaegers.jaeger-primer :as primer]
            [jaegers.utils :as ju]
            [plumbing.core :refer [defnk]]
            [soda-common.regexes :as regex])
  (:import (java.util Date)))

;;;;;;;;;;      START COMMON/UTIL FUNCTIONS AND VARS      ;;;;;;;;;;

(def interest-rate-like #"([1-4]?\d\.\d+)\s?%")
(def series-name #"([Ss]eries\s*[-]?\s*(?:19|20)\d{2}[a-zA-Z]?)|((?:19|20)\d{2}[a-zA-Z]?\s+[Ss]eries)|((?:19|20)\d{2}[a-zA-Z])")
(def date-like #"(?i)(\d{1,2}/\d{1,2}/\d{2,4})|((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]{0,6}\.? \d{1,2}[,\)]? \d{4})\b|(\d{1,2}\-\d{1,2}\-\d{2,4})|(\d{4}-\d{2}-\d{2})")
(def four-digit-year #"\s*(?:19|20)\d{2}\s*")
(def messy-year #"\s*(?:19|20)\d{2}.?\s*.*")
(def messy-money #"\p{Sc}?((?:(?:\d{1,3})(?:,\d{3})+)(?:\.\d{2})?)\s*.*")

(def money #"[$]\s*\d[\d,]+")

(def modified #"\(.*|.*\)|[^\d]|.*[*]|[Mm][aA][tT][a-zA-Z]*")
(def modifier #"\(.*\)|[a-zA-Z]*\s?[Mm][aA][tT][a-zA-Z]*|\*")

(defn- pretty-reseq [pattern string]
  (->> string
       (re-seq pattern)
       (map (comp first
                  (partial filter identity)))))

(defn- type? [string]
  (cond
    (or
      (re-matches date-like string)
      (re-matches four-digit-year string)
      (re-matches messy-year string)
      (first (pretty-reseq date-like string))) :date
    (re-matches messy-money string) :amount
    (= "" string) :padding
    (re-matches modifier string) :modifier))

(defn- columns-type? [column]
  (->> column
       (map (comp
              type?
              (partial cs/join " ")
              (partial map :text)
              (partial remove :superscript?)))
       frequencies
       (sort-by second)
       last
       key))


(defn column-types [{tbl :vals}]
  (->> tbl
       rest
       (apply mapv vector)                                  ;transpose the table
       (map columns-type?)))

;For debugging only
; (defn pretty-table [component]
;   (update component :vals (fn [x]
;                             (cs/join "\n" (map #(cs/join " | " (map (fn [y] (cs/join " " (map :text y))) %)) x)))))

(defn redemp-schedule? [table-component]
  (and
    (>= (count (:vals table-component)) 2)
    (let [{date-cnt :date amount-cnt :amount nil-cnt nil :as freqs} (->> table-component column-types frequencies)]
      (and date-cnt amount-cnt (< (Math/abs (- date-cnt amount-cnt)) 2) (not nil-cnt)))))

(defn- partition-when [predicate seq-data]
  (reduce (fn [partitions datum]
            (if-let [prev-datum (peek (peek partitions))]
              (if (predicate prev-datum datum)
                (conj partitions [datum])
                (conj (pop partitions) (conj (peek partitions) datum)))
              (conj partitions [datum])))
          [] seq-data))

;;;;;;;;;;      END COMMON FUNCTIONS       ;;;;;;;;;;

;;;;;;;;;;     START LOCATE MANDATORY REDEMPTION TERMS SECTION       ;;;;;;;;;;

(def ref-paragraphs [(cs/split "2012A Bonds - Mandatory Sinking Fund Redemption. The 2012A Bonds maturing on March 1, 2028, and March 1, 2030 (the \"Term Bonds\") are subject to mandatory sinking fund redemption at a redemption price equal to 100% of the principal amount thereof and accrued interest to the redemption date: at par: periodic retirement" #" ")
                     (cs/split "mandatory redemption" #" ")])

(defn trim-section [components]
  (loop [comps components
         section []]
    (let [[pre post] (split-with (fn [{t :type :as cmp}]
                                   (not (and (= :table (keyword t))
                                             (redemp-schedule? cmp)))) comps)]
      (if (empty? post)
        (concat section (take 2 pre))                       ;add 2 components in case final maturity data is in text below table
        (recur (rest post) (concat section pre (take 1 post)))))))

(defn- extract-mand-redemp-section [mind-food]
  (let [page-num (-> mind-food first :page-number)]
    (->> mind-food
         (reduce (fn [{:keys [last-table-pg] :as state}
                      {:keys [page-number type] :as cmp}]
                   (if (and (= 1000 last-table-pg)
                            (> (- page-number page-num) 3))
                     (reduced nil)
                     (if (and (= :table (keyword type))
                              (redemp-schedule? cmp))
                       (-> state
                           (update :section conj cmp)
                           (assoc :last-table-pg page-number))
                       (if (< (- page-number last-table-pg) 2)
                         (update state :section conj cmp)
                         (reduced state)))))
                 {:last-table-pg 1000 :section []})
         :section
         trim-section)))

(defn mrs-language? [{vals :vals t :type}]
  (and (= :text (keyword t))
       (let [txt (->> vals flatten (map :text))]
         (->> ref-paragraphs
              (map (partial tfidf/calc-cosine-similarity txt))
              (some (partial < 0.3))))))

(defn mrs-schedule? [{type :type :as tbl}]
  ;TODO expand to cover text based schedules (extremely low priority, 0.5 % seem to do it)
  (and (= :table (keyword type))
       (redemp-schedule? tbl)))

(defn food->mrs-sections [mind-food]
  (loop [sections []
         mindfood mind-food]
    (let [[pre post] (split-with #(not (mrs-schedule? %)) mindfood)]
      (if (empty? post)                                     ;didn't find a table
        sections
        (if-let [section-prelude (->> pre (take-last 15) (drop-while (complement mrs-language?)) not-empty)]
          (let [section (extract-mand-redemp-section post)
                last-component (last section)]
            (recur (conj sections (concat section-prelude section))
                   (rest (drop-while (partial not= last-component) post))))
          (recur sections (rest post)))))))


;;;;;;;;;;      END LOCATE MRS SECTION FUNCTIONS     ;;;;;;;;;;


;;;;;;;;;;      PARSE MRS SECTION FUNCTIONS       ;;;;;;;;;;

(defn xform-date [raw-date-str & [maturity-month-day]]
  (or (->> (if (re-matches four-digit-year raw-date-str)
             (str (or maturity-month-day "01-01") " " raw-date-str)
             raw-date-str)
           cs/trim
           soda-parse/parse
           :date)
      raw-date-str))

(defn parse-num [raw-str]
  (some-> raw-str
          (cs/replace #"[^\d\.]" "")
          not-empty
          ((fn [rate] (try (Double/parseDouble rate) (catch Exception _ rate))))))

(defmulti parse-cell-value (fn [type _] type))

(defmethod parse-cell-value :amount [_ tokens]
  (->> tokens
       (map :text)
       (filter #(not= "(1)" %))
       (cs/join " ")
       (#(cs/replace % #"[^\d\.]" ""))
       (#(if (not (empty? %)) (try (Double/parseDouble %) (catch Exception _ %))))))

(defmethod parse-cell-value :date [_ tokens]
  (let [raw-str (->> tokens (map :text) (cs/join " "))]
    (or (some identity (re-find date-like raw-str))
        (re-find four-digit-year raw-str)
        raw-str)))

(defmethod parse-cell-value :default [_ _] nil)

(defn- <-series [tokens]
  (js/component->strict-series {:vals [tokens]}))

(defn- <-interest-rates [tokens]
  (sp/rematch-in interest-rate-like [:text] tokens))

(defn- <-day-of-months [tokens]
  (sp/rematch-in rgx/month-day [:text] tokens))

(defn modified? [cell]
  (or
    (some :superscript? cell)
    (->> cell last :text (re-matches modified))))

(defn parse-cell [tokens-raw]
  (let [tokens (cond-> tokens-raw (not (sequential? tokens-raw)) vector)
        {x0 :x y :y page-number :page-number} (first tokens)
        {:keys [x width]} (last tokens)
        type (type? (cs/join " " (map :text tokens)))]
    {:type     type
     :value    (parse-cell-value type tokens)
     :ids      (map :id tokens)
     :coords   {:y0          y
                :y1          y
                :x0          x0
                :x1          (some-> (or x x0) (+ (or width 0)))
                :page-number page-number}
     :modified (modified? tokens)}))

(defn merge-modified [cells]
  (reduce
    (fn [ret cell]
      (if (= :modifier (:type (peek ret)))
        (conj (pop ret) (assoc cell :modified (:modified (peek ret))))
        (conj ret cell)))
    []
    cells))

(defn ->pairs
  "extracts date-amount pairs from a row in a table"
  [key-type cells]
  (let [join-pair (fn [[{:keys [type value ids coords modified]}
                        {type1 :type value1 :value ids1 :ids coords1 :coords modified1 :modified}]]
                    {(keyword type)  value
                     (keyword type1) value1
                     :ids            (remove #(= "0_0_0" %) (concat ids ids1))
                     :coords         (assoc coords :x1 (:x1 coords1))
                     :modified       (or modified modified1)})]
    (->> cells
         merge-modified
         (partition-by #(= :date (:type %)))
         (partition 2)
         (map flatten)
         (map (fn [[d & r]] (map #(vector d %) r)))
         (mapcat identity)
         (filter (fn [[{tf :type} {ts :type}]] (and
                                                 (= key-type tf)
                                                 (not= tf ts))))
         (mapv join-pair))))

(defmulti parse-component #(keyword (:type %)))

(defmethod parse-component :table [{vals :vals}]
  (let [[headers data] (split-with #(not (re-find #"\$[,\d]+" (cs/join " " (map :text (flatten %))))) vals)
        [headers data] (if (empty? data) [(first vals) (rest vals)] [headers data])]
    (when-not (re-find #"(?i)debt service" (cs/join " " (map :text (flatten headers))))
      (let [header-tokens (flatten headers)
            data (if (re-find #"[a-zA-Z]+" (cs/replace (cs/join " " (map :text (flatten headers))) regex/month-names ""))
                   data
                   (concat data headers))
            first-column-type (->> data first first (map :text) (cs/join " ") type?)
            schedules (->> data
                           (mapcat (comp
                                     not-empty
                                     (partial ->pairs first-column-type)
                                     (partial filter #(#{:amount :date :modifier} (:type %)))
                                     (partial map parse-cell)))
                           (sort-by #(get-in % [:coords :x0])) ;now make a single column of pairs, ordered from left to right, top to bottom, and split when a modifier appears
                           (partition-when #(> (get-in %2 [:coords :x0]) (get-in %1 [:coords :x1]))) ;no overlap in the y plane
                           (mapcat (partial sort-by #(get-in % [:coords :y0])))
                           (partition-when (fn [{m :modified} _] m)))
            base-map {:type           :table
                      :series         (<-series header-tokens)
                      :interest-rates (<-interest-rates header-tokens)
                      :day-of-months  (<-day-of-months header-tokens)}]
        (map (partial assoc base-map :schedule) schedules)))))


(defmethod parse-component :text [{vals :vals}]
  (let [tokens (flatten vals)]
    {:type           :text
     :series         (<-series tokens)
     :day-of-months  (<-day-of-months tokens)
     :date           (sp/rematch-in date-like [:text] tokens)
     :amount         (sp/rematch-in money [:text] tokens)
     :interest-rates (<-interest-rates tokens)
     :tokens         tokens}))

(def bond-line (cs/split "$265,000; 3.000% Term Bond due February 1, 2026; Yield *2.750%; CUSIP No. 439866 M27" #" "))

(defn <-final-maturity [schedule nxt-component]
  (or (when-let [x (->> schedule (filter :modified) first :date)]
        {:reason :modifier :final-maturity x})
      (if-let [x (some->> nxt-component :date first :text xform-date)]
        (if (and (-> nxt-component :amount not-empty)       ;date and amount but not a term bond header
                 (instance? Date x)
                 (instance? Date (->> schedule (map :date) sort last))
                 (.after x (->> schedule (map :date) sort last))
                 (< (tfidf/calc-cosine-similarity bond-line (->> nxt-component :tokens (map :text))) 0.4))
          {:reason :below-in-text :final-maturity x}))
      (if-let [x (->> schedule (map :date) sort last)]
        {:reason :eldest :final-maturity x})))

(defn decorate-schedule [schedule nxt-cmp attributes]
  (let [schedule-v2 (mapv #(-> (dissoc % :coords :day-of-month)
                               (update :date xform-date (:text (:day-of-month %)))) schedule)
        {:keys [reason final-maturity]} (<-final-maturity schedule-v2 nxt-cmp)
        final-schedule (if (= :below-in-text reason)
                         (conj schedule-v2 {:date   final-maturity
                                            :amount (-> nxt-cmp :amount first :text parse-num)
                                            :ids    (concat (->> nxt-cmp :amount first :objs (map :id))
                                                            (->> nxt-cmp :date first :objs (map :id)))})
                         schedule-v2)]
    (-> attributes
        (update :series get-in [:series :value])
        (update :interest-rate #(parse-num (:text %)))
        (dissoc :day-of-month :date)
        (assoc :schedule (sort-by :date (map #(dissoc % :modified) final-schedule))
               :final-maturity final-maturity))))

(defn euc-distance [point1 point2]
  (let [[{:keys [x y p]} {x1 :x y1 :y p1 :p}] (sort-by :p [point1 point2])]
    (Math/sqrt (+ (Math/pow (- x x1) 2) (Math/pow (- y (+ (* 800 (- p1 p)) y1)) 2)))))

(defn decorate-schedules [parsed-components]
  (let [nearest (fn [{schedule :schedule} matches]
                  (if (not-empty matches)
                    (if-let [{x0 :x0 x1 :x1 y0 :y0 page-num :page-number} (:coords (first schedule))]
                      (apply min-key (fn [{objs :objs series :series}]
                                       (let [{:keys [x y width page-number]} (first objs)
                                             {sx :x sy :y sp :page-number} (-> series :coords flatten first)
                                             v-left-x (second (ju/id->vec (last (:ids (first schedule)))))]
                                         (+ (if (< v-left-x (or x 0)) 50 0) ;weight dates to the left higher
                                            (euc-distance {:x v-left-x :y y0 :p page-num}
                                                          {:x (or x sx) :y (or y sy) :p (or page-number sp)}))))
                             matches))))]
    (loop [{:keys [series day-of-months interest-rates type] :as state} {}
           {c-type :type c-series :series c-interests
                   :interest-rates c-day-months :day-of-months
            :as    current} (first parsed-components)
           remaining (rest parsed-components)
           schedules []]
      (if current
        (if (= :text (keyword c-type))
          (recur (-> state
                     (assoc :type :text)
                     (update :series concat c-series)
                     (update :day-of-months concat c-day-months)
                     (update :interest-rates #(if (= :table (keyword type))
                                                c-interests
                                                (concat % c-interests))))
                 (first remaining)
                 (rest remaining)
                 schedules)
          (recur (assoc state :type :table)                 ;table
                 (first remaining)
                 (rest remaining)
                 (conj schedules (decorate-schedule
                                   (map
                                     (fn [x]
                                       (assoc x :day-of-month (nearest {:schedule [x]}
                                                                       (concat day-of-months c-day-months))))
                                     (:schedule current))
                                   (first remaining)
                                   {:series        (nearest current (concat series c-series))
                                    :interest-rate (nearest current (concat interest-rates c-interests))}))))
        schedules))))

(defn parse-sections [section]
  (->> section
       (keep parse-component)
       flatten))

;;;;;;;;;;      END PARSE MRS SECTION FUNCTIONS       ;;;;;;;;;;

;;;;;;;;;;      JAEGER FUNCTIONS       ;;;;;;;;;;

(defn ->jaeger-form [schedule]
  (update schedule :schedule (fn [x] (hash-map :value (map #(dissoc % :ids) x)
                                               :jaeger :mandatory-redemption-schedule
                                               :class :mandatory-redemption-paydown-schedule
                                               :coords (mapv (fn [id]
                                                               (let [[page x y]
                                                                     (ju/id->vec id)]
                                                                 {:page-number page :x x :y y}))
                                                             (mapcat :ids x))
                                               :ids (vector (mapcat :ids x))))))

(defn mind-food->mandatory-redemption-schedule [mind-food]
  (->> mind-food
       food->mrs-sections
       (mapcat (comp
                 decorate-schedules
                 parse-sections))
       (map ->jaeger-form)))

(defn match [{:keys [final-maturity series interest-rate]} securities]
  (loop [matches securities
         filters [(fn [[_ {security-date :value} _ _]]
                    (= security-date final-maturity))
                  (fn [[_ _ _ {security-rate :value}]]
                    (or (not interest-rate)
                        (= security-rate interest-rate)))
                  (fn [[_ _ {security-series :value} _]]
                    (= security-series series))]]
    (if (or (empty? filters)
            (<= (count matches) 1))
      matches
      (recur (filter (first filters) matches) (rest filters)))))

(defn merge-mrs [agg-docs schedules]
  (reduce (fn [ret schedule]
            (let [matched-docs (match schedule agg-docs)]
              (if (= 1 (count matched-docs))
                (assoc ret (ffirst matched-docs) (:schedule schedule))
                ret)))
          {}
          schedules))

;thought we might use this, but found out we don't. leaving it here in case we do use it in the future.
#_(defn calc-msr-field [cusip msrb]
    (let [mdate (get-in (get msrb cusip) [:maturity-date :value])
          prev-date (->> (sort (map (comp :value :maturity-date) (vals msrb)))
                         (filter #(.after mdate %))
                         (last))]
      (when (and mdate prev-date
                 (> (/ (- (.getTime mdate) (.getTime prev-date)) (* 24 60 60 1000)) 400))
        {:jaeger :mandatory-redemption-schedule
         :class  :mandatory-redemption-paydown-schedule
         :value  [{:date mdate :price 100}]})))

(defn link-calc-mrs [maturity-dates principal-amounts schedules]
  (let [grouped-schedules (group-by (fn [schedule]
                                      (let [principal-amount (->> (get-in schedule [:schedule :value])
                                                                  (keep :amount)
                                                                  (filter number?)
                                                                  (reduce + 0))]
                                        [(:final-maturity schedule) principal-amount]))
                                    schedules)]
    (reduce
      (fn [ret [cusip v]]
        (assoc ret cusip (:schedule (first (get grouped-schedules v)))))
      {}
      (merge-with (fn [{v1 :value} {v2 :value}]
                    [v1 v2])
                  maturity-dates principal-amounts))))

(defnk mandatory-redemption-schedule* [mind-food principal-amount* maturity-date* series* interest-rate*]
  (let [schedules (mind-food->mandatory-redemption-schedule mind-food)]
    (merge
      (link-calc-mrs maturity-date* principal-amount* schedules)
      (merge-mrs (map vector (keys maturity-date*) (vals maturity-date*) (vals series*) (vals interest-rate*))
                 schedules))))







(comment
  (require 'jaegers.muni.msrb-supplement
           'jaegers.muni.cusips
           'jaegers.muni.capital-appreciation
           'jaegers.muni.series)

  (def memoized-query-omni-data
    (memoize (fn [q] (primer/query->omni-data q))))

  (keep :mandatory-redemption-paydown-schedule
        (run-all {:md5 "4695f4ecb3aca7e689621190d731d99d"})))
