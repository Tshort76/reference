(ns jaegers.edgar.prospectus.covered
  (:require [clojure.spec.alpha :as s]
            [jaegers.core :as jcr]
            [jaegers.jaeger-primer :as primer]
            [plumbing.core :refer [defnk]]))

(defnk covered* [issue-description*]
  (zipmap
    (keys issue-description*)
    (map
      (fn [{:keys [value]}] {:value (boolean (some->> value (re-find #"(?i)covered"))) :jaeger ::covered :class :covered})
      (vals issue-description*))))
