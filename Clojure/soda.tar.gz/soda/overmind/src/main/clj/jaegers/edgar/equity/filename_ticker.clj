(ns jaegers.edgar.equity.filename-ticker
  (:require [clojure.string :as str]))

(defn find-filename-ticker [file-string]
  (->> file-string
       str/split-lines
       (some (fn [s]
               (let [[_ m] (re-matches #"<FILENAME>([a-zA-Z]{1,5})-.+\.xsd" s)]
                 (when-not (contains? #{"none" "ex" nil} m)
                   (str/upper-case m)))))))
