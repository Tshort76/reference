(ns jaegers.muni.coupon-frequency
  (:require [clojure.java.io :as io]
            [clojure.edn :as edn]
            [doc-transforms.core :as dtc]
            [simple-mind.naive-bayes.util :as nbu]
            [simple-mind.naive-bayes.core :as nb]
            [clojure.string :as cs]
            [jaegers.jaeger-primer :as primer]
            [plumbing.core :refer [defnk]]))

(def samples (some-> "jaegers/coupon_frequency_set.edn" io/resource slurp edn/read-string))
(def n-grams 2)
(def cls-weights {"at-maturity" {:weight 10 :words ["compounded" "accrete"]}
                  "monthly"     {:weight 10 :words ["month"]}
                  "annual"      {:weight 100 :words ["annual"]}
                  "quarterly"   {:weight 100 :words ["quarter"]}})

(def bayes-model
  (reduce (fn [m [cls sams]] (nbu/train-all m cls sams :n n-grams :cls-weights cls-weights)) {} samples))

(defn classify-text [text verbose]
  (some-> text
          nbu/->words
          (nb/->bag-of-words :n n-grams)
          (#(nb/classify-multinomial bayes-model % verbose))))

(defn find-coupon-frequency
  [{ca :value}
   {note :value}
   {fcd-sentence :sentence fcd-ids :ids fcd-coords :coords}]
  (let [probs (classify-text fcd-sentence true)
        cls (ffirst probs)]
    (cond
      (or note ca) {:value "At Maturity" :jaeger :coupon-frequency :class :coupon-frequency}
      (and cls (not= cls :bayes/unclassified))
      {:value            (get {"at-maturity" "At Maturity"} (name cls)
                              (cs/capitalize (name cls)))
       :ids              fcd-ids
       :coords           fcd-coords
       :overmind-details {:method        :bayes
                          :probabilities (->> probs (into {}))}
       :class            :coupon-frequency
       :jaeger           :coupon-frequency}

      :else
      {:value  "Semi-annually"
       :class  :coupon-frequency
       :jaeger :coupon-frequency})))

(defnk coupon-frequency* [cusips* capital-appreciation* is-note* first-coupon-date*]
  (zipmap
    (keys cusips*)
    (map find-coupon-frequency (vals capital-appreciation*) (vals is-note*) (vals first-coupon-date*))))

; Possible values for coupon-frequency:
;
; Semi-annually     68106 (~95%)
; Once at Maturity  2360  (~3.5%)
; Monthly           989   (~1.5%)
; Quarterly         107
; ...

; (comment
;   (require 'jaegers.muni.msrb-supplement
;            'jaegers.muni.cusips
;            'jaegers.muni.is-note
;            'jaegers.muni.capital-appreciation
;            'jaegers.muni.first-coupon-date)
;
;   (def memoized-query-omni-data
;     (memoize (fn [q] (primer/query->omni-data q))))
;
;   (keep (juxt :cusip-9 :coupon-frequency :first-coupon-date)
;         (run-all {:md5 "7357beadecc46f15d8e1c452fb9123ce"}))
;
;   "Daily",
;   "Weekly",
;   "Monthly",
;   "Quarterly",
;   "Semi-annually",
;   "Annual",
;   "At Maturity",
;   "Biennially"
;
;   (classify-text (clojure.string/replace "The\nBonds\nwill\nbe\nissued\nas\ncurrent\ninterest\nbonds\n(the\n\"Current\nInterest\nBonds\"),\ncapital\nappreciation\nbonds\n(the\n\"Capital\nAppreciation\nBonds\")\nand\nconvertible\ncapital\nappreciation\nbonds\n(the\n\"Convertible\nCapital\nAppreciation\nBonds\").\nInterest\nwith\nrespect\nto\nthe\nCurrent\nInterest\nBonds\naccrues\nfrom\nthe\ndate\nof\ndelivery\nof\nthe\nBonds\n(the\n\"Date\nof\nDelivery\")\nand\nis\npayable\nsemiannually\non\nFebruary\n1\nand\nAugust\n1\nof\neach\nyear,\ncommencing\nFebruary\n1,\n2013.\nThe\nCurrent\nInterest\nBonds\nare\nissuable\nin\ndenominations\nof\n$5,000\nor\nany\nintegral\nmultiple\nthereof.\nThe\nCapital\nAppreciation\nBonds\nare\ndated\nthe\nDate\nof\nDelivery\nand\naccrete\ninterest\nfrom\nsuch\ndate,\ncompounded\nsemiannually\non\nFebruary\n1\nand\nAugust\n1\nof\neach\nyear\n(each\na\n\"Bond\nPayment\nDate\"),\ncommencing\non\nFebruary\n1,\n2013.\nThe\nCapital\nAppreciation\nBonds\nare\nissuable\nin\ndenominations\nof\n$5,000\nMaturity\nValue\nor\nany\nintegral\nmultiple\nthereof." "\n" " ") true)
;
;   (take 5 (filter (comp not empty?)))
;
;   (map
;     (fn [jds] (distinct (keep (comp :coupon-frequency :jaeger-doc) jds)))
;     (map
;       jaegers.soda-pipe/md5->security-docs
;       ["0916dd61588895772680f29c27e6d4ac"]
;       #_(map
;           :md5
;           (jaegers.md5-control-sets/control-sets :kilo-of-happiness))))
;
;   (take 10)
;   ;(filter (comp empty? second))
;   (first
;     (map
;       (fn [[md5 jds]] [md5 (distinct (keep (comp :sentence :first-coupon-date :jaeger-doc) jds))])
;       (map
;         (juxt identity jaegers.soda-pipe/md5->security-docs)
;         ["cf981dc987f16e3ef5c3b6692130aa8f"]
;         #_(map
;             :md5
;             (jaegers.md5-control-sets/control-sets :kilo-of-happiness)))
;
;       ))
;
;   (def cf-set (edn/read-string (slurp (io/resource "jaegers/coupon_frequency_set.edn"))))
;   (reduce-kv (fn [m k v]
;                (assoc m k (count v))) {} cf-set)
;   (spit
;     (io/resource "jaegers/coupon_frequency_trainset.edn")
;     (into {}
;           (map (fn [[k v]]
;                  {k (take (Math/floor (* (count v) 0.8)) v)})
;                cf-set)))
;
;   (def testcf-set (edn/read-string (slurp (io/resource "jaegers/coupon_frequency_testset.edn"))))
;   (reduce-kv (fn [m k v]
;                (assoc m k (count v))) {} testcf-set)
;   (map (fn [[k vs]] (frequencies (map #(= k (classify-text % false)) vs))) testcf-set)
;
;   (def oracle-data (into #{}
;                          (pmap (comp :data first jaegers.oracle/cusips->oracle-data vector :cusip)
;                                (flatten (vals jaegers.md5-control-sets/control-sets)))))
;
;   (def md5s->coupon-frequency
;     (keep
;       #(if-let [mf (dtc/mongo->transform :mind-food {:filename (str (:cusip %) ".pdf")})]
;          (let [cf (:coupon-frequency %)]
;            (when cf
;              {(:md5 mf) (clojure.string/replace (clojure.string/lower-case cf) " " "-")})))
;       oracle-data))
;   (count md5s->coupon-frequency)
;   (def better-md5s->coupon-frequency
;     (reduce-kv (fn [m k v]
;                  (update m v conj k)) {}
;                (into {} md5s->coupon-frequency)))
;   (map
;     (comp :coupon-frequency :jaeger-doc)
;     (flatten
;       (map
;         (fn [cls md5s]
;           (jaegers.soda-pipe/md5->security-docs))
;         better-md5s->coupon-frequency)))
;
;   (def result
;     (reduce
;       (fn [m k]
;         (update m k (fn [md5s] (take 300 (distinct (keep (comp :sentence :first-coupon-date :jaeger-doc) (flatten (map jaegers.soda-pipe/md5->security-docs md5s))))))))
;       better-md5s->coupon-frequency
;       (keys better-md5s->coupon-frequency)))
;   (map count (vals result))
;   (spit (clojure.java.io/resource "jaegers/coupon_frequency_set.edn") result)
;
;
;   (def tfidf-q-doc
;     (tfidf.core/query-essence
;       (clojure.string/join " " (flatten (vals (edn/read-string (slurp (clojure.java.io/resource "jaegers/coupon_frequency_set.edn"))))))
;       2))
;   (spit "resources/jaegers/coupon-frequency-tfidf-doc.edn" tfidf-q-doc)
;
;   (def quarterly-mf (keep first quarterly-mf))
;
;   (map first (jaegers.mind-food-utils/mind-food->sentence-tokenvecs (:mind-food (first quarterly-mf))))
;
;   )
