(ns jaegers.edgar.prospectus.issuer-name
  (:require
    [clojure.string :as string]
    [jaegers.hickory-utils :as hu]
    [jaegers.mind-food-utils :as mfu]
    [edgar.subsidiaries :as subsidiaries]
    [medley.core :refer [find-first]]
    [plumbing.core :refer [defnk]]
    [tokenvec.core :as tv]))

(def no-match
  "Magic number used in sort-key to reject a candidate entity"
  100)

(defn text-before [toks tok n]
  (let [[before] (split-with (partial not= tok) (distinct toks))]
    (string/join " " (take-last n (map :text before)))))

(defn text-after [toks tok n]
  (let [[_ [_ & after]] (split-with (partial not= tok) (distinct toks))]
    (string/join " " (take n (map :text after)))))

(defn sort-key
  "Returns a pair of numbers used to sort the entity given by ent-toks"
  [enhik toks ent-toks]
  (let [trb (string/join " " (hu/words-in-row-before (hu/id->loc enhik (:id (first ent-toks)))))
        tb (text-before toks (first ent-toks) 3)
        ta (text-after toks (last ent-toks) 10)]
    [(cond
       (re-find #"(?i)\bissuer:" trb) 0
       (re-find #"(?i)\bissuer:" tb) 1
       (re-find #"(?i)(the \W{0,2}issuer\W{0,2})" ta) 2
       (re-find #"(?i)^issuer" trb) 3
       :else no-match)
     (-> ent-toks first :max-y)]))

(defn find-issuer
  "Finds the most likely issuer name in tvs, with precedence given to those
   with surrounding text matching issuer-like patterns and those higher in the
   document"
  [enhik tvs]
  (->> (for [[s toks] tvs
             ent (-> s subsidiaries/parser subsidiaries/transform)
             :when (meta ent)
             :let [ent-toks (tv/unique-tokens toks (subsidiaries/indexes ent))]]
         (assoc ent :ids (map :id ent-toks), :sort-key (sort-key enhik toks ent-toks)))
       (sort-by :sort-key)
       (find-first (comp not #{no-match} first :sort-key))
       (#(dissoc % :sort-key))))

(defn ->jaeger-form [issuer-name ids]
  {:jaeger ::issuer-name
   :value issuer-name
   :class :issuer-name
   :ids ids})

(defnk issuer-name* [enhanced-hickory tokenvecs cusips]
  (let [{:keys [ids name]} (find-issuer enhanced-hickory tokenvecs)]
    (zipmap cusips (repeat (->jaeger-form name ids)))))
