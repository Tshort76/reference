(ns jaegers.muni.candidate-generator)
;   (:require [clj-time.coerce :as co]
;             [clj-time.core :as t]
;             [jaegers.muni.candidate-linker-utils :refer :all]
;             [jaegers.muni.primer :as jmp]
;             [jaegers.jaeger-primer :as jp]
;             [clojure.edn :as edn]
;             [ml.training-sets :as train]
;             [clojure.java.browse :as b]
;             [clojure.set :as c-set]
;             [clojure.pprint :as pp]))
;             ;[jaegers.muni.candidate-linker-utils :refer :all]
;
;
; (defn tag-all-datoms [class value-set datoms]
;   (let [match (filter (comp value-set :value) datoms)
;         no-match (remove (comp value-set :value) datoms)
;         changed (map (fn [d] (assoc-in d [:features :class] class)) match)]
;
;     (concat no-match changed)))
;
; (defn date->month-day
;   "sometimes maturity dates in documents are split into month/days with the year seperated
;   this function is need to tag values that match up with the parse values found in the document"
;   [date]
;   ;  (debug (ps date))
;   (pp/cl-format nil "~2,'0d/~2,'0d"
;                             (Integer. ((comp t/month co/from-date) date))
;                             (Integer. ((comp t/day co/from-date) date))))
;
; (defn tag-datoms [datoms omni-doc]
;   (let [principal-amounts (into #{} (map :maturity-principal-amount (:msrb-supplemental-data omni-doc)))
;         interest-rates (into #{} (map :interest-rate (:msrb-supplemental-data omni-doc)))
;         maturity-dates (into #{} (map :maturity-date (:msrb-supplemental-data omni-doc)))
;         maturity-years (into #{} (map (comp t/year co/from-date) maturity-dates))
;         maturity-month-days (into #{} (map date->month-day maturity-dates))
;         prices (into #{} (map :initial-offering-price (:msrb-supplemental-data omni-doc)))
;         yields (into #{} (map :initial-offering-yield (:msrb-supplemental-data omni-doc)))]
;
;     (->> datoms
;          (tag-all-datoms :price prices)
;          (tag-all-datoms :yield yields)
;          (tag-all-datoms :maturity-date maturity-dates)
;          (tag-all-datoms :maturity-year maturity-years)
;          (tag-all-datoms :maturity-month-day maturity-month-days)
;          (tag-all-datoms :interest-rate interest-rates)
;          (tag-all-datoms :principal-amount principal-amounts))))
;
;
;
;
; (defn generate-and-tag-datoms [omni-doc]
;   (if (= (count (:cusips (:candidates omni-doc)))
;          (count (:msrb-supplemental-data omni-doc)))
;     (let [datoms (jmp/enfeature-enhik (:enhanced-hickory omni-doc))
;           t-datoms (tag-datoms datoms omni-doc)]
;       (vec t-datoms))
;     []))
;
; (defn process-md5 [md5]
;   (let [omni-doc (jp/query->omni-data {:md5 md5})]
;     (generate-and-tag-datoms omni-doc)))
;
; (defn process-md5-list [md5-list]
;   (let [t-datoms (pmapcat process-md5 md5-list)
;         filename (str (first md5-list) ".datoms")]
;
;     (spit (str "D:\\datoms\\Feb-14\\" filename) (pr-str t-datoms))
;     filename))
;
; ;(def t-datoms (mapcat jmcl/generate-and-tag-datoms (take 10 md5s-shuff))
; (defn datoms-file->arrf [d-file a-file]
;   (let [datoms (edn/read-string (slurp d-file))
;         training-set (train/feature-maps->training-set "training-set" datoms)]
;
;     (train/training-set->arff-file training-set a-file)))
;
; (defn datoms-file-collection->arff [d-files a-file transform]
;   (let [datoms (mapcat (fn [f] (transform (edn/read-string (slurp f)))) d-files)
;         training-set (train/feature-maps->training-set "training-set" datoms)]
;
;     (train/training-set->arff-file training-set a-file)))
;
; (defn random-sample-datoms [percent datoms]
;   (let [take-amount (int (* percent (count datoms)))]
;     (take take-amount (shuffle datoms))))
;
;
; (defn generate-sample [size collection]
;   (if (< size (count collection))
;     (take size (shuffle collection))
;     (concat (shuffle collection)
;             (repeatedly (- size (count collection)) (partial rand-nth collection)))))
;
;
; (defn random-sample-by-least-class [multiplier datoms]
;   (let [[least-class amount] (first (sort-by second (frequencies (map (comp :class :features) datoms))))
;         clazz-sets (group-by (comp :class :features) datoms)
;         new-samples (mapcat (fn [[k v]] (generate-sample (* multiplier amount) v)) clazz-sets)]
;     ;(debug (ps (take 2 new-samples)))
;     (shuffle new-samples)))
;
; (defn get-datom-files [directory]
;   (filter (fn [s] (clojure.string/ends-with? s ".datoms"))
;           (map str (file-seq (clojure.java.io/file directory)))))
;
; (defn datoms-file-collection->decision-tree [d-files transform]
;   (let [datoms (mapcat (fn [f] (transform (edn/read-string (slurp f)))) d-files)
;         training-set (train/feature-maps->training-set "training-set" datoms)]
;
;     (train/training-set->decision-tree training-set)))
