(ns jaegers.features.context
  "Functions to support adding contextual data to a feature map"
  (:require
    [clojure.string :as string]
    [datascript.core :as d]
    [jaegers.features.enfeature :as enfeature]
    [jaegers.features.queries :as q]
    [jaegers.utils :as ju]
    [medley.core :refer [assoc-some]]
    [plumbing.core :refer [?>]]
    [taoensso.timbre :as log]))

(defn idvec->id [idvec]
  (string/join #"_" (map str idvec)))

(defn hik-id->ent-id [db hid]
  (first (d/q '[:find [?eid] :in $ ?tok :where [?eid :token-id ?tok]] db hid)))

(defn ent-id->text [db eid]
  (:text (d/entity db eid)))

(defn ent-id->hik-id [db eid]
  (idvec->id (:token-id (d/entity db eid))))

(defn hik-id->text [db hik-id]
  (d/q '[:find [?text] :in $ ?tok :where [?eid :token-id ?tok] [?eid :text ?text]] db hik-id))

; FIXME temporarily flattening until model code is updated to support words grouped by cell
(defn words-by-cell [db datoms]
  (flatten
    (for [part (partition-by :cell-id datoms)]
      (keep (comp (partial ent-id->text db) :db/id) part))))

(defn ids-by-cell [db datoms]
  (flatten
    (for [part (partition-by :cell-id datoms)]
      (keep (comp (partial ent-id->hik-id db) :db/id) part))))

(defn token-component-datoms
  "Returns datoms from the component that contains the token at entity-id"
  [db entity-id & [{:keys [sort-fn] :or {sort-fn (enfeature/token-sort-fn :default)}}]]
  (->> (d/q q/token-component-toks db entity-id)
       (d/pull-many db [:*])
       (filter :text)
       sort-fn))

(defn component-datoms
  "Returns datoms from the component identified by the component-id vector"
  [db component-id & [{:keys [sort-fn] :or {sort-fn (enfeature/token-sort-fn :default)}}]]
  (->> (d/q q/component-toks db component-id)
       (d/pull-many db [:*])
       sort-fn))

(defn component-words
  "Like component-datoms, but only includes datoms with text content"
  [db & [opts]]
  (for [cid (d/q q/component-ids db)
        :let [datoms (component-datoms db cid opts)]]
    (map #(update % :component-id idvec->id)
         (filter :text datoms))))

(defn enhik-db->components
  "Returns a sequence of all components in db"
  [db source & [opts]]
  (map (fn [datoms]
         (let [words (map :text datoms)]
           {:component-id (:component-id (first datoms))
            :ids (map (comp idvec->id :token-id) datoms)
            :words words
            :text (string/join " " words)
            :source source}))
       (component-words db opts)))

(defn add-context
  "Adds all contextual data to fmap required for deep learning applications"
  [db {{:keys [value-type]} :features, :keys [ids] :as fmap}]
  (if-let [[eid :as eids] (->> ids flatten (map ju/id->vec) (keep (partial hik-id->ent-id db)) not-empty)]
    (let [sort-fn (enfeature/token-sort-fn (d/pull db [:file-type :filename :content-type] 1))
          coords (d/pull-many db [:min-x :min-y :max-x :max-y] eids)
          {:keys [cell-id component-id]} (d/entity db eid)
          comp-datoms (token-component-datoms db eid {:sort-fn sort-fn})
          block-datoms (d/pull-many db [:*] (d/q q/block-toks db eid))
          row-datoms (d/pull-many db [:*] (d/q q/row-cells db eid))
          col-datoms (d/pull-many db [:*] (d/q q/column-cells db eid))
          [_ bb ba] (enfeature/eids-around block-datoms eids {:sort-fn sort-fn})
          [_ rb ra] (enfeature/datoms-around-cell row-datoms eid cell-id {:sort-fn sort-fn})
          [_ ca cb] (enfeature/datoms-around-cell col-datoms eid cell-id {:sort-fn sort-fn})]
      (-> (dissoc fmap :features)
          (assoc :value-type value-type
                 :component-id (idvec->id component-id)
                 :ids-in-component (map (comp idvec->id :token-id) comp-datoms)
                 :words-in-component (keep (comp (partial ent-id->text db) :db/id) comp-datoms)
                 :ids-before (keep (partial ent-id->hik-id db) bb)
                 :words-before (keep (partial ent-id->text db) bb)
                 :ids-after (keep (partial ent-id->hik-id db) ba)
                 :words-after (keep (partial ent-id->text db) ba)
                 :ids-in-row-before (ids-by-cell db rb)
                 :words-in-row-before (words-by-cell db rb)
                 :ids-in-row-after (ids-by-cell db ra)
                 :words-in-row-after (words-by-cell db ra)
                 :ids-in-col-above (ids-by-cell db ca)
                 :words-in-col-above (words-by-cell db ca)
                 :ids-in-col-below (ids-by-cell db cb)
                 :words-in-col-below (words-by-cell db cb))
          (?> (seq coords)
              (assoc :min-x (:min-x (apply min-key :min-x coords))
                     :min-y (:min-y (apply min-key :min-y coords))
                     :max-x (:max-x (apply max-key :max-x coords))
                     :max-y (:max-y (apply max-key :max-y coords))))))))

;; ----------------------------------------------------------------------------

; Generate candidates from feature maps

;(defn feature-maps->candidates
;  [control-set]
;  (let [fmaps (feature-maps {:descriptor-id control-set :validated? true})]
;    (->> fmaps
;         (group-by :md5)
;         vals
;         (pmap
;           (fn [[{:keys [md5]} :as fmap-batch]]
;             (let [;; FOR MINDFOOD
;                   [{:keys [mind-food]}] (dtc/mongo->transform :mindfood {:md5 md5})
;                   enhanced-hickory (dtmf/enhik-mindfood mind-food)
;                   ;; FOR ENHIK
;                   ;[{:keys [enhanced-hickory]}] (dtc/mongo->transform :enhik {:md5 md5})
;
;                   db (enfeature/enhik->db primer/dissect-text enhanced-hickory)]
;               (for [{{:keys [value-type]} :features :as fmap} fmap-batch]
;                 (add-context
;                   db
;                   (-> fmap
;                       (select-keys [:string :sentence :md5 :class :ids])
;                       (assoc :features {:value-type value-type} :source :emma)
;                       (update :ids flatten))))
;               #_
;               (mc/insert-batch
;                 (ds/get-db "training-sets") "candidates3"
;                 (for [{{:keys [value-type]} :features :as fmap} fmap-batch]
;                   (add-context
;                     db
;                     (-> fmap
;                         (select-keys [:string :sentence :md5 :class])
;                         (assoc :features {:value-type value-type} :source :emma)
;                         (update :ids flatten))))))))
;         doall
;         #_dorun)))
