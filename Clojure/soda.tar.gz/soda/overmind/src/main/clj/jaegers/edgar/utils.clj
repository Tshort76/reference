(ns jaegers.edgar.utils)

;; NOTE: these distance metrics are duplicated in jaegers.edgar.linking and jaegers.utils
; (defn manhattan-distance [u v]
;   (reduce + (map (comp #(Math/abs ^double %) -) u v)))

(defn euclidean-distance [u v]
  (Math/sqrt (reduce + (map #(* % %) (map - u v)))))

(defn log-distance [u v]
  (let [x (euclidean-distance u v)]
    (if (zero? x) 0 (long (Math/ceil (Math/log10 x))))))

; (defn angle [u v]
;   (let [x  (- (first u) (first v) )
;         y (- (second u) (second v)) ]
;     (Math/atan2 y x)))


; (defn calc-proximity-score [scores cusip-id ids-path]
;   (some->> (keep #(map-indexed
;                     (fn [idx ids]
;                       (array-map
;                         (->> (first ids)
;                              split-and-parse
;                              (manhattan-distance cusip-id))
;                         (update-in % ids-path (fn [idsv] [(nth idsv idx)]))))
;                     (get-in % ids-path))
;                  scores)
;            flatten
;            (into {})))

; (defn levenshtein-distance
;   [a b]
;   (letfn [(l [m [i j]]
;             (if (zero? (min i j))
;               (max i j)
;               (min (inc (get-in m [(dec i) j]))
;                    (inc (get-in m [i (dec j)]))
;                    (+ (get-in m [(dec i) (dec j)])
;                       (if (= (get a (dec i)) (get b (dec j))) 0 1)))))]
;     (let [grid (reduce
;                  (fn [m ij] (assoc-in m ij (l m ij)))
;                  (vec (repeat (count b) []))
;                  (for [i (range (inc (count a))) j (range (inc (count b)))] [i j]))]
;       (get-in grid [(count a) (count b)]))))
