(ns jaegers.tokenvec-solver)

(defn solve-fields [featuremaps]
  (loop [[featuremap & r] featuremaps soln {}]
    (if (or (nil? featuremap) (every? soln (-> featuremap :features-descriptor :class :options)))
      soln
      (recur r (into {(get-in featuremap [:features :class]) featuremap} soln)))))

(defn solve-distinct-fields [featuremaps fields]
  (let [solvables (set fields)]
    (loop [[featuremap & r] featuremaps soln {}]
      (if (or (nil? featuremap) (every? soln solvables))
        soln
        (let [c (get-in featuremap [:features :class])]
          (recur r (cond-> soln (and (solvables c) (not (c soln))) (assoc c featuremap))))))))

(defn solve-multi-fields [featuremaps fields]
  (let [desired (set fields)]
    (->> featuremaps
         (filter (comp desired :class :features))
         (map (fn [m] { (get-in m [:features :class]) m})))))

(defn solve-all-fields [featuremaps & {:keys [distinct-fields nondistinct-fields]}]
  (into [(solve-distinct-fields featuremaps distinct-fields)]
        (solve-multi-fields featuremaps nondistinct-fields)))

(defn classify-featuremaps [classifier & featuremaps]
  (map (fn [{:keys [features] :as fm}]
         (assoc fm :classifier-results (classifier features))) featuremaps))