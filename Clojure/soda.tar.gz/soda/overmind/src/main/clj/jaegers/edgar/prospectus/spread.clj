(ns jaegers.edgar.prospectus.spread
  (:require [clojure.pprint :as pp]
            [edgar.geometric-combo-linker :as gcl]
            [medley.core :refer [map-vals]]
            [plumbing.core :refer [defnk]]))

(def default {:value 0, :jaeger ::spread, :class :spread, :overmind-details {:method :default}})

(defn eliminate-bad-candidates [row-sorted-features]
  (remove #(some (comp #{:gross :benchmark :treasury} :value-type :features) %) row-sorted-features))

(defn spread-row [features]
  (letfn [(vt [{{v :value-type} :features}] v)]
    (into
      ; get basis points or percents following spread labels
      (filter (comp #{:basis-points :percent} vt)
              (drop-while (complement (comp #{:spread} vt)) features))
      ; get percents directly adjacent to "plus"
      (->> features
           (partition 2 1)
           (keep (fn [[x y]] (when (and (#{:plus} (vt x)) (#{:percent} (vt y))) y)))))))

(defn spread-rows [row-sorted-features]
  (mapcat spread-row row-sorted-features))

(defn encandidate [s] {:spread (mapv #(assoc % :class :spread) s)})

(defn promote-percents [soln]
  (map-vals
    (fn [m]
      (cond-> m
        (#{:percent} (get-in m [:features :value-type]))
        (-> (update :value #(double (* (bigdec %) 100)))
            (assoc-in [:features :value-type] :basis-points))))
    soln))

(defnk spread* [coupon-rate-type* ids->coords basic-features row-sorted-features]
  (let [cusips (keys (filter (fn [[_ {:keys [value]}]] (#{:Floating :Fixed-to-float :Float-to-fixed} value)) coupon-rate-type*))
        strong-candidates (spread-rows (eliminate-bad-candidates row-sorted-features))
        weak-candidates (filter #(#{:basis-points} (get-in % [:features :value-type])) basic-features)]
    (promote-percents
      (cond
        (<= 1 (count cusips) (count strong-candidates))
        (gcl/solve-for-edgar :spread cusips (encandidate strong-candidates) ids->coords)

        (<= 1 (count cusips) (count weak-candidates))
        (gcl/solve-for-edgar :spread cusips (encandidate weak-candidates) ids->coords)

        :else (zipmap cusips (repeat default))))))

;[14624 [{:features {:value-type :spread, :term? true},
;         :value "Spread",
;         :max-x 922,
;         :ids [["1_14_0_19_0_0"]],
;         :min-y 14326,
;         :string "Spread",
;         :max-y 14624,
;         :indexes [0 6],
;         :min-x 180}]
; 14922 [{:features {:value-type :index},
;         :value "LIBOR",
;         :max-x 1056,
;         :ids [["1_14_0_19_0_4"]],
;         :min-y 14624,
;         :string "LIBOR",
;         :max-y 14922,
;         :indexes [10 15],
;         :min-x 180}
;        {:features {:value-type ::, :term? true},
;         :value ":",
;         :max-x 1056,
;         :ids [["1_14_0_19_0_4"]],
;         :min-y 14624,
;         :string ":",
;         :max-y 14922,
;         :indexes [15 16],
;         :min-x 180}]]
