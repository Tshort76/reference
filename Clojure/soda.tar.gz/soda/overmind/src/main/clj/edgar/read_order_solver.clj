(ns edgar.read-order-solver
  (:require [math.vecmath :as vecmath]
            [math.stats :as stats]
            [simple-mind.k-means :as km]))
;This name space solves one problem, and one problem only.
;Given a set of candidates and their locations (and ranges)
;on the page, what is the proper order that someone would read them?
;assumes single column, right to left, top to bottom.

;This is the set which has overlapping x ranges
; (def set-0000950103-14-001667 [[865.0 113.0 928.0 137.0]
;                                [862.0 138.0 925.0 162.0]
;                                [770.0 163.0 833.0 187.0]
;                                [779.0 188.0 842.0 212.0]
;                                [890.0 213.0 953.0 237.0]
;                                [833.0 238.0 896.0 262.0]] )

;two rows floating rate vs fixed rate.
;interest payment date
; (def set-0001193125-15-186340  [[933.0 973.0 975.0 997.0]
;                                 [1694.0 985.0 1736.0 1009.0]
;                                 [469.0 1655.0 534.0 1679.0]
;                                 [695.0 1680.0 760.0 1704.0]
;                                 [944.0 1680.0 1009.0 1704.0]
;                                 [1191.0 1680.0 1256.0 1704.0]
;                                 [1438.0 1680.0 1503.0 1704.0]
;                                 [1685.0 1680.0 1750.0 1704.0]])

; (def set-0001193125-07-230063 [[545.0 486.0 623.0 507.0]
;           [1381.0 465.0 1422.0 486.0]
;           [1846.0 465.0 1881.0 486.0]])

(def coord (comp (juxt :min-x :min-y) :coords))

; (defn simple->mock-candidate [[min-x min-y max-x max-y]]
;   { :coords { :min-x min-x
;               :min-y min-y
;               :max-x max-x
;               :max-y max-y}})

(defn variance [numbers]
  (apply stats/variance numbers))

(defn mean-vector [vectors]
  (let [sum-vector (reduce vecmath/add vectors)]
    (vec (map (fn [v] (/ (float v) (count vectors))) sum-vector))
    ))

(defn _vertical? [selector-fn input]
  (if (< 1 (count input))
    (let [ [vx vy] (map variance (apply map vector (map selector-fn input)))]
      (> vy vx))
    true))

(def vertical? (partial _vertical? identity))

(def candidate-vertical? (partial _vertical? coord))

;this are a bit weird, but they cast the 2d array to a scalar
;which most clojure sorting is happier with.
(defn y-warp [[x y]]
  (+ (* 1000 y) x))

(defn x-warp [[x y]]
  (+ (* 1000 x) y))

(defn get-expanse [candidate]
  (let [x-expanse (- (get-in candidate [:coords :max-x])
                     (get-in candidate [:coords :min-x]))
        y-expanse (- (get-in candidate [:coords :max-y])
                     (get-in candidate [:coords :min-y]))]
    [x-expanse y-expanse]))

(defn overlap [candidates]
  (let [bb-min-x (apply min (map (comp :min-x :coords) candidates))
        bb-min-y (apply min (map (comp :min-y :coords) candidates))
        bb-max-x (apply max (map (comp :max-x :coords) candidates))
        bb-max-y (apply max (map (comp :max-y :coords) candidates))
        [bb-x-expanse bb-y-expanse] [(- bb-max-x bb-min-x) (- bb-max-y bb-min-y)]
        [c-x-expanse c-y-expanse] (reduce vecmath/add (map get-expanse candidates))]
    [ (< bb-x-expanse c-x-expanse) (< bb-y-expanse c-y-expanse)]))

;this section deals with candidates that are maps with :coords {:min-y etc
; (def  y-select (comp :min-y :coords))

(defn  y-select-vec [c]
  (if (map? c)
    ((comp vector :min-y :coords) c)
    c))

(def distance-fn (partial km/selector-distance y-select-vec km/vec-distance))

(def average-fn (partial km/selector-average y-select-vec km/vec-average))

(defn cluster-by-y [candidates]
  (let [ grouper (km/k-groups candidates distance-fn average-fn)]
    (vec (first (grouper [(first candidates) (last candidates)])) )))

(defn sort-within-group [candidates]
  (let [[x-overlap y-overlap] (overlap candidates)]
    ;if arranged vertically, sort by y then x
    (if (candidate-vertical? candidates)
      (sort-by (comp y-warp coord)  candidates)
      (if x-overlap; unless we have x overlap
        (sort-by (comp y-warp coord)  candidates)
        (sort-by (comp x-warp coord)  candidates))
    )))

(defn group-centroid [group]
  (mean-vector (map coord group)))

(defn sort-candidates [candidates]
  ;(pprint candidates)
  (if (< (count candidates) 2)
    candidates
    (let [groups (cluster-by-y candidates)
          re-order (map sort-within-group (if (vertical? (map group-centroid groups))
                                            (sort-by (comp y-warp group-centroid) groups)
                                            (sort-by (comp x-warp group-centroid) groups)))]
      (flatten re-order))
    ))
;EXAMPLE ****************
;to mock up a sorting for a set of candidates, do this:
; (sort-candidates (map simple->mock-candidate set-0001193125-07-230063))
