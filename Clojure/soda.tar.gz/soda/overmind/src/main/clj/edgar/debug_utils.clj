(ns edgar.debug-utils
  (:require [jaegers.edgar.primer :as primer]
            [html.utils :as hu]
            [jaegers.edgar.cusips :as cusip-jaeger]
            [enhanced-hickory.core :as ehc]
            [enhanced-hickory.util :as ehu]))
            ; [cheshire.core :as ch]))

(def orig-file-url-prefix "http://dev-soda-intake-group1-app1:8084/soda-jerk-ws/overmind/original-file/?filename=")

;(defn omni-data [md5]
;  (-> (str "http://dev-soda-intake-group1-app1:8084/soda_jerk_ws/overmind/mind-food/?md5=" md5)
;      slurp
;      (ch/parse-string true)))

(defn jaeger-form [m]
  (mapv (fn [[k v]]
          (let [m {:ids v :jaeger ::cusips}]
            {:cusip-3 (assoc m :value (subs k 6 9))
             :cusip-6 (assoc m :value (subs k 0 6))
             :cusip-9 (assoc m :value k)})) m))

(defn enhik->sample-data [enhik]
  {:starts (jaeger-form (cusip-jaeger/explicit-search enhik))
   :ends   (primer/classify-candidates {:enhanced-hickory enhik})
   :enhik  enhik
   :graph  (ehc/enhik->enhiccup enhik)})

(defn filename->sample-data [filename]
  (->> (str orig-file-url-prefix filename) slurp hu/get-html ehc/html->enhik enhik->sample-data))

;(def md5->sample-data (comp enhik->sample-data :mind-food omni-data))

(defn data->options-html [{:keys [enhik starts ends]} & {:keys [only]}]
  (let [subselected (into {:cusip (mapv :cusip-9 starts)} (cond-> ends only (select-keys only)))
        idsmap (zipmap (keys subselected) (map #(mapcat (comp flatten :ids) %) (vals subselected)))
        h (reduce (fn [eh [k ids]] (ehu/add-tooltips eh ids (name k))) enhik idsmap)]
    (->> (vals idsmap)
         (ehu/add-highlight-groups h)
         ehc/enhik->html)))

; (defn doc->options-html [doc-name & {:keys [only]}]
;   (-> doc-name
;       filename->sample-data
;       (data->options-html :only only)
;       (->> (spit (str doc-name "-candidates.html")))))

;(defn md5->options-html [md5 & {:keys [only]}]
;  (-> md5
;      md5->sample-data
;      (data->options-html :only only)))
