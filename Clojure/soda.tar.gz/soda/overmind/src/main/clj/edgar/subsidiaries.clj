(ns edgar.subsidiaries
  (:require
    [clojure.java.io :as io]
    [clojure.string :as string]
    [enhanced-hickory.tokenvec :as eht]
    [instaparse.core :as insta]
    [jaegers.mind-food-utils :as mfu]
    [medley.core :as medley]
    [tokenvec.core :as tv]))

(def blacklist-pattern #"(?i)((subsidiar(y|ies) of)|(name of company))")

(def parser (insta/parser (slurp (io/resource "grammars/organizations.bnf"))))

(def transform
  (partial 
    insta/transform 
    {:UPPER_CHAR str 
     :NUMBER str
     :PAREN_WORD str
     :SEP_WORD str
     :ORG_NUMB str
     :ORG_WORD str
     :ORG_WORDS str 
     :ORG_SUFX str
     :ORG_NAME (fn [& s] {:name (apply str s)})
     :TOKEN (fn [& [w]] w)
     :S (fn [& s] (remove empty? s))}))

(def indexes (comp (juxt :instaparse.gll/start-index :instaparse.gll/end-index) meta))

(defn normalize-name [s] (-> s string/upper-case (string/replace #"\p{P}" "")))

(defn tokenvec->subsidiaries [[s toks]]
  (keep (fn [org]
          (when (and (meta org) (not (re-find blacklist-pattern (:name org))))
            {:name (:name org)
             :ids (mapv :id (tv/unique-tokens toks (indexes org)))})) 
       (transform (parser s))))

(defn enhik->subsidiaries [enhik]
  (some->> enhik
           eht/enhik->tokenvecs
           (mapcat tokenvec->subsidiaries)
           (medley/distinct-by (comp normalize-name :name))))
