(ns edgar.tfidf-enfeaturing
  (:require [simple-mind.naive-bayes.core :as nb]
            [html.utils :as html]
            [medley.core :refer [map-vals]]
            [simple-mind.naive-bayes.util :as nbu]
            [soda.data.file-system :as sdfs]))

(def char-limit 100000)

; (defn md5->html [md5] (some->> md5 (array-map :md5) sdfs/find-file :input-stream slurp html/html-contents))

(def tokenize (comp nbu/->words html/strip-html-tags))

(defn calc-idf [num-docs df] (if (pos? df) (Math/log10 (/ num-docs df)) 0))
(defn calc-tfidf [tf num-docs df] (* tf (calc-idf num-docs df)))

(defn index-tf
  "Returns a map of term -> file-id -> TF score from the words in the md5 document.
   nseq is a sequence of ns for which to build n-grams."
  [nseq html file-id]
  (let [words (when html (tokenize (subs html 0 (min (count html) char-limit))))]
    (reduce
      (fn [m n]
        (let [ngrams (nb/->bag-of-words words :n n :prefix "text-")]
          (merge m (map-vals (fn [v] {file-id (/ v (reduce + (map val ngrams)))}) ngrams))))
      {} nseq)))

(defn enfeature-tfidf
  [html {:keys [doc-freqs doc-count means n-gram-sizes scale] :as tfidf-model}]
  (let [tfs (into {} (map (fn [[k v]] [k (val (first v))])
                          (index-tf n-gram-sizes html 0)))]
    (->> doc-freqs
         (map (fn [[term df]]
                (if-let [tf (get tfs term)]
                  [term (* (calc-tfidf tf doc-count df) scale)]
                  [term (get means term 0)])))
         (into {}))))

(defn prune-terms
  [doc-count min-df max-df tf-index tfidf-index]
  (let [terms (->> tf-index
                   (filter (comp #(or (< % (* min-df doc-count))
                                      (> % (* max-df doc-count)))
                                 count
                                 second))
                   (map first))]
    (apply dissoc tfidf-index terms)))

(defn id-term-map
  "Returns a map of file ID -> term -> TF-IDF score"
  [tfidf-index]
  (reduce-kv
    (fn [m term filemap]
      (reduce-kv (fn [m i tfidf] (update m i assoc term tfidf)) m filemap))
    {} tfidf-index))
