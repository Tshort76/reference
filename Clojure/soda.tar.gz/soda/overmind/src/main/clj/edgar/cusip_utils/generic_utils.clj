(ns edgar.cusip-utils.generic-utils
  (:require [clojure.string :as cs]
            [soda-common.regexes :as rgx]))

;(defn text-contents [s]
;  (some-> s (cs/split #"(?i)<TEXT>") second (cs/split #"(?i)</TEXT>") first))

(defn text-contents [s]
  (->> (cs/split s #"(?i)<TEXT>")
       (map #(cs/split % #"(?i)</TEXT>"))
       (rest)
       (map first)
       (cs/join "\n")))

(defn realtrim [s] (some-> s (cs/replace #"[^\p{Graph}]+" " ") cs/trim))

(def bad-hombres
  (let [pct #"((?:\d|[1-9]\d|1\d{2})|(?:\.\d+)|(?:\d|[1-9]\d|1\d{2})\.\d+)\s*%"
        dbl #"\d+\.\d+"
        money #"\$?\s*(\d{1,3})(,\d{1,3})+(\.\d{1,3})?"
        hyphenated #"-*(?:\d+-)+\d+-*"
        pages #"(?i)Page \d+"
        footnote #"\(\d{0,8}\)"]
    (rgx/alts pct dbl money pages hyphenated rgx/four-digit-year-date rgx/named-month-year hyphenated footnote)))

(defn kill-bad-hombres [s] (cs/replace s bad-hombres ""))
