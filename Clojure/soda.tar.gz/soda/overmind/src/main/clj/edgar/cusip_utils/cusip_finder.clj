(ns edgar.cusip-utils.cusip-finder
  (:require [taoensso.timbre :as timbre]
            [clojure.string :as cs]
            [edgar.cusip-utils.pseudohtml-utils :refer [pseudohtml->lines]]
            [edgar.cusip-utils.generic-utils :as gu :refer [text-contents]]
            [edgar.html-utils :as ehu :refer [html->lines]]
            [html.utils :refer [html-contents] :as hu]
            [soda-common.cusip :as c])
            ; [hickory.core :as hc])
            ; [hiccup-bridge.core :as hicv]

  (:import (org.jsoup Jsoup)))

(def csf
  #"(?:[^\p{Alnum}]|^)([A-Za-z0-9]\s{0,2}(:?[0-9]\s{0,2}){3}[A-Za-z0-9]\s{0,2}[A-Za-z0-9*@#])\s{0,2}(:?([A-Za-z0-9*@#]\s{0,2}){2}([0-9]))(?:[^\p{Alnum}]|$)")

(defn has-potential-checkdigit? [s]
  (when (and (string? s) (> (count s) 8))
    (re-matches #".*\d+.*" (subs s 8))))

(defn has-cusip-word? [s] (when (string? s) (re-matches #"(?is).*cusip.*" s)))

; (defn has-cusip? [s] (when (string? s) (not-empty (re-seq csf s))))

(defn line->cusips [^String line]
  (try
    (some->>
      line
      gu/kill-bad-hombres
      (#(cs/split % #"[^\p{Alnum}*@# ]+"))
      (map cs/trim)
      (filter has-potential-checkdigit?)
      (filter #(>= (count (cs/replace % #"\s+" "")) 9))
      (mapcat (partial re-seq csf))
      (map #(cs/replace (first %) #"\s+" ""))
      (filter c/valid?)
      distinct
      not-empty)
    (catch Exception _ (timbre/error (str "Failed to get cusips from :\"" line "\".")))))

(defn file-contents->lines [file-contents]
  (if-some [html (html-contents file-contents)]
    (html->lines html)
    (pseudohtml->lines file-contents)))

(defn slurpable->lines [is]
  (if-some [text (some-> is slurp text-contents)]
    (file-contents->lines text)
    (timbre/warn (str "No <TEXT> section was found in: " is))))

; (defn lines->lines-values-of-interest [lines]
;   (->> lines
;        (map-indexed (fn [i line] [i {:cusip? (has-cusip-word? line) :cusips (line->cusips line)}]))
;        (drop-while (comp nil? :cusip? second))
;        (filter (fn [[_ {:keys [cusip? cusips]}]] (or cusip? cusips)))))

; (defn cluster-cusips [vois]
;   (loop [[[i {:keys [cusip?] :as m} :as f] & r] vois clusters []]
;     (cond
;       (nil? f) (filter #(some (comp :cusips second) %) clusters)
;       (some? cusip?) (recur r (conj clusters [[i (assoc m :delta 0)]]))
;       :default (let [cluster (peek clusters)
;                      j (first (peek cluster))]
;                  (recur r (conj (pop clusters) (conj cluster [i (assoc m :delta (- i j))])))))))

; (defn sanitize-cluster [cluster]
;   (take-while (comp #(< % 20) :delta second) cluster))

; (defn cleanup [clusters]
;   (into #{} (for [cluster clusters [_ {:keys [cusips]}] (sanitize-cluster cluster) cusip cusips] cusip)))

; (defn cusip-search [lines]
;   (->> lines
;        lines->lines-values-of-interest
;        cluster-cusips
;        cleanup))

; (defn find-cusips [is]
;   (-> is slurpable->lines cusip-search))

;OOM 0001193125-06-063114.txt
;S/O 0001144204-12-030653.txt
;S/O 0000950136-06-000421.txt ;FWP
; (defn web-file->cusips [filename]
;   (try
;     (find-cusips (str "http://dev-soda-app3:8084/soda-jerk-ws/overmind/original-file/?filename=" filename))
;     (catch Exception _ (str "web-file->cusips failed with \"" filename "\"."))))

;(def jsoup1 (.get (Jsoup/connect "http://dev-soda-intake-group1-app1:8084/soda_jerk_ws/edgar-prospectus/0000950136-06-000421.txt")))
;
;(def jsoup
;  (->> "so-0000950136-06-000421.txt"
;       slurp
;       text-contents
;       html-contents
;       ;hicv/html->hiccup
;       hc/parse
;       ;hc/as-hiccup
;       ;count
;       ;hc/as-hickory
;       ;hik->lines
;       ))
;
;(defn foo [e]
;  (first (.children e)))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;Section for testing the current interesting file
;Misses "06050XZD8" - The html isn't simplified because it doesn't recognize it as such.
;(def current-test-file "0000353524-94-000057.txt")
;(def current-test-file-url (str "http://dev-soda-app3:8084/soda-jerk-ws/overmind/original-file/?filename=" current-test-file))
;
;(web-file->cusips current-test-file)
;(slurpable->lines current-test-file-url)
;(-> current-test-file-url
;    slurp
;    text-contents
;    ;(cs/replace #"(?i)<[^>]*>" " ")
;    ;StringEscapeUtils/unescapeHtml
;    ;kill-bad-hombres
;    ;cs/split-lines
;    )

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
