(ns edgar.cusip-utils.pseudohtml-utils
  (:require [clojure.string :as cs]
            [edgar.cusip-utils.generic-utils :refer [realtrim kill-bad-hombres]])
  (:import (org.apache.commons.lang StringEscapeUtils)))

(defn pseudohtml->lines [file-contents]
  (some-> file-contents
          ;Eliminate tags
          (cs/replace #"(?i)<[^>]*>" " ")
          StringEscapeUtils/unescapeHtml
          kill-bad-hombres
          cs/split-lines
          (->> (map realtrim) (filter not-empty))))