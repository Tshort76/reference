(ns edgar.geometric-combo-linker
  (:require [clojure.math.combinatorics :as combo]
            [edgar.link-geometries :as elg]
            [math.vecmath :as vecmath]
            [math.stats :as math]
            [edgar.read-order-solver :as ros]))

(def coord (comp (juxt :min-x :min-y) :coords))

(def dummy-solution
  {:dummy? true
   :coords {:min-x Double/NaN :min-y Double/NaN :max-x Double/NaN :max-y Double/NaN}
   ::cartesian-coordinates [Double/NaN Double/NaN]
   ::polar-coordinates [Double/NaN Double/NaN]
   ::theta Double/NaN})

(defn enfeature-solution-pair [target solution]
  (if (some identity solution)
    (let [target-coord (coord target)
          solution-coord (coord solution)
          [dx dy :as v] (vecmath/sub solution-coord target-coord)
          theta (Math/atan2 dy dx)]
      {:target target
       :solution (-> solution
                     (update :jaeger (fn [j] (or j :jaegers.edgar.geometric-multilink/geometric-combo-multilink)))
                     (assoc ::cartesian-coordinates v
                            ::polar-coordinates (vecmath/cartesian->polar v)
                            ::theta theta))})
    {:target target
     :solution dummy-solution}))

(defn create-single-multilink [targets solutions]
  (mapv
    (fn [target solution]
      (enfeature-solution-pair target solution))
    (ros/sort-candidates targets)
    (ros/sort-candidates solutions)))

(defn create-solution-groups [targets solutions]
  (let [num-tar (count targets)
        num-sol (count solutions)]
    (mapv
      (partial create-single-multilink targets)
      (if (>= num-sol num-tar)
        (combo/combinations solutions num-tar)
        (vector (into solutions (repeat (- num-tar num-sol) dummy-solution)))))))

(defn get-best-subgroup
  "Returns the highest-confidence subset of candidates with the same cardinality
  as targets. If none is found, returns candidates."
  [targets candidates]
  (let [sub-groups (group-by (comp (juxt :confidence (comp first :contributions)) :classifier-results) candidates)
        best (first (reverse (sort (keys sub-groups))))]
    (if (= (count (sub-groups best)) (count targets))
      (sub-groups best)
      candidates)))

(defn cluster-size-from-centroid [& vs]
  (let [center (apply math.vecmath/centroid vs)
        from-center (map (partial vecmath/sub center) vs)
        mags (map math.vecmath/mag from-center)
        mean (apply math/mean mags)]
    mean))

(defn enfeature-solution-group [solution-group]
  (let [{:keys [::x-deviation ::y-deviation] :as solution}
        {:solution-group      solution-group
         ::theta-deviation    (apply math/stddev (map (comp ::theta :solution) solution-group))
         ::x-deviation        (apply math/stddev (map (comp first ::cartesian-coordinates :solution) solution-group))
         ::y-deviation        (apply math/stddev (map (comp second ::cartesian-coordinates :solution) solution-group))
         ::distance-deviation (apply math/stddev (map (comp first ::polar-coordinates :solution) solution-group))
         ::cluster-deviation  (apply cluster-size-from-centroid (map (comp ::cartesian-coordinates :solution) solution-group))
         ::mean-distance      (apply math/mean (map (comp first ::polar-coordinates :solution) solution-group))}]
    solution))

(defn get-solutions [targets candidates]
  (->> (get-best-subgroup targets candidates)
       (create-solution-groups targets)
       (map enfeature-solution-group)
       (filter (comp pos? count :solution-group))))

(defn rms-error [m]
  (vecmath/mag ((juxt ::x-deviation ::y-deviation ::theta-deviation ::distance-deviation) m)))

(defn choose-best [solution-groups]
  (let [{:keys [solution-group] :as best}
        (first (sort-by (juxt ::cluster-deviation ::mean-distance rms-error) solution-groups))]
    (map (fn [m]
           (if-not (get-in m [:solution :dummy?])
             (update m :solution (partial merge (dissoc best :solution-group)))
             (assoc m :solution nil)))
         solution-group)))

;; -----------------------------------------------------------------------------

; If |candidates| < |targets|:
;   Swap targets and candidates, compute best links, and re-link with only the chosen targets
(defn link
  "Returns best geometric combo links between targets and candidates."
  [targets candidates]
  (let [filtered-targets
        (if (>= (count candidates) (count targets))
          targets
          (let [swapped-best (choose-best (get-solutions candidates targets))]
            (map #(array-map :coords (get-in % [:solution :coords])) swapped-best)))]
    (->> (get-solutions filtered-targets candidates)
         choose-best)))

;; -----------------------------------------------------------------------------

(defn solve [targets target-field candidates candidate-field ids->geom]
  (let [linkable-target->original-target (zipmap (map (comp ids->geom target-field) targets) targets)
        linkable-candidates (map ids->geom (candidate-field candidates))
        final-solution (link (keys linkable-target->original-target) linkable-candidates)]
    (into {}
          (map (fn [{:keys [target solution]}]
                 [(linkable-target->original-target target)
                  (assoc solution :field candidate-field)])
               final-solution))))

(defn solve-for-edgar [candidate-field cusips candidates ids->coords]
  (solve cusips :cusip-9 candidates candidate-field (partial elg/add-jaeger-doc-geom ids->coords)))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;WEIRD PROBLEM TO LOOK AT LATER;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; (defn add-geometric-coordinates [{:keys [enhanced-hickory] :as omni} cusip-docs]
;   (let [ids->geom (partial elg/add-jaeger-doc-geom (elg/create-ids->geometries-map (elg/create-geometry-maps enhanced-hickory)))]
;     (-> omni
;         (assoc :securities (elg/create-security-nodes cusip-docs ids->geom))
;         (update :candidates elg/create-solution-nodes ids->geom))))

; (defn query->solutions-graph [query]
;   (let [{:keys [enhanced-hickory] :as m} (jp/query->omni-data query)]
;     (when (nil? enhanced-hickory)
;       (timbre/warn (str "(:enhanced-hickory (jp/query->omni-data " query ")) returned nil.")))
;     (add-geometric-coordinates m (some->> enhanced-hickory cusip-jaeger/explicit-search edbug/jaeger-form))))

;;Sort order of combo is jacked up.
;(defonce solutions-graph (query->solutions-graph {:filename "0001193125-12-302065.txt"}))
;
;(-> solutions-graph
;    (update :candidates select-keys [:interest-rate])
;    combos
;    :interest-rate
;    choose-combo
;    vals
;    (->> (map #(select-keys % [:cusip-9 :interest-rate])))
;    (->> (mapv (fn [m] (zipmap (keys m) (map #(select-keys % [:value :coords]) (vals m)))))))
;
;(->> [{:cusip-9 {:value "03523TBP2", :coords {:min-x 8.0, :min-y 10886.0, :max-x 48.0, :max-y 10907.0}},
;       :interest-rate {:value 1.375, :coords {:min-x 153.0, :min-y 1225.0, :max-x 217.0, :max-y 1246.0}}}
;      {:cusip-9 {:value "03523TBQ0", :coords {:min-x 8.0, :min-y 10924.0, :max-x 48.0, :max-y 10945.0}},
;       :interest-rate {:value 2.5, :coords {:min-x 153.0, :min-y 1263.0, :max-x 217.0, :max-y 1284.0}}}
;      {:cusip-9 {:value "03523TBN7", :coords {:min-x 8.0, :min-y 10848.0, :max-x 48.0, :max-y 10869.0}},
;       :interest-rate {:value 3.75, :coords {:min-x 153.0, :min-y 1301.0, :max-x 217.0, :max-y 1322.0}}}
;      {:cusip-9 {:value "03523TBM9", :coords {:min-x 733.0, :min-y 10791.0, :max-x 773.0, :max-y 10812.0}},
;       :interest-rate {:value 0.8, :coords {:min-x 812.0, :min-y 1529.0, :max-x 873.0, :max-y 1550.0}}}]
;     (mapcat identity)
;     (sort-by (juxt (comp :min-y :coords second) (comp :min-x :coords second))))
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;;;MSB - example
;(def m (-> "m.edn" slurp edn/read-string (update :candidates select-keys [:issue-date])))
;(def cusip-docs (map #(select-keys % [:issue-date :cusip-6 :cusip-3 :cusip-9]) (-> "c.edn" slurp edn/read-string)))
;
;(->> cusip-docs
;     (generate-solutions-graph m)
;     solutions-graph->securities)
;
;(->> cusip-docs
;     (generate-solutions-graph m)
;     combos
;     (map (fn [[k v]] [k (remove-poor-solutions v)]))
;     (filter (comp pos? count second))
;     (map (fn [[k v]] [k (choose-combo v)])))

;{:value #inst"2021-05-23T00:00:00.000-00:00",
; :ids [["1_26_0_0_16_2_0_0_0" "1_26_0_0_16_2_0_0_2" "1_26_0_0_16_2_0_0_4"]],
; :classifier-results {:class :maturity-date, :contributions [7091 0], :confidence 1.0},
; :class :maturity-date,
; :coords {:min-x 856.0, :min-y 1359.0, :max-x 891.0, :max-y 1380.0}}
;(->> {:filename "0001341004-11-002019.txt"}
;     query->solutions-graph
;     :enhanced-hickory
;     ;:candidates
;     ;:maturity-date
;     )

;(->> {:filename "0001193125-15-231936.txt"}
;     query->solutions-graph
;     solutions-graph->securities
;     )

;;I think this has bad coords
;(defonce test-0 (query->solutions-graph {:filename "0000930413-12-005553.txt"}))
;(solutions-graph->securities test-0)
;
;(->> test-0
;     combos
;     vals
;     (filter (comp pos? count))
;     (map #(first (sort-by (juxt ::theta-deviation ::x-deviation ::y-deviation ::distance-deviation) %)))
;     (mapcat :solution)
;     (group-by (comp :value :cusip-9))
;     vals
;     (mapv #(reduce into %)))

#_(defn add-solution-tooltips [enhik {:keys [cusip-9] :as solution}]
  (reduce
    (fn [h [k {:keys [ids]}]]
      (let [[first-id :as flat-ids] (flatten ids)]
        (enhik/add-tooltips h flat-ids (str (:value cusip-9) " : " (name k) " : " first-id))))
    enhik
    (seq solution)))

#_(defn add-highlights [enhik solutions]
  (->> solutions
       (map #(filter identity (flatten (map :ids (vals %)))))
       (enhik/add-highlight-groups enhik)))

#_(defn doc->link-html [doc-name]
  (timbre/info (str "Processing " doc-name))
  (let [{:keys [enhanced-hickory] :as m} (query->solutions-graph {:filename doc-name})
        min-deviation-solution (solutions-graph->securities m)
        h (reduce add-solution-tooltips enhanced-hickory min-deviation-solution)]
    (some->>
      min-deviation-solution
      seq
      (add-highlights h)
      enhik/enhik->html
      (spit (str doc-name "-x.html")))))

;(let [{:keys [enhanced-hickory] :as m} (query->solutions-graph {:filename "0001193125-15-276636.txt"})
;      min-deviation-solution (solutions-graph->securities m)
;      h (reduce add-solution-tooltips enhanced-hickory min-deviation-solution)]
;  (some->>
;    min-deviation-solution
;    seq
;    (add-highlights h)
;    enhik/enhik->html
;    (spit (str doc-name "-x.html"))))

;(doc->link-html "0001193125-15-231936.txt")
;(doc->link-html "0000930413-12-005553.txt")
;(doc->link-html "0000950103-14-001667.txt")
;(doc->link-html "0001068800-03-000687.txt")
;(doc->link-html "0001193125-14-085108.txt")
;;

;;;;;;;;;;;;;;;;;;;;Tests and stuff;;;;;;;;;;;;;;;;;;;;;;;;;
;(query->solution-links {:filename "0000950103-14-001667.txt"})
;(query->solution-links {:filename "0001068800-03-000687.txt"})
;(edbug/doc->options-html "0001068800-03-000687.txt")
;(edbug/doc->options-html "0000950123-10-022755.txt")
;(edbug/doc->options-html "0001193125-08-019447.txt")
;(edbug/doc->options-html "0001193125-17-005695.txt")
;(edbug/doc->options-html "0000930413-08-002530.txt")
;(edbug/doc->options-html "0001193125-15-378630.txt")

#_(def docs
  ["0000930413-12-005553.txt"
   "0001193125-15-231936.txt"                               ;Some other weird case
   "0000950103-14-001667.txt"                               ;no interest rate - ugh
   "0000950123-10-022755.txt"                               ;interest rate correct
   "0001193125-13-101307.txt"                               ;interest rate correct
   "0001193125-14-092176.txt"                               ;no cusips
   "0001193125-12-115286.txt"                               ;interest rate correct
   "0001193125-15-378630.txt"                               ;interest rate correct
   "0001193125-15-040186.txt"                               ;interest rate correct
   "0001193125-13-227663.txt"                               ;wrong order in interest rate
   "0001193125-14-085108.txt"                               ;wth?
   "0001193125-15-186340.txt"                               ;wrong interest rate
   "0001193125-15-378630.txt"
   "0001104659-10-020840.txt"
   "0001104659-16-106651.txt"
   "0001193125-08-019447.txt"
   "0001193125-17-005695.txt"                               ;Maturity date issue
   "0000930413-08-002530.txt"                               ;Maturity date issue
   "0001193125-07-230063.txt"                               ;  https://jira.arbfund.com/browse/SODA-2368 -cross link
   "0001193125-15-036444.txt"                               ;  https://jira.arbfund.com/browse/SODA-2368 -cross link
   "0001193125-10-252363.txt"                               ;  https://jira.arbfund.com/browse/SODA-2368 -cross link
   "0000950142-11-001963.txt"                               ;we don't cross link, but choose the wrong interest rate
   ;"0001068800-03-000687.txt"                               ;Stretch goal - it's huge
   ])

;(doc->link-html "0000930413-08-002530.txt")

#_(defn sample-run []
  (time (count (map doc->link-html docs))))
