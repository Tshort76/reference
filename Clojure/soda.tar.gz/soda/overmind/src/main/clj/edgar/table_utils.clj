(ns edgar.table-utils
  (:require [clojure.string :as cs]
            [edgar.parse-utils :as pu]
            [hickory.select :as s]
            ; [soda-common.regexes :as rgx]
            ; [soda-common.cusip :as c]
            [soda.core :as soda]
            [edgar.html-utils :as hu]))

; (defn table->row-data [[k v]] (zipmap (map (comp pu/parse-key :text) k) v))

; (defn table->col-data [table]
;   (reduce into {}
;           (map (fn [[{:keys [text]} v & c]]
;                  (when (and v (empty? c))
;                    {(name (pu/parse-key text)) v})) table)))

; (defn cleanup-tables [tables]
;   (letfn [(f [t] (vec (filter #(-> % count dec pos?) t)))]
;     (f (mapv f tables))))

; (defn data-guess [table]
;   (let [nr (count table)
;         nc (pu/most-freq (map count table))
;         ;fro (filter (fn [row] (= nc (count row))) t)
;         ]
;     (cond
;       (and (== 2 nr) (> nc 2)) (pu/parse-values (table->row-data table))
;       (and (== 2 nc) (> nr 2)) (pu/parse-values (table->col-data table))
;       :default nil)))

(defn cell-data [v]
  (letfn [(sjoin [s] (cs/join " " (filter not-empty (map pu/realtrim s))))]
    (cond
      (map? v) (let [{:keys [content]} v]
                 (if (every? string? content) (sjoin content) (cell-data (map cell-data content))))
      (nil? v) nil
      (string? v) v
      (every? string? v) (sjoin v)
      :default (cell-data (map cell-data v)))))

(defn get-cells [h] (s/select (s/tag :td) h))
(defn get-rows [h] (s/select (s/tag :tr) h))
(defn get-tables [h] (s/select (s/tag :table) h))

(defn table-data [hik]
  (letfn [(simplify [v] (vec (filter not-empty v)))]
    (simplify
      (for [{table-content :content} (get-tables hik)
            :when (not-empty table-content)]
        (simplify
          (for [row-contents (map get-rows table-content)
                {row-content :content} row-contents
                :when (not-empty row-content)]
            (simplify
              (flatten
                (for [cell-contents (map get-cells row-content)
                      {cell-content :content {id :id colspan :colspan} :attrs} cell-contents
                      :when (not-empty cell-content)
                      :let [s (cell-data cell-content)
                            colspan (soda/parse-long colspan)]]
                      ;This prevents filtering of empty string cells. We need them for correct table padding.
                      ;:when (not-empty s)

                  (cons {:text s :id id}
                        (repeat (dec (or colspan 0)) {:text ""})))))))))))

; (defn flatten-rows [table] (mapv #(cs/join " " (map :text %)) table))

; (defn left [[t r c]] [t r (dec c)])
; (defn right [[t r c]] [t r (inc c)])
; (defn up [[t r c]] [t (dec r) c])
; (defn down [[t r c]] [t (inc r) c])
; (defn walk [dir] (partial iterate dir))
; (def walk-left (walk left))
; (def walk-right (walk right))
; (def walk-up (walk up))
; (def walk-down (walk down))

;(def sample
;  (->> "0000764764-12-000088.txt" filename->hik table-data))

; (defn contains-cusip? [text] (not-empty (re-seq #"(?i)cusip" text)))
; (defn contains-maturity? [text] (not-empty (re-seq #"(?i)maturity" text)))

(defn cell-search [tables text-pred?]
  (for [t (range (count tables)) r (range (count (get-in tables [t]))) c (range (count (get-in tables [t r])))
        :when (some-> (get-in tables [t r c :text]) text-pred?)]
    [t r c]))

; (defn col [table c] (mapv #(get % c) table))
; (defn row [table r] (get table r))

; (defn search-walk [tables coords dir]
;   (take-while not-empty (map (partial get-in tables) ((walk dir) coords))))

; #_(defn find-potential-data [tables acceptfn]
;    (for [cell (cell-search tables acceptfn) dir [right down]]
;      (cs/join " " (filter not-empty (map :text (search-walk tables cell dir))))))

; (defn find-potential-data [tables acceptfn]
;   (for [[t r c] (cell-search tables acceptfn)
;         :let [rt (row (tables t) r)
;               ct (col (tables t) c)]]
;     [{:text (cs/join " " (filter not-empty (map :text rt))) :ids (keep :id rt)}
;      {:text (cs/join " " (filter not-empty (map :text ct))) :ids (keep :id ct)}]))

;(map down (cell-search sample contains-cusip?))

;(-> "0000764764-12-000088.txt"
;    filename->hik
;    table-data
;    (find-potential-data #(not-empty (re-seq #"(?i)price" %))))
;
;(-> "0000764764-12-000088.txt"
;    filename->hik
;    table-data
;    (find-potential-data #(not-empty (re-seq #"(?i)cusip" %))))

; (defn filename->table-data [filename]
;   (some-> filename hu/filename->decorated-hik table-data))

; (defn term-hunt [term table-data coarse-query fine-query parsefn]
;   (mapcat
;     (fn [[{r :text rids :ids} {c :text cids :ids}]]
;       (cond-> []
;               (fine-query r) (conj {term (parsefn r) :ids rids})
;               (fine-query c) (conj {term (parsefn c) :ids cids})))
;     (find-potential-data table-data coarse-query)))

; (defn hunt-maturity-date [table-data]
;   (term-hunt
;     :maturity-date
;     table-data
;     #(not-empty (re-seq #"(?i)maturity" %))
;     #(not-empty (re-seq #"(?i)maturity date" %))
;     #(some->> % (re-seq rgx/date) first first)))

; (defn hunt-cusip [table-data]
;   (term-hunt
;     :cusip
;     table-data
;     #(not-empty (re-seq #"(?i)cusip" %))
;     #(not-empty (re-seq c/cusip-9-rgx %))
;     #(some->> % (re-seq c/cusip-9-rgx) first first)))

; (defn hunt-fields [table-data]
;   [(hunt-maturity-date table-data)
;   (hunt-cusip table-data)])

;(hunt-fields (filename->table-data "0000764764-12-000088.txt"))

;Failure mode
;(hunt-fields (filename->table-data "0000897101-02-000737.txt"))

;;Interesting cases
;Jagged array (data in columns)
;http://dev-soda-app3:8084/soda-jerk-ws/edgar-prospectus/0000764764-12-000065.txt
;Row data
;http://dev-soda-app3:8084/soda-jerk-ws/edgar-prospectus/0000038009-13-000035.txt
;Fairly standard column data
;http://dev-soda-app3:8084/soda-jerk-ws/edgar-prospectus/0000950103-15-007874.txt
;Keys and vals spread across multiple columns in a td (row data)
;http://dev-soda-app3:8084/soda-jerk-ws/edgar-prospectus/0000764764-12-000088.txt
