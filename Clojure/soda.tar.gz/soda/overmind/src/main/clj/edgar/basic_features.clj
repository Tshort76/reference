(ns edgar.basic-features
  (:require [enhanced-hickory.core :as ec]
            [jaegers.mind-food-utils :as mfu]
            [jaegers.hickory-utils :as hu]
            [clojure.edn :as edn]
            [clojure.zip :as zip]
            [jaegers.regisector :as rs]
            [clojure.string :as cs]
            [soda-common.parsers :as scp]
            [soda-common.regexes :as rgx]
            [soda-common.isin :as isin]
            [soda-common.cusip :as cusip]
            [soda.data.file-system :as sdfs]
            [html.utils]
            [jaegers.edgar.primer :as primer]
            [soda.data.core :as sdc]
            [clojure.java.io :as io]
            [tokenvec.core :as tv]))

(sdc/defcon "training-sets" "features-descriptors" :updatable true)
(sdc/defcon "training-sets" "feature-maps")

(defn alts-regex [alts]
  (re-pattern (str "(?i)(?:\\b|^)" (cs/join "|" alts) "(?:\\b|$)")))

(defn terms->feature-desc [w]
  (->>
    w
    (sort-by count >)
    (mapv (juxt (comp keyword #({":" "colon"} % %)) #(re-pattern (str "(?i)(?:\\b|^)" % "(?:\\b|$)"))))))

(def interesting-phrases
  (into
    [[:interest-rate #"(?i)(coupon|((interest|coupon|annual) rate)|(fixed rate note))"]
     [:issue-date #"(?i)(((original |expected )?(issue|settle(ment)?) date)|(date of issue)|((expected )?settlement))"]
     [:maturity-date #"(?i)((stated )?maturity( date)?|matur(e|ing|ities))"]
     [:principal-amount #"(?i)((aggregate )?(principal|face) amount)( offered)?"]
     [:issue-price #"(?i)(initial )?((price to (the )?(public|investors))|((issue|selling) price)|((public )?offering price))"]
     [:first-coupon-date #"(?i)(1\s?st |first )?(((interest )?pay(ment)?)|coupon) dates?"]
     [:call-option-date #"(?i)(((optional )?redemption( information)?))"]
     [:accrual-start-date #"(?i)(interest )?accrual date"]
     [:per-note #"(?i)per note"]
     [:common-code #"(?i)common code"]]
    (terms->feature-desc
      ["actual" "aggregate" "allocation" "amount" "annual" "annum" "authorized"
       "beginning" "benchmark"
       "callable" "certificate" "commencing" "coupon" "cusip" "concurrent"
       "date" "delivery" "denomination" "due"
       "face" "first" "fixed" "floating" "frequency"
       "gross"
       "inception" "increment" "indexed" "information" "initial" "interest" "issue"
       "mandatory" "maturity" "maximum" "minimum" "month" "multiple"
       "note" "number"
       "offering" "offerings" "offered" "option" "optional" "original"
       "payment" "plus" "price" "pricing" "principal" "prospectus"
       "rate" "record" "redemption" "registration"
       "securities" "security" "settlement" "size" "spread" "state" "stated" "supplement"
       "tax" "term" "title" "total" "trade" "treasury"
       "yield"
       ":"])))

(def term-splits
  (let [split-def (fn [[kw re]]
                    {:regex   re
                     :handler (fn [s]
                                {:value (cond-> s (not (string? s)) first) :features {:value-type kw :term? true}})})]
    (map split-def interesting-phrases)))

(def re-percent #"((?:\d|[1-9]\d|1\d{2})|(?:\.\d+)|(?:\d|[1-9]\d|1\d{2})\.\d+)\s?%")
(def re-money #"\$\s*(\d{1,3})(,\d{3})*(\.\d{1,2})?(\p{Z}*(((m|b|tr)illion)|mm))?")
(def re-money-like #"(\d{1,3})(,\d{3})+(\.\d{1,2})?")
(def re-double #"(\d{1,3}\.\d{1,3})")
(def re-int #"(\d+)")
(def re-rule #"(?i)(?:rule (\d+(?:\(\s*\p{Alnum}\))*))")
(def re-page-number #"(?i)page\s+(\d+)")
(def re-section #"(?i)section\s+(\d+)")
(def re-basis-points #"(?i)(minus\s*|plus\s*|[+-]?)((?:\d{1,3}(?:,\d{3})*\.\d+)|(?:\d+(?:\.\d+)?))\s*(?:bps|basis points)")
(def numbers (zipmap ["zero" "one" "two" "three" "four" "five" "six" "seven" "eight" "nine" "ten" "eleven" "twelve"
                      "thirteen" "fourteen" "fifteen" "sixteen" "seventeen" "eighteen" "nineteen" "twenty" "twenty-one"
                      "twenty-two" "twenty-three" "twenty-four" "twenty-five" "twenty-six" "twenty-seven" "twenty-eight"
                      "twenty-nine" "thirty"] (range)))
(def false-check-box
  (zipmap ["☐" "&#9744" "\\[ \\]" "£" "&#163" "¨" "&#168" "&#161" "\\[_\\]" "\\| \\|" "___" "/ /" "\\( \\)" "o" "&#111"] (repeat :unchecked)))
(def true-check-box
  (zipmap ["☒" "&#9746" "þ" "&#254" "ý" "&#253" "\\[x\\]" "\\|x\\|" "/x/" "\\(x\\)" "\\[\\*\\]"
           "\\[ x \\]" "\\| x \\|" "/ x /" "\\( x \\)" "\\[ \\* \\]" "x"] (repeat :checked)))
(def re-security-alias #"(?i)(\d{4} (?:notes|bonds))|((?:notes|bonds) due \d{4})")
(def check-box (merge true-check-box false-check-box))
(def re-check-box (re-pattern (str "(?i)(?:(?:^|\\b|\\p{Z})" (cs/join "(?:\\b|\\p{Z}|$)|(?:^|\\b|\\p{Z})" (keys check-box)) "(?:\\b|\\p{Z}|$))")))
(def re-day-span (re-pattern (str "(?i)(?:(" (cs/join "|" (keys numbers)) ")|(\\d+))[\\s-]DAYS?")))
(def re-month-span (re-pattern (str "(?i)(?:(" (cs/join "|" (keys numbers)) ")|(\\d+))[\\s-]MONTHS?")))
(def re-year-span (re-pattern (str "(?i)(?:(" (cs/join "|" (keys numbers)) ")|(\\d+))[\\s-]YEARS?")))

(defn basis-points-parser [[_ s v]]
  (let [sign (some-> s cs/trim cs/lower-case {"+" 1 "-" -1 "plus" 1 "minus" -1})]
    (* (or sign 1) (Double/parseDouble v))))

(defn value [value-type regex & {:keys [parser]}]
  (cond-> {:regex regex :value-type value-type} parser (assoc :parser parser)))

(def value-splits
  [(value :isin isin/regex)
   (value :cusip cusip/regex)
   (value :cusip-like rgx/cusip-9-like)
   (value :index (alts-regex ["(?:U.S. Dollar )?Constant Maturity Swap Rate" "30CMS" "10CMS" "CMS10" "CMS30" "10CMS" "CMS7"
                              "libor" "3mL" "STISEK3M" "CIDKK3M" "CMT" "AUBB3M" "EURIBOR" "BBSW"]))
   (value :security-alias re-security-alias :parser (fn [[_ s1 s2]] (cond s1 (cs/lower-case s1) s2 (cs/lower-case (str (re-find #"\d{4}" s2) " " (re-find #"notes|bonds" s2))))))
   (value :date rgx/date :parser (fn [[s]] (:date (scp/parse s))))
   (value :month-day rgx/month-day :parser (fn [[_ m d]] (scp/parse (str m " " d))))
   (value :year-offset #"T[+-] ?(\d\d?)"  :parser (fn [[_ s]] (Long/parseLong s)))
   (value :month-span re-month-span :parser (fn [[_ named-num digits]] (if named-num (numbers (cs/lower-case named-num)) (Long/parseLong digits))))
   (value :year-span re-year-span :parser (fn [[_ named-num digits]] (if named-num (numbers (cs/lower-case named-num)) (Long/parseLong digits))))
   (value :day-span re-day-span :parser (fn [[_ named-num digits]] (if named-num (numbers (cs/lower-case named-num)) (Long/parseLong digits))))
   (value :phone-number #"\d-\d{3}-\d{3}-\d{4}")
   (value :rule re-rule :parser (fn [[_ s]] s))
   (value :basis-points re-basis-points :parser basis-points-parser)
   (value :numeric-code #"\p{Alnum}+(?:-\d+)+")
   (value :year-due #"(?i)due\s*(\d{4})" :parser (fn [[_ s]] (Long/parseLong s)))
   (value :page-number re-page-number :parser (fn [[_ s]] (Long/parseLong s)))
   (value :section re-section :parser (fn [[_ s]] (Long/parseLong s)))
   (value :percent re-percent :parser (fn [[s]] (-> s scp/parse first val double)))
   (value :dollars re-money :parser (fn [[s]] (-> s scp/parse first val double)))
   (value :dollars-like re-money-like :parser (fn [[s]] (-> s scp/parse first val double)))
   (value :number re-double :parser (fn [[s]] (Double/parseDouble s)))
   (value :int re-int :parser (fn [[s]] (Long/parseLong s)))
   (value :check-box re-check-box :parser (fn [s] (get check-box (-> s cs/lower-case cs/trim))))])

(def all-splits (into value-splits term-splits))
(defn dissect-text [s] (rs/dissect s all-splits))

; (def class-options
;   [:accrual-start-date
;    :face-value
;    :first-coupon-date
;    :interest-rate
;    :issue-date
;    :issue-price
;    :maturity-date
;    :other
;    :principal-amount
;    :call-option-date
;    ;Floating rate values
;    :multiplier
;    :spread
;    :rate-cap
;    :rate-floor])

;;;;;;;;;;;;;;for jaegers to use;;;;;;;;;;;;;;;

(defn dissect-with
  "Dissect with value-splits in addition to general value-splits"
  [value-splits tokenvecs]
  (rs/dissect tokenvecs (into value-splits all-splits)))

(defn group-by-row
  "Groups features by table row id if present, or max-y otherwise"
  [enhik features]
  (->> features
       (group-by (some-fn (comp (partial hu/id->row-id enhik) ffirst :ids) :max-y))
       vals
       (sort-by (some-fn (comp :max-y first) :class))))

(defn group-by-col
  "Groups features by table column id if present, otherwise the features is discarded"
  [enhik features]
  (->> features
       (group-by (some-fn (comp (partial hu/id->col-id enhik) ffirst :ids) :min-x))
       vals
       (map (partial sort-by :max-y))
       (sort-by (juxt (comp :max-y first) (comp :min-x first)))))

(defn tokenvecs->row-features
  "Generates row-features using value-splits in addition to general value-splits"
  [enhik tvs value-splits]
  (->> tvs
       (tv/tokenvecs->basic-features (partial dissect-with value-splits))
       (group-by-row enhik)))

(defn features->candidates
  [field pre-types pred features]
  (->> features
       (drop-while (complement (comp pre-types :value-type :features)))
       (filter pred)
       (map #(assoc % :class field))))

; (defn enfeature-enhik [enhanced-hickory]
;   (let [features-descriptor (create-features-descriptor class-options value-splits)
;         enfeaturer (partial hu/enfeature-tokenvecs enhanced-hickory features-descriptor dissect-text)]
;     (some->>
;       enhanced-hickory
;       (ec/filter-pages 10)
;       mfu/enhik->sentence-tokenvecs
;       enfeaturer
;       (map #(assoc % :features-descriptor features-descriptor)))))

; (defn query->enhik [query]
;   (let [{:keys [input-stream] :as m} (sdfs/find-file query)]
;     (assoc (select-keys m [:filename :md5])
;       :enhanced-hickory (->> input-stream slurp html.utils/get-html ec/html->enhik (ec/filter-pages 10)))))

; (defn fname->enhik [fname] (query->enhik {:filename fname}))
; (defn md5->enhik [md5] (query->enhik {:md5 md5}))

; (defn enhiks->feature-store [id docs]
;   (let [feature-maps (mapcat (fn [{:keys [enhanced-hickory] :as m}]
;                                (map (fn [fm] (into fm (select-keys m [:md5 :filename])))
;                                     (enfeature-enhik enhanced-hickory))) docs)]
;     (->> feature-maps
;          first
;          :features-descriptor
;          (reduce (fn [m [k {:keys [options]}]]
;                    (assoc m k (if (coll? options)
;                                 {:options options}
;                                 options)))
;                  {})
;          (hash-map :jaeger id :features-descriptor)
;          (#(update-features-descriptors-by-id id % {:upsert true})))
;     {:descriptor-id (if (keyword? id) (name id) (str id))
;      :feature-map-ids (->> feature-maps
;                            (map #(-> % (assoc :descriptor-id id) (dissoc :features-descriptor)))
;                            bulk-write-feature-maps
;                            (map str))}))

;(->> "0001193125-15-285301.txt"
;     fname->enhik
;     :enhanced-hickory
;     (ec/filter-pages 1)
;     ;ec/enhik->tokenvecs
;     ;(map (fn [{:keys [min-x max-x min-y max-y] :as m}] (into m {:w (- max-x min-x) :h (- max-y min-y)})))
;     ;first
;     )

; (defn test-fn []
;   (time
;    (->> "controls/edgar-floating-corps.edn"
;         io/resource
;         slurp
;         edn/read-string
;         (map #(dissoc % :cusip))
;         distinct
;         (map query->enhik)
;         (take 5)
;         (enhiks->feature-store :spread2)
;         :descriptor-id)))

; (defn test-fn2 []
;   (time
;    (->> "controls/edgar-floating-corps.edn"
;         io/resource
;         slurp
;         edn/read-string
;         (map #(dissoc % :cusip))
;         distinct
;         (run! (fn [q] (time (enhiks->feature-store :spread2 [(query->enhik q)])))))))

;(slurp (io/resource "/controls/edgar-floating-corps.edn"))

;(->> "0001193125-15-285301.txt"
;     fname->enhik
;     :enhanced-hickory
;     enfeature-enhik
;     ;first
;
;     ;(map (fn [[k v]] [k (select-keys v [:options :default])]))
;     ;(into {})
;     )
;
;
;(enhiks->feature-store :test [(fname->enhik "0001193125-15-285301.txt")])
;;
;;;(->> "0001193125-15-285301.txt"
;;;     fname->enhik
;;;     primer/enfeature-enhik
;;;     (map :features))
