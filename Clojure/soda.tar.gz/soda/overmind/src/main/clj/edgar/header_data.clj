(ns edgar.header-data
  (:require [clojure.string :as s]
            [soda.data.file-system :as sdfs]))

(defn keywordize [s]
  (-> s s/lower-case (s/replace " " "-") keyword))

(defn- parse-header-raw [text data]
  (let [pairs (->> (s/split text #"\r?\n") (filter not-empty) (map #(s/split % #":")))]
    (loop [remaining pairs data data path []]
      (if (empty? remaining)
        data
        (let [[label value] (first remaining)
              trimmed-label (s/trim label)
              label-kw (keywordize trimmed-label)
              trimmed-value (s/trim (or value ""))
              indent (- (count label) (count trimmed-label))
              field-path (conj (subvec path 0 (* 2 indent)) label-kw)
              next-path (conj field-path (count (get-in data field-path)))
              old-values (or (get-in data field-path) [])]
          (if (empty? trimmed-value) ;If first instance of label for nested structure, populate with empty vector
            (recur (rest remaining) (assoc-in data field-path old-values) next-path)
            (recur (rest remaining) (assoc-in data field-path (conj old-values trimmed-value)) next-path)))))))

(defn q->d [query]
  (->> query sdfs/find-file :input-stream slurp))

(defn raw-doc->file-header-data [raw-doc]
  (when-let [header-text (re-find #"(?s)<SEC-HEADER>.*</SEC-HEADER>" raw-doc)]
    (let [acceptance-datetime (re-find #"(?<=<ACCEPTANCE-DATETIME>).*(?=\r?\n)" header-text)
          header-data-text (re-find #"(?s)ACCESSION NUMBER:.*(?=\r?\n</SEC-HEADER>)" header-text)]
      (when (and acceptance-datetime header-data-text)
        (parse-header-raw header-data-text {:acceptance-datetime [acceptance-datetime]})))))

(defn scrape-file-header-data [query]
  (raw-doc->file-header-data (q->d query)))

(defn unmarshal [is]
  (when-let [header-text (->> is slurp (re-find #"(?s)<SEC-HEADER>.*</SEC-HEADER>"))]
    (let [acceptance-datetime (re-find #"(?<=<ACCEPTANCE-DATETIME>).*(?=\r?\n)" header-text)
          header-data-text (re-find #"(?s)ACCESSION NUMBER:.*(?=\r?\n</SEC-HEADER>)" header-text)]
      (when (and acceptance-datetime header-data-text)
        [(parse-header-raw header-data-text {:acceptance-datetime [acceptance-datetime]})]))))

(defn get-entities [{:keys [subject-company filed-by filer filed-as-of-date]}]
  (-> (partial map (fn [entity] (assoc entity :filed-as-of-date filed-as-of-date)))
      (mapcat [subject-company filed-by filer])
      vec))

(defn flatten-entity [raw-entity-data & {:keys [current-path] :or {current-path []}}]
  (let [paths-to-plural-vals #{[:former-company]}
        is-plural? (paths-to-plural-vals current-path)]
    (cond
      (map? raw-entity-data) (into {} (for [[k v] raw-entity-data]
                                        [k (flatten-entity v :current-path (conj current-path k))]))
      (vector? raw-entity-data) (if is-plural?
                               (vec (map #(flatten-entity % :current-path current-path) raw-entity-data))
                               (flatten-entity (first raw-entity-data) :current-path current-path))
      :default raw-entity-data)))
