(ns edgar.linker-chunker
  (:require [jaegers.utils :as ju]))

(defn- get-sort-id [candidate]
  (-> candidate
      first
      second
      :ids
      ffirst
      ju/id->vec))

(defn- make-length [l len]
  (->> (concat l (repeat 0))
       (take len)
       vec))

(defn- list-compare [list-a list-b]
  (cond
    (= (count list-a) (count list-b))
    (compare list-a list-b)
    (> (count list-a) (count list-b))
    (compare list-a (make-length list-b (count list-a)))
    :else
    (compare (make-length list-a (count list-b)) list-b)))

(defn form-cusip-groups [linker-fn cusips candidates ids->coords]
  (->> candidates
       (map (fn [c] {:candidate c}))
       (concat cusips)
       (sort-by get-sort-id list-compare)
       (partition-by (comp boolean :candidate))
       (partition 2)
       (mapv (fn [[a b]]
               (if (:candidate (first a))
                 (linker-fn b (mapv :candidate a) ids->coords)
                 (linker-fn a (mapv :candidate b) ids->coords))))
       (reduce merge)))
