(ns edgar.parse-utils
  (:require [clojure.string :as cs]))

(defn realtrim [s]
  (some-> s (cs/replace #"[^\p{Graph}]+" " ") cs/trim))

(defn parse-key [k]
  (let [nk (cs/lower-case k)]
    (cond
      (cs/includes? nk "cusip") :cusip
      (cs/includes? nk "maturity date") :maturity-date
      (cs/includes? nk "issue date") :issue-date
      (= nk "interest rate") :interest-rate
      (= nk "principal amount") :principal-amount
      (= nk "interest payment frequency") :coupon-frequency
      :default nk)))
