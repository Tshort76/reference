(ns edgar.html-utils
  (:require [hickory.core :as hc]
            [html.utils :as hu]
            [clojure.string :as cs]
            [edgar.cusip-utils.generic-utils :refer [realtrim kill-bad-hombres]]
            [soda.data.file-system :as files]
            ; [simple-mind.parse-objects-utils :as pou]
            [enhanced-hickory.core :as eh]))

(defn mongo-file->html [filename]
  (let [{:keys [filename input-stream md5 id]} (files/find-file {:filename filename})]
    {:filename filename :md5 md5 :id id
     :html (-> input-stream slurp hu/get-html)}))

(defn filename->decorated-hik [filename]
  (eh/html->enhik (:html (mongo-file->html filename))))

(defn hik->lines
  [{:keys [tag type content] :as m}]
  (cond
    (#{:document} type) (flatten (mapv hik->lines content))
    (string? m) (realtrim m)
    (#{:tr :th :font} tag) (cs/join " " (flatten (map hik->lines content)))
    :default (vec (concat (filter not-empty (map hik->lines content))))))

; (defn hik->id-lines
;   [{:keys [tag type content attrs] :as m} & [id]]
;   (let [id (or (:id attrs) id)]
;     (cond
;       (#{:document} type) (flatten (mapv hik->id-lines content))
;       (string? m) {:id id :text (realtrim m)}
;       (#{:tr :th :font} tag) {:text (cs/join " " (keep (comp not-empty :text) (flatten (map hik->id-lines content)))) :id id}
;       :default (vec (concat (filter not-empty (map #(hik->id-lines % id) content)))))))

(defn html->lines [html-str]
  (->> html-str
       hc/parse
       hc/as-hickory
       hik->lines
       (mapv kill-bad-hombres)))

; (defn regex-lines [lines regex]
;   (reduce
;     (fn [v {objs :objs}]
;       (conj v {:text (cs/join " " (map :text objs)) :ids (map :id objs)}))
;     []
;     (pou/rematch-in regex [:text] lines)))

(defn submission-sections
  "Parses a string representing a complete submission file from edgar into a
   vector of maps, one per section, with each map transformed by xform-fn."
  [s & {:keys [xform-fn] :or {xform-fn identity}}]
  (loop [rm (re-matcher #"(?m)^<DOCUMENT>[\r\n]+<TYPE>(.+)$" s)
         res []]
    (if-let [contents (and (.find rm)
                           (not-empty (subs s (.start rm)
                                            (cs/index-of s "</DOCUMENT>" (.start rm)))))]
      (recur rm (conj res (xform-fn {:section (.group rm 1)
                                     :contents contents})))
      res)))

(defn submission-section-enhiks [s]
  (submission-sections s :xform-fn
    (fn [{:keys [section contents] :as m}]
      (cond-> m
              (re-find #"^EX-(?:21|8)(?:[.]|$)" section)
              (assoc-in [:enhanced-hickory :submission] (some-> contents hu/get-html eh/html->enhik))
              (and (re-find #"^10-K$" section)
                   (re-find #"(?m)^<FILENAME>.+\.html?$" contents))
              (assoc-in [:raw :ten-k] (some-> contents hu/get-html))))))
; (assoc-in [:enhanced-hickory :ten-k] (some-> contents hu/get-html eh/html->enhik))

;; debug stuff
; (defn html-clean [html-str]
;   (-> html-str
;       (cs/replace #"&#\w{1,5};" "")
;       (cs/replace #"<[^<>]*?>" "")
;       ; (cs/replace #"[\n\r]" " ")
;       (cs/replace #"\s\s+" " ")))

; (defn print-submission-sections [s]
;   (loop [rm (re-matcher #"(?m)^<DOCUMENT>[\r\n]+<TYPE>(10-K|EX-.+)$" s) c 0]
;     (if-let [type (second (re-find rm))]
;       (let [contents (not-empty (subs s (.start rm)
;                                        (cs/index-of s "</DOCUMENT>" (.start rm))))
;             clean-contents (html-clean contents)]
;         (println type " ->" (count clean-contents))
;         (println (subs clean-contents 0 (min 2000 (count clean-contents))))
;         (recur rm (inc c)))
;       c)))
