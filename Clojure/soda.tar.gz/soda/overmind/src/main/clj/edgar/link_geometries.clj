(ns edgar.link-geometries)

;TODO move this ns to linker
(defn create-geometry-maps [{:keys [type content attrs]}]
  (let [[term & r] content {:keys [id min-x min-y max-x max-y]} attrs]
    (if (and (#{:element} type) (empty? r) (string? term) id)
      (zipmap
        [:term :id :min-x :min-y :max-x :max-y]
        (concat [term id] (map #(or % 0) [min-x min-y max-x max-y]))) ; todo: Probably shouldn't replace nil with 0
      (flatten (filter seq (map create-geometry-maps content))))))

(defn create-ids->geometries-map [geometry-maps]
  (zipmap
    (map :id geometry-maps)
    (map #(select-keys % [:min-x :min-y :max-x :max-y]) geometry-maps)))

(defn add-jaeger-doc-geom [ids->geoms {:keys [ids] :as m}]
  (assoc m :coords (ids->geoms (ffirst ids))))

(defn add-muni-doc-geom [ids->geoms {:keys [ids] :as m}]
  (assoc m :coords (ids->geoms (first (sort (flatten ids))))))

(defn create-security-nodes [cusip-docs ids->geom]
  (map
    (fn [cusip-doc] (zipmap (keys cusip-doc) (flatten (map ids->geom (vals cusip-doc)))))
    cusip-docs))

(defn create-muni-security-nodes [cusip-docs ids->geom]
  (let [result (map (fn [cusip-doc] {:cusip-3 (ids->geom (:cusip-3 cusip-doc))})
                    cusip-docs)]
    result))

(defn create-solution-nodes [candidates ids->geom]
  (zipmap (keys candidates) (map (fn [v] (flatten (map ids->geom v))) (vals candidates))))
