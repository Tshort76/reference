(ns nlp.core
  (:require
    [clojure.java.io :as io]
    [opennlp.nlp :as nlp]))

(def sentence-detector (nlp/make-sentence-detector (io/resource "models/en-sent.bin")))

(defn parse-sentences [text]
  (let [sentences (sentence-detector text)
        spans (->> sentences meta :spans vec)]
    (->> sentences
         (partition 2 1 nil)
         (map-indexed
           (fn [i [a b]]
             (let [to-start (->> i (nth spans) :start)
                   to-end (- (count text) (->> i (nth spans) :end))
                   to-next (- (or (-> spans (get (inc i)) :start) 0)
                              (->> i (nth spans) :end))]
               (-> []
                   (into (repeat (if (zero? i) to-start 0) " "))
                   (into [a])
                   (into (repeat (if (nil? b) to-end to-next) " "))
                   (->> (apply str)))))))))

