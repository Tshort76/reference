(ns tokenvec.core
  (:require [clojure.spec.alpha :as spec]
            [soda.core :as soda]
            [tokenvec.spec]))

(defn valid? [tokenvec]
  (case (first tokenvec)
    (nil "") false
    true))

(defn tokens->tokenvec [tokens]
  {:pre  [(spec/assert :tokenvec/tokens tokens)]}
  ;  :post [(spec/assert :tokenvec/tokenvec %)]}
  (some->> tokens
           not-empty
           (map (fn [{:keys [text] :as token}] [text (vec (repeat (count text) token))]))
           (reduce (fn [[s0 t0] [s1 t1]] [(str s0 " " s1) (into (conj t0 nil) t1)]))))

(defn tokenvec-splitter
  "Take a tokenvec [string [tokens]] and split it into more tokenvecs via a function that operates on string.
  For example, a sentence splitter could be applied to a paragraph string."
  [splitfn [string tokenvec :as v]]
  {:pre [(spec/assert (spec/fspec :args (spec/cat :text string?) :ret (spec/coll-of string?)) splitfn)
         (spec/assert :tokenvec/tokenvec v)]}
  (loop [[s & r] (splitfn string) vecs tokenvec res []]
    (if s
      (let [[a b] (split-at (count s) vecs)]
        (recur r b (conj res [s (vec a)])) )
      res)))

(defn reduce-fields [[ids min-x min-y max-x max-y]]
  (letfn [(f [m s](some->> s (filter number?) seq (apply m)))]
    {:ids   [(some->> ids (filter identity) distinct vec)]
     :min-x (f min min-x) :min-y (f min min-y)
     :max-x (f max max-x) :max-y (f max max-y)}))

; (defn tokensplit [split-defs [sentence tokenvec]]
;   [sentence
;    (->> (soda/regex-multisplit sentence split-defs)
;         (filter :re-pattern)
;         (map (fn [{:keys [start end] :as m}]
;                (into m
;                      (->> (range start end)
;                           (map (comp (juxt :id :min-x :min-y :max-x :max-y) tokenvec))
;                           (apply map vector)
;                           reduce-fields))))
;         (filter seq)
;         (map (fn [{:keys [value] :as m}] (into m value))))])

(defn unique-tokens
  [toks indices]
  {:pre [(vector? toks)
         (spec/assert (spec/coll-of int? :distinct true) indices)]}
  (vec (filter identity (distinct (apply subvec toks indices)))))

(defn tokenvec->basic-features [dissector [s tvs]]
  (distinct
    (for [{:keys [indexes] :as feature} (dissector s)
          :when (seq indexes)
          :let [tvs (distinct (for [i (apply range indexes) :let [tv (tvs i)] :when tv] tv))
                ids [(vec (filter identity (map :id tvs)))]
                min-x (some->> tvs (map :min-x tvs) (filter number?) seq (apply min))
                min-y (some->> tvs (map :min-y tvs) (filter number?) seq (apply min))
                max-x (some->> tvs (map :max-x tvs) (filter number?) seq (apply max))
                max-y (some->> tvs (map :max-y tvs) (filter number?) seq (apply max))]]
      (into feature {:ids ids :min-x min-x :max-x max-x :min-y min-y :max-y max-y}))))

(defn tokenvecs->basic-features [dissector tokenvecs]
  (mapcat (partial tokenvec->basic-features dissector) tokenvecs))
