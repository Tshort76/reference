(ns simple-mind.k-means)

;; Absolutely brazenly stolen from:
;; http://www.learningclojure.com/2011/01/k-means-algorithm-for-clustering-data.html

(defn closest [point means distance-fn]
  (apply min-key #(distance-fn % point) means))

(defn point-groups [means data distance-fn]
  (group-by #(closest % means distance-fn) data))

(defn new-means [average point-groups old-means]
  (for [o old-means]
    (if (contains? point-groups o)
      (apply average (get point-groups o)) o)))

(defn iterate-means [data distance-fn average]
  (fn [means] (new-means average (point-groups means data distance-fn) means)))

(defn groups [data distance-fn means]
  (vals (point-groups means data distance-fn)))

(defn take-while-unstable 
  ([sq] (lazy-seq (if-let [sq (seq sq)]
                    (cons (first sq) (take-while-unstable (rest sq) (first sq))))))
  ([sq last] (lazy-seq (if-let [sq (seq sq)]
                         (if (= (first sq) last) '() (take-while-unstable sq))))))

(defn k-groups [data distance-fn average-fn]
  (fn [guesses]
    (take-while-unstable
      (map #(groups data distance-fn %)
           (iterate (iterate-means data distance-fn average-fn) guesses)))))
 
(defn distance [a b] (if (< a b) (- b a) (- a b)))
(defn vec-distance [a b] (reduce + (map #(* % %) (map - a b))))
(defn vec-average  [& d] (map #(/ % (count d)) (apply map + d)))

(defn selector-distance [selector-fn distance-fn a b] (distance-fn (selector-fn a) (selector-fn b)))
(defn selector-average [selector-fn average-fn & d] (apply average-fn (map selector-fn d)))

