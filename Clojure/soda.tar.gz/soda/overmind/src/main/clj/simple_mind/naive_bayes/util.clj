(ns simple-mind.naive-bayes.util
  (:require
    [clojure.string :as s]
    [simple-mind.naive-bayes.core :as nb]
    [simple-mind.naive-bayes.normalize :as nbn]))

(def ->words #(s/split % #"[\r\p{Z}]+"))

(defn train-all
  "Trains model for class cls on n-grams from texts (a collection of strings)"
  [model cls texts & {:keys [n cls-weights normalize-fn] :or {n 1 cls-weights {} normalize-fn nbn/normalize-words}}]
  (reduce (fn [m txt]
            (nb/train m cls (-> txt ->words (nb/->bag-of-words :n n :weight (get cls-weights cls) :normalize-fn normalize-fn))))
          model texts))
