(ns simple-mind.naive-bayes.core
  (:require
    [clojure.string :as string]
    [simple-mind.naive-bayes.normalize :refer :all]))

(defn train 
  "Trains a model for class cls on features in bag-of-words"
  ([cls bag-of-words]
   (train {} cls bag-of-words))
  ([model cls bag-of-words]
   (reduce (fn [m [k v]] (update-in m [cls k] (fnil + 0) v)) model bag-of-words)))

(defn weight-words
  [{:keys [weight words] :or {weight 1}} freqs]
  (let [pattern (re-pattern (string/join "|" (normalize-words words)))
        rf (fn [m k v] (assoc m k (cond-> v (re-find pattern (name k)) (* weight))))]
    (reduce-kv rf {} freqs)))

(defn ->bag-of-words
  "Returns a frequency map of the n-grams from words"
  [words & {:keys [n weight prefix normalize-fn] 
            :or {n 1, weight {}, prefix "", normalize-fn normalize-words}}]
  (->> words
       normalize-fn
       (partition n 1) 
       (map (partial string/join "_"))
       (map (partial str prefix))
       (map keyword)
       frequencies
       (weight-words weight)
       (into {})))

(defn total-word-count [model word]
  (reduce (fn [sum [_ m]] (+ sum (get m word 0))) 0 model))

(defn smoothed-feature-count [model alpha words clazz]
  (into {} (map (fn [word]
         { word (+ (get-in model [clazz word] 0) alpha)}) words)))

(defn all-words-set [model]
  (into #{} (mapcat keys (vals model))))


(defn smoothed-class-count [model alpha clazz]
  (let [all-words (all-words-set model)]
  (apply + (map (fn [word]
                  (+ (get-in model [clazz word] 0) alpha)) all-words))))

(def mem-smoothed-class-count (memoize smoothed-class-count))

(defn calc-log [smoothed-cc smoothed-fc clazz word alpha]
  (- (Math/log (get-in smoothed-fc [clazz word] alpha)) (Math/log (get smoothed-cc clazz))))

(defn class-feature-log-prob [alpha smoothed-fc smoothed-cc words clazz]
  (into {} (map (fn [word]
                  { word (calc-log smoothed-cc smoothed-fc clazz word alpha)})
                words)))

(defn feature-log-prob [model alpha words]
  (let [smoothed-fc (into {} (map (fn [clazz] {clazz (smoothed-feature-count model alpha words clazz)}) (keys model)))
        smoothed-cc (into {} (map (fn [clazz] {clazz (mem-smoothed-class-count model alpha  clazz)}) (keys model)))
        flp (into {} (map (fn [clazz] {clazz (class-feature-log-prob alpha smoothed-fc smoothed-cc words clazz)}) (keys model)))]
  flp))


(defn class-log-likelihood [bag-of-words flp clazz]
  (reduce + (map (fn [word] (* (get-in flp [clazz word])
                               (get bag-of-words word))) (keys bag-of-words))))

(defn joint-log-likelihood [model bag-of-words]
  (let [words (keys bag-of-words)
        flp (feature-log-prob model 1.0 words)]
    (into {} (map (fn [clazz] {clazz (class-log-likelihood bag-of-words flp clazz)}) (keys model)))))


(defn prob [model word cls]
  (let [n (+ (get-in model [cls word] 0) 1.0)
        d (+ (total-word-count model word) (count (keys model)))]
    (/ n d)))

(defn combine-probs [probs]
  (let [p (reduce * probs)
        invp (reduce * (map (partial - 1) probs))
        denom (+ p invp)]
    (when (> denom 0) (/ p denom))))

(defn get-probs 
  "Calculates probability of each word in bag-of-words to occur in a document for every class in model"
  [model bag-of-words]
  (reduce (fn [result [word ct]] 
            (reduce (fn [result cls] 
                      (update result cls (fnil + 0) (* ct (Math/log10 (prob model word cls))))) 
                    result (keys model)))
          {} bag-of-words))

(defn classify 
  "Classifies feature set represented by bag-of-words using model. Returns the
   class, or a vector of [class, probability] pairs if verbose? is truthy."
  [model bag-of-words & [verbose?]]
  (let [result (->> bag-of-words (get-probs model) (sort-by val >))]
    (cond
      (or (empty? result) (apply = (map second result))) (if verbose? [[:bayes/unclassified 0]] :bayes/unclassified)
      verbose? result
      :else (ffirst result))))


(defn get-word-set [model]  (into #{} (flatten (map (fn [[k v]] (keys v)) model))))
(def m-get-word-set (memoize get-word-set))

(defn classify-multinomial
  "Classifies feature set represented by bag-of-words using model. Returns the
   class, or a vector of [class, probability] pairs if verbose? is truthy."
  [model bag-of-words & [verbose?]]
  (let [word-set (m-get-word-set model)
        clean-bag (into {} (filter (comp word-set first) bag-of-words))
        result (->> clean-bag (joint-log-likelihood model) (sort-by val >))
        ]
    (cond
      (or (empty? result) (apply = (map second result))) (if verbose? [[:bayes/unclassified 0]] :bayes/unclassified)
      verbose? result
      :else (ffirst result))))


;; TESTS -----------------------------------------------------------------------

#_(let [classes [:spade :heart :diamond :club]
      model (-> (train :spade (->bag-of-words ["spade" "black" "black"]))
                (train :club (->bag-of-words ["club" "black"]))
                (train :heart (->bag-of-words ["heart" "red"]))
                (train :diamond (->bag-of-words ["diamond" "red"])))]
  (classify model (->bag-of-words ["black"]) true))
