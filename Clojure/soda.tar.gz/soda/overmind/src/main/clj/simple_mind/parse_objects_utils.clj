(ns simple-mind.parse-objects-utils
   (:require
      [clojure.data.json :as json]
      [clojure.pprint :refer :all]
      [simple-mind.stopwords :as stopwords]
      [clojure.string :as cstr]
     ))

(defn in-seq? [value a-sequence]
  (some? (some #{value} a-sequence)))

(defn ->text
  "Given a parse-object, pulls all the :text values from the :vals entries
  and joins them.  Preserveres lines in the joined text, with new lines and word
  boundaries with spaces"
  [an-object]
  (cstr/join "\n" (map (fn [l] (cstr/join " " (map :text l))) (:vals an-object))))

(defn cell->text [cell]
  (:text cell))

(defn row->text [row]
  (into [] (map cell->text row)))

(defn table->text [a-table]
  (into [] (map row->text (:vals a-table))))




; (defn text-density
;   "Calculates the ratio of numerics to non-numerics in the text,
;   this can be useful for estimating if text contains data or not"
;   [an-object]
;   (let [ text (->text an-object)
;          nums (re-seq #"\d" text)
;         num-count (count nums)
;         all-count (count text)]
;     (if (< 0 all-count)
;       (float (/ num-count all-count))
;       0)))


(defn re-positions
  "Find occurrences of the regex in the string, recording meta-data
  for each match"
  [regex group string]
  (loop [matcher (re-matcher regex string)
         results  []]
    (if (.find matcher)
      (recur matcher (conj results {:start (.start matcher group)
                                    :end (.end matcher group)
                                    :text (.group matcher group) :objs []}))
      results)))

(defn strs->objs
  "Associate text-containing objects with the indices that were determined
  from concatenating the text (with spaces)."
  [key-vec objects matches]
  (loop [objs objects matches matches results [] char-pos -1 index 0]
    (if-let [continue? (and (first matches) (first objs))]
      (let [obj (first objs)
            txt-len (count (get-in obj key-vec))
            new-pos (+ txt-len char-pos 1) ;+1 since space characters are accounted for when building matches but are not represented in the objects
            match (first matches)]
        (if (< new-pos (:start match))  ;is the end of the word after (inclusive) the match's starting index?
          (recur (rest objs) matches results new-pos (inc index))
          (if (<= (- new-pos txt-len) (:end match))   ;is the start of the word before (inclusive) the match's ending index
            (recur (rest objs) (map (fn [{:keys [start end] :as m}]
                                      (cond-> m
                                        (and (>= new-pos start) (<= char-pos end))
                                        (update :objs conj obj))) matches) results new-pos (inc index))       ;this obj belongs in all overlapping matches
            (recur objs (into [] (rest matches)) (conj results (assoc match :index-last (dec index))) char-pos index))))      ;this word is beyond the match, save off the match to results
      (if (empty? matches)
        results
        (conj results (first matches))))))


(defn rematch-in
  "Run a regex search across the aggregation of text-containing associative objects,
  finding the objects that are associated with each pattern match"
  [pattern key-vec data & {:keys [group] :or {group 0}}]
  (->> data
       (map #(get-in % key-vec))   ;locate the text for the associative object
       (clojure.string/join " ")   ;concat together so we do a regex search
       (re-positions pattern group)      ;find the matches and their indices in the string
       (strs->objs key-vec data)   ;map the matches back to their associated objects
       (map #(dissoc % :start :end))))

(defn re-pos
  "finds all the occurences of the given regular expression
   in the string, returning the start, stop and match group"
  [re s]
     ;;(println (str re s))
     (loop [m (re-matcher re (str s))
               res  []]
          (if (.find m)
            (recur m (conj res [ (.start m) (.end m) (.group m)]))
            res)))


(defn count-matches [re string] (count (re-pos re string)))

(defn count-matches-row [re row] (reduce + (map (partial count-matches re) row)))

(defn count-matches-table [re table] (map (partial count-matches-row re) table))

(defn count-all-matches-table [re-list table]
  (apply map + (map (fn [re] (count-matches-table re table)) re-list)))

(defn find-table-pattern
  "Turns table into string representing how much data is there.
  For example, a normal table will be '0111', where as a table
  with header, data ,header, data would be '0101'"
  [re-list table]
  (let [counts  (count-all-matches-table re-list table)
        min-counts (map (fn [d] (- d (apply min counts))) counts)]
    (apply str (map (fn [d] (if (> d 0) 1 0)) min-counts))
    ))



(defn merge-structures
  "Given a list of parse-objects, merges them into one parse object, sets
  the value to text"
  [a-partition]
 ;; (pprint a-partition)
  [{ :type "text"
     :vals   (apply concat (map :vals a-partition))
  }]
  )


(defn process-partition
  "Given a partition (list) of parse-objects, if the the first object
  in the list is in the types-to-merge, merges all the parse objects
  assumes that only objects of the types-to-merge are in list.
  will return a text type object"
  [types-to-merge a-partition]
  (let [ first-type (get (first a-partition) :type )]
   ;; (pprint first-type)
    (if (in-seq? first-type types-to-merge )
      (merge-structures a-partition)
      a-partition)))

; (defn merge-by-type
;   "merges consecutive structures of the given types and converts them
;   to a text structure with multiple new lines between each type."
;   [structure-list types-to-merge]
;   (let [partitions  (partition-by  (fn [s] (in-seq?  (get s :type) types-to-merge)) structure-list)
;         processed (map (partial process-partition types-to-merge) partitions)]
;    ;; (pprint partitions)
;     (flatten processed)))

(defn add-headers [headers row]
  (map vector headers row))

(defn process-table-0101
  "Zips the headers row over each of the rows of data.  Adds special word before the header
  text, so words are not removed as partial words."
  [parse-object]
  (let [ headers (flatten (take-nth 2  (:vals parse-object)))
         data (flatten (take-nth 2 (drop 1 (:vals parse-object))))
         tagged-rows (add-headers headers data)]
     (map (fn [c]  {:type "text" :vals [c]} ) tagged-rows)
    ))

(defn process-table-0111
"represents the naive way of parsing a table, where the first
  row are the headers and the rest represent cells of data"
  [parse-object]
  (let [headers (first (:vals parse-object))
        rows (rest (:vals parse-object))
        tagged-rows (map (partial add-headers headers) rows)
        tagged-cells (apply concat tagged-rows) ]
      (map (fn [c]  {:type "text" :vals [c]} ) tagged-cells)
    ))

(defn process-table-structure-finder
  "Uses the regular expression list to find out the data density of the rows,
  then decides how to 'fix' the table to add context to the data"
  [re-list parse-object]
  (let [ table-pattern (find-table-pattern re-list (table->text parse-object))]
    ;;(pprint (table->text parse-object))
   ;; (pprint table-pattern)
    (cond
      (re-matches #"01+" table-pattern) (process-table-0111 parse-object)
      (re-matches #"(01)+" table-pattern) (process-table-0101 parse-object)
      :else parse-object))) ;pass-through



(defn transform-structure
  "transforms all structures to text bits for processing"
  [data-detectors structure]
  (case (:type structure)
    "table"  (process-table-structure-finder data-detectors structure)
    [structure]))

; (defn get-text-bits [data-detectors structure-list]
;   (reduce into [] (map (partial transform-structure data-detectors) structure-list)))

(defn- add-context
  "Associate neighboring text with each text match"
  [data-items pre-len post-len matches]
  (let [data (if (vector? data-items) data-items (into [] data-items))]
    (map #(let [index-last (if-let [i (:index-last %)] i (dec (count data-items)))
                index-first (inc (- index-last (count (:objs %))))
                to-text (fn [l u] (mapv :text (subvec data l u)))]
            (assoc % :prev-context (to-text (max 0 (- index-first pre-len)) index-first)
                     :post-context (to-text (inc index-last) (min (count data) (+ index-last post-len 1)))))
         matches)))

(defn find-particles
  "Runs a rematch-in across data and then add contexts to each of
  the resulting items"
  [regex span-before span-after data]
  (->> data
       (rematch-in regex [:text])
       (map #(assoc % :ids (mapv :id (:objs %))))
       (add-context data span-before span-after)
       (mapv #(dissoc % :objs :index-last))))



(defn find-objs-particles
  "Runs a rematch-in across data and then add contexts to each of
  the resulting items.  Wraps find-particles so that it works on
  objects produced by the pdf_transformer.  Assumes the text is nested
  in vectors of vectors."
  [regex span-before span-after {obj-vals :vals}]
  (->> obj-vals
       (mapv (fn [line] (update-in line [(dec (count line)) :text] #(str %1 "\n")))) ;for each line, add a newline character to the last word in a line
       flatten
       (find-particles regex span-before span-after)))

(defn normalize-context [word-list string-normalizer]
   (remove stopwords/stopwords (string-normalizer (cstr/join " " word-list))))

(defn build-data-particle [particle-name string-normalizer particle-match]
  {
   :particle-type particle-name
   :words-before (normalize-context (:prev-context particle-match) string-normalizer)
   :words-after  (normalize-context (:post-context particle-match) string-normalizer)
   :value (:text particle-match)
   :context  (cstr/join " " (concat (:prev-context particle-match) [(:text particle-match)] (:post-context particle-match)))
   :ids (:ids particle-match)
   :polarity "unknown"
  })

;; a data particle is a keyword and regular expression pair.
;; for a given particle, generates a list of particle vectors [keyword start stop match-string]
(defn find-data-particles [parse-object string-normalizer particle-definition]
  (let [ particle-name (first particle-definition)
         particle-regex (second particle-definition)
         all-matches (find-objs-particles particle-regex 6 6 parse-object)]
    (map (partial build-data-particle particle-name string-normalizer) all-matches)))


;; finds all the data particles in the muni-data particles by mapping
;; in the given string.
; (defn find-all-particles [parse-object particle-definitions string-normalizer]
;   (into [] (mapcat (partial find-data-particles parse-object string-normalizer) particle-definitions)))
