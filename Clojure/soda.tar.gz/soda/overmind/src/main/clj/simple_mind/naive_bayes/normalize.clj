(ns simple-mind.naive-bayes.normalize
  (:require 
    [clojure.string :as string]
    [clj-fuzzy.stemmers :as stem]
    [soda-common.regexes :as re]
    [simple-mind.stopwords :refer [stopwords]]))

(def not-contains? (complement contains?))
(def letters (map (comp str char) (into (range 65 91) (range 97 123))))

(defn norm-with-re [words re normv]
  (map (fn [w] (if (re-find re w) normv w)) words))
 
(def norm-case (partial map string/lower-case))
(def norm-empty (partial remove (comp empty? #(string/replace % #"^\p{Z}+|\p{Z}$" ""))))
(def norm-chars (partial map #(string/replace % #"[^A-Za-z_]" "")))
(def norm-stopwords (partial filter (fn [w] (not-contains? (into stopwords letters) w))))
(def norm-stems (partial map #(stem/porter %)))
(defn norm-money [words] (norm-with-re words (re-pattern (str "^" re/money-like "$")) "__money__"))
(defn norm-percents [words] (norm-with-re words (re-pattern (str "^" re/percent-like "$")) "__percent__"))
(defn norm-numbers [words] (norm-with-re words (re-pattern (str "^" re/double-like "$")) "__number__"))
(defn norm-cusip9s [words] (norm-with-re words (re-pattern (str "^" re/cusip-9-like "$")) "__cusip9__"))
(defn norm-months [words] (norm-with-re words (re-pattern (str "(?i)^" re/month-names "$")) "__month__"))
(defn norm-years [words] (norm-with-re words (re-pattern (str "^" re/four-digit-year "$")) "__year__"))
(defn norm-states [words] (norm-with-re words (re-pattern (str "^" re/state-names "$")) "__state__"))
(def norm-small-words (partial remove (fn [w] (< (count w) 3))))

(def normalize-words (comp norm-empty norm-chars norm-stems norm-numbers norm-money norm-percents norm-cusip9s norm-months norm-years norm-states norm-stopwords norm-case))
