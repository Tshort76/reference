(defproject
  com.clearwateranalytics/overmind "1.46-SNAPSHOT"
  :description "overmind prospectus parser"
  :parent-project {:coords [com.clearwateranalytics/soda-meta-parent "0.2-SNAPSHOT"]
                   :inherit [:global-vars
                             :license
                             :managed-dependencies
                             :min-lein-version
                             :parent
                             :url
                             :javac-options]}
  :dependencies
  [[aysylu/loom]
   [cc.artifice/clj-ml]
   [cheshire]
   [clj-fuzzy]
   [clj-http]
   [clj-time]
   [clojure-opennlp]
   [clojure-stemmer]
   [com.clearwateranalytics/pdf-transforms "1.44-SNAPSHOT"]
   [com.clearwateranalytics/soda-common "1.46-SNAPSHOT"]
   [com.cognitect/transit-clj]
   [com.grammarly/perseverance]
   [com.novemberain/monger]
   [com.taoensso/timbre]
   [com.taoensso/tufte]
   [commons-lang/commons-lang]
   [datascript]
   [digest]
   [environ]
   [hiccup]
   [hiccup-bridge]
   [hickory]
   [instaparse]
   [jline/jline]
   [net.sourceforge.jtds/jtds]
   [org.clojure/clojure]
   [org.clojure/core.async]
   [org.clojure/core.match]
   [org.clojure/data.csv "0.1.2"]
   [org.clojure/data.json]
   [org.clojure/data.xml]
   [org.clojure/data.zip]
   [org.clojure/math.combinatorics]
   [org.clojure/tools.trace]
   [wit/duckling]
   [yesql]]

  ; :offline true
  :exclusions [org.apache.lucene/lucene-analyzers-common]

  :plugins [[lein-parent "0.3.4"]
            [lein-environ "1.1.0"]
            [lein-modules "0.3.11"]
            [lein-pprint "1.2.0"]
            [com.clearwateranalytics/lein-cwan-alpha "0.2.11"]]

  ;; The following is used when the class path is too long (error 206 on Windows)
  :eval-in ~(if (= "Linux" (System/getProperty "os.name")) :subprocess :classloader)

  :jvm-opts  ["-Xmx4g" "-server" "-XX:-OmitStackTraceInFastThrow"]

  :aot :all
  :jar-exclusions [#"\.swp|\.swo|\.DS_Store"]
  :profiles {:uberjar {:aot :all}
             :dev     [:project/dev :profiles/dev]
             :test    [:project/test :profiles/test]
             :project/dev  {:env {:dev "true"}
                            :global-vars {*assert* true}
                            :resource-paths ["src/test/resources"]}
             :project/test {:env {:test "true"}
                            :global-vars {*assert* true}
                            :resource-paths ["src/test/resources"]
                            :dependencies   [[pjstadig/humane-test-output "0.8.3"]]
                            :injections     [(require 'pjstadig.humane-test-output)
                                             (pjstadig.humane-test-output/activate!)]}
             :profiles/dev {}
             :profiles/test {}}

  :source-paths ["src/main/clj" "src/main/cljc"]
  :test-paths ["src/test/clj" "src/test/cljc"]
  :resource-paths ["src/main/resources" "src/main/clj" "src/main/cljc"]

  :repositories ^:replace
  [["releases" {:url "https://artifactory.arbfund.com/releases-group"}]
   ["snapshots" {:url "https://artifactory.arbfund.com/snapshots-group"}]]

  :packaging "jar"

  :repl-options {:timeout 120000
                 :aot [clojure.tools.logging]
                 :init (do (require '[soda-common.logger])
                           (soda-common.logger/init-logging! "com.clearwateranalytics.overmind"))})
